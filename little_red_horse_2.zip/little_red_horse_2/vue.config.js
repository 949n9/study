const TerserPlugin = require('terser-webpack-plugin')
const CompressionWebpackPlugin = require('compression-webpack-plugin')
module.exports = {
  baseUrl: '/',
  productionSourceMap: false,
  devServer: {
    open: true
  },
  css: { // 配置css模块
    loaderOptions: { // 向预处理器 Loader 传递配置选项
      less: { // 配置less（其他样式解析用法一致）
        javascriptEnabled: true // 设置为true
      }
    }
  },
  configureWebpack: {
    optimization: {
      minimizer: [
        new TerserPlugin({
          terserOptions: {
            compress: {
              drop_console: true
            }
          }
        }),
        new CompressionWebpackPlugin({
          algorithm: 'gzip',
          test: /\.js$|\.html$|.\css/, // 匹配文件名
          threshold: 10240,
          minRatio: 0.8
        })
      ]
    }
  }
}
