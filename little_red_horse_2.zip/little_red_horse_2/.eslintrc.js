module.exports = {
  root: true,
  env: {
    node: true
  },
  'extends': [
    'plugin:vue/essential',
    '@vue/standard'
  ],
  rules: {
    'no-console': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    'no-debugger': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    'space-before-function-paren': 0,
    'indent': 0,  // 缩进
    'vue/no-parsing-error': 0,
    'no-unused-expressions': 0,
    'eqeqeq': 0,
    'object-curly-spacing': 0,
    'camelcase': 0
  },
  parserOptions: {
    parser: 'babel-eslint'
  }
}
