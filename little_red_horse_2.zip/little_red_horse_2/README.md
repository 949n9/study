# 小红马

#### 项目介绍


#### 软件架构

1. 表现层：
* store/ - Vuex 状态管理
* router/ - vue-router前端路由
* views/ - 各个业务页面
* assets/ - 公共资源
* components/ - 通用组件

2. 业务层：

3. API 层：
* 接口API

4. util层：
* util

#### 目录结构
```
/src
  ├── assets/        # 公共资源
  ├── common/        # 统用配置
  ├── components/    # 统用组件
  ├── core/          # API接口
  ├── filters/       # 通用过滤器
  ├── mixins/        # 全局混合
  ├── store/         # 全局的 Store
  ├── views/         # 视图（页面）
  │
  ├── App.vue        # 根组件
  └── main.js       # 入口配置
```

#### 项目依赖
```
     "dependencies": {
         "axios": "^0.18.0",
         "clipboard": "^2.0.4",
         "element-ui": "^2.4.11",
         "font-awesome": "^4.7.0",
         "iview": "^3.2.1",
         "moment": "^2.23.0",
         "normalize.css": "^8.0.1",
         "qs": "^6.6.0",
         "vue": "^2.5.17",
         "vue-router": "^3.0.1",
         "vuex": "^3.0.1",
         "vuex-persistedstate": "^2.5.4"
       },
```


#### 安装教程

###### Project setup
```
npm install
```

###### Compiles and hot-reloads for development
```
npm run serve
```

###### Compiles and minifies for production
```
npm run build
```

#### 使用说明

###### 交互相关

###### 参考文档：

#### 注意事项

.........................................