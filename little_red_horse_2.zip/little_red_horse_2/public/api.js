(function () {
  let config = {
    site: 'test.mall.redhoma.cn/ccb/pc/'
    // site: '192.168.13.136/ccb/pc/'
    // site: 'pcapi.ccb.redhoma.cn/'
    // site: '192.168.13.171:7075'
    // site: '192.168.13.125:7071/ccbpc/'
    // site: '192.168.13.194:8084/fuwushe_ccbpc_web_war_exploded/'
  }
  window.configs = {
    API_ROOT: 'http://'.concat(config.site),
    TITLE: '小红马'
  }
})()
