import Vue from 'vue'
import App from './App.vue'
import router from './router/index'
import store from './store/index'
import iView from 'iview'
import '@babel/polyfill'
import * as filters from './filters/index'
import mixins from './mixins/index'
import 'normalize.css'
import './assets/css/resert.css'
import moment from 'moment'
// import 'iview/dist/styles/iview.css'

import './assets/my-theme/index.less'

import {Table, TableColumn, Dialog, Loading, Tree} from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import clipboard from 'clipboard'

Vue.use(Table)
Vue.use(TableColumn)
Vue.use(Dialog)
Vue.use(Tree)
Vue.use(Loading.directive)

Vue.prototype.$loading = Loading.service
// 按需引入element-ui的loading
Vue.prototype.$clipboard = clipboard
// 复制粘贴插件
moment.locale('zh-cn')
// 时间处理插件
Vue.prototype.$moment = moment
// 注册全局过滤器
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})

Vue.use(iView)
Vue.config.productionTip = false
// 全局混入
Vue.mixin(mixins)

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
