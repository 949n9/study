let API_ROOT = window.configs.API_ROOT

let apiHYZ = {
  Login: 'user/login/',
  LogOut: 'user/logOut/',
  // 订货单位列表
  SubCustomerList: 'user/subCustomerList/',
  CustomerSupplierList: 'select/customerSupplierList',
  SelectSupplierList: 'select/subcustomerList/',
  // 选择订货单位列表
  SelectSubCustomer: 'user/selectSubCustomer/',
  // 商品分类
  Product2Category: 'product/productCategoryMeanwhileTwoAndThree',
  // 首页商品
  ProductList: 'home/product/',
  // 近期新品
  NewProductList: 'product/categoryProduct/',
  // 爆品促销
  PromotionProduct: 'product/promotionProduct/',
  // 热卖推荐
  HotProductList: 'product/hotProduct/',
  // 地配商品
  SupplierProductList: 'product/supplier/list/',
  // 分类商品 查询
  CategoryProductList: 'product/categoryProduct/',
  // 统一搜索商品
  ProductUnifiedSearchList: 'elastic/search/', // 统一搜索商品
  // 收藏的商品列表
  CollectionProductList: 'product/collectionProduct/',
  // 支付成功后的推荐商品
  GuideProduct: 'product/guideProduct/',
  CategoryList: 'tree/productCategory/',
  BannerList: 'user/materialList/',
  MaterialProduct: 'product/material/',
  BandList: 'select/brandList/',
  CategoryBandList: 'product/brandListByCode',
  PropertyList: 'select/productPropertyList/',
  ProductDetailInfo: 'product/productDetail/',
  ProductSeriesInfo: 'product/productSet/', // 商品系列信息
  ProductDateInfo: 'product/periodProductDetail/', // 商品生产月份信息
  ProductAttachList: 'product/productAttachList/',
  SupplierProductDetail: 'product/supplier/detail/',
  SupplierProductSeriesInfo: 'product/supplier/productSet/', // 直送商品系列信息
  // 收藏商品
  CollectionProduct: 'product/collection/',
  // 控区控价 可申请
  SupplierBrand: 'brandRestriction/brand/',
  SupplierBrandOther: 'brandRestriction/list/',
  SupplierBrandDetail: 'brandRestriction/brandDetail/',
  SupplierBrandApply: 'brandRestriction/apply/',
  SupplierBrandAll: 'brandRestriction/brandAll/', // 控区控价（全部）
  // 控区控价特优推荐
  ControlAreaProductList: 'brandRestriction/specialProduct/',
  // 资金账户查询
  Balance: 'user/balance/',
  ChargeList: 'transfer/chargeList/',
  // 个人中心资金账户
  SubList: 'customerManager/sublist/',
  UpdateSub: 'customerManager/updateSubCustomer/',
  UpdateSubInfo: 'customerManager/updateSub/',
  // 订货单位列表
  UserCenter: 'user/center/',
  // 添加订货单位
  AddSub: 'customerManager/addSub/',
  // 本单位人员列表
  UserList: 'user/list/',
  // 修改新增人员列表
  EditUserList: 'user/add/',
  // 服务商业务员
  ProviderUsers: 'select/providerUsers/',
  // 修改密码
  UpdatePassword: 'user/updatePassword/',
  UpdatePayPassword: 'user/updatePayPassword/',
  SubDetail: 'customerManager/subDetail/',
  // 二级地址
  AreaList: 'tree/area/',
  // 三级地址
  RegionList: 'tree/region/',
  CouponList: 'coupon/list/', // 优惠券列表
  GetCoupon: 'coupon/getCoupon/', // 领取优惠券
  GetCouponProduct: 'coupon/getCouponProductList/', // 获取可用该优惠券的商品
  GetCouponNum: 'coupon/couponInfo/', // 获取优惠券数量
  CouponSelect: '', // 选择优惠券
  // 购物车列表
  CommonCartList: 'cart/list/',
  SupplierCartList: 'cart/supplier/list/',
  SeriesCartList: 'cart/listProduct', // 商品系列购物车列表
  SupplierSeriesCartList: 'cart/supplier/listProduct', // 直送商品系列购物车列表
  // 添加到购物车
  CartAdd: 'cart/save/',
  CartSupplierAdd: 'cart/supplier/save/',
  CartSeriesAdd: 'cart/saveList/', // 商品系列加入购物车
  CartSupplierSeriesAdd: 'cart/supplier/saveList/', // 直送商品加入购物车
  CartDateAdd: 'cart/savePeriodList/', // 生产期间商品添加购物车
  CartDelete: 'cart/delete/',
  CartSupplierDelete: 'cart/supplier/delete/',
  // 订单列表
  OrderList: 'order/list/',
  SupplierOrderList: 'order/supplier/list/',
  OrderDetail: 'order/detail/',
  CommonOrderUnDo: 'order/undo/',
  CommonOrderProductDelete: 'order/deleteDetail/',
  SupplierOrderDetail: 'order/supplier/detail/',
  SupplierOrderProductDelete: 'order/supplier/deleteDetail/',
  // 删除订单
  OrderDelete: 'order/delete/',
  SupplierOrderDelete: 'order/supplier/delete/',
  // 撤销订单
  OrderUndo: 'order/undo/',
  SupplierOrderUndo: 'order/supplier/undo/',
  UpdateConfirmReceipt: 'order/supplier/updateConfirmReceipt/',
  // 转账记录详情
  TransferDetail: 'transfer/detail/',
  // 在线充值
  OnlineRecharge: 'transfer/onlineRecharge/',
  PayStatus: 'transfer/payStatus/',
  PayBank: 'transfer/bank/',
  UpdateBank: 'transfer/updateBank/',
  BrandPinYinList: 'select/brandPinYinList/',
  LoadExtra: 'upload/download',
  CommonSettlement: 'cart/settlement/',
  SupplierSettlement: 'cart/supplier/settlement/',
  OrderSend: 'order/send/',
  SupplierOrderSend: 'order/supplier/generate/',
  Category: 'product/category/',
  CcbRoles: 'select/ccbRoles/',
  UpdateCommonQty: 'order/updateQty/',
  UpdateSupplierQty: 'order/supplier/updateQty/',
  FlashSaleProduct: 'product/flashSale/',
  CurrentTime: 'product/currentTime/',
  BankList: 'select/bankList/',
  OnlineDetail: 'transfer/onlineDetail/',
  // InlineDetail: 'transfer/bankList/',
  InlineDetail: 'transfer/payer/list/', // 转账人信息列表
  AddTranferInfo: 'transfer/payer/add', // 新增转账人信息
  UpdateTranferInfo: 'transfer/payer/update', // 编辑转账人信息
  DeleteTranferInfo: 'transfer/payer/delete', // 删除转账人信息
  PayerDetail: 'transfer/payer/list/',
  SendPhoneCode: 'user/sendPhoneCode/',
  OrderTrace: 'order/trace/',
  SoDcSubOrderDetail: 'order/soDcSubOrderDetail',
  chechVersion: 'user/version/',
  AddCustomerManager: 'customerManager/add/',
  CustomerRegister: 'customerManager/register/',
  SendRegisterCode: 'customerManager/sendRegisterCode/',
  ArticleList: 'article/list/',
  ArticleDetail: 'article/detail/',
  ReceiveAddress: 'receiveAddress/list/',
  DeleteReceiveAddress: 'receiveAddress/delete/',
  UpdateReceiveAddress: 'receiveAddress/update/',
  AddReceiveAddress: 'receiveAddress/add/',
  ReceiveAddressDetail: 'receiveAddress/detail/',
  UpdateOrderReceiveAddress: 'order/updateReceiveAddress/',
  UpdateSupplierOrderReceiveAddress: 'order/supplier/updateReceiveAddress/',
  GetMaxRechargeAmount: 'transfer/riskControlStatus/', // 支付宝、微信风控接口
  GetActionTime: 'action/log/' // 记录进入系统和离开系统的时间
}

export const Login = API_ROOT.concat(apiHYZ.Login)
export const LogOut = API_ROOT.concat(apiHYZ.LogOut)
export const SubCustomerList = API_ROOT.concat(apiHYZ.SubCustomerList)
export const SelectSubCustomer = API_ROOT.concat(apiHYZ.SelectSubCustomer)
export const Product2Category = API_ROOT.concat(apiHYZ.Product2Category)
export const ProductList = API_ROOT.concat(apiHYZ.ProductList)
export const NewProductList = API_ROOT.concat(apiHYZ.NewProductList)
export const PromotionProduct = API_ROOT.concat(apiHYZ.PromotionProduct)
export const HotProductList = API_ROOT.concat(apiHYZ.HotProductList)
export const SupplierProductList = API_ROOT.concat(apiHYZ.SupplierProductList)
export const CategoryProductList = API_ROOT.concat(apiHYZ.CategoryProductList)
export const ProductUnifiedSearchList = API_ROOT.concat(apiHYZ.ProductUnifiedSearchList) // 统一搜索商品
export const CollectionProductList = API_ROOT.concat(apiHYZ.CollectionProductList)
export const GuideProduct = API_ROOT.concat(apiHYZ.GuideProduct) // 支付成功后的推荐商品
export const ProductDetailInfo = API_ROOT.concat(apiHYZ.ProductDetailInfo)
export const ProductSeriesInfo = API_ROOT.concat(apiHYZ.ProductSeriesInfo) // 商品系列信息
export const ProductDateInfo = API_ROOT.concat(apiHYZ.ProductDateInfo) // 商品生产月份信息
export const ProductAttachList = API_ROOT.concat(apiHYZ.ProductAttachList)
export const SupplierProductDetail = API_ROOT.concat(apiHYZ.SupplierProductDetail)
export const SupplierProductSeriesInfo = API_ROOT.concat(apiHYZ.SupplierProductSeriesInfo) // 直送商品系列信息
export const CategoryList = API_ROOT.concat(apiHYZ.CategoryList)
export const BannerList = API_ROOT.concat(apiHYZ.BannerList)
export const MaterialProduct = API_ROOT.concat(apiHYZ.MaterialProduct)
export const CategoryBandList = API_ROOT.concat(apiHYZ.CategoryBandList)
export const PropertyList = API_ROOT.concat(apiHYZ.PropertyList)
export const BandList = API_ROOT.concat(apiHYZ.BandList)
export const CollectionProduct = API_ROOT.concat(apiHYZ.CollectionProduct)
export const SupplierBrand = API_ROOT.concat(apiHYZ.SupplierBrand)
export const SupplierBrandOther = API_ROOT.concat(apiHYZ.SupplierBrandOther)
export const SupplierBrandDetail = API_ROOT.concat(apiHYZ.SupplierBrandDetail)
export const SupplierBrandApply = API_ROOT.concat(apiHYZ.SupplierBrandApply)
export const SupplierBrandAll = API_ROOT.concat(apiHYZ.SupplierBrandAll)
export const ControlAreaProductList = API_ROOT.concat(apiHYZ.ControlAreaProductList)
export const Balance = API_ROOT.concat(apiHYZ.Balance)
export const ChargeList = API_ROOT.concat(apiHYZ.ChargeList)
export const SubList = API_ROOT.concat(apiHYZ.SubList)
export const UpdateSub = API_ROOT.concat(apiHYZ.UpdateSub)
export const UpdateSubInfo = API_ROOT.concat(apiHYZ.UpdateSubInfo)
export const UserCenter = API_ROOT.concat(apiHYZ.UserCenter)
export const AddSub = API_ROOT.concat(apiHYZ.AddSub)
export const UserList = API_ROOT.concat(apiHYZ.UserList)
export const EditUserList = API_ROOT.concat(apiHYZ.EditUserList)
export const ProviderUsers = API_ROOT.concat(apiHYZ.ProviderUsers)
export const UpdatePassword = API_ROOT.concat(apiHYZ.UpdatePassword)
export const UpdatePayPassword = API_ROOT.concat(apiHYZ.UpdatePayPassword)
export const SelectSupplierList = API_ROOT.concat(apiHYZ.SelectSupplierList)
export const CustomerSupplierList = API_ROOT.concat(apiHYZ.CustomerSupplierList)
export const AreaList = API_ROOT.concat(apiHYZ.AreaList)
export const RegionList = API_ROOT.concat(apiHYZ.RegionList)
export const CouponList = API_ROOT.concat(apiHYZ.CouponList) // 优惠券列表
export const GetCoupon = API_ROOT.concat(apiHYZ.GetCoupon) // 领取优惠券
export const GetCouponProduct = API_ROOT.concat(apiHYZ.GetCouponProduct) // 获取可用该优惠券的商品
export const GetCouponNum = API_ROOT.concat(apiHYZ.GetCouponNum) // 获取优惠券数量
export const SubDetail = API_ROOT.concat(apiHYZ.SubDetail)
export const CommonCartList = API_ROOT.concat(apiHYZ.CommonCartList)
export const SupplierCartList = API_ROOT.concat(apiHYZ.SupplierCartList)
export const SeriesCartList = API_ROOT.concat(apiHYZ.SeriesCartList) // 商品系列购物车列表
export const SupplierSeriesCartList = API_ROOT.concat(apiHYZ.SupplierSeriesCartList) // 直送商品系列购物车列表
export const CartAdd = API_ROOT.concat(apiHYZ.CartAdd)
export const CartSupplierAdd = API_ROOT.concat(apiHYZ.CartSupplierAdd)
export const CartSeriesAdd = API_ROOT.concat(apiHYZ.CartSeriesAdd) // 配送系列商品加入购物车
export const CartSupplierSeriesAdd = API_ROOT.concat(apiHYZ.CartSupplierSeriesAdd) // 直送系列商品加入购物车
export const CartDateAdd = API_ROOT.concat(apiHYZ.CartDateAdd) // 生产期间商品加入购物车
export const CartDelete = API_ROOT.concat(apiHYZ.CartDelete)
export const CartSupplierDelete = API_ROOT.concat(apiHYZ.CartSupplierDelete)
export const OrderList = API_ROOT.concat(apiHYZ.OrderList)
export const SupplierOrderList = API_ROOT.concat(apiHYZ.SupplierOrderList)
export const TransferDetail = API_ROOT.concat(apiHYZ.TransferDetail)
export const OnlineRecharge = API_ROOT.concat(apiHYZ.OnlineRecharge)
export const PayStatus = API_ROOT.concat(apiHYZ.PayStatus)
export const PayBank = API_ROOT.concat(apiHYZ.PayBank)
export const UpdateBank = API_ROOT.concat(apiHYZ.UpdateBank)
export const BrandPinYinList = API_ROOT.concat(apiHYZ.BrandPinYinList)
export const LoadExtra = API_ROOT.concat(apiHYZ.LoadExtra)
export const CommonSettlement = API_ROOT.concat(apiHYZ.CommonSettlement)
export const SupplierSettlement = API_ROOT.concat(apiHYZ.SupplierSettlement)
export const OrderSend = API_ROOT.concat(apiHYZ.OrderSend)
export const SupplierOrderSend = API_ROOT.concat(apiHYZ.SupplierOrderSend)
export const OrderDelete = API_ROOT.concat(apiHYZ.OrderDelete)
export const SupplierOrderDelete = API_ROOT.concat(apiHYZ.SupplierOrderDelete)
export const OrderUndo = API_ROOT.concat(apiHYZ.OrderUndo)
export const SupplierOrderUndo = API_ROOT.concat(apiHYZ.SupplierOrderUndo)
export const UpdateConfirmReceipt = API_ROOT.concat(apiHYZ.UpdateConfirmReceipt)
export const OrderDetail = API_ROOT.concat(apiHYZ.OrderDetail)
export const CommonOrderUnDo = API_ROOT.concat(apiHYZ.CommonOrderUnDo)
export const CommonOrderProductDelete = API_ROOT.concat(apiHYZ.CommonOrderProductDelete)
export const SupplierOrderProductDelete = API_ROOT.concat(apiHYZ.SupplierOrderProductDelete)
export const SupplierOrderDetail = API_ROOT.concat(apiHYZ.SupplierOrderDetail)
export const Category = API_ROOT.concat(apiHYZ.Category)
export const CcbRoles = API_ROOT.concat(apiHYZ.CcbRoles)
export const UpdateCommonQty = API_ROOT.concat(apiHYZ.UpdateCommonQty)
export const UpdateSupplierQty = API_ROOT.concat(apiHYZ.UpdateSupplierQty)
export const FlashSaleProduct = API_ROOT.concat(apiHYZ.FlashSaleProduct)
export const CurrentTime = API_ROOT.concat(apiHYZ.CurrentTime)
export const BankList = API_ROOT.concat(apiHYZ.BankList)
export const OnlineDetail = API_ROOT.concat(apiHYZ.OnlineDetail)
export const InlineDetail = API_ROOT.concat(apiHYZ.InlineDetail)
export const AddTranferInfo = API_ROOT.concat(apiHYZ.AddTranferInfo)
export const UpdateTranferInfo = API_ROOT.concat(apiHYZ.UpdateTranferInfo)
export const DeleteTranferInfo = API_ROOT.concat(apiHYZ.DeleteTranferInfo)
export const SendPhoneCode = API_ROOT.concat(apiHYZ.SendPhoneCode)
export const OrderTrace = API_ROOT.concat(apiHYZ.OrderTrace)
export const SoDcSubOrderDetail = API_ROOT.concat(apiHYZ.SoDcSubOrderDetail)
export const chechVersion = API_ROOT.concat(apiHYZ.chechVersion)
export const AddCustomerManager = API_ROOT.concat(apiHYZ.AddCustomerManager)
export const CustomerRegister = API_ROOT.concat(apiHYZ.CustomerRegister)
export const SendRegisterCode = API_ROOT.concat(apiHYZ.SendRegisterCode)
export const ArticleList = API_ROOT.concat(apiHYZ.ArticleList)
export const ArticleDetail = API_ROOT.concat(apiHYZ.ArticleDetail)
export const ReceiveAddress = API_ROOT.concat(apiHYZ.ReceiveAddress)
export const DeleteReceiveAddress = API_ROOT.concat(apiHYZ.DeleteReceiveAddress)
export const UpdateReceiveAddress = API_ROOT.concat(apiHYZ.UpdateReceiveAddress)
export const AddReceiveAddress = API_ROOT.concat(apiHYZ.AddReceiveAddress)
export const ReceiveAddressDetail = API_ROOT.concat(apiHYZ.ReceiveAddressDetail)
export const UpdateOrderReceiveAddress = API_ROOT.concat(apiHYZ.UpdateOrderReceiveAddress)
export const UpdateSupplierOrderReceiveAddress = API_ROOT.concat(apiHYZ.UpdateSupplierOrderReceiveAddress)
export const GetMaxRechargeAmount = API_ROOT.concat(apiHYZ.GetMaxRechargeAmount) // 支付宝、微信风控接口
export const GetActionTime = 'http://219.234.84.247:8011/action/log/' // 记录进入系统和离开系统的时间（测试）
// export const GetActionTime = 'http://219.234.84.247:8013/action/log/' // 记录进入系统和离开系统的时间（正式）
