import axios from 'axios'
import router from '../router/index'
import store from '../store/index'
import iView from 'iview'
import {
  Login,
  LogOut,
  SubCustomerList,
  SelectSubCustomer,
  Product2Category,
  ProductList,
  NewProductList,
  PromotionProduct,
  HotProductList,
  CollectionProductList,
  SupplierProductList,
  CategoryProductList,
  ProductUnifiedSearchList, // 统一搜索商品
  ProductDetailInfo,
  ProductSeriesInfo, // 商品系列信息
  ProductDateInfo, // 商品生产月份信息
  ProductAttachList,
  SupplierProductDetail,
  SupplierProductSeriesInfo, // 直送商品系列信息
  GuideProduct, // 支付成功后的推荐商品
  CategoryList,
  BannerList,
  BandList,
  MaterialProduct,
  CategoryBandList,
  PropertyList,
  CollectionProduct,
  SupplierBrand,
  SupplierBrandOther,
  SupplierBrandDetail,
  SupplierBrandApply,
  SupplierBrandAll,
  ControlAreaProductList,
  Balance,
  ChargeList,
  UserCenter,
  SubList,
  UpdateSub,
  UpdateSubInfo,
  AddSub,
  UserList,
  EditUserList,
  ProviderUsers,
  UpdatePassword,
  UpdatePayPassword,
  SelectSupplierList,
  CustomerSupplierList,
  SubDetail,
  AreaList,
  RegionList,
  CouponList, // 优惠券列表
  GetCoupon, // 领取优惠券
  GetCouponProduct, // 获取可以使用该优惠券的商品
  GetCouponNum, // 获取优惠券的数量
  CommonCartList,
  SupplierCartList,
  SeriesCartList, // 配送商品系列购物车列表
  SupplierSeriesCartList, // 直送商品系列购物车列表
  CartAdd,
  CartSupplierAdd,
  CartSeriesAdd, // 配送系列商品加入购物车
  CartSupplierSeriesAdd, // 直送系列商品加入购物车
  CartDateAdd, // 生产期间商品加入购物车
  CartDelete,
  CartSupplierDelete,
  OrderList,
  OrderDelete,
  SupplierOrderDelete,
  SupplierOrderList,
  TransferDetail,
  OnlineRecharge,
  PayStatus,
  PayBank,
  UpdateBank,
  BrandPinYinList,
  LoadExtra,
  CommonSettlement,
  SupplierSettlement,
  OrderSend,
  SupplierOrderSend,
  OrderUndo,
  SupplierOrderUndo,
  UpdateConfirmReceipt,
  OrderDetail,
  CommonOrderUnDo,
  CommonOrderProductDelete,
  SupplierOrderProductDelete,
  SupplierOrderDetail,
  Category,
  CcbRoles,
  UpdateCommonQty,
  UpdateSupplierQty,
  FlashSaleProduct,
  CurrentTime,
  BankList,
  OnlineDetail,
  InlineDetail, // 转账人列表
  AddTranferInfo, // 新增转账人信息
  UpdateTranferInfo, // 编辑转账人信息
  DeleteTranferInfo, // 删除转账人信息
  SendPhoneCode,
  OrderTrace,
  SoDcSubOrderDetail,
  chechVersion,
  AddCustomerManager,
  CustomerRegister,
  SendRegisterCode,
  ArticleList,
  ArticleDetail,
  ReceiveAddress,
  DeleteReceiveAddress,
  UpdateReceiveAddress,
  AddReceiveAddress,
  ReceiveAddressDetail,
  UpdateOrderReceiveAddress,
  UpdateSupplierOrderReceiveAddress,
  GetMaxRechargeAmount,
  GetActionTime
} from './resource'

let qs = require('qs')

axios.defaults.withCredentials = true
// axios.defaults.timeout = 100000
axios.defaults.headers['Content-Type'] = 'application/x-www-form-urlencoded'

// 添加请求拦截器
axios.interceptors.request.use(
  response => {
    return response
  },
  error => {
    console.log('请求失败：')
    return Promise.reject(error)
  }
)

// 添加响应拦截器
axios.interceptors.response.use(
  response => {
    console.log('响应成功：' + response)
    let path = router.currentRoute.fullPath
    if (response.data.status == 4002) {
      console.log(path)
      router.replace({path: '/login'})
    }
    return response
  },
  error => {
    console.log('响应失败')
    // router.push({path: '*'})
    return Promise.reject(error)
  }
)

// -----------------华丽丽的的分割线---------------------------------
function apiPost(url, params) {
  return new Promise((resolve, reject) => {
    store.dispatch('showLoading', true)
    iView.LoadingBar.start()
    let temp
    if (url.indexOf('action/log/') !== -1) {
      temp = params
      console.log('记录进入系统时间')
      axios.defaults.headers['Content-Type'] = 'application/json'
    } else {
      axios.defaults.headers['Content-Type'] = 'application/x-www-form-urlencoded'
      temp = qs.stringify(params)
    }
    axios.post(url, temp).then(res => {
      store.dispatch('showLoading', false)
      iView.LoadingBar.finish()
      resolve(res)
    }).catch(err => {
      store.dispatch('showLoading', false)
      reject(err)
    })
  })
}

// function apiGet(url, params) {
//   // return axios.get(url)
//   return new Promise((resolve, reject) => {
//     store.dispatch('showLoading', true)
//     iView.LoadingBar.start()
//     axios.get(url, {
//       params: params
//     }).then(res => {
//       iView.LoadingBar.finish()
//       store.dispatch('showLoading', false)
//       resolve(res)
//     }).catch(err => {
//       store.dispatch('showLoading', false)
//       reject(err)
//     })
//   })
// }

/**
 * 接口请求地址封装
 * 规则：
 */
export default {
  login: (data) => apiPost(Login, data), //  用户登陆
  LogOut: (data) => apiPost(LogOut, data), //  登出
  getSubCustomerList: (data) => apiPost(SubCustomerList, data),
  getCustomerSupplierList: (data) => apiPost(CustomerSupplierList, data),
  getSelectSupplierList: (data) => apiPost(SelectSupplierList, data),
  selectSubCustomerId: (data) => apiPost(SelectSubCustomer, data),
  getProduct2Category: (data) => apiPost(Product2Category, data),
  getProductList: (data) => apiPost(ProductList, data),
  getNewProductList: (data) => apiPost(NewProductList, data),
  getPromotionProduct: (data) => apiPost(PromotionProduct, data),
  getHotProductList: (data) => apiPost(HotProductList, data),
  getCollectionProductList: (data) => apiPost(CollectionProductList, data),
  getGuideProductList: (data) => apiPost(GuideProduct, data), // 支付成功后的推荐商品
  getSupplierProductList: (data) => apiPost(SupplierProductList, data),
  getCategoryProductList: (data) => apiPost(CategoryProductList, data), // CategoryProductList
  getProductUnifiedSearchList: (data) => apiPost(ProductUnifiedSearchList, data), // 统一搜索商品
  getBannerList: (data) => apiPost(BannerList, data),
  getCategoryList: (data) => apiPost(CategoryList, data),
  getBandList: (data) => apiPost(BandList, data),
  getMaterialProduct: (data) => apiPost(MaterialProduct, data),
  getCategoryBandList: (data) => apiPost(CategoryBandList, data),
  getPropertyList: (data) => apiPost(PropertyList, data),
  getProductDetailInfo: (data) => apiPost(ProductDetailInfo, data),
  getProductSeriesInfo: (data) => apiPost(ProductSeriesInfo, data), // 商品系列信息
  getProductDateInfo: (data) => apiPost(ProductDateInfo, data), // 商品生产月份信息  
  getProductAttachList: (data) => apiPost(ProductAttachList, data),
  getSupplierProductDetail: (data) => apiPost(SupplierProductDetail, data),
  getSupplierProductSeriesInfo: (data) => apiPost(SupplierProductSeriesInfo, data), // 直送商品系列信息
  CollectionPro: (data) => apiPost(CollectionProduct, data),
  getSupplierBrand: (data) => apiPost(SupplierBrand, data),
  getSupplierBrandOther: (data) => apiPost(SupplierBrandOther, data),
  getSupplierBrandDetail: (data) => apiPost(SupplierBrandDetail, data),
  getSupplierBrandApply: (data) => apiPost(SupplierBrandApply, data),
  getSupplierBrandAll: (data) => apiPost(SupplierBrandAll, data),
  getControlAreaProductList: (data) => apiPost(ControlAreaProductList, data),
  getBalance: (data) => apiPost(Balance, data),
  getChargeList: (data) => apiPost(ChargeList, data),
  getUserCenter: (data) => apiPost(UserCenter, data),
  getSubList: (data) => apiPost(SubList, data),
  getUpdateSub: (data) => apiPost(UpdateSub, data),
  getUpdateSubInfo: (data) => apiPost(UpdateSubInfo, data),
  getAddSub: (data) => apiPost(AddSub, data),
  getUserList: (data) => apiPost(UserList, data),
  getEditUserList: (data) => apiPost(EditUserList, data),
  getProviderUsers: (data) => apiPost(ProviderUsers, data),
  getUpdatePassword: (data) => apiPost(UpdatePassword, data),
  getUpdatePayPassword: (data) => apiPost(UpdatePayPassword, data),
  getAreaList: (data) => apiPost(AreaList, data),
  getRegionList: (data) => apiPost(RegionList, data),
  getCouponList: (data) => apiPost(CouponList, data), // 优惠券列表
  getCoupon: (data) => apiPost(GetCoupon, data), // 领取优惠券
  getCouponProduct: (data) => apiPost(GetCouponProduct, data), // 获取能使用该优惠券的商品
  getCouponNum: (data) => apiPost(GetCouponNum, data), // 获取优惠券数量
  getSubDetail: (data) => apiPost(SubDetail, data),
  getCommonCartList: (data) => apiPost(CommonCartList, data),
  getSupplierCartList: (data) => apiPost(SupplierCartList, data),
  getSeriesCartList: (data) => apiPost(SeriesCartList, data), // 系列商品购物车列表
  getSupplierSeriesCartList: (data) => apiPost(SupplierSeriesCartList, data), // 直送系列商品购物车列表
  getOnlineRecharge: (data) => apiPost(OnlineRecharge, data),
  getPayStatus: (data) => apiPost(PayStatus, data),
  getPayBank: (data) => apiPost(PayBank, data),
  getUpdateBank: (data) => apiPost(UpdateBank, data),
  getCartAdd: (data) => apiPost(CartAdd, data),
  getCartSupplierAdd: (data) => apiPost(CartSupplierAdd, data),
  getCartSeriesAdd: (data) => apiPost(CartSeriesAdd, data), // 配送系列商品加入购物车
  getCartSupplierSeriesAdd: (data) => apiPost(CartSupplierSeriesAdd, data), // 直送系列商品加入购物车
  getCartDateAdd: (data) => apiPost(CartDateAdd, data), // 生产期间商品加入购物车
  getCartDelete: (data) => apiPost(CartDelete, data),
  getCartSupplierDelete: (data) => apiPost(CartSupplierDelete, data),
  getOrderList: (data) => apiPost(OrderList, data),
  getOrderDelete: (data) => apiPost(OrderDelete, data),
  getSupplierOrderDelete: (data) => apiPost(SupplierOrderDelete, data),
  getOrderUndo: (data) => apiPost(OrderUndo, data),
  getSupplierOrderUndo: (data) => apiPost(SupplierOrderUndo, data),
  getUpdateConfirmReceipt: (data) => apiPost(UpdateConfirmReceipt, data),
  getSupplierOrderList: (data) => apiPost(SupplierOrderList, data),
  getTransferDetail: (data) => apiPost(TransferDetail, data),
  getBrandPinYinList: (data) => apiPost(BrandPinYinList, data),
  getLoadExtra: LoadExtra,
  getCommonSettlement: (data) => apiPost(CommonSettlement, data),
  getSupplierSettlement: (data) => apiPost(SupplierSettlement, data),
  getOrderSend: (data) => apiPost(OrderSend, data),
  getSupplierOrderSend: (data) => apiPost(SupplierOrderSend, data),
  getOrderDetail: (data) => apiPost(OrderDetail, data),
  getCommonOrderUnDo: (data) => apiPost(CommonOrderUnDo, data),
  getCommonOrderProductDelete: (data) => apiPost(CommonOrderProductDelete, data),
  getSupplierOrderProductDelete: (data) => apiPost(SupplierOrderProductDelete, data),
  getSupplierOrderDetail: (data) => apiPost(SupplierOrderDetail, data),
  getCategory: (data) => apiPost(Category, data),
  getCcbRoles: (data) => apiPost(CcbRoles, data),
  getUpdateCommonQty: (data) => apiPost(UpdateCommonQty, data),
  getUpdateSupplierQty: (data) => apiPost(UpdateSupplierQty, data),
  getFlashSaleProduct: (data) => apiPost(FlashSaleProduct, data),
  getCurrentTime: (data) => apiPost(CurrentTime, data),
  getBankList: (data) => apiPost(BankList, data),
  getOnlineDetail: (data) => apiPost(OnlineDetail, data),
  getInlineDetail: (data) => apiPost(InlineDetail, data),
  getAddTranferInfo: (data) => apiPost(AddTranferInfo, data),
  getUpdateTranferInfo: (data) => apiPost(UpdateTranferInfo, data),
  getDeleteTranferInfo: (data) => apiPost(DeleteTranferInfo, data),
  getSendPhoneCode: (data) => apiPost(SendPhoneCode, data),
  getOrderTrace: (data) => apiPost(OrderTrace, data),
  getSoDcSubOrderDetail: (data) => apiPost(SoDcSubOrderDetail, data),
  getVersion: (data) => apiPost(chechVersion, data),
  getAddCustomerManager: (data) => apiPost(AddCustomerManager, data),
  getCustomerRegister: (data) => apiPost(CustomerRegister, data),
  getSendRegisterCode: (data) => apiPost(SendRegisterCode, data),
  getArticleList: (data) => apiPost(ArticleList, data),
  getArticleDetail: (data) => apiPost(ArticleDetail, data),
  getReceiveAddress: (data) => apiPost(ReceiveAddress, data),
  getDeleteReceiveAddress: (data) => apiPost(DeleteReceiveAddress, data),
  getUpdateReceiveAddress: (data) => apiPost(UpdateReceiveAddress, data),
  getAddReceiveAddress: (data) => apiPost(AddReceiveAddress, data),
  getReceiveAddressDetail: (data) => apiPost(ReceiveAddressDetail, data),
  getUpdateOrderReceiveAddress: (data) => apiPost(UpdateOrderReceiveAddress, data),
  getUpdateSupplierOrderReceiveAddress: (data) => apiPost(UpdateSupplierOrderReceiveAddress, data),
  getMaxRechargeAmount: (data) => apiPost(GetMaxRechargeAmount, data), // 微信、支付宝风控接口
  getGetActionTime: (data) => apiPost(GetActionTime, data) // 记录进入系统和离开系统的时间
}
