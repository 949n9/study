import utils from './index'

const regPass = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,}$/
const validator = {
  validatePhone: (rule, value, callback) => {
    let msg = rule.msg || ''
    if (value === '' || typeof (value) == 'undefined') {
      callback(new Error(`请输入${msg}手机号码`))
    } else {
      if (!utils.isPhone(value)) {
        callback(new Error('请输入正确的手机号码'))
      }
      callback()
    }
  },
  validateName: (rule, value, callback) => {
    if (value === '' || typeof (value) == 'undefined') {
      callback(new Error(`请输入收货人姓名`))
    } else if (value.length < 2) {
      callback(new Error('收货人姓名不小于2个字！'))
    } else {
      callback()
    }
  },
  validateNewPass: (rule, value, callback) => {
    if (value === '') {
      callback(new Error('请输入新密码！'))
    } else if (value.length < 8 || value.length > 20) {
      callback(new Error('输入的密码长度不符合要求，应在8-20位之间！'))
    } else if (!regPass.test(value)) {
      callback(new Error('为确保密码安全，请输入8位或8位以上字母和数字组合！不可以全是数字，也不可以全是字母！'))
    } else {
      callback()
    }
  }
}
export default validator
