// 小红马平台服务协议
export const ServicePolicy = 'https://aiqin.oss-cn-beijing.aliyuncs.com/attachment/%E5%B0%8F%E7%BA%A2%E9%A9%AC%E5%B9%B3%E5%8F%B0%E6%9C%8D%E5%8A%A1%E5%8D%8F%E8%AE%AE.html'

export const BeianUrl = 'http://www.miitbeian.gov.cn'
export const BaseUrl = 'http://www.redhoma.cn/'

export const CustomerInfo = '“客户信息”是指您公司的信息，如果有多个分店，这里应填写总部的公司信息。如果只有一个店，可以填写本店信息。'
export const UnitInfo = '“订货单位”是指您公司的分店信息，在注册时可以同时增加一个门店信息。如果您的公司只有一个分店，也必须填写“订货单位”信息（可以“复制”客户信息）。如果有多个分店，可以在注册后登录小红马APP，增加更多分店信息。'
export const UserInfo = '“用户”是指要使用小红马APP或PC端的人，需要录入其手机号，审核通过后，会给这个手机发送登录密码。此后可以用手机号和密码登录小红马APP或PC端。'

export const yyImg = 'https://aiqin.oss-cn-beijing.aliyuncs.com/attachment/xyapp/%E8%90%A5%E4%B8%9A%E6%89%A7%E7%85%A7.jpg'
export const mtImg = 'https://aiqin.oss-cn-beijing.aliyuncs.com/attachment/xyapp/%E9%97%A8%E5%A4%B4%E7%85%A7.png'
export const dnImg = 'https://aiqin.oss-cn-beijing.aliyuncs.com/attachment/xyapp/%E5%BA%97%E5%86%85%E7%85%A7.png'

export const bankHref = 'https://aiqin.oss-cn-beijing.aliyuncs.com/attachment/%E7%BD%91%E5%85%B3%E6%94%AF%E4%BB%98%E9%99%90%E9%A2%9D%E8%A1%A8.xlsx'

export const defaultBankImg = 'https://aiqin.oss-cn-beijing.aliyuncs.com/attachment/xyapp/demo1.png'
export const defaultBanKImg2 = 'https://aiqin.oss-cn-beijing.aliyuncs.com/attachment/xyapp/demo2.png'
