import * as types from './mutation_types'

export default {
  [types.SHOW_LOADING](state, data) {
    state.loading = data
  },
  [types.HANDLE_BASEDIALOG](state, data) {
    state[data.type] = data.visible || false
    state.dialogTitle = data.title || ''
    state.orderType = data.orderType
  },
  [types.HANDLEBASIC_INFO](state, data) {
    state.baseInfo = data
  },
  [types.SAVECATEGORY_INFO](state, data) {
    let arr = state.categoryInfo
    let newArr = []
    if (arr.length > 0 && data.length > 0) {
      newArr = arr.filter((item) => item.key != data[0].key)
    }
    newArr = newArr.concat(data)
    state.categoryInfo = newArr
  },
  [types.SAVESEARCH_INFO](state, data) {
    state.searchInfo = data
  },
  [types.SAVESEARCH_RECORD](state, data) {
    localStorage.setItem('searchRecord', JSON.stringify(data))
    state.searchRecord = JSON.parse(localStorage.getItem('searchRecord'))
  },
  [types.SAVE_SELECTINFO](state, data) {
    state.selectInfo = data
  },
  [types.SAVE_PRODUCTINFO](state, data) {
    state.productId = data
  },
  [types.SAVE_PRODUCTSERIESINFO](state, data) {
    state.productSeriesId = data
  },
  [types.SAVE_PRODUCTDATEINFO](state, data) {
    state.productDateId = data
  },
  [types.SAVE_SUPPLIERPRODUCTINFO](state, data) {
    state.supplierProduct = data
  },
  [types.SAVE_SUPPLIERPRODUCTSERIESINFO](state, data) {
    state.supplierProductSeriesId = data
  },
  [types.SAVE_CARTID](state, data) {
    state.cartId = data
  },
  [types.SAVE_SUPPLIERCARTID](state, data) {
    state.supplierCartId = data
  },
  [types.ADD_PRODUCTSUCCESS](state, data) {
    state.addSuccess = data
  },
  [types.USE_COUPONSUCCESS](state, data) {
    state.useSuccess = data
  },
  [types.HIDE_LEFTMENU](state, data) {
    state.hideMenu = data
  },
  [types.SAVE_SELECTEDID](state, data) {
    state.selectedArr = data
  },
  [types.SAVE_SELECTEDSUPPLIERID](state, data) {
    state.selectedSupplierArr = data
  },
  [types.SAVE_ORDERSTATUS](state, data) {
    state.orderStatus = data
  },
  [types.SAVE_ORDERINFO](state, data) { // 支付信息
    state.orderInfo = data
  },
  [types.SAVE_ORDERID](state, data) {
    state.orderDetailId = data
  },
  [types.HANDLE_ORDERSTATUS](state, data) {
    state.handleSuccess = data
  },
  [types.SAVE_COMMONSETTLEMENTINFO](state, data) {
    state.commonSettlementInfo = data
  },
  [types.SAVE_SUPPLIERSETTLEMENTINFO](state, data) {
    state.supplierSettlementInfo = data
  },
  [types.HANDLE_ADDRESSEDIT](state, data) {
    state.addressEdit = data
  },
  [types.SAVE_COUPON_DETAIL](state, data) {
    state.couponDetail = data
  }
}
