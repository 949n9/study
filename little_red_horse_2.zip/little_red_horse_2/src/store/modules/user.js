import API from '../../core/index'
import * as types from '../mutation_types'

const state = {
  userInfo: {},
  commonCartNum: 0,
  supplierCartNum: 0,
  cartList: [],
  cartSupplierList: [],
  // 云仓商品 购物车数量
  cartTotalQty: 0,
  // 地配商品 购物车数量
  cartSupplierTotalQty: 0
}

const actions = {
  // 选择订货单位
  selectSub: function ({commit}, data) {
    return new Promise((resolve, reject) => {
      API.selectSubCustomerId(data).then((res) => {
        // let data = res.data
        // let arr = []
        // if (data.status == 0) {
        //   console.log(state.userInfo)
        //   arr = data.data
        //   arr = Object.assign({}, data.data, getters.userData)
        // }
        // commit(types.USER_INFO, arr)
        resolve(res)
      }).catch(err => {
        console.log(err)
        reject(err)
      })
    })
  },
  saveCommonCartNum: ({commit}, data) => {
    commit(types.SAVE_COMMONCARTNUM, data)
  },
  saveSupplierCartNum: ({commit}, data) => {
    commit(types.SAVE_SUPPLIERCARTNUM, data)
  },
  // 获取购物车中的商品(普通商品)
  getCartData: ({commit}, data) => {
    return new Promise((resolve, reject) => {
      API.getSeriesCartList(data).then((res) => {
        let data = res.data
        let arr = []
        let qty = {}
        if (data.status == 0) {
          arr = data.data.list
          qty = data.data.sumInfo
          console.log(qty.totalQty)
          commit(types.SAVE_COMMONCARTNUM, qty.totalQty)
          arr.forEach(e => {
            if (e.distQty > 0) {
              e.checked = true
            } else {
              e.checked = false
            }
            if (e.productList.length) {
              e.productList.forEach(i => {
                if (i.distQty > 0) {
                  i.checked = true
                } else {
                  i.checked = false
                }
              })
            }
          })
          console.log('商城购物车数据：', arr)
        }
        commit(types.CART_LIST, arr)
        resolve(res)
      }).catch(err => {
        console.log(err)
        reject(err)
      })
    })
  },
  // 获取购物车中的商品(地配商品)  地配商品没有启用会出现问题 增加commit(types.SAVE_SUPPLIERCARTNUM, 0)
  getSupplierCartData: ({commit}, data) => {
    return new Promise((resolve, reject) => {
      API.getSupplierSeriesCartList(data).then((res) => {
        let data = res.data
        let arr = []
        let qty = {}
        if (data.status == 0) {
          arr = data.data.list
          qty = data.data.sumInfo
          commit(types.SAVE_SUPPLIERCARTNUM, qty.totalQty)
          arr.forEach(e => {
            e.selectAll = true
            e.fsoSupplierProductDtos.forEach(i => {
              // i.disabled = false
              if (i.distQty > 0) {
                i.checked = true
              } else {
                i.checked = false
              }
              if (i.productSetList.length) {
                i.productSetList.forEach(el => {
                  if (el.distQty > 0) {
                    el.checked = true
                  } else {
                    el.checked = false
                  }
                })
              }
            })
          })
        }
        commit(types.CART_SUPPLIER_LIST, arr)
        resolve(res)
      }).catch(err => {
        console.log(err)
        reject(err)
      })
    })
  },

  // 添加到购物车(普通商品)
  addToCart: ({commit}, params) => {
    return new Promise((resolve, reject) => {
      API.getCartAdd(params).then((res) => {
        let data = res.data
        if (data.status == 0) {
          commit(types.ADD_TO_CART, data.data)
        }
        resolve(res)
      }).catch(err => {
        console.log(err)
        reject(err)
      })
    })
  },
  // 添加到购物车(地配商品)
  addToSupplierCart: ({commit}, params) => {
    return new Promise((resolve, reject) => {
      API.getCartSupplierAdd(params).then((res) => {
        let data = res.data
        if (data.status == 0) {
          commit(types.ADD_TO_CART, data.data)
        }
        resolve(res)
      }).catch(err => {
        console.log(err)
        reject(err)
      })
    })
  },
  // 添加到购物车(系列商品)
  addToSeriesCart: ({commit}, params) => {
    return new Promise((resolve, reject) => {
      API.getCartSeriesAdd(params).then((res) => {
        let data = res.data
        if (data.status == 0) {
          // commit(types.ADD_TO_SUPPLIER_CART, data.data)
        }
        resolve(res)
      }).catch(err => {
        console.log(err)
        reject(err)
      })
    })
  },
  // 添加到购物车(系列商品)
  addToDateCart: ({commit}, params) => {
    return new Promise((resolve, reject) => {
      API.getCartDateAdd(params).then((res) => {
        let data = res.data
        if (data.status == 0) {
          // commit(types.ADD_TO_SUPPLIER_CART, data.data)
        }
        resolve(res)
      }).catch(err => {
        console.log(err)
        reject(err)
      })
    })
  },
  // 添加到购物车(直送系列商品)
  addToSupplierSeriesCart: ({commit}, params) => {
    return new Promise((resolve, reject) => {
      API.getCartSupplierSeriesAdd(params).then((res) => {
        let data = res.data
        if (data.status == 0) {
          // commit(types.ADD_TO_SUPPLIER_CART, data.data)
        }
        resolve(res)
      }).catch(err => {
        console.log(err)
        reject(err)
      })
    })
  },
  // 删除购物车中的商品
  deleteCartProduct: ({commit}, data) => {
    return new Promise((resolve, reject) => {
      API.getCartDelete(data).then((res) => {
        let data = res.data
        if (data.status == 0) {
          commit(types.DELETE_CART_PRODUCT, data.data)
        }
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    })
  },
  // 删除购物车中的商品
  deleteSupplierCartProduct: ({commit}, data) => {
    return new Promise((resolve, reject) => {
      API.getCartSupplierDelete(data).then((res) => {
        let data = res.data
        if (data.status == 0) {
          commit(types.DELETE_CART_SUPPLIER_PRODUCT, data.data)
        }
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    })
  }
}

const mutations = {
  [types.USER_INFO](state, data) {
    state.userInfo = data
  },
  [types.SAVE_COMMONCARTNUM](state, data) {
    state.commonCartNum = data * 1
  },
  [types.SAVE_SUPPLIERCARTNUM](state, data) {
    state.supplierCartNum = data * 1
  },
  [types.CART_LIST](state, data) {
    state.cartList = data
  },
  [types.CART_SUPPLIER_LIST](state, data) {
    state.cartSupplierList = data
  },
  [types.ADD_TO_CART](state, data) {
    let result = data
    state.cartTotalQty = result.totalQty
  },
  [types.ADD_TO_SUPPLIER_CART](state, data) {
    let result = data
    state.cartSupplierTotalQty = result.totalQty
  },
  [types.DELETE_CART_PRODUCT](state, data) {
    let result = data
    state.cartTotalQty = result.totalQty
  },
  [types.DELETE_CART_SUPPLIER_PRODUCT](state, data) {
    let result = data
    state.cartSupplierTotalQty = result.totalQty
  }
}

const getters = {
  userData(state) {
    return state.userInfo
  },
  getCommonCartNum(state) {
    return state.commonCartNum * 1
  },
  getSupplierCartNum(state) {
    return state.supplierCartNum * 1
  },
  getCartNum(state) {
    return state.commonCartNum * 1 + state.supplierCartNum * 1
  },
  cartProductData(state) {
    let arr = state.cartList
    if (arr.length) {
      arr.forEach(item => {
        item.orderQty = item.orderQty * 1
      })
    }
    return arr || []
  },
  // 为了切换 返回的 字符串false  为Boolean值
  cartSupplierProductData(state) {
    let arr = state.cartSupplierList
    // if (arr.length) {
    //   arr.forEach(item => {
    //     if (item.selectAll === 'true') {
    //       item.selectAll = true
    //     }
    //     item.fsoSupplierProductDtos.forEach(i => {
    //       i.orderQty = i.orderQty * 1
    //     })
    //   })
    // }
    return arr || []
  }
}

export default {
  state,
  actions,
  mutations,
  getters
}
