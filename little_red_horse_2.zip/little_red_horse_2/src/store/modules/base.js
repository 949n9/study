import API from '../../core/index'
import * as types from '../mutation_types'

const state = {
  categoryList: [],
  categorySecondList: [],
  propertyList: [],
  promotionProduct: [],
  storeProduct: [],
  fwProduct: [],
  hotProduct: [],
  controlAreaProduct: [],
  categoryProduct: [],
  searchProduct: {}, // 统一搜索商品
  couponProduct: [], // 能使用当前优惠券的商品列表
  supplierProduct: [],
  receiverAddressList: [],
  maxRechargeAmount: '' // 风控
}

const actions = {
  // 品类列表
  getCategoryData: ({commit}, params) => {
    API.getCategoryList(params).then((res) => {
      let data = res.data
      let arr = []
      if (data.status == 0) {
        arr = data.data
      }
      if (params.parentId == '') {
        commit(types.CATEGORY_LIST, arr)
      } else {
        commit(types.CATEGORY_SECOND_LIST, arr)
      }
    }).catch(err => {
      console.log(err)
    })
  },
  // 商品属性列表
  getPropertyData: ({commit}, data) => {
    API.getPropertyList(data).then((res) => {
      let data = res.data
      let arr = []
      if (data.status == 0) {
        arr = data.data.list
      }
      commit(types.PROPERTY_LIST, arr)
    }).catch(err => {
      console.log(err)
    })
  },
  // 商品列表 (爆品促销)
  getPromotionData: ({commit}, data) => {
    API.getPromotionProduct(data).then((res) => {
      let data = res.data
      let obj = []
      if (data.status == 0) {
        obj = data.data
      }
      commit(types.PROMOTION_PRODUCT, obj)
    }).catch(err => {
      console.log(err)
    })
  },
  // 商品列表 (服务商)
  getFwData: ({commit}, data) => {
    API.getSupplierProductList(data).then((res) => {
      let data = res.data
      let obj = []
      if (data.status == 0) {
        obj = data.data
      }
      commit(types.FW_PRODUCT, obj)
    }).catch(err => {
      console.log(err)
    })
  },
  // 商品列表 (热卖推荐)
  getHotData: ({commit}, data) => {
    API.getHotProductList(data).then((res) => {
      let data = res.data
      let obj = []
      if (data.status == 0) {
        obj = data.data
      }
      commit(types.HOT_PRODUCT, obj)
    }).catch(err => {
      console.log(err)
    })
  },
  // 控区控价特优推荐列表
  getControlAreaData: ({commit}, data) => {
    API.getControlAreaProductList(data).then((res) => {
      let data = res.data
      let obj = []
      if (data.status == 0) {
        obj = data.data
      }
      commit(types.CONTROL_AREA_PRODUCT, obj)
    }).catch(err => {
      console.log(err)
    })
  },
  // 商品列表 (收藏商品)
  getStoreData: ({commit}, data) => {
    API.getCollectionProductList(data).then((res) => {
      let data = res.data
      let obj = []
      if (data.status == 0) {
        obj = data.data
      }
      commit(types.STORE_PRODUCT, obj)
    }).catch(err => {
      console.log(err)
    })
  },
  // 商品列表 (地配商品)
  getSupplierProductData: ({commit}, data) => {
    API.getSupplierProductList(data).then((res) => {
      let data = res.data
      let obj = []
      if (data.status == 0) {
        obj = data.data
      }
      commit(types.SUPPLIER_PRODUCT, obj)
    }).catch(err => {
      console.log(err)
    })
  },
  // 商品列表 (分类查询商品)
  getCategoryProductData: ({commit}, data) => {
    API.getCategoryProductList(data).then((res) => {
      let data = res.data
      let obj = []
      if (data.status == 0) {
        obj = data.data
      }
      commit(types.CATEGORY_PRODUCT, obj)
    }).catch(err => {
      console.log(err)
    })
  },
  // 统一搜索商品
  getProductUnifiedSearchData: ({commit}, data) => {
    API.getProductUnifiedSearchList(data).then((res) => {
      let data = res.data
      let obj = []
      if (data.status == 0) {
        obj = data.data
      }
      commit(types.SEARCH_PRODUCT, obj)
    }).catch(err => {
      console.log(err)
    })
  },
  // 获取能使用当前优惠券的商品
  getProductCouponData: ({commit}, data) => {
    API.getCouponProduct(data).then((res) => {
      let data = res.data
      let obj = []
      if (data.status == 0) {
        obj = data.data
        console.log(data)
      }
      commit(types.COUPON_PRODUCT, obj)
    }).catch(err => {
      console.log(err)
    })
  },
  getReceiverAddress: ({commit}, data) => {
    let params = {
      subCustomerId: data
    }
    API.getReceiveAddress(params).then((res) => {
      let data = res.data
      let arr = []
      if (data.status == 0) {
        arr = data.data.list
      }
      commit(types.RECEIVER_ADDRESSLIST, arr)
    }).catch(err => {
      console.log(err)
    })
  }
  // 支付宝、微信风控接口
  // getMaxRechargeAmount: ({commit}, data) => {
  //   API.getReceiveAddress().then((res) => {
  //     let data = res.data
  //     let arr = []
  //     if (data.status == 0) {
  //       arr = data.data.list
  //     }
  //     commit(types.RECEIVER_ADDRESSLIST, arr)
  //   }).catch(err => {
  //     console.log(err)
  //   })
  // }
}

const mutations = {
  [types.CATEGORY_LIST](state, data) {
    state.categoryList = data
  },
  [types.CATEGORY_SECOND_LIST](state, data) {
    state.categorySecondList = data
  },
  [types.PROPERTY_LIST](state, data) {
    state.propertyList = data
  },
  [types.PROMOTION_PRODUCT](state, data) {
    state.promotionProduct = data
  },
  [types.FW_PRODUCT](state, data) {
    state.fwProduct = data
  },
  [types.HOT_PRODUCT](state, data) {
    state.hotProduct = data
  },
  [types.CONTROL_AREA_PRODUCT](state, data) {
    state.controlAreaProduct = data
  },
  [types.STORE_PRODUCT](state, data) {
    state.storeProduct = data
  },
  [types.SUPPLIER_PRODUCT](state, data) {
    state.supplierProduct = data
  },
  [types.CATEGORY_PRODUCT](state, data) {
    state.categoryProduct = data
  },
  [types.SEARCH_PRODUCT](state, data) { // 统一搜索商品
    state.searchProduct = data
  },
  [types.COUPON_PRODUCT](state, data) { // 能使用当前优惠券的商品
    state.couponProduct = data
  },
  [types.RECEIVER_ADDRESSLIST](state, data) {
    state.receiverAddressList = data
  },
  [types.MAX_RECHARGE_AMOUNT](state, data) { // 风控
    state.maxRechargeAmount = data
  }
}

const getters = {
  categoryData(state) {
    return state.categoryList
  },
  propertyData(state) {
    return state.propertyList
  },
  promotionProductData(state) {
    return state.promotionProduct || []
  },
  fwProductData(state) {
    return state.fwProduct || []
  },
  hotProductData(state) {
    return state.hotProduct || []
  },
  controlAreaProductData(state) {
    return state.controlAreaProduct || []
  },
  storeProductData(state) {
    return state.storeProduct || []
  },
  supplierProductData(state) {
    return state.supplierProduct || []
  },
  categoryProductData(state) {
    return state.categoryProduct || []
  },
  searchProductData(state) {
    return state.searchProduct || {
      brands: [],
      categories: [],
      products: {
        list: []
      }
    }
  },
  couponProductData(state) {
    return state.couponProduct || []
  },
  getAddressList(state) {
    return state.receiverAddressList || []
  },
  // 保存搜索记录
  searchRecord(state) {
    return JSON.parse(localStorage.getItem('searchRecord')) || []
  },
  couponDetail(state) {
    return state.couponDetail || {}
  },
  maxRechargeAmount(state) {
    return state.maxRechargeAmount || {}
  }
}

export default {
  state,
  actions,
  mutations,
  getters
}
