import Vue from 'vue'
import Vuex from 'vuex'
import state from './state'
import mutations from './mutations'
import actions from './actions'
import getters from './getters'
import createPersistedState from 'vuex-persistedstate'
import base from './modules/base'
import user from './modules/user'

Vue.use(Vuex)

export default new Vuex.Store({
  modules: {
    'base': base,
    'user': user
  },
  state,
  plugins: [createPersistedState({
    reducer(val) {
      return {
        // 只储存state中的user
        user: val.user
      }
    }
  })],
  mutations,
  actions,
  getters
})
