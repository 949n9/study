import * as types from './mutation_types'

export default {
  showLoading: ({commit}, data) => {
    commit(types.SHOW_LOADING, data)
  },
  handleBaseDialog: ({commit}, data) => {
    commit(types.HANDLE_BASEDIALOG, data)
  },
  handleBasicInfo: ({commit}, data) => {
    commit(types.HANDLEBASIC_INFO, data)
  },
  saveCategoryInfo: ({commit}, data) => {
    commit(types.SAVECATEGORY_INFO, data)
  },
  saveSearchInfo: ({commit}, data) => {
    commit(types.SAVESEARCH_INFO, data)
  },
  saveSearchRecord: ({commit}, data) => {
    commit(types.SAVESEARCH_RECORD, data)
  },
  saveSelectInfo: ({commit}, data) => {
    commit(types.SAVE_SELECTINFO, data)
  },
  saveProductInfo: ({commit}, data) => {
    commit(types.SAVE_PRODUCTINFO, data)
  },
  saveProductSeriesInfo: ({commit}, data) => {
    commit(types.SAVE_PRODUCTSERIESINFO, data)
  },
  saveProductDateInfo: ({commit}, data) => {
    commit(types.SAVE_PRODUCTDATEINFO, data)
  },
  saveSupplierProductInfo: ({commit}, data) => {
    commit(types.SAVE_SUPPLIERPRODUCTINFO, data)
  },
  saveSupplierProductSeriesInfo: ({commit}, data) => {
    commit(types.SAVE_SUPPLIERPRODUCTSERIESINFO, data)
  },
  saveCartId: ({commit}, data) => {
    commit(types.SAVE_CARTID, data)
  },
  saveSupplierCartId: ({commit}, data) => {
    commit(types.SAVE_SUPPLIERCARTID, data)
  },
  addProductSuccess: ({commit}, data) => {
    commit(types.ADD_PRODUCTSUCCESS, data)
  },
  useCouponSuccess: ({commit}, data) => {
    commit(types.USE_COUPONSUCCESS, data)
  },
  hideLeftMenu: ({commit}, data) => {
    commit(types.HIDE_LEFTMENU, data)
  },
  saveSelectedId: ({commit}, data) => {
    commit(types.SAVE_SELECTEDID, data)
  },
  saveSelectedSupplierId: ({commit}, data) => {
    commit(types.SAVE_SELECTEDSUPPLIERID, data)
  },
  saveOrderStatus: ({commit}, data) => {
    commit(types.SAVE_ORDERSTATUS, data)
  },
  saveOrderInfo: ({commit}, data) => { // 支付信息
    commit(types.SAVE_ORDERINFO, data)
  },
  saveOrderId: ({commit}, data) => {
    commit(types.SAVE_ORDERID, data)
  },
  handleOrderStatus: ({commit}, data) => {
    commit(types.HANDLE_ORDERSTATUS, data)
  },
  saveCommonSettlementInfo: ({commit}, data) => {
    commit(types.SAVE_COMMONSETTLEMENTINFO, data)
  },
  saveSupplierSettlementInfo: ({commit}, data) => {
    commit(types.SAVE_SUPPLIERSETTLEMENTINFO, data)
  },
  handleAddressEdit: ({commit}, data) => {
    commit(types.HANDLE_ADDRESSEDIT, data)
  },
  saveCouponDetail: ({commit}, data) => {
    commit(types.SAVE_COUPON_DETAIL, data)
  }
}
