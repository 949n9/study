<template>
  <div class="home-wrap" style="padding: 0" v-if="defaultData.imgList.length">
    <div class="home-active">
      <img :src="defaultData.imgList[0].url" @click="handleJump(defaultData.imgList[0])" alt=""
           class="home-active-img">
    </div>
  </div>

</template>

<script>
  export default {
    name: 'MCapsule',
    props: {
      defaultData: {
        type: Object,
        required: true
      }
    },
    methods: {
      // 处理跳转 1：相应的路由地址 2. 广告页面
      handleJump(item) {
        this.handleADJump(item)
      }
    }
  }
</script>

<style scoped>

</style>
