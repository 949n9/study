<template>
  <!--今日抢购-->
  <div :style="{backgroundColor:defaultData.bgColor}" class="home-wrap" style="border: 1px solid #cccccc"
       v-show="flashSale.flashSaleProduct.length">
    <Row justify="space-between" style="margin-bottom: 15px" type="flex">
      <Col span="20">
        <div class="flashSale_wrap">
          <!--<img src="../../assets/images/home/jinqiqinggou@2x.png" alt="" class="buy_img">-->
          <span :style="{color:defaultData.textColor}" class="sale_title">{{defaultData.title}}</span>
          <div class="flashSale_wrap" v-if="status==2">
            <span :style="{color:defaultData.textColor}" class="buy_time">距离本场结束：</span>
            <div class="buy_wrap" v-if="downTime.d">
              <span class="buy_text">{{downTime.d}} </span>
            </div>
            <span class="buy_day" v-if="downTime.d">天</span>
            <div class="buy_wrap">
              <span class="buy_text">{{downTime.h}}</span>
            </div>
            <span class="buy_m">:</span>
            <div class="buy_wrap">
              <span class="buy_text">{{downTime.m}}</span>
            </div>
            <span class="buy_m">:</span>
            <div class="buy_wrap">
              <span class="buy_text">{{downTime.s}}</span>
            </div>
          </div>

          <div class="flashSale_wrap" v-if="status=='0'">
            <span class="before_sale" style="background-color: #19be6b">{{showTime}} 开抢</span>
          </div>
          <div class="flashSale_wrap" v-if="status=='3'">
            <span class="before_sale" style="background-color: #999999">活动已结束</span>
          </div>

        </div>
      </Col>
      <Col span="2">
        <span :style="{color:defaultData.textColor}"
              @click="toFlashSale"
              style="height: 40px;line-height: 40px;font-size: 14px;font-weight: 600;cursor: pointer ">更多 >>
        </span>
      </Col>
    </Row>

    <Row class="today-bg" v-if="flashSale.flashSaleProduct.length">
      <template v-for="(item,index) in flashSale.flashSaleProduct">
        <Col :key="item.id" class="grid-wrap" span="4">
          <Card :key="index" @click.native="toDetail(item)" class="p-wrap grid-wrap-today" style="height: 332px">
            <div @click="toDetail(item)" class="p-wrap-grid">
              <img :alt="item.productName" :onerror="defaultPimg()" :src="item.imgUrl" class="p-wrap-grid-img">
            </div>
            <h4 :title="item.productName" @click="toDetail(item)" class="p-wrap-name">{{item.productName}}</h4>
            <!-- <Badge :text="'物流费减免：'+item.deliveryFeeReduceRate+'%'" class-name="p-wrap-badge">
            </Badge> -->
            <div class="p-wrap-line">
              <p class="p-wrap-time" v-if="userData.showDistQty==='true'">还剩：{{item.dcDistQty}}件</p>
              <p class="p-wrap-time" v-else>
                  <span class="warn--text" v-if="item.dcDistQty>0&&item.dcDistQty<item.warnDistQty">库存紧张</span>
                  <span class="red--text" v-else-if="item.dcDistQty<=0">暂时无货</span>
                  <span v-else>库存充足</span>
              </p>
            </div>
            <div>
              <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice!=item.minPeriodPrice">
                    <span style="font-size:12px;">￥</span>{{item.minPeriodPrice}} -
                    <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                </p>
                <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice==item.minPeriodPrice">
                    <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                </p>
                <p class="p-wrap-price" v-if="item.productType!=2">
                    <span style="font-size:12px;">￥</span>{{item.taxPrice}}
                </p>
            </div>
            <div class="clearfix">
              <Button @click="toFlashSale" long type="success" v-if="status=='0'">即将开始
              </Button>
              <Button @click="toDetail(item)" long type="primary" v-else>订货
                <em v-show="item.orderQty>0">({{item.orderQty}})</em>
              </Button>
            </div>
          </Card>
        </Col>
      </template>
    </Row>
    <Row v-else>
      <template v-for="(item,index) in 5">
        <Col :key="index" class="col-wrap" span="4">
          <Card :key="index" class="p-wrap">
          </Card>
        </Col>
      </template>
    </Row>
  </div>

</template>

<script>
  import api from '../core/index'
  import {mapState, mapGetters, mapActions} from 'vuex'

  export default {
    name: 'MTodayPurchase',
    props: {
      defaultData: {
        type: Object,
        required: true
      },
      flashSale: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        currentTime: '',
        startTime: '',
        endTime: '',
        showTime: '',
        downTime: {
          d: null,
          h: '00',
          m: '00',
          s: '00'
        },
        beforeInterval: null,
        interval: null,
        status: null
      }
    },
    created() {
      this.getInitData()
      this.getTime()
    },
    computed: {
      ...mapState([]),
      ...mapGetters([
        'userData'
      ])
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'saveProductInfo',
        'saveProductSeriesInfo',
        'saveProductDateInfo'
      ]),
      getInitData() {
        this.flashSaleProduct = this.flashSale.flashSaleProduct.slice(0, 5)
        this.startTime = this.flashSale.startTime
        this.endTime = this.flashSale.endTime
        this.status = this.flashSale.status
        this.handleTime()
      },
      // 处理跳转 1：相应的路由地址 2. 广告页面
      handleJump(item) {
        this.handleADJump(item)
      },
      // 获取当前时间
      async getTime() {
        let self = this
        let {data} = await api.getCurrentTime()
        if (data.status == 0) {
          self.currentTime = data.data.currentTime
        }
      },
      // 去抢购页面
      toFlashSale() {
        this.$router.push({path: '/index/todaypromotionproduct', query: {id: this.flashSale.id}})
      },
      toDetail(row) {
        this.saveProductInfo(row.productId)
        this.saveProductSeriesInfo(row.productSetId)
        this.saveProductDateInfo('null')
        if (row.productType == '0') {
          this.handleBaseDialog({visible: true, type: 'productDetailVisible'})
        }
        if (row.productType == '1') {
          this.handleBaseDialog({visible: true, type: 'productSeriesDetailVisible'})
        }
        if (row.productType == '2') {
          this.handleBaseDialog({visible: true, type: 'productDateDetailVisible'})
        }
      },
      handleTime() {
        let self = this
        let a = this.$moment(this.startTime)
        let b = this.$moment(this.currentTime)

        let beforeTime = this.$moment(this.startTime).diff(this.$moment())
        let time = this.$moment(this.endTime).diff(this.$moment())

        // 未开始
        if (this.status == '0') {
          if (a.diff(b, 'days') >= 1) {
            this.showTime = this.startTime
          } else {
            this.showTime = this.startTime.substring(10)
          }
          self.beforeInterval = setInterval(function () {
            beforeTime -= 1000
            if (beforeTime < 0) {
              clearInterval(self.beforeInterval) // 判断是否到期,到期后自动删除定时器
              self.status = '2'
            }
          }, 1000)
        }

        self.interval = setInterval(function () {
          let t = null
          let d = null
          let h = null
          let m = null
          let s = null
          // js默认时间戳为毫秒,需要转化成秒
          t = time / 1000
          d = Math.floor(t / (24 * 3600))
          h = Math.floor((t - 24 * 3600 * d) / 3600)
          m = Math.floor((t - 24 * 3600 * d - h * 3600) / 60)
          s = Math.floor((t - 24 * 3600 * d - h * 3600 - m * 60))
          // 这里可以做一个格式化的处理,甚至做毫秒级的页面渲染,基于DOM操作,太多个倒计时一起会导致页面性能下降
          if (h < 10) {
            h = '0' + h
          }
          if (s < 10) {
            s = '0' + s
          }
          if (m < 10) {
            m = '0' + m
          }

          self.downTime = {
            s: s,
            d: d,
            h: h,
            m: m
          }

          time -= 1000
          if (time < 0) {
            clearInterval(self.interval) // 判断是否到期,到期后自动删除定时器
            self.interval = null
            self.status = '3'
          }
        }, 1000)
      }
    }
  }
</script>

<style lang="less">
  .sale_title {
    font-size: 30px;
    font-weight: 700;
  }

</style>
