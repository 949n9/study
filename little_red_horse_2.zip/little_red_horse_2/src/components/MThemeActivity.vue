<template>
  <!--主题活动-->
  <div class="theme-wrap" v-if="defaultData.imgList.length">
    <ul class="theme-ul">
      <li :key="index" :style="{width:defaultData.shareSize? `${(1200-(defaultData.nums-1)*8)/defaultData.nums}px`: '49%'}" :class="{'right-item': (index+1)%defaultData.nums==0}"
          v-for="(item,index) in defaultData.imgList">
        <img :src="item.url" @click="handleJump(item)" alt="" class="theme-img">
      </li>
    </ul>
  </div>

</template>

<script>
  export default {
    name: 'MThemeActivity',
    props: {
      defaultData: {
        type: Object,
        required: true
      }
    },
    methods: {
      // 处理跳转 1：相应的路由地址 2. 广告页面
      handleJump(item) {
        this.handleADJump(item)
      }
    }
  }
</script>

<style lang="less">
</style>
