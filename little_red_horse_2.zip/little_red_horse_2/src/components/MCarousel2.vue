<template>
  <div class="home-wrap carouse_2" style="padding: 0;">
    <div class="brand-header">
      <div>
        <span class="brand-title">{{defaultData.title}}</span>
        <em class="brand-em" v-if="defaultData.subTitle"></em>
        <span class="brand-des">{{defaultData.subTitle}}</span>
      </div>
    </div>
    <Carousel :arrow="defaultData.arrow" :autoplay="defaultData.autoplay"
              :autoplay-speed="defaultData.autoplaySpeed"
              :height="450"
              :radius-dot="defaultData.radiusDot"
              :trigger="defaultData.trigger"
              ref="carouselDom"
              v-if="defaultData.imgList.length>1"
              v-model="defaultData.carousel">
      <CarouselItem :key="i" style="display: flex;justify-content: center;" v-for="(item,i) in defaultData.imgList">
        <img :src="item.url" @click="handleJump(item)" alt="" class="carousel-img">
      </CarouselItem>
    </Carousel>
    <img :src="defaultData.imgList[0].url" @click="handleJump(defaultData.imgList[0])" alt=""
         class="carousel-img"
         v-else-if="defaultData.imgList.length==1">
    <img alt="" src="../assets/images/banner3.png" style="height: 450px;width: 100%;cursor: pointer" v-else>
  </div>

</template>

<script>
  export default {
    name: 'MCarousel',
    props: {
      defaultData: {
        type: Object,
        required: true
      },
      leftHeight: {
        type: String,
        required: false
      }
    },
    data() {
      return {}
    },
    created() {
      setTimeout(() => {
        this.$refs.carouselDom.handleResize()
      }, 1)
    },
    methods: {
      // 处理跳转 1：相应的路由地址 2. 广告页面
      handleJump(item) {
        this.handleADJump(item)
      }
    }
  }
</script>

<style lang="less">
.carouse_2{
  width: 1920px;
  margin: 0 auto;
   .ivu-carousel-item{
      width: 100%;
  }
}
</style>
