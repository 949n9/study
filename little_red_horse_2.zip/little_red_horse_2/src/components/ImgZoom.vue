<template>
  <div class="vue-magnify">
    <div class="preview-box" @mousemove="move($event)" @mouseout="out" ref="previewBox">
      <div class="video-wrap" v-show="openVideoVisiable">
         <div class="video-con">
            <div class="video-close-btn" @click="closeVideo()"><img src="@/assets/images/detail/close_btn.png" alt=""></div>
            <video controls :src="videoUrl" @pause="videoPause" @play="videoPlay" @error="videoError" id="video-src" class="video-src" ref="videoSrc"></video>
         </div>
      </div>
      <div class="video-wrap-btn" v-if="sourchSuccess&&!startPlay"><img class="video-open-btn" src="@/assets/images/detail/open1.png" @click="playVideo()"></div>
      <!-- <div class="video-wrap-btn1" v-if="sourchSuccess&&!startPlay"><img class="video-open-btn" src="@/assets/images/detail/open2.png" @click="playVideo()"></div> -->
      <img width="100%" :src="src" alt="">
      <div class="hover-box" ref="hoverBox" v-if="hoverShow"></div>
    </div>
    <div class="zoom-box" v-show="zoomVisiable" ref="zoomBox">
      <img :src="bigsrc" alt="" ref="bigImg">
    </div>
  </div>
</template>

<script>
  import {mapState} from 'vuex'
  export default {
    name: 'vue-magnify',
    props: {
      src: {
        type: String,
        default: ''
      },
      bigsrc: {
        type: String,
        default: ''
      },
      videoUrl: {
        type: String,
        default: ''
      }
    },
    data() {
      return {
        zoomVisiable: false,
        hoverVisiable: false,
        startPlay: false, // 播放开始
        openVideoVisiable: false, // 打开视频弹窗
        sourchSuccess: true, // 视频资源加载成功
        hoverShow: true
      }
    },
    computed: {
      ...mapState([
        'loading',
        'productDetailVisible',
        'productSeriesDetailVisible',
        'supplierDetailVisible',
        'supplierSeriesDetailVisible',
        'commonBrandDetailVisible',
        'commonBrandSeriesDetailVisible',
        'supplierBrandDetailVisible',
        'supplierBrandSeriesDetailVisible'
      ])
    },
    created() {
      console.log(this.videoUrl)
    },
    methods: {
      out() {
        this.zoomVisiable = false
      },
      move(ev) {
        this.init()
        const scrollX = document.documentElement.scrollLeft || document.body.scrollLeft
        const scrollY = document.documentElement.scrollTop || document.body.scrollTop
        let moveX = ev.clientX + scrollX
        let moveY = ev.clientY + scrollY
        let offsetLeft = this.offset(this.oPreviewBox).left
        let offsetTop = this.offset(this.oPreviewBox).top
        let left = moveX - offsetLeft - this.houverWidth / 2
        let top = moveY - offsetTop - this.houverHeight / 2
        let maxWidth = this.pWidth - this.houverWidth
        let maxHeight = this.pWidth - this.houverHeight

        left = left < 0 ? 0 : left > maxWidth ? maxWidth : left
        top = top < 0 ? 0 : top > maxHeight ? maxHeight : top
        let percentX = left / (maxWidth)
        let percentY = top / (maxHeight)

        this.oHoverBox.style.left = left + 'px'
        this.oHoverBox.style.top = top + 'px'
        this.oBigImg.style.left = percentX * (this.bWidth - this.imgWidth) + 'px'
        this.oBigImg.style.top = percentY * (this.bHeight - this.imgHeight) + 'px'
        this.$emit('move', ev)
        this.zoomVisiable = true
      },
      init() {
        this.oHoverBox = this.$refs.hoverBox
        this.oPreviewBox = this.$refs.previewBox
        this.oBigImg = this.$refs.bigImg
        this.imgBox = this.$refs.zoomBox

        this.houverWidth = this.oHoverBox.offsetWidth
        this.houverHeight = this.oHoverBox.offsetHeight
        this.pWidth = this.oPreviewBox.offsetWidth
        this.pHeight = this.oPreviewBox.offsetHeight

        this.imgWidth = this.oBigImg.offsetWidth
        this.imgHeight = this.oBigImg.offsetHeight
        this.bWidth = this.imgBox.offsetWidth
        this.bHeight = this.imgBox.offsetHeight
      },
      offset(el) {
        let top = el.offsetTop
        let left = el.offsetLeft
        while (el.offsetParent) {
          el = el.offsetParent
          top += el.offsetTop
          left += el.offsetLeft
        }
        return {
          left: left,
          top: top
        }
      },
      playVideo() {
        this.openVideoVisiable = true
        this.hoverShow = false
        this.$refs.videoSrc.play()
      },
      closeVideo() {
        this.openVideoVisiable = false
        this.hoverShow = true
        this.$refs.videoSrc.currentTime = 0
        this.videoPause()
      },
      videoPause() {
        console.log('暂停')
        this.startPlay = false
      },
      videoPlay() {
        console.log('开始')
        this.startPlay = true
      },
      videoError() {
        console.log('出错')
        this.sourchSuccess = false
      }
    },
    watch: {
      productDetailVisible (val, oldval) {
        if (val) {
          this.sourchSuccess = true
        } else {
          this.closeVideo()
        }
      },
      productSeriesDetailVisible (val, oldval) {
        if (val) {
          this.sourchSuccess = true
        } else {
          this.closeVideo()
        }
      },
      supplierSeriesDetailVisible (val, oldval) {
        if (val) {
          this.sourchSuccess = true
        } else {
          this.closeVideo()
        }
      },
      supplierDetailVisible (val, oldval) {
        if (val) {
          this.sourchSuccess = true
        } else {
          this.closeVideo()
        }
      },
      commonBrandDetailVisible (val, oldval) {
        if (val) {
          this.sourchSuccess = true
        } else {
          this.closeVideo()
        }
      },
      commonBrandSeriesDetailVisible (val, oldval) {
        if (val) {
          this.sourchSuccess = true
        } else {
          this.closeVideo()
        }
      },
      supplierBrandDetailVisible (val, oldval) {
        if (val) {
          this.sourchSuccess = true
        } else {
          this.closeVideo()
        }
      },
      supplierBrandSeriesDetailVisible (val, oldval) {
        if (val) {
          this.sourchSuccess = true
        } else {
          this.closeVideo()
        }
      }
    }
  }
</script>

<style lang="less">
  .vue-magnify {
    position: relative;
    .preview-box {
      width: 398px;
      height: 398px;
      border: 1px solid #dededd;
      position: relative;
      &:hover .hover-box {
        display: block;
      }
      .hover-box {
        position: absolute;
        display: none;
        left: 0;
        top: 0;
        width: 200px;
        height: 200px;
        border: 1px solid #545454;
        cursor: move;
        user-select: none;
        background: red;
        opacity: 0.2;
      }
    }
    .zoom-box {
      width: 450px;
      height: 450px;
      overflow: hidden;
      position: absolute;
      left: 435px;
      background: #ffffff;
      border: 1px solid #dc7a7a;
      z-index: 9999;
      top: 0;
      img {
        position: absolute;
        top: 0;
        left: 0;
      }
    }
  }
  .video-wrap{
    position:absolute;
    top:0;
    left:0;
    bottom:0;
    right:0;
    margin: auto;
    background: #000;
    cursor: pointer;
    .video-con{
      width: 100%;
      height: 100%;
      .video-close-btn{
        position:absolute;
        top:8px;
        right:8px;
        width: 30px;
        height: 30px;
        z-index: 1000;
        img{
          width: 100%;
        }
      }
    }
    .video-src{
      width: 100%;
      height: 100%;
    }
  }
  .video-wrap-btn{
     position:absolute;
    top:0;
    left:0;
    bottom:0;
    right:0;
    margin: auto;
    height:50px;
    background: rgba(1,1,1,0);
    cursor: pointer;
    .video-open-btn{
      position:absolute;
      display: block;
      width: 50px;
      height: 50px;
      top:50%;
      margin:0 auto;
      margin-top: -25px;
      margin-left: 175px;
      z-index:1000;
      cursor: pointer;
      opacity: 0.7;
      &:hover{
         opacity: 1;
      }
    }
  }
  .video-wrap-btn1{
     position:absolute;
    top:0;
    left:0;
    bottom:0;
    right:0;
    margin: auto;
    height:50px;
    background: rgba(1,1,1,0);
    cursor: pointer;
    .video-open-btn{
      position:absolute;
      display: block;
      width: 80px;
      height: 50px;
      top:50%;
      margin:0 auto;
      margin-top: -25px;
      margin-left: 175px;
      z-index:1000;
      cursor: pointer;
      opacity: 0.7;
      &:hover{
         opacity: 1;
      }
    }
  }
</style>
