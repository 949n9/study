<template>
  <Modal
    v-model="CustomerListVisible"
    title="请选择订货单位"
    :mask-closable="false"
    :footer-hide="true"
    scrollable
    @on-visible-change="change">
    <ul class="customer-list-wrap">
      <li v-for="(item,index) in tableData" :key="index" class="list-item" @click="selectItem(item)">
        <p class="text">{{item.name}}</p>
      </li>
    </ul>
  </Modal>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../core/index'
  import * as types from '@/store/mutation_types'

  export default {
    name: '',
    data() {
      return {
        name: '',
        columns: [
          {
            type: 'index',
            title: '序号',
            width: 60,
            align: 'center'
          },
          {
            title: '编号',
            width: 150,
            key: 'code'
          },
          {
            title: '名称',
            key: 'name',
            className: 'table-cell'
          }
        ],
        tableData: []
      }
    },
    computed: {
      ...mapState([
        'CustomerListVisible'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'selectSub',
        'saveCommonCartNum',
        'saveSupplierCartNum'
      ]),
      change(v) {
        if (v) {
          this.getList()
        } else {
          this.cancel()
        }
      },
      // 获取
      async getList() {
        let self = this
        let params = {
          searchCondition: self.name
        }
        let {data} = await api.getSubCustomerList(params)
        console.log(data)
        self.tableData = data.data.list
      },
      selectItem(row) {
        console.log(row)
        // 选择部门
        this.selectSub({subCustomerId: row.id}).then(res => {
          let data = res.data
          if (data.status == 0) {
            console.log(data.data.totalQty)
            this.saveCommonCartNum(data.data.totalQty)
            this.saveSupplierCartNum(data.data.supplierTotalQty)
            this.$store.commit(types.USER_INFO, Object.assign({}, data.data, this.userData))
            this.$router.replace({name: 'home'})
            // 进行刷新操作，清除浏览器缓存
            // window.location.reload(true)
            this.cancel()
          }
        })
      },
      cancel() {
        this.handleBaseDialog({visible: false, type: 'CustomerListVisible'})
      }
    }
  }
</script>

<style lang="less">
  .customer-list-wrap {
    height: 400px;
    padding: 10px 30px;
    overflow: auto;
    .list-item {
      text-align: center;
      background-color: #F4F9FF;
      height: 50px;
      line-height: 50px;
      border-radius: 5px;
      font-size: 16px;
      margin-bottom: 5px;
      cursor: pointer;
    }
    .list-item:hover {
      color: #E61E10;
      background-color: #edf2f8;
    }
  }

  .ivu-table td.table-cell {
    color: blue;
    cursor: pointer;
  }
</style>
