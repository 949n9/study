<template>
  <div class="home-wrap" v-show="defaultProduct.length">
    <Row justify="space-between" type="flex">
      <Col span="3">
        <span class="p-title">{{defaultData.title}} </span>
      </Col>
      <Col span="2">
        <Button to="/index/hotproduct" type="text">更多>></Button>
      </Col>
    </Row>

    <Row>
      <Col span="4">
        <div class="activity-wrap-cus">
          <img :src="defaultData.bgImage" @click="jump('/index/hotproduct')" alt="" class="img"
               v-if="defaultData.bgImage">
        </div>
      </Col>
      <Col span="20">
        <Row v-if="defaultProduct.length">
          <template v-for="(item,index) in defaultProduct">
            <Col :key="item.id" class="grid-wrap" span="4">
              <Card :key="index" @click.native="toDetail(item)" class="p-wrap" style="height: 341px">
                <div @click="toDetail(item)" class="p-wrap-grid">
                  <img :alt="item.productName" :onerror="defaultPimg()" :src="item.imgUrl" class="p-wrap-grid-img">
                </div>
                <h4 :title="item.productName" @click="toDetail(item)" class="p-wrap-name">
                  <img src="@/assets/images/detail/icon_shangcheng.png" alt="" srcset="" v-if="item.serviceType==2">
                  <img src="@/assets/images/detail/icon_service.png" alt="" srcset="" v-if="item.serviceType==1">
                  <img src="@/assets/images/detail/icon_shangjia.png" alt="" srcset="" v-if="item.serviceType==0">
                  {{item.productName}}
                </h4>
                <p class="p-wrap-areaProduct-flag" v-if="item.areaProduct==1">控区控价</p>
                <p v-if="item.areaProduct==0" style="height:18px;margin:5px 0;"></p>
                <!-- <div class="p-wrap-line" v-if="item.areaProduct==0" style="height:26px;">
                  <Badge :text="'物流费减免：'+item.deliveryFeeReduceRate+'%'" class-name="p-wrap-badge">
                  </Badge>
                </div> -->
                <!-- <div class="p-wrap-from">
                   <img src="../../assets/images/detail/icon_shangchen.png" alt="" srcset="">
                   <span>{{'小红马商城直供'}}</span>
                </div> -->
                <!-- <p class="p-wrap-time" style="height:20px;"></p> -->
                <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                  库存：{{item.dcDistQty}}
                </p>
                <p class="p-wrap-time" v-else>
                  <span class="warn--text" v-if="item.dcDistQty>0&&item.dcDistQty<item.warnDistQty">库存紧张</span>
                  <span class="red--text" v-else-if="item.dcDistQty<=0">暂时无货</span>
                  <span v-else>库存充足</span>
                </p>
                <div v-if="item.areaProduct==0">
                  <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice!=item.minPeriodPrice">
                    <span style="font-size:12px;">￥</span>{{item.minPeriodPrice}} -
                    <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                  </p>
                  <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice==item.minPeriodPrice">
                      <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                  </p>
                  <p class="p-wrap-price" v-if="item.productType!=2">
                      <span style="font-size:12px;">￥</span>{{item.taxPrice}}
                  </p>
                </div>
                <div v-if="item.areaProduct==1" style="margin:10px 0;color:#E61E10;">
                    <span class="p-wrap-hide" v-if="item.approveStatus==0">加盟看价格</span>
                    <span class="p-wrap-hide" v-if="item.approveStatus==1">审核中</span>
                    <span class="p-wrap-hide" v-if="item.approveStatus==2">已退回</span>                  
                </div>
                <div class="clearfix" v-if="item.areaProduct==0">
                  <Button type="primary" long v-if="item.taxPrice*1>0" @click="toDetail(item)">订货
                    <em v-show="item.orderQty>0">({{item.orderQty}})</em>
                  </Button>
                </div>
                <div class="p-wrap-areaProduct" v-if="item.areaProduct==1">
                    <Button type="primary" class="button-primary" v-if="item.approveStatus==0">申请加盟</Button>
                    <Button class="disable-btn button-primary" v-if="item.approveStatus==1">审核中</Button>
                    <Button class="disable-btn button-primary" v-if="item.approveStatus==2">已退回</Button>
                </div>
                <!-- <div class="p-wrap-areaProduct" v-if="item.areaProduct==1" style="margin-top:5px;">
                  <Button type="primary" v-if="item.approveStatus==0">申请加盟</Button>
                  <Button class="disable-btn" v-if="item.approveStatus==1">审核中</Button>
                  <Button class="disable-btn" v-if="item.approveStatus==2">已退回</Button>
                </div> -->
              </Card>
            </Col>

          </template>
        </Row>
        <Row v-else>
          <template v-for="(item,index) in defaultProduct">
            <Col :key="index" class="col-wrap" span="4">
              <Card :key="index" class="p-wrap">
              </Card>
            </Col>
          </template>
        </Row>
      </Col>
    </Row>
  </div>

</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'

  export default {
    name: 'MHotProduct',
    props: {
      defaultData: {
        type: Object,
        required: true
      },
      defaultProduct: {
        type: Array,
        required: true
      }
    },
    computed: {
      ...mapState([]),
      ...mapGetters([
        'userData'
      ])
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'saveProductInfo',
        'saveProductSeriesInfo',
        'saveProductDateInfo'
      ]),
      jump(path) {
        this.$router.push({path: path})
      },
      toDetail(row) {
        this.toProductDetail(row)
      }
    }
  }
</script>

<style lang="less">
// .p-wrap-hide{
//   margin:5px 0;
//   color:#E61E10;
//   display:flex;
//   align-items: center;
//   justify-content: space-between;
// }
</style>
