<template>
  <!--品牌专区-->
  <div class="home-wrap" style="padding: 0" v-if="defaultData.imgList.length">
    <div class="brand-header">
      <div>
        <span class="brand-title">{{defaultData.title}}</span>
        <em class="brand-em"></em>
        <span class="brand-des">{{defaultData.subTitle}}</span>
      </div>
    </div>
    <Carousel :height="180" :loop="true"
              :radius-dot="true" autoplay ref="carouselDom" v-if="defaultData.imgList.length>1">
      <CarouselItem :key="i" v-for="(item,i) in defaultData.imgList">
        <img :src="item.url" @click="handleJump(item)" alt="" class="carousel-brand-img">
      </CarouselItem>
    </Carousel>
    <div style="height: 180px" v-if="defaultData.imgList.length==1">
      <img :src="defaultData.imgList[0].url" @click="handleJump(defaultData.imgList[0])" alt=""
           class="carousel-brand-img">
    </div>
    <ul class="brand-list">
      <li :key="index" class="brand-item" v-for="(item,index) in defaultData.brandList">
        <img :src="item.url" @click="handleJump(item)" alt=""
             class="brand-img">
      </li>
    </ul>
  </div>

</template>

<script>
  export default {
    name: 'MBrand',
    props: {
      defaultData: {
        type: Object,
        required: true
      }
    },
    created() {
      setTimeout(() => {
        this.$refs.carouselDom.handleResize()
      }, 1)
    },
    methods: {
      // 处理跳转 1：相应的路由地址 2. 广告页面
      handleJump(item) {
        this.handleADJump(item)
      }
    }
  }
</script>

<style scoped>

</style>
