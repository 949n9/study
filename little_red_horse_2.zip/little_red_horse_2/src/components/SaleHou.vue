<template>
  <Modal
    :value="saleDetailVisible"
    title="售后流程"
    :mask-closable="false"
    footer-hide
    width="950"
    :styles="{top: '60px'}"
    @on-visible-change="saleDialogChange">
    <div class="sale-hou" :style="{height: tabSaleHeight+'px'}">
       <iframe :style="{height: tabSaleHeight+'px'}" src="http://mall.redhoma.cn/question_pc/Organization/Chapter2.html#1_1" frameborder="0"></iframe>
    </div>
  </Modal>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
//   import api from '../core/index'

  export default {
    name: '',
    data() {
      return {
        tabSaleHeight: ''
      }
    },
    computed: {
      ...mapState([
        'CustomerListVisible',
        'saleDetailVisible'
      ]),
      ...mapGetters([])
    },
    created() {
      this.handleBaseDialog({visible: false, type: 'saleDetailVisible'})
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'selectSub',
        'saveCommonCartNum',
        'saveSupplierCartNum'
      ]),
      saleDialogChange(v) {
        console.log(v)
        this.handleBaseDialog({visible: v, type: 'saleDetailVisible'})
        let h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
        this.tabSaleHeight = h - 150
      }
    }
  }
</script>

<style lang="less">

</style>
