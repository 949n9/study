<template>
  <div class="nofound">
    <div class="content-text">
      <h1>404 <br>您访问的页面失踪了</h1>
      <div>
        <router-link to="/">
          <Button class="btn" type="text">
            << 返回首页 <Icon type="md-home"  size="14" style="margin-bottom: 3px;"/>
          </Button>
        </router-link>
      </div>
    </div>
  </div>
</template>

<style lang="less">
  .nofound {
    height: 100%;
    width: 100%;
    position: absolute;
    left: 0;
    top: 0;
    text-align: center;
    background: url("../assets/images/404.png") no-repeat center center;
    background-size: cover;

    .content-text {
      color: #4a6d8c;
      padding-top: 100px;
      h1 {
        font-size: 30px;
        line-height: 48px;
        margin: 0;
        padding: 0;
      }
    }
    .btn {
      cursor: pointer;
      font-size: 14px;
    }
  }

  .el-input__inner {
    height: 35px;
  }
</style>
