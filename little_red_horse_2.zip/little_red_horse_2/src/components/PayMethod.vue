<template>
  <Modal
    :value="payMethodDialogVisible"
    title="付款"
    :mask-closable="false"
    footer-hide
    width="1000"
    :styles="{top: '130px'}"
    class-name="pay-modal"
    @on-visible-change="dialogChange"
  >
    <div class="pay-method-warp">
       <div class="pay-method-warp-top">
          <p>订单总金额：<span>￥{{formatAmount(accountInfo.totalPayAmount, 2)}}</span></p>
          <p @click="openOrderDetail()"></p>
          <p>共1张订单，为保证价格不影响您的订单，请尽快完成付款。</p>
       </div>
       <div class="pay-method-warp-method">
          <p>使用：</p>
          <ul>
              <li :class="{'default': !item.checked,
                'selected1': [0].includes(index)&&item.checked,
                'selected2': [1, 2].includes(index)&&item.checked,
                'disabled': item.disabled}"
                v-for="(item, index) in payMethods" :key="index" @click="selected(item, index)">
                <img :src="item.icon" alt="" srcset="">
                <span v-if="index==0">账户可用余额：{{`￥${formatAmount(accountInfo.availableBalance, 2)}`}}</span>
              </li>
          </ul>
       </div>
       <div class="pay-method-warp-bottom">
          <div>支付：<span>￥{{formatAmount(totalPayAmount, 2)}}</span></div>
          <Button type="error" :disabled="loading" class="btn" @click="pay()">支付</Button>
       </div>
    </div>
     <Modal
        :value="tipRechargeDialogVisible"
        title="付款"
        :mask-closable="false"
        footer-hide
        width="800"
        :styles="{top: '150px'}"
        class-name="pay-modal"
        @on-visible-change="tipRechargeChange"
        @on-cancel="closeDialog">
        <div class="tip-info">
            <div>
               <p class="totalpay-price">￥{{formatAmount((accountInfo.totalPayAmount-accountInfo.availableBalance), 2)}}</p>
               <p class="tatalpay-text">应付金额</p>
            </div>
            <p class="total-text">订单总金额：<span>￥{{formatAmount(accountInfo.totalPayAmount, 2)}}</span></p>
            <p class="available-text">账户可用余额：<span>￥{{formatAmount(accountInfo.availableBalance, 2)}}</span></p>
            <p class="des">因微信和支付宝政策限制，当单笔支付金额大于20000.00元时，可能出现支付失败的情况，请先充值到您的资金账户，充值成功后再发送订单。</p>
            <div class="pay-btn">
                 <Button type="error" :disabled="loading" class="btn" @click="goRecharge()">现在去充值</Button>
            </div>
        </div>
     </Modal>
     <Modal v-model="wxModal" :title="payType=='weixin'?'微信支付':'支付宝支付'" width="600"
           :mask-closable="false"
           @on-cancel="wxModalClose"
           footer-hide>
      <div class="wx-modal-1">
        <h3>请您在 <b class="red--text">5分钟</b> 内完成支付</h3>
        <!-- <p class="">如果支付后1分钟内未得到“支付成功”的提示，请关闭本窗口，</p>
        <p>稍后再点击本功能右上角的“充值记录”按钮，查看支付“状态”，以确定是否支付成功。</p> -->
        <div class="wx-modal-content-1">
          <p>客户名称：<span class="red--text">{{payInfo.customerName}}</span></p>
          <p>充值单号：<span class="red--text">{{payInfo.code}}</span></p>
          <p>充值金额：<span class="red--text">¥{{payInfo.chargeAmount}}</span></p>
        </div>
        <div class="wx-modal-img" v-loading="imgLoading">
          <img :src="payInfo.qrCodeImgUrl" alt="" class="code-img">
          <p v-if="payType=='weixin'">请使用微信扫描二维码！</p>
          <p v-if="payType=='zhifubao'">请使用支付宝扫描二维码！</p>
        </div>
        <!-- <ul class="content-tip">
          <li>
            <em class="red--text">*</em> 温馨提示：
          </li>
          <li class="item" v-if="payType=='weixin'">
            由于政策原因，使用微信绑定的“信用卡”做在线充值时，如果经常金额较大，有时会被禁止用信用卡支付。
            如果遇到这种情况，可以改为使用微信绑定的<b>储蓄卡或余额</b>进行支付。
          </li>
          <li class="item" v-if="payType=='zhifubao'">
            由于政策原因，使用支付宝绑定的“信用卡”做在线充值时，如果经常金额较大，有时会被禁止用信用卡支付。
            如果遇到这种情况，可以改为使用支付宝绑定的<b>储蓄卡或余额</b>进行支付。
          </li>
        </ul> -->
      </div>
    </Modal>
  </Modal>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '@/core'
  // import * as opt from './options'

  export default {
    name: 'PayMethod',
    data() {
      return {
        payMethods: [
          {checked: false, type: 0, disabled: false, tip: false, click: true, icon: require('@/assets/images/pay/pay_type_yu_icon.png')},
          {checked: false, type: 1, disabled: false, tip: false, click: true, icon: require('@/assets/images/pay/pay_type_wx_icon.png')},
          {checked: false, type: 2, disabled: false, tip: false, click: true, icon: require('@/assets/images/pay/pay_type_ali_icon.png')}
        ],
        accountInfo: {
          availableBalance: '0.00',
          totalAmount: '0.00',
          totalPayAmount: '0.00',
          limitAmount: '20000.00'
        },
        totalPayAmount: '0.00',
        settlementInfo: {},
        tipRechargeDialogVisible: false,
        aloneSelect: false,
        payType: 'weixin',
        payInfo: {},
        payResult: {},
        timer: null,
        wxModal: false,
        successModal: false,
        imgLoading: false
      }
    },
    computed: {
      ...mapState([
        'loading',
        'payMethodDialogVisible',
        'orderInfo',
        'commonSettlementInfo',
        'supplierSettlementInfo',
        'orderType' // 1 配送(从购物车结算) 3 配送(从订单详情结算) 2直送（从购物车结算） 4直送（从订单详情结算）
      ]),
      ...mapGetters([
        'getCommonCartNum',
        'getSupplierCartNum'

      ])
    },
    watch: {
      'payMethods': {
        handler: function(val, oldval) {
          let temp = val.filter(e => {
            return e.checked
          })
          console.log(temp)
          if (temp.length == 1 && [1, 2].includes(temp[0].type)) {
            this.totalPayAmount = parseFloat(this.accountInfo.totalPayAmount)
          }
          if (temp.length == 2) {
            this.totalPayAmount = parseFloat(this.accountInfo.totalPayAmount) - parseFloat(this.accountInfo.availableBalance)
          }
          if (temp.length == 1 && [0].includes(temp[0].type)) {
            this.totalPayAmount = '0.00'
          }
          if (temp.length == 0) {
            this.totalPayAmount = '0.00'
          }
        },
        deep: true
      }
    },
    created() {
      this.initData()
    },
    mounted() {
      this.handleBaseDialog({visible: false, type: 'payMethodDialogVisible', orderType: this.orderType})
      this.commonDialog = this.$refs.commonDialog
      // taotalPayAmount
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'handleBasicInfo',
        'saveCommonCartNum',
        'saveSupplierCartNum',
        'saveOrderStatus',
        'addProductSuccess',
        'handleOrderStatus'
      ]),
      initData() {
        this.handleBaseDialog({visible: false, type: 'payMethodDialogVisible', orderType: this.orderType})
      },
      dialogChange(v) {
        if (v) {
          if (this.orderType == 1 || this.orderType == 3) {
            let temp = {
              availableBalance: parseFloat(this.commonSettlementInfo.availableBalance),
              totalAmount: parseFloat(this.commonSettlementInfo.totalAmount),
              totalPayAmount: parseFloat(this.commonSettlementInfo.taotalPayAmount),
              maxRechargeAmount: parseFloat(this.commonSettlementInfo.maxRechargeAmount)
            }
            this.accountInfo = Object.assign({}, this.commonSettlementInfo, temp)
          }
          if (this.orderType == 2 || this.orderType == 4) {
            let temp = {
              availableBalance: parseFloat(this.supplierSettlementInfo.availableBalance),
              totalAmount: parseFloat(this.supplierSettlementInfo.totalAmount),
              totalPayAmount: parseFloat(this.supplierSettlementInfo.taotalPayAmount),
              maxRechargeAmount: parseFloat(this.supplierSettlementInfo.maxRechargeAmount)
            }
            this.accountInfo = Object.assign({}, this.supplierSettlementInfo, temp)
          }
          console.log(this.accountInfo)
          this.handleBaseDialog({visible: true, type: 'payMethodDialogVisible', orderType: this.orderType})
          this.initSelect()
        } else {
          this.handleBaseDialog({visible: false, type: 'payMethodDialogVisible', orderType: this.orderType})
        }
      },
      tipRechargeChange(v) {
        this.tipRechargeDialogVisible = v
        if (!v) {
          this.handleBaseDialog({visible: false, type: 'payMethodDialogVisible', orderType: this.orderType})
        }
      },
      initSelect() {
        // 初始化支付方式
        this.payMethods = [
          {checked: false, type: 0, disabled: false, tip: false, click: true, icon: require('@/assets/images/pay/pay_type_yu_icon.png')},
          {checked: false, type: 1, disabled: false, tip: false, click: true, icon: require('@/assets/images/pay/pay_type_wx_icon.png')},
          {checked: false, type: 2, disabled: false, tip: false, click: true, icon: require('@/assets/images/pay/pay_type_ali_icon.png')}
        ]
        this.aloneSelect = false
        this.tipRechargeDialogVisible = false
        // 获取应付金额
        if (parseFloat(this.accountInfo.availableBalance) >= parseFloat(this.accountInfo.totalPayAmount)) {
          this.totalPayAmount = this.accountInfo.availableBalance - this.accountInfo.totalPayAmount
        }
        if (parseFloat(this.accountInfo.totalPayAmount) > parseFloat(this.accountInfo.availableBalance) && parseFloat(this.accountInfo.availableBalance) >= 0) {
          this.totalPayAmount = this.accountInfo.totalPayAmount - this.accountInfo.availableBalance
        }
        if (parseFloat(this.accountInfo.availableBalance) < 0) {
          this.totalPayAmount = this.accountInfo.totalPayAmount
        }
        console.log('应付金额：', this.totalPayAmount)
        let limitAmount = this.accountInfo.maxRechargeAmount
        console.log(limitAmount)
        // 订单总金额大于M=20000时
        if (this.accountInfo.totalPayAmount > limitAmount) {
          // 资金账户可用余额大于等于订单总金额
          if (parseFloat(this.accountInfo.availableBalance) >= parseFloat(this.accountInfo.totalPayAmount)) {
              this.payMethods[0]['checked'] = true
              this.payMethods[0]['click'] = false
              this.payMethods[1]['disabled'] = true
              this.payMethods[2]['disabled'] = true
          } else if (parseFloat(this.accountInfo.availableBalance) < parseFloat(this.accountInfo.totalPayAmount) && parseFloat(this.accountInfo.availableBalance) > 0) { // 资金账户可用余额小于订单总金额且大于0
            // 应付金额小于等于M=20000,弹窗提示
            let temp = this.accountInfo.totalPayAmount - this.accountInfo.availableBalance
            console.log(temp)
            if (parseFloat(temp) <= limitAmount) {
                this.payMethods[0]['checked'] = true
                this.payMethods[1]['checked'] = true
                this.payMethods[0]['tip'] = true
            } else { // 弹窗提示去充值
              console.log('去充值吧')
              this.tipRechargeDialogVisible = true
              this.handleBaseDialog({visible: false, type: 'payMethodDialogVisible', orderType: this.orderType})
            }
          } else if (parseFloat(this.accountInfo.availableBalance) <= 0) { // 资金账户可用余额小于等于0
            console.log('去充值吧')
            this.tipRechargeDialogVisible = true
            this.handleBaseDialog({visible: false, type: 'payMethodDialogVisible', orderType: this.orderType})
          }
        } else { // 订单总金额小于等于20000元时
          // 账户可用余额大于等于订单总金额
          console.log(parseFloat(this.accountInfo.availableBalance), parseFloat(this.accountInfo.totalAmount))
          if (parseFloat(this.accountInfo.availableBalance) >= parseFloat(this.accountInfo.totalAmount)) {
            console.log('账户可用余额大于等于订单总金额')
            this.payMethods[0]['checked'] = true
            this.aloneSelect = true
          }
          // let temp = 0
          // 账户可用余额小于订单总金额时且大于0
          if (parseFloat(this.accountInfo.availableBalance) > 0 && parseFloat(this.accountInfo.totalAmount) > parseFloat(this.accountInfo.availableBalance)) {
            console.log('账户可用余额大于0且小于订单总金额')
            this.payMethods[0]['checked'] = true
            this.payMethods[1]['checked'] = true
          }
          // 账户可用余额等于0
          if (this.accountInfo.availableBalance <= 0) {
            console.log('账户可用余额小于等于0')
            this.payMethods[0]['disabled'] = true
            this.payMethods[0]['checked'] = false
            this.payMethods[1]['checked'] = true
          }
        }
      },
      selected(item) {
        // 至少有一个选中
        let temp = this.payMethods.filter(e => {
          return e.checked
        })
        if (temp.length == 1 && item.checked) {
          return null
        }
        // 禁用不可点击
        if (item.disabled || !item.click) {
          return null
        }
        // 账户支付不能取消
        if (item.type === 0) {
          if (item.tip && item.checked) {
            this.$Modal.warning({
              title: '提示！',
              content: '如果取消余额支付，那么需要用微信或支付宝支付的金额将大于20000.00元，' +
              '因微信和支付宝政策限制，单笔金额较大时可能出现支付失败的情况，所以不建议取消余额支付。',
              onOk: () => {
              }
            })
          }
          if (!item.tip) {
            item.checked = !item.checked
          }
        } else { // 正常选中与取消选中
          if (!item.disabled) {
            item.checked = !item.checked
          }
        }
        // 支付宝与微信支付为单选
        if ([1, 2].includes(item.type)) {
          // item.checked = !item.checked
          if (item.checked) {
            if (item.type == 1) {
              item.checked = true
              this.payMethods[2].checked = false
            }
            if (item.type == 2) {
              item.checked = true
              this.payMethods[1].checked = false
            }
          } else {
            item.checked = false
          }
        }
        // 三种支付方式为单选
        if (this.aloneSelect) {
          if (item.checked) {
            if (item.type == 1) {
              item.checked = true
              this.payMethods[2].checked = false
              this.payMethods[0].checked = false
            }
            if (item.type == 2) {
              item.checked = true
              this.payMethods[1].checked = false
              this.payMethods[0].checked = false
            }
            if (item.type == 0) {
              item.checked = true
              this.payMethods[2].checked = false
              this.payMethods[1].checked = false
            }
          } else {
            item.checked = false
          }
        }
      },
      goRecharge() {
        this.tipRechargeDialogVisible = false
        this.handleBaseDialog({visible: false, type: 'cartDialogVisible'})
        this.handleBaseDialog({visible: false, type: 'commonSettlementDialogVisible'})
        this.handleBaseDialog({visible: false, type: 'supplierSettlementDialogVisible'})
        this.handleBaseDialog({visible: false, type: 'commonOrderDialogVisible'})
        this.handleBaseDialog({visible: false, type: 'supplierOrderDialogVisible'})
        this.handleBaseDialog({visible: false, type: 'orderDialogVisible'})

        this.$router.push({path: '/mine/recharge', query: {amount: this.accountInfo.totalPayAmount}})
      },
      openOrderDetail() {
        this.handleBaseDialog({visible: true, type: 'commonOrderDialogVisible'})
      },
      pay() {
        let temp = this.payMethods.filter(e => {
          return e.checked
        }).map(item => {
          return item.type
        })
        console.log(temp, this.accountInfo)
        if (!temp.length) {
          this.$Notice.info({
            desc: '请选择支付方式！'
          })
        } else {
          if (temp.includes(1)) {
            console.log('微信支付')
            this.payType = 'weixin'
            this.handlePay(1)
          }
          if (temp.includes(2)) {
            console.log('支付宝支付')
            this.payType = 'zhifubao'
            this.handlePay(2)
          }
          if (temp.includes(0) && temp.length == 1) {
            console.log('账户余额支付')
            if (this.orderType == 1) { this.toSettlement(1) }
            if (this.orderType == 2) { this.toSupplierSettlement(2) }
            if (this.orderType == 3) { this.toSettlement(3) }
            if (this.orderType == 4) { this.toSupplierSettlement(4) }
          }
        }
      },
      // 进行结算（配送）
      async toSettlement(type) {
        let self = this
        let params = {
          distFeeReduceRatio: self.accountInfo.distFeeReduceRatio,
          distFeeReduceRuleId: self.accountInfo.distFeeReduceRuleId,
          description: self.accountInfo.description,
          payPassword: self.accountInfo.payPassword,
          receiveAddressId: self.accountInfo.receiveAddressId || '',
          couponIds: self.accountInfo.couponIds
        }
        if (type == 1) { params = Object.assign({}, params, {ids: self.accountInfo.cartId}) }
        if (type == 3) { params = Object.assign({}, params, {orderId: self.accountInfo.orderId}) }
        let {data} = await api.getOrderSend(params)
        if (data.status == 0) {
          self.$Notice.success({
            desc: data.message
          })
          self.saveOrderStatus({type: 'commonOrder', status: '1', name: '1'})
          self.handleOrderStatus(new Date().getTime())
          self.handleBaseDialog({visible: false, type: 'commonSettlementDialogVisible'})
          self.handleBaseDialog({visible: false, type: 'cartDialogVisible'})
          self.handleBaseDialog({visible: false, type: 'payMethodDialogVisible', orderType: 1})
          self.handleBaseDialog({visible: false, type: 'orderDialogVisible'})
          self.handleBaseDialog({visible: false, type: 'commonOrderDialogVisible'})
          self.$router.push({name: 'paysuccess', query: {amount: data.data.payAmount, orderId: data.data.orderId, type: 'commonOrder'}})
          // self.$Modal.success({
          //   title: '温馨提示',
          //   content: '<div margin:0 auto 30px;font-size: 18px!important;>订单发送成功！</div>' +
          //            '<p>下午16:00前发送的订单将于当天审核发出，请耐心等待。</p>' +
          //            '<p>为保障您的权益，请先验货，再签收！</p>',
          //   width: '450',
          //   onOk: () => {
          //     self.handleBaseDialog({visible: false, type: 'commonSettlementDialogVisible'})
          //     self.handleBaseDialog({visible: false, type: 'cartDialogVisible'})
          //     self.handleBaseDialog({visible: false, type: 'payMethodDialogVisible', orderType: 1})
          //     self.handleBaseDialog({visible: false, type: 'commonOrderDialogVisible'})
          //     self.handleBaseDialog({visible: true, type: 'orderDialogVisible'})
          //   }
          // })
        } else {
          self.$Modal.error({
            title: '温馨提示',
            content: data.message,
            onOk: () => {
            }
          })
        }
      },
      // 进行结算(直送)
      async toSupplierSettlement(type) {
        let self = this
        let params = {
          provOrderNo: '',
          description: self.accountInfo.description,
          payPassword: self.accountInfo.payPassword,
          receiveAddressId: self.accountInfo.receiveAddressId || ''
        }
        console.log(self.accountInfo)
        if (type == 2) { params = Object.assign({}, params, {ids: self.accountInfo.supplierCartId}) }
        if (type == 4) { params = Object.assign({}, params, {orderId: self.accountInfo.orderId}) }
        console.log(params)
        let {data} = await api.getSupplierOrderSend(params)
        if (data.status == 0) {
          self.$Notice.success({
            desc: data.message
          })
          self.saveOrderStatus({type: 'supplierOrder', status: '3', name: '1'})
          self.handleOrderStatus(new Date().getTime())
          self.handleBaseDialog({visible: false, type: 'supplierSettlementDialogVisible'})
          self.handleBaseDialog({visible: false, type: 'cartDialogVisible'})
          self.handleBaseDialog({visible: false, type: 'payMethodDialogVisible', orderType: 2})
          self.handleBaseDialog({visible: false, type: 'supplierOrderDialogVisible'})
          self.handleBaseDialog({visible: false, type: 'orderDialogVisible'})
          self.$router.push({name: 'paysuccess', query: {amount: data.data.payAmount, orderId: data.data.orderId, type: 'supplierOrder'}})
        } else {
          self.$Modal.error({
            title: '温馨提示',
            content: data.message,
            onOk: () => {
            }
          })
        }
        console.log(data)
      },
      // 支付宝微信支付,可能存在金额超过单次充值额度
      async handlePay(payType) {
        let self = this
        // self.imgLoading = true
        let params = {
          payType: payType,
          transferAmount: this.totalPayAmount
        }
        let {data} = await api.getOnlineRecharge(params)
        console.log(data)
        if (data.status == 0) {
          self.wxModal = true
          self.payInfo = data.data
          // self.imgLoading = false
          this.checkPayStatus()
        } else {
          self.$Modal.confirm({
            title: '温馨提示',
            content: data.message,
            onOk: () => {
            }
          })
        }
      },
      // 检查支付状态  设置最长 5分钟 内支付完
      checkPayStatus() {
        let self = this
        let longTime = 5 * 60 * 1000
        this.timer = setInterval(() => {
          longTime -= 3000
          console.log(longTime)
          if (longTime < 0) {
            clearInterval(self.timer)
          } else {
            self.checkStatus()
          }
        }, 3000)
      },
      async checkStatus() {
        let self = this
        let params = {
          paymentId: self.payInfo.paymentId
        }
        let {data} = await api.getPayStatus(params)
        if (data.status == 0) {
          if (data.data.payStatus == 3) {
            console.log('充值成功')
            self.successModal = true
            self.wxModal = false
            self.payResult = data.data
            clearInterval(self.timer)
            if (self.orderType == 1) { self.toSettlement(1) }
            if (self.orderType == 2) { self.toSupplierSettlement(2) }
            if (self.orderType == 3) { self.toSettlement(3) }
            if (self.orderType == 4) { self.toSupplierSettlement(4) }
          }
        }
      },
      // 微信、支付宝 支付弹窗关闭时候
      wxModalClose() {
        clearInterval(this.timer)
      },
      // 关闭弹窗
      closeDialog() {
        // this.handleBaseDialog({visible: false, type: 'commonSettlementDialogVisible'})
        // this.handleBaseDialog({visible: false, type: 'supplierSettlementDialogVisible'})
      }
    }
  }
</script>

<style lang="less">
.wx-modal-1{
  text-align: center;
}
.wx-modal-content-1{
  padding:10px 0;
}
.pay-method-warp{
  font-size: 14px;
  padding:0 40px;
  &-top{
    border-bottom: 1px solid #dddddd;
    padding: 5px 0 10px;
    p{
      margin: 8px 0;
      &:first-child{
        color: #333;
        span{
          color: #E61E10;
        }
      }
      &:nth-child(2){
        font-size: 15px;
        color: #5584FF;
        cursor: pointer;
      }
    }
  }
  &-method{
    display: flex;
    align-items: center;
    margin: 30px 0;
    p{
      margin-right: 10px;
    }
    ul{
      display: flex;
      li{
        position: relative;
        margin-right: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        span{
          margin-left: 15px;
          color: #666666;
        }
        em{
          position: absolute;
          display: block;
          width:30px;
          height: 20px;
          background: #E61E10;
          top:0;
          left:0;
        }
        &:nth-child(1){
          width: 300px;
          height: 50px;
        }
        &:nth-child(2){
          width: 180px;
          height: 50px;
        }
        &:nth-child(3){
          width: 180px;
          height: 50px;
        }
        &.disabled{
          cursor: no-drop;
          -webkit-filter: grayscale(1);/* Webkit */
          filter:gray;/* IE6-9 */
          filter: grayscale(1);/* W3C */
          opacity: 0.7;
        }
        &.default{
          border: 1px solid #dddddd;
        }
        &.selected1{
          background: url('../assets/images/pay/pay_type_1_bg.png') no-repeat;
          background-size: 100% 100%;
        }
        &.selected2{
          background: url('../assets/images/pay/pay_type_2_bg.png') no-repeat;
          background-size: 100% 100%;
        }
      }
    }
  }
  &-bottom{
    div{
     margin-bottom: 30px;
      span{
        color:#E61E10;
      }
    }
    .btn{
      margin-bottom: 100px;
      width: 210px;
    }
  }
}
.tip-info{
  margin: 30px auto 70px;
  p{
    text-align: center;
  }
  .totalpay-price{
     font-size: 22px;
     color: #E61E10;
     font-weight: bold;
  }
  .tatalpay-text{
     color: #333;
     font-size: 14px;
     margin: 10px 0;
  }
  .total-text{
     font-size: 14px;
     color: #333;
  }
  .available-text{
     font-size: 14px;
     color: #333;
  }
  .des{
     font-size: 14px;
     color: #333;
     width: 500px;
     margin: 30px auto;
  }
  .pay-btn{
     width: 200px;
     margin: 0 auto;
     .btn{
       width: 100%;
     }
  }
}
</style>
