<template>
  <div id="app">
    <router-view v-if="isRouterAlive"/>
  </div>
</template>
<script>

  export default {
    name: 'Index',
    provide() {
      return {
        reload: this.reload
      }
    },
    components: {},
    data: () => ({
      isRouterAlive: true
    }),
    created() {
      this.$Modal.remove()
      this.$Notice.config({
        top: 80,
        duration: 2
      })
    },
    methods: {
      reload() {
        this.isRouterAlive = false
        this.$nextTick(function () {
          this.isRouterAlive = true
        })
      }
    }
  }
</script>
<style lang="less">
  #app {
    height: 100%;
    overflow: auto;
    min-width: 1230px;

    .m-wrap {
      width: 1200px;
      margin: 0 auto;
      min-width: 1000px;
      position: relative;
    }

    .p-wrap-badge {
      color: #E61E10 !important;
      background: #fff0f0;
      border: 1px solid #E61E10 !important;
      z-index: 9;
    }

    .ivu-input-number-handler-wrap {
      display: none;
    }

    .ivu-btn:focus {
      box-shadow: none;
      -webkit-box-shadow: none;
    }

    .ivu-table-overflowX {
      overflow-x: hidden;
    }

    /*.ivu-menu-light.ivu-menu-horizontal .ivu-menu-item-active, .ivu-menu-light.ivu-menu-horizontal .ivu-menu-submenu-active, .ivu-menu-light.ivu-menu-horizontal .ivu-menu-item:hover, .ivu-menu-light.ivu-menu-horizontal .ivu-menu-submenu:hover:hover {*/
    /*border-bottom: none;*/
    /*}*/

    .ivu-menu-item-active {
      font-weight: 600;
    }

    .ivu-tabs.ivu-tabs-card > .ivu-tabs-bar .ivu-tabs-tab-active {
      background-color: #E61E10;
      color: #ffffff;
    }

    .order-btn {
      text-align: center;
      padding: 0;
      height: 31px;
      width: 90px;
    }

    .spacer {
      -webkit-box-flex: 1 !important;
      -ms-flex-positive: 1 !important;
      flex-grow: 1 !important;
    }

    .material-wrap {
      display: flex;
      justify-content: center;
    }

    .material-img {
      height: auto;
      width: 1920px;
      cursor: pointer;
    }

    .red--text {
      color: #E61E10;
    }

    .white--text {
      color: #ffffff;
    }

    .green--text {
      color: #E61E10;
    }

    .grey--text {
      color: #999999;
    }

    .warn--text {
      color: #e69c2e;
    }

    .m-header {
      display: flex;
      height: 35px;
      line-height: 35px;
      flex-wrap: nowrap;

      .item {
        display: flex;
        padding-right: 20px;

        span {
          margin: 0 5px;
          display: inline-block;
          white-space: nowrap;
        }

        .header-ipt {
          width: 150px;
        }
      }
    }

    .grid-wrap {
      width: 235px;
      height: 100%;
      padding: 10px;

      .p-wrap-unstore {
        display: none;
      }

      .grid-wrap-fw:hover {
        .p-wrap-unstore {
          display: block;
          position: absolute;
          left: 0;
          top: 0;
          width: 100%;
          cursor: pointer;
          text-align: center;
          background-color: #cccccc;

          span {
            height: 28px;
            line-height: 28px;
            color: #ffffff;
          }
        }
      }

      .grid-wrap-h {
        height: 340px;
      }

      .grid-wrap-promotion {
        height: 342px;
      }

      .grid-wrap-today:hover {
        border: none;
      }

      .grid-wrap-recent {
        height: 334px;
      }

      .grid-wrap-h3 {
        height: 370px;
      }

      .grid-wrap-fw {
        height: 314px;
      }

      .grid-wrap-hot {
        height: 316px;
      }
      .grid-wrap-franchise {
        height: 312px;
      }
      .grid-wrap-brand {
        height: 286px;
      }
      .grid-wrap-brand2 {
        height: 324px;
      }
    }

    .list-wrap {
      width: 100%;
      height: 213px;
      margin-bottom: 15px;

      &-h {
        display: flex;
        flex-direction: row;
        width: 100%;
      }

      &-product {
        width: 100%;
        padding-right: 500px;
        margin-left: 10px;
      }
    }

    .p-wrap {
      position: relative;
      cursor: pointer;
      &-grid {
        text-align: center;
        width: 181px;
        height: 151px;
      }

      &-grid-img {
        width: 146px;
        height: 146px;
        cursor: pointer;
      }

      &-list-img {
        width: 180px;
        height: 180px;
        cursor: pointer;
      }

      &-name {
        cursor: pointer;
        height: 42px;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        line-clamp: 2;
        -webkit-box-orient: vertical;
      }

      &-name:hover {
        color: #E61E10;
      }

      &-badge {
        border: 1px solid #E61E10;
        color: #E61E10;
        background-color: #fff2fb !important;
      }
      &-from {
        display: flex;
        justify-content: flex-start;
        align-items: center;
        margin: 5px 0;
        img{
           width: 24px;
           height: 12px;
           margin: 0 5px 0 0;
        }
        span{
           color: #999999;
           font-size: 12px;
        }
      }
      &-from-servies {
        display: flex;
        justify-content: flex-start;
        align-items: center;
        margin: 5px 0;
        img{
           width: 45px;
          //  height: 14px;
           margin: 0 5px 0 0;
        }
        span{
           color: #999999;
           font-size: 12px;
           cursor: pointer;
          //  text-decoration: underline;
           &:hover{
             text-decoration: underline;
           }
        }
      }

      &-line {
        display: flex;
        justify-content: space-between;
        padding: 3px 0;
      }

      &-brand {
        height: 30px;
        line-height: 30px;
      }

      &-star {
        margin-top: -3px;
        cursor: pointer;
      }

      &-time {
        padding-top: 5px;
        font-size: 12px;
        overflow: hidden;
        white-space: nowrap;
      }

      &-price {
        color: #E61E10;
        line-height: 35px;
        font-size: 18px;
        font-weight: 500;
      }

      &-old-price {
        margin-left: 10px;
        text-decoration: line-through
      }
    }

    .search-result {
      width: 100%;
      display: flex;
      justify-content: center;
      flex-direction: column;
      align-items: center;

      .search-img {
        width: 280px;
        height: 280px;
      }

      .search-info {
        font-size: 16px;
        height: 30px;
        line-height: 30px;
      }
    }

    .el-checkbox__input.is-checked .el-checkbox__inner, .el-checkbox__input.is-indeterminate .el-checkbox__inner {
      background-color: #E61E10;
      border-color: #E61E10;
    }

    .item-copy {
      cursor: pointer;
      height: 20px;
      line-height: 20px;
      width: 40px;
      margin-left: 10px;
      border-radius: 10px;
      background-color: #ffffff;
      border: 1px solid #E61E10;
      font-size: 12px;
      color: #E61E10;
    }
  }
  .p-wrap-areaProduct-flag{
    color:#F39800;
    background: #FFF3DF;
    font-size: 10px;
    border-radius: 5px;
    width: 60px;
    text-align: center;
    margin: 5px 0;
  }
  .p-wrap-areaProduct-left{
    display: flex;
    justify-content: flex-start;
    margin-top: 45px;
    .disable-btn{
      display: block;
      border:0;
      width: 90px;
      color: #ffffff;
      &:hover{
        color: #ffffff;
        background: #BBBBBB;
      }
      background: #BBBBBB;
    }
  }
  .p-wrap-areaProduct{
    display: flex;
    justify-content: flex-end;
    // margin-top: 25px;
    .button-primary{
      width: 100%!important;
      // margin-top: 10px;
    }
    .second-primary{
      width: 140px;
      height: 40px;
      line-height: 40px;
      font-size: 20px;
      border-radius: 20px;
    }
    .second-disable-btn{
      display: block;
      border:0;
      width: 140px;
      color: #ffffff;
      height: 40px;
      line-height: 40px;
      font-size: 20px;
      border-radius: 20px;
      &:hover{
        color: #ffffff;
        background: #BBBBBB;
      }
      background: #BBBBBB;
    }
    .disable-btn{
      display: block;
      border:0;
      width: 90px;
      color: #ffffff;
      &:hover{
        color: #ffffff;
        background: #BBBBBB;
      }
      background: #BBBBBB;
    }
  }
  .p-wrap-name{
    span{
    }
    img{
      width: 30px;
    }
  }
  /*modal 设置确定为左，取消为右*/
  .ivu-modal-confirm-footer {
    .ivu-btn-text {
      float: right;
      margin-left: 10px;
    }
  }

  .ivu-btn-error {
    background-color: #E61E10 !important;
    color: #ffffff;
  }
  .easemobim-chat-panel{
    z-index: 100000;
  }
</style>
