import Vue from 'vue'
import Router from 'vue-router'

import NotFoundComponent from '../components/NotFoundComponent'

const Index = () => import(/* webpackChunkName: 'base' */ '../views/admin/Index')
const Mine = () => import(/* webpackChunkName: 'base' */ '../views/admin/Mine')
const Login = () => import(/* webpackChunkName: 'base' */ '../views/Login')
const Register = () => import(/* webpackChunkName: 'base' */ '../views/Register')
const Home = () => import(/* webpackChunkName: 'base' */ '../views/index/Home')
// 服务商商品
const FwProduct = () => import(/* webpackChunkName: 'base' */ '../views/index/FwProduct')
// 爆品促销
const PromotionProduct = () => import(/* webpackChunkName: 'base' */ '../views/index/PromotionProduct')
const BrandPromotionProduct = () => import(/* webpackChunkName: 'base' */ '../views/index/BrandPromotionProduct')
// 新品查询
const RecentProduct = () => import(/* webpackChunkName: 'base' */ '../views/index/RecentProduct')
// 热卖推荐
const HotProduct = () => import(/* webpackChunkName: 'base' */ '../views/index/HotProduct')
// 控区控价
const ControlProduct = () => import(/* webpackChunkName: 'base' */ '../views/index/ControlProduct')
const ControlAreaProduct = () => import(/* webpackChunkName: 'base' */ '../views/index/ControlAreaProduct')
const SupplierBrandDetail = () => import(/* webpackChunkName: 'base' */ '../views/index/components/SupplierBrandDetail')
// 地配商品
const SupplierProduct = () => import(/* webpackChunkName: 'base' */ '../views/index/SupplierProduct')
// 今日促销
const TodayPromotionProduct = () => import(/* webpackChunkName: 'base' */ '../views/index/TodayPromotionProduct')
// 收藏商品
const StoreProduct = () => import(/* webpackChunkName: 'base' */ '../views/index/StoreProduct')
const ResultProduct = () => import(/* webpackChunkName: 'base' */ '../views/index/ResultProduct')

const SearchCommonProduct = () => import(/* webpackChunkName: 'base' */ '../views/index/SearchCommonProduct')
const SearchSupplierProduct = () => import(/* webpackChunkName: 'base' */ '../views/index/SearchSupplierProduct')
const SearchUnifiedProduct = () => import(/* webpackChunkName: 'base' */ '../views/index/SearchUnifiedProduct')
const CouponProduct = () => import(/* webpackChunkName: 'base' */ '../views/index/CouponProduct')
const PaySuccess = () => import(/* webpackChunkName: 'mine' */ '../views/index/PaySuccess')
// 快讯列表页面
const News = () => import(/* webpackChunkName: 'base' */ '../views/index/News')
const NewsDetail = () => import(/* webpackChunkName: 'base' */ '../views/index/NewsDetail')
// 门店商品
const FranchiseStoreProduct = () => import(/* webpackChunkName: 'base' */ '../views/index/FranchiseStoreProduct')
// const ProductDetail = () => import(/* webpackChunkName: 'base' */ '../views/index/ProductDetail')
// 个人中心
const Recharge = () => import(/* webpackChunkName: 'mine' */ '../views/mine/Recharge')
const RechargeList = () => import(/* webpackChunkName: 'mine' */ '../views/mine/RechargeList')
const Account = () => import(/* webpackChunkName: 'mine' */ '../views/mine/Account')
const Coupon = () => import(/* webpackChunkName: 'mine' */ '../views/mine/Coupon')
const OrderUnit = () => import(/* webpackChunkName: 'mine' */ '../views/mine/OrderUnit')
const ReceiveAddress = () => import(/* webpackChunkName: 'mine' */ '../views/mine/ReceiveAddress')
const SubCustomerInfo = () => import(/* webpackChunkName: 'mine' */ '../views/mine/SubCustomerInfo')
const UnitManage = () => import(/* webpackChunkName: 'mine' */ '../views/mine/UnitManage')
const EditLoginPwd = () => import(/* webpackChunkName: 'mine' */ '../views/mine/EditLoginPwd')
const EditPayPwd = () => import(/* webpackChunkName: 'mine' */ '../views/mine/EditPayPwd')
const ContactService = () => import(/* webpackChunkName: 'mine' */ '../views/mine/ContactService')
const PersonalCenter = () => import(/* webpackChunkName: 'mine' */ '../views/mine/PersonalCenter')
const DeliveryAddress = () => import(/* webpackChunkName: 'mine' */ '../views/mine/DeliveryAddress')
const CommonProblem = () => import(/* webpackChunkName: 'mine' */ '../views/mine/CommonProblem')
Vue.use(Router)

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {path: '/', redirect: '/index/home'},
    {
      path: '/index',
      name: 'index',
      component: Index,
      children: [
        {
          path: 'home',
          name: 'home',
          component: Home
        },
        {
          path: 'couponproduct',
          name: 'couponproduct',
          component: CouponProduct
        },
        {
          path: 'recentproduct',
          name: 'recentproduct',
          component: RecentProduct
        },
        {
          path: 'promotionproduct',
          name: 'promotionproduct',
          component: PromotionProduct
        },
        {
          path: 'brandpromotionproduct',
          name: 'brandpromotionproduct',
          component: BrandPromotionProduct
        },
        {
          path: 'hotproduct',
          name: 'hotproduct',
          component: HotProduct
        },
        {
          path: 'supplierproduct',
          name: 'supplierproduct',
          component: SupplierProduct
        },
        {
          path: 'fwproduct',
          name: 'fwproduct',
          component: FwProduct
        },
        {
          path: 'controlproduct',
          name: 'controlproduct',
          component: ControlProduct
        },
        {
          path: 'controlareaproduct',
          name: 'controlareaproduct',
          component: ControlAreaProduct
        },
        {
          path: 'storeproduct',
          name: 'storeproduct',
          component: StoreProduct
        },
        {
          path: 'todaypromotionproduct',
          name: 'todaypromotionproduct',
          component: TodayPromotionProduct
        },
        {
          path: 'resultproduct',
          name: 'resultproduct',
          component: ResultProduct
        },
        {
          path: 'searchcommonproduct',
          name: 'searchcommonproduct',
          component: SearchCommonProduct
        },
        {
          path: 'searchsupplierproduct',
          name: 'searchsupplierproduct',
          component: SearchSupplierProduct
        },
        {
          path: 'searchunifiedproduct',
          name: 'searchunifiedproduct',
          component: SearchUnifiedProduct
        },
        {
          path: 'franchisestoreproduct',
          name: 'franchisestoreproduct',
          component: FranchiseStoreProduct
        },
        {
          path: 'supplierbranddetail',
          name: 'supplierbranddetail',
          component: SupplierBrandDetail
        },
        {
          path: 'news',
          name: 'news',
          component: News
        },
        {
          path: 'newsdetail/:id',
          name: 'newsdetail',
          component: NewsDetail
        },
        {
          path: 'paysuccess',
          name: 'paysuccess',
          component: PaySuccess
        }
        // {
        //   path: 'productdetail/:id',
        //   name: 'productdetail',
        //   component: ProductDetail
        // }
      ]
    },
    {
      path: '/mine',
      name: 'mine',
      component: Mine,
      children: [
        {
          path: 'personalcenter',
          name: 'personalcenter',
          component: PersonalCenter
        },
        {
          path: 'recharge',
          name: 'recharge',
          component: Recharge
        }, {
          path: 'rechargelist',
          name: 'rechargelist',
          component: RechargeList
        },
        {
          path: 'account',
          name: 'account',
          component: Account
        },
        {
          path: 'coupon',
          name: 'coupon',
          component: Coupon
        },
        {
          path: 'orderunit',
          name: 'orderunit',
          component: OrderUnit
        },
        {
          path: 'receiveaddress',
          name: 'receiveaddress',
          component: ReceiveAddress
        },
        {
          path: 'subcustomerinfo',
          name: 'subcustomerinfo',
          component: SubCustomerInfo
        },
        {
          path: 'unitmanage',
          name: 'unitmanage',
          component: UnitManage
        },
        {
          path: 'editloginpwd',
          name: 'editloginpwd',
          component: EditLoginPwd
        },
        {
          path: 'editpaypwd',
          name: 'editpaypwd',
          component: EditPayPwd
        },
        {
          path: 'contactservice',
          name: 'contactservice',
          component: ContactService
        },
        {
          path: 'deliveryaddress',
          name: 'deliveryaddress',
          component: DeliveryAddress
        },
        {
          path: 'commonproblem',
          name: 'commonproblem',
          component: CommonProblem
        }
      ]
    },
    {
      path: '/login',
      name: 'login',
      component: Login
    },
    {
      path: '/register',
      name: 'register',
      component: Register
    },

    {path: '*', component: NotFoundComponent}
  ],
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    } else {
      return {x: 0, y: 0}
    }
  }
})
