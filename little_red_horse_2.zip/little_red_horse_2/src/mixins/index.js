// mixins
import {mapState, mapGetters, mapActions} from 'vuex'

export default {
  computed: {
    ...mapState([
      'addSuccess',
      'loading'
    ]),
    ...mapGetters([
    ])
  },
  methods: {
    ...mapActions([
      'saveProductInfo',
      'saveProductSeriesInfo',
      'saveProductDateInfo',
      'saveSupplierProductSeriesInfo',
      'saveSupplierProductInfo',
      'handleBaseDialog'
    ]),
    // 商品 404 图
    defaultPimg() {
      return 'this.src="' + require('../assets/images/default.png') + '"'
    },
    // 品牌 404 图
    defaultBimg() {
      return 'this.src="' + require('../assets/images/defaultB.png') + '"'
    },
    // 控区控价 404 图
    defaultCimg() {
      return 'this.src="' + require('../assets/images/default.png') + '"'
    },
    handleADJump(item) {
      console.log(item)
      if (item.eventType == 1) {
        this.$router.push({
          path: '/index/brandpromotionproduct',
          query: {id: item.id}
        })
      }
    },
    formatAmount (formatV, len = 0) {
      //  处理undefined数据, 判断是不是数字
      let reg = /^-?[0-9]+(.[0-9]*)?$/g
      if (formatV === undefined || formatV === null || !reg.test(formatV)) {
        let r = '-.'
        for (let i = 0; i < len; i++) {
          r += '-'
        }
        return r
      }
      var array = []
      // 参数为字符串，直接转数字
      if (typeof formatV === 'string') {
        formatV = Number(formatV)
      }
      // 四舍五入保留小数位
      formatV = parseInt(formatV * Math.pow(10, len) + 0.5) / Math.pow(10, len)
      array = formatV.toFixed(len).split('.')
      // 处理整数，插入千位符
      var re = /(-?\d+)(\d{3})/
      while (re.test(array[0])) {
        array[0] = array[0].replace(re, '$1,$2')
      }
      if (len > 0) {
        return `${array[0]}.${array[1]}`
      } else {
        return array[0]
      }
    },
    feeReduceRateTip() {
      this.$Modal.confirm({
        title: '温馨提示',
          content: '物流减免费用=进价×物流减免比例。  例如，进价200元，物流费减免比例2%，则该商品可扣减200×2%=4元物流费。',
          onOk: () => {
          }
      })
    },
    toProductDetail(row) {
      console.log(row)
      if (row.serviceType == '2') {
        this.saveProductInfo(row.productId)
        this.saveProductSeriesInfo(row.productSetId)
        this.saveProductDateInfo('null')
        if (row.productType == '0' && row.areaProduct == '0') {
          this.handleBaseDialog({visible: true, type: 'productDetailVisible'})
        }
        if (row.productType == '0' && row.areaProduct == '1') {
          this.handleBaseDialog({visible: true, type: 'commonBrandDetailVisible'})
        }
        if (row.productType == '1' && row.areaProduct == '0') {
          this.handleBaseDialog({visible: true, type: 'productSeriesDetailVisible'})
        }
        if (row.productType == '1' && row.areaProduct == '1') {
          this.handleBaseDialog({visible: true, type: 'commonBrandSeriesDetailVisible'})
        }
        if (row.productType == '2' && row.areaProduct == '0') {
          this.handleBaseDialog({visible: true, type: 'productDateDetailVisible'})
        }
        if (row.productType == '2' && row.areaProduct == '1') {
          this.handleBaseDialog({visible: true, type: 'productBrandDateDetailVisible'})
        }
      } else {
        if (row.serviceType == '1') {
          row.service = '服务商'
        }
        this.saveSupplierProductInfo(row)
        this.saveSupplierProductSeriesInfo(row.productSetId)
        if (row.productType == '0' && row.areaProduct == '0') {
          this.handleBaseDialog({visible: true, type: 'supplierDetailVisible'})
        }
        if (row.productType == '0' && row.areaProduct == '1') {
          this.handleBaseDialog({visible: true, type: 'supplierBrandDetailVisible'})
        }
        if (row.productType == '1' && row.areaProduct == '0') {
          this.handleBaseDialog({visible: true, type: 'supplierSeriesDetailVisible'})
        }
        if (row.productType == '1' && row.areaProduct == '1') {
          this.handleBaseDialog({visible: true, type: 'supplierBrandSeriesDetailVisible'})
        }
      }
    }
  }
}
