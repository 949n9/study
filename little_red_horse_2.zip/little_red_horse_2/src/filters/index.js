// 自定义过滤器
export function cutTime(msg) {
  msg = msg + ''
  return msg.substring(0, 11)
}

export function cutAddress(msg) {
  msg = msg + ''
  return msg.length > 30 ? msg.substring(0, 30) + '...' : msg
}

export function filterPrice(v) {
  v = v * 1
  return v.toFixed(2)
}

export function cut4(msg) {
  if (msg) {
    msg = msg.replace(/[\s]/g, '').replace(/(\d{4})(?=\d)/g, '$1 ')
    return msg
  }
}
