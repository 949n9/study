export const commonHeader = [
  {
    type: 'selection',
    width: 50,
    align: 'center'
  },
  {
    title: '商品',
    slot: 'name',
    width: 400,
    align: 'left'
  },
  {
    title: '单价',
    key: 'orderPrice',
    align: 'center'
  },
  {
    title: '数量',
    slot: 'num',
    align: 'center'
  },
  {
    title: '小计',
    slot: 'sum',
    align: 'center'
  },
  {
    title: '操作',
    slot: 'action',
    align: 'center'
  }
]
export const commonHeader2 = [
  {prop: 'saleQty', label: '商品', align: 'right', width: '90'},
  {prop: 'saleTaxAmount', label: '单价', align: 'right', width: '105'},
  {prop: 'saleRatio', label: '数量', align: 'right', width: '100'},
  {prop: 'costTaxAmount', label: '小计', align: 'right', width: '105'}
]
export const commonSettlementHeader = [
  {
    title: '商品',
    slot: 'name',
    width: 600,
    align: 'left'
  },
  {
    title: '单价',
    align: 'center',
    slot: 'price'
  },
  {
    title: '数量',
    slot: 'num',
    align: 'center'
  }
]
