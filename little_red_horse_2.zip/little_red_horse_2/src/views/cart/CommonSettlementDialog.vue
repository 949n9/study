<template>
  <Modal
    :value="commonSettlementDialogVisible"
    title="订单详情"
    :mask-closable="false"
    footer-hide
    width="1300"
    :styles="{top: '10px'}"
    @on-visible-change="dialogChange"
    @on-cancel="closeDialog"
  >
    <!-- 用于调试 -->
    <!-- <template>
         <i-form :model="settlementInfo" label-position="left" :label-width="100">
            <Form-item label="账户可用余额">
                <i-input v-model="settlementInfo.availableBalance"></i-input>
            </Form-item>
            <Form-item label="订单总金额">
                <i-input v-model="settlementInfo.totalAmount"></i-input>
            </Form-item>
            <Form-item label="实际支付金额">
                <i-input v-model="settlementInfo.taotalPayAmount"></i-input>
            </Form-item>
            <Form-item label="限制金额">
                <i-input v-model="settlementInfo.maxRechargeAmount"></i-input>
            </Form-item>
            <Form-item>
                <i-button type="primary" @click="handleSubmit('formValidate')">提交</i-button>
            </Form-item>
         </i-form>
    </template> -->
    <div class="common-settlement" ref="commonDialog" :style="{height:tabHeight+'px'}">
      <div class="mine-header">
        <Breadcrumb>
          <BreadcrumbItem>购物车</BreadcrumbItem>
          <BreadcrumbItem>小红马商城商品</BreadcrumbItem>
          <BreadcrumbItem>订单详情</BreadcrumbItem>
        </Breadcrumb>
      </div>

      <div class="address-header">
        <h3 class="settle-header">确认收货地址</h3>
        <p class="address-add red--text" @click="addAddress(settlementInfo.subCustomerId)">新增收货地址</p>
      </div>

      <div class="common-wrap">
        <div v-if="!showMoreAddress">
          <Radio class="address-item address-text" :value="true">
            <span :title="settlementInfo.address">{{settlementInfo.address | cutAddress}} </span>
            <span style="margin-left: 10px">{{settlementInfo.contactor}}</span>
            <span style="margin-left: 10px">{{settlementInfo.mobilePhone}}</span>
            <Badge style="margin-left: 15px" v-if="settlementInfo.isDefaultReceiveAddress==1"
                   text="默认地址" type="warning"></Badge>
            <Button type="text" @click="editAddress(settlementInfo.receiveAddressId)" class="address-item-edit">修改本地址
            </Button>
          </Radio>
        </div>
        <div v-else-if="showMoreAddress && getAddressList.length">
          <RadioGroup v-model="receiveAddressId" vertical class="address-group" @on-change="handleRadioChange">
            <Radio class="address-item" v-for="(item,index) in getAddressList" :key="index" :label="item.id"
                   :class="{'address-text':receiveAddressId==item.id}">
              <span :title="item.fullAddress">{{item.fullAddress | cutAddress}}</span>
              <span style="margin-left: 10px">{{item.receiver}}</span>
              <span style="margin-left: 10px">{{item.receiveMobilePhone}}</span>
              <Badge v-show="item.isDefault==1" style="margin-left: 15px" text="默认地址" type="warning"></Badge>
              <Button type="text" @click="editAddress(item.id)" class="address-item-edit">修改本地址</Button>
            </Radio>
          </RadioGroup>
        </div>

        <div class="address-more" v-show="getAddressList.length>1">
          <div @click="changeAddress" class="address-more-btn">
            {{showMoreAddress?'收起地址':'查看更多'}}
            <Icon v-if="!showMoreAddress" type="ios-arrow-down"/>
            <Icon v-else type="ios-arrow-up"/>
          </div>
        </div>
      </div>

      <div class="address-header">
        <h3 class="settle-header">确认订单信息</h3>
      </div>

      <div class="common-wrap">
        <Table border v-if="productsList.length" size="small" :columns="columns"
               ref="table"
               :data="productsList">
          <template slot-scope="{ row }" slot="name">
            <div class="cart-name">
              <img :src="row.imgUrl" alt="" :onerror="defaultPimg()" class="p-img">
              <div class="p-name-wrap">
                <p class="p-name">{{row.productName}}</p>
                <p style="margin:5px 0;color:#E61E10;" v-if="row.periodKey&&row.periodKey!=='null'">{{row.periodKey}}</p>
                <Badge :text="'物流费减免：'+row.deliveryFeeReduceRate+'%'" class-name="p-wrap-badge">
                </Badge>
              </div>
            </div>
          </template>
          <template slot-scope="{ row }" slot="num">
            <div class="cart-num">
              <!--<InputNumber :min="1" v-model="row.orderQty"></InputNumber>-->
              <p>{{row.orderQty}}</p>
              <!--<p class="p-store">库存：{{row.distQty}}</p>-->
            </div>
          </template>
          <template slot-scope="{ row }" slot="price">
            <p>¥{{row.orderPrice }}</p>
          </template>
        </Table>
        <div class="coupon-wrap" v-if="couponList.length">
           <div class="coupon-header"><span>优惠券</span>本订单可使用以下优惠券</div>
           <div class="coupon-list">
              <!-- <section class="coupon-type-list" v-for="e in couponList" :key="e.categoryId"> -->
                <!-- <div class="coupon-list-header">{{e.categoryName}}</div> -->
                <div class="coupon-list-item" :class="selectedStatus(item)" v-for="(item, index) in couponList" :key="index" @click="selectCoupon(item)">
                    <div class="item-top">
                      <p><em>￥</em><span class="price">{{item.value}}</span><span class="type">{{item.categoryName}}</span></p>
                    </div>
                    <div class="item-bottom">
                      <p class="date">{{item.begDate}}至{{item.endDate}}</p>
                      <p class="des">
                          <Tooltip theme="light" placement="bottom" max-width="200">
                            <p class="des" @click.stop="openCouponDetail(item)">[使用说明]</p>
                            <div slot="content">
                              <p>{{item.description}}</p>
                            </div>
                          </Tooltip>
                      </p>
                    </div>
                </div>
              <!-- </section> -->
           </div>
        </div>
        <Row class="common-footer">
          <Col span="18">
            <div class="item">
              <div>配送方式：由小红马优选物流送货
                <Tooltip theme="light" placement="right-start">
                  <Icon size="20" type="ios-help-circle-outline" class="warn--text"/>
                  <div slot="content">
                    <p>物流费为小红马合作快递或物流公司</p>
                    <p>送货到店的费用，极少数偏远地区需</p>
                    <p>到附近的快递、物流站点自提或与站</p>
                    <p>点协商送货费用。</p>
                  </div>
                </Tooltip>
              </div>
            </div>
            <div class="item">
              <p>备注信息：</p>
              <form action="javascript:void(0)">
                <Input class="ipt" type="textarea" :maxlength="200" v-model.trim="description"/>
              </form>
            </div>
          </Col>
          <Col span="6">
            <div>
              <p class="r-price"><span>商品总额：</span><span class="red--text">¥{{settlementInfo.totalAmount}}</span></p>
              <div class="r-item-other">
                <div class="r-item">
                  <span>物流费：</span>
                  <span>
                <Tooltip theme="light" placement="left-end">
                  <Icon size="20" type="ios-help-circle-outline" class="warn--text"/>
                  <div slot="content">
                    <p v-html="cost"></p>
                  </div>
                </Tooltip>
                  ¥{{settlementInfo.totalDeliveryFeeCalcAmount}}
                </span>

                </div>
                <p class="r-item"><span>物流减免：</span><span>-¥{{settlementInfo.totalDeliveryFeeReduceAmount}}</span></p>
                <p class="r-item"><span>物流费调整：</span><span>-¥0.00</span></p>
              </div>

              <p class="r-item"><span>实付物流费：</span><span class="red--text">¥{{settlementInfo.totalPayDeliveryFeeReduceAmount}}</span>
              </p>
              <p class="r-item"><span>优惠券：</span><span class="red--text">-¥{{settlementInfo.selectedCouponDiscountAmount}}</span></p>

            </div>
          </Col>
        </Row>
        <Row class="common-footer line">
          <Col span="18">
            &nbsp;
          </Col>
          <Col span="6">
            <div>
              <p class="r-price red--text"><span>订单总金额：</span><span>¥{{settlementInfo.taotalPayAmount}}</span></p>
              <p class="r-item"><span>账户可用金额：</span><span>¥{{settlementInfo.availableBalance}}</span></p>
              <Button type="error" :disabled="loading" class="btn" @click="handleSettlement">发送并结算</Button>
            </div>
          </Col>
        </Row>
        <Row>
          <Col>
            <div class="footer-address-result">
              <span>{{settlementInfo.address}} </span>
              <span style="margin-left: 10px">{{settlementInfo.contactor}}</span>
              <span style="margin-left: 10px">{{settlementInfo.mobilePhone}}</span>
            </div>
          </Col>
        </Row>
      </div>
    </div>
    <Modal
      v-model="couponDetailsVisible"
      title="优惠券详情"
      :mask-closable="false"
      :footer-hide="true"
      scrollable
      @on-visible-change="couponDetailChange">
      <ul class="coupon_wrap" v-if="couponDetail">
          <!-- <li class="coupon_wrap_item"><em>优惠劵编号：</em><span>{{couponDetail.id}}</span></li> -->
          <li class="coupon_wrap_item"><em>优惠券种类：</em><span>{{couponDetail.categoryName}}</span></li>
          <li class="coupon_wrap_item"><em>面值：</em><span>{{couponDetail.value}}</span></li>
          <li class="coupon_wrap_item"><em>有效期：</em><span>{{`${couponDetail.begDate} 到 ${couponDetail.endDate}`}}</span></li>
          <li class="coupon_wrap_item"><em>使用要求：</em><span>{{couponDetail.useNote}}</span></li>
          <!-- <li class="coupon_wrap_item"><em>使用状态：</em><span>{{couponDetail.statusText}}</span></li> -->
          <li class="coupon_wrap_item"><em>优惠券摘要：</em><span>{{couponDetail.description}}</span></li>
      </ul>
    </Modal>
  </Modal>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core'
  import * as opt from './options'

  export default {
    name: 'CommonCartSettlement',
    data() {
      return {
        commonDialog: null,
        tabHeight: '',
        columns: opt.commonSettlementHeader,
        settlementInfo: {},
        productsList: [],
        couponList: [],
        couponDetail: {},
        couponDetailsVisible: false,
        description: '',
        payPassword: '',
        cost: '',
        showMoreAddress: false,
        receiveAddressId: '',
        couponIds: ''
      }
    },
    computed: {
      ...mapState([
        'loading',
        'cartId',
        'commonSettlementDialogVisible',
        'commonSettlementInfo',
        'addressEdit'
      ]),
      ...mapGetters([
        'cartProductData',
        'getCommonCartNum',
        'getAddressList'
      ])
    },
    watch: {
      'addressEdit': 'handleAddress'
    },
    created() {
      this.initData()
    },
    mounted() {
      this.commonDialog = this.$refs.commonDialog
    },
    methods: {
      ...mapActions([
        'saveCommonCartNum',
        'deleteCartProduct',
        'handleBaseDialog',
        'saveOrderStatus',
        'addProductSuccess',
        'useCouponSuccess',
        'handleBasicInfo',
        'getReceiverAddress',
        'saveCommonSettlementInfo'
      ]),
      initData() {
        this.handleBaseDialog({visible: false, type: 'commonSettlementDialogVisible'})
      },
      couponDetailChange(e) {
      },
      openCouponDetail(item) {
        if (item.status == 0) item.statusText = '未使用'
        if (item.status == 1) item.statusText = '已使用'
        if (item.status == 2) item.statusText = '已过期'
        this.couponDetail = item
        this.couponDetailsVisible = true
      },
      selectedStatus(item) {
        if (item.selected == 1) return ''
        if (item.selected == 0) return 'coupon-list-item-selected'
        if (item.selected == 2) return 'coupon-list-item-disable'
      },
      dialogChange(v) {
        console.log(v)
        this.showMoreAddress = false
        if (v) {
          this.$nextTick(() => {
            this.commonDialog.scrollTop = 0
          })
          let h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
          this.tabHeight = h - 95
          this.getSettlement()
          this.getReceiverAddress(this.settlementInfo.subCustomerId)
          this.receiveAddressId = this.settlementInfo.receiveAddressId
        } else {
          this.handleBaseDialog({visible: false, type: 'commonSettlementDialogVisible'})
        }
      },
      // 获取结算详情
      getSettlement() {
        this.settlementInfo = this.commonSettlementInfo
        this.productsList = this.commonSettlementInfo.products
        this.couponList = this.commonSettlementInfo.couponList
        let temp = []
        this.couponList.forEach(e => {
          if (e.selected == 0) {
            temp.push(e)
          }
        })
        this.couponIds = temp.map(e => {
          return e.id
        }).join()
        let obj = this.settlementInfo.deliveryDcFeeCalcAmount
        let str = ''
        for (let key in obj) {
          console.log(key)
          console.log(obj[key])
          str += '<p>' + key + '：¥' + obj[key] + '元</p>'
        }
        this.cost = str
      },
      // 进行结算前先进性判断 余额是否够支付 该订单金额
      handleSettlement() {
        if (this.settlementInfo.isFirstOrder == '1') {
          this.$Modal.confirm({
            title: '温馨提示',
            content: this.settlementInfo.firstOrderAlert,
            cancelText: '返回修改地址',
            okText: '确定',
            onOk: () => {
              this.confirmSend()
            },
            onCancel: () => {
              this.backFix()
            }
          })
        } else {
          if (this.settlementInfo.taotalPayAmount == 0) {
            this.toSettlement()
          } else {
            let temp = {
              couponIds: this.couponIds,
              cartId: this.cartId,
              description: this.description,
              payPassword: this.payPassword
            }
            this.saveCommonSettlementInfo(Object.assign({}, this.commonSettlementInfo, temp))
            this.settlementInfo = this.commonSettlementInfo
            this.handleBaseDialog({visible: true, type: 'payMethodDialogVisible', orderType: 1})
          }
        }
        // if (this.settlementInfo.taotalPayAmount == 0) {
        //   this.toSettlement()
        // } else {
        //   let temp = {
        //     couponIds: this.couponIds,
        //     cartId: this.cartId,
        //     description: this.description,
        //     payPassword: this.payPassword
        //   }
        //   this.saveCommonSettlementInfo(Object.assign({}, this.commonSettlementInfo, temp))
        //   this.settlementInfo = this.commonSettlementInfo
        //   this.handleBaseDialog({visible: true, type: 'payMethodDialogVisible', orderType: 1})
        // }
        // if (this.settlementInfo.taotalPayAmount * 1 > 0 && parseFloat(this.settlementInfo.taotalPayAmount) > parseFloat(this.settlementInfo.availableBalance)) {
        //   let amount = parseFloat(this.settlementInfo.taotalPayAmount) - parseFloat(this.settlementInfo.availableBalance)
        //   amount = amount.toFixed(2)
        //   let message = `<p>您的资金账户可用余额不足，还需要充值 <span style="color:#E61E10">¥ ${amount}</span>，</p><p>去充值吧！</p>`
        //   this.$Modal.error({
        //     title: '温馨提示',
        //     content: message,
        //     width: 435,
        //     onOk: () => {
        //       this.handleBaseDialog({visible: false, type: 'commonSettlementDialogVisible'})
        //       this.handleBaseDialog({visible: false, type: 'cartDialogVisible'})
        //       this.$router.push({path: '/mine/recharge', query: {amount: amount}})
        //     }
        //   })
        // } else {
        //   this.toSettlement()
        // }
      },
      confirmSend() {
        console.log('确定')
        if (this.settlementInfo.taotalPayAmount == 0) {
          this.toSettlement()
        } else {
          let temp = {
            couponIds: this.couponIds,
            cartId: this.cartId,
            description: this.description,
            payPassword: this.payPassword
          }
          this.saveCommonSettlementInfo(Object.assign({}, this.commonSettlementInfo, temp))
          this.settlementInfo = this.commonSettlementInfo
          this.handleBaseDialog({visible: true, type: 'payMethodDialogVisible', orderType: 1})
        }
      },
      backFix() {
        console.log('取消，返回修改地址')
      },
      // 进行结算
      async toSettlement() {
        let self = this
        let params = {
          ids: self.cartId,
          distFeeReduceRatio: self.settlementInfo.distFeeReduceRatio,
          distFeeReduceRuleId: self.settlementInfo.distFeeReduceRuleId,
          description: self.description,
          payPassword: self.payPassword,
          receiveAddressId: self.receiveAddressId || '',
          couponIds: self.couponIds
        }
        let {data} = await api.getOrderSend(params)
        if (data.status == 0) {
          self.$Notice.success({
            desc: data.message
          })
          let num = self.getCommonCartNum - self.settlementInfo.totalQty
          self.saveCommonCartNum(num)
          // 通知 结算成功  更新 页面订货数量
          self.addProductSuccess(self.$route.path + '?' + new Date().getTime())
          // self.useCouponSuccess(true)
          self.saveOrderStatus({type: 'commonOrder', status: '1', name: '1'})
          self.handleBaseDialog({visible: false, type: 'commonSettlementDialogVisible'})
          self.handleBaseDialog({visible: false, type: 'cartDialogVisible'})
          self.$router.push({name: 'paysuccess', query: {amount: self.settlementInfo.taotalPayAmount}})
          // self.$Modal.success({
          //   title: '温馨提示',
          //   content: '<div margin:0 auto 30px;font-size: 18px!important;>订单发送成功！</div>' +
          //            '<p>下午16:00前发送的订单将于当天审核发出，请耐心等待。</p>' +
          //            '<p>为保障您的权益，请先验货，再签收！</p>',
          //   width: '450',
          //   onOk: () => {
          //     self.handleBaseDialog({visible: false, type: 'commonSettlementDialogVisible'})
          //     self.handleBaseDialog({visible: false, type: 'cartDialogVisible'})
          //     self.handleBaseDialog({visible: true, type: 'orderDialogVisible'})
          //   }
          // })
        } else {
          self.$Modal.error({
            title: '温馨提示',
            content: data.message,
            onOk: () => {
            }
          })
        }
        console.log(data)
      },
      // 选择优惠券(请求接口)
      async selectCouponItem() {
        let self = this
        let params = {
          ids: self.cartId,
          couponChooseType: 1,
          receiveAddressId: self.receiveAddressId || '',
          couponIds: self.couponIds
        }
        let {data} = await api.getCommonSettlement(params)
        if (data.status == 0) {
          this.settlementInfo = data.data
          this.couponList = data.data.couponList
          this.saveCommonSettlementInfo(Object.assign({}, this.commonSettlementInfo, data.data))
          console.log(this.commonSettlementInfo)
          this.settlementInfo = self.commonSettlementInfo
          this.getSettlement()
        } else {
          this.$Modal.error({
            title: '温馨提示',
            content: data.message,
            onOk: () => {
            }
          })
        }
      },
      // 关闭弹窗
      closeDialog() {
        this.handleBaseDialog({visible: false, type: 'commonSettlementDialogVisible'})
      },
      // 选择优惠券
      selectCoupon(item) {
        if (item.selected == 2) return null
        if (item.selected == 0) {
          item.selected = 1
        } else {
          item.selected = 0
        }
        let temp = []
        this.couponList.forEach(e => {
          if (e.selected == 0) {
            temp.push(item)
          }
        })
        this.couponIds = temp.map(e => {
          return e.id
        }).join()
        this.selectCouponItem()
      },
      // 是否展示更多地址数据  ================================================================
      changeAddress() {
        this.showMoreAddress = !this.showMoreAddress
      },
      // 切换地址 1.需要刷新订单信息（物流费）
      handleRadioChange(v) {
        console.log(v)
        this.showMoreAddress = false
        this.toCommonSettlement()
      },
      // 修改地址
      editAddress(id) {
        this.handleBasicInfo({id: id, from: 'commonSettlement'})
        this.handleBaseDialog({visible: true, type: 'addAddressVisible', title: '编辑'})
      },
      // 新增地址
      addAddress(id) {
        this.handleBasicInfo({subCustomerId: id, from: 'commonSettlement'})
        this.handleBaseDialog({visible: true, type: 'addAddressVisible', title: '新增'})
      },
      // 修改完成 1.需要刷新地址信息 2.刷新订单信息
      handleAddress(v) {
        let path = v.split('?')[0]
        if (path == 'commonSettlement') {
          this.toCommonSettlement()
          this.getReceiverAddress(this.settlementInfo.subCustomerId)
        }
      },
      // 修改地址后 更新订单信息
      async toCommonSettlement() {
        let self = this
        let params = {
          ids: self.cartId,
          receiveAddressId: self.receiveAddressId,
          couponIds: self.couponIds,
          couponChooseType: 1
        }
        let {data} = await api.getCommonSettlement(params)
        if (data.status == 1) {
          let msg = data.message.replace(/\n\n/g, '</p></br><p>')
          msg = '<div style="max-height: 500px;overflow: auto"><p>' + msg + '</p></div>'
          self.$Modal.error({
            title: '温馨提示',
            content: msg,
            width: 600,
            onOk: () => {
            }
          })
        } else {
          let result = data.data
          self.saveCommonSettlementInfo(Object.assign({}, this.commonSettlementInfo, result))
          console.log(this.commonSettlementInfo)
          self.settlementInfo = self.commonSettlementInfo
          self.getSettlement()
        }
      }
    }
  }
</script>

<style lang="less">
  @import "settlement";
</style>
