<template>
  <Modal
    :value="cartDialogVisible"
    title="购物车"
    :mask-closable="false"
    footer-hide
    width="1200"
    :styles="{top: '10px'}"
    @on-visible-change="dialogChange"
    @on-cancel="closeDialog"
  >
    <div class="cart-wrap" ref="dialog">
      <Tabs class="menu-wrap" v-model="tabName" @on-click='tabClick'>
        <TabPane name="commonCart" :label="'小红马商城商品（'+getCommonCartNum+'）'">
          <div class="common-cart" :style="{height:tabHeight+50+'px'}">
            <div class="common-cart-table" v-if="cartProductData.length">
              <div class="common-cart-table-header">
                <ul>
                   <li class="checkbox"><Checkbox v-model="allChecked"  @click.prevent.native="commonSelectAll"></Checkbox></li>
                   <li class="product">商品</li>
                   <li class="price">单价</li>
                   <li class="number">数量</li>
                   <li class="subtotal">小计</li>
                   <li class="option">操作</li>
                </ul>
              </div>
              <div class="common-cart-table-con">
                 <div class="common-cart-table-con-item" v-for="(item, index) in cartProductData" :key="index">
                    <ul class="common-cart-table-con-style1" v-if="!item.productList.length" :class="tableRowClassNameDe(item)">
                       <li class=""><Checkbox v-model="item.checked" :disabled="item.distQty<=0"></Checkbox></li>
                       <li class="">
                          <div class="cart-name">
                            <img :src="item.imgUrl" alt="" :onerror="defaultPimg()" class="p-img" @click="toCommonDetail(item)">
                            <div class="p-name-wrap">
                              <p class="p-name" @click="toCommonDetail(item)">{{item.productName}}</p>
                              <Badge :text="'物流费减免：'+item.deliveryFeeReduceRate+'%'" class-name="p-wrap-badge">
                              </Badge>
                              <p class="p-name-area" v-if="item.distDcDescription">{{item.distDcDescription}}</p>
                            </div>
                          </div>
                       </li>
                       <li class="">{{item.orderPrice}}</li>
                       <li class="">
                         <div class="cart-num">
                            <InputNumber
                              :min="item.minOrderQty*1"
                              :max="999999"
                              v-model="item.orderQty"
                              :precision="item.qtyDecimalPlace*1"
                              :ref="item.id" :active-change="false"
                              @on-focus="(a)=>commonQtyFocus(a,item.id)"
                              @on-change="(a)=>commonQtyChange(a,item,item.$index)"></InputNumber>
                            <p class="p-store" v-if="userData.showDistQty==='true'">库存：{{item.distQty}}</p>
                            <p class="p-store" v-else>
                              <span v-if="item.distQty*1>0 && item.distQty*1<item.warnDistQty*1" class="warn--text">库存紧张</span>
                              <span v-else-if="item.distQty*1<=0" class="red--text">暂时无货</span>
                              <span v-else class="defult--text">库存充足</span>
                            </p>
                          </div>
                       </li>
                       <li class="">￥{{item.orderQty*item.orderPrice|filterPrice}}</li>
                       <li class="">
                         <Button type="text" size="small" class="del-btn" @click.native="commonDeleteCart(item.id)">删除
                         </Button>
                       </li>
                    </ul>
                    <div class="common-cart-table-con-style2" v-else>
                       <p class="cart-des">
                           <Checkbox v-model="item.checked" @click.prevent.native="commonSelectItemAll(item)" :disabled="item.disabled">全选</Checkbox>
                           <em>{{item.setOrderPrompt}}</em>
                       </p>
                       <ul class="" v-for="(i, index) in item.productList" :key="index" :class="tableRowClassNameDe(i)" style="height:120px;">
                            <li class=""><Checkbox v-model="i.checked" @click.prevent.native="commonSelectItem(i, item)" :disabled="i.distQty<=0"></Checkbox></li>
                            <li class="">
                                <div class="cart-name">
                                  <img :src="i.imgUrl" alt="" :onerror="defaultPimg()" class="p-img" @click="toCommonDetail(i)">
                                  <div class="p-name-wrap">
                                    <p class="p-name" @click="toCommonDetail(i)">{{i.productName}}</p>
                                    <p style="margin:5px 0;color:#E61E10;" v-if="i.productType==2&&i.periodKey">{{i.periodKey}}</p>
                                    <Badge :text="'物流费减免：'+i.deliveryFeeReduceRate+'%'" class-name="p-wrap-badge">
                                    </Badge>
                                    <p class="p-name-area" style="margin-top:5px;" v-if="i.distDcDescription">{{i.distDcDescription}}</p>
                                  </div>
                                </div>
                            </li>
                            <li class="">{{i.orderPrice}}</li>
                            <li class="">
                              <div class="cart-num">
                                  <InputNumber
                                    :min="i.minOrderQty*1"
                                    :max="999999"
                                    v-model="i.orderQty"
                                    :precision="i.qtyDecimalPlace*1"
                                    :ref="i.id" :active-change="false"
                                    @on-focus="(a)=>commonQtyFocus(a,i.id)"
                                    @on-change="(a)=>commonQtyChange(a,i,i.$index)"></InputNumber>
                                  <p class="p-store" v-if="userData.showDistQty==='true'">库存：{{i.distQty}}</p>
                                  <p class="p-store" v-else>
                                    <span v-if="i.distQty*1>0 && i.distQty*1<i.warnDistQty*1" class="warn--text">库存紧张</span>
                                    <span v-else-if="i.distQty*1<=0" class="red--text">暂时无货</span>
                                    <span v-else class="defult--text">库存充足</span>
                                  </p>
                                </div>
                            </li>
                            <li class="">￥{{i.orderQty*i.orderPrice|filterPrice}}</li>
                            <li class="">
                              <Button type="text" size="small" class="del-btn" @click.native="commonDeleteCart(i.id)">删除
                              </Button>
                            </li>
                       </ul>
                    </div>
                 </div>
              </div>
              <div class="table-footer">
                <div class="tab-footer">
                  <div class="tab-footer-l">
                    <Checkbox v-model="allChecked" @click.prevent.native="commonSelectAll">全选</Checkbox>
                    <Button class="btn" type="text" @click="commonDeleteSelect">删除选中商品</Button>
                    <!--<Button class="btn" type="text">清除失效商品</Button>-->
                  </div>
                  <div class="tab-footer-r">
                    <span class="text">
                      已选中
                      <em class="red--text">{{commonSelectPro.length}}</em>
                      种
                    </span>
                    <span class="text">合计金额：</span>
                    <span class="price">¥{{commonTotalAmount|filterPrice}}</span>
                    <Button class="btn" :disabled="loading" type="error" @click="toCommonSettlement">去结算</Button>
                  </div>
                </div>
              </div>
            </div>
            <Row v-else>
              <Col span="24">
                <div class="search-result">
                  <img src="../../assets/images/empty/cart.png" alt="" class="search-img">
                  <span class="search-info">购物车竟然是空的！</span>
                  <a href="javascript:void(0)" @click="toJump"><span>去逛逛>></span></a>
                </div>
              </Col>
            </Row>

          </div>
        </TabPane>
        <TabPane name="supplierCart" :label="'厂商直送商品（'+getSupplierCartNum+'）'">
          <div class="supplier-cart" :style="{height:tabHeight+50+'px'}">
            <div class="supplier-cart-table" v-loading="loading"
                 v-if="cartSupplierProductData">
              <Row class="tab-header">
                <Col :span="14" class="tab-item">
                  商品
                </Col>
                <Col :span="3" class="tab-item">
                  单价
                </Col>
                <Col :span="2" class="tab-item">
                  数量
                </Col>
                <Col :span="3" class="tab-item">
                  小计
                </Col>
                <Col :span="2" class="tab-item">
                  操作
                </Col>
              </Row>

              <div class="supplier-cart-table-item" v-for="(e,index) in cartSupplierProductData" :key="index">
                <div class="tab-header tab-header-item">
                  <Checkbox v-model="e.selectAll" @click.prevent.native="supplierSelectAll(e,e.suppilerId,index)">全选</Checkbox>
                  <p class="way" @click="jump(e.service)">
                    <span class="way-name">{{e.supplierName}}</span>
                    <Badge text="服务商" v-if="e.service=='0'" @click.native="jump(e.service)" type="warning"
                           style="margin-top: 7px;margin-left: 10px;cursor: pointer;z-index: 1">
                    </Badge>
                  </p>
                  <span>联系电话：{{e.supplierMobilePhone}}</span>
                </div>
                <div class="common-cart-table-con">
                 <div class="common-cart-table-con-item" v-for="(item, index2) in e.fsoSupplierProductDtos" :key="index2">
                    <ul class="common-cart-table-con-style1" v-if="!item.productSetList.length" :class="tableRowClassNameDe(item)">
                       <li class=""><Checkbox v-model="item.checked" @click.prevent.native="supplierSelectItem(e, item)" :disabled="item.distQty<=0"></Checkbox></li>
                       <li class="">
                          <div class="cart-name">
                            <img :src="item.productImgUrl" alt="" :onerror="defaultPimg()" class="p-img" @click="toSupplierDetail(item, e.service)">
                            <div class="p-name-wrap">
                              <p class="p-name" @click="toSupplierDetail(item, e.service)">{{item.productName}}</p>
                            </div>
                          </div>
                       </li>
                       <li class="">{{item.taxPrice}}</li>
                       <li class="">
                         <div class="cart-num">
                            <InputNumber
                              :min="item.minOrderQty*1"
                              :max="999999"
                              v-model="item.orderQty"
                              :precision="item.qtyDecimalPlace*1"
                              :ref="item.id" :active-change="false"
                              @on-focus="(a)=>qtyFocus(e,item.id)"
                              @on-change="(a)=>qtyChange(a,e,item,item.$index)"></InputNumber>
                            <p class="p-store" v-if="userData.showDistQty==='true'">库存：{{item.distQty}}</p>
                            <p class="p-store" v-else>
                              <span v-if="item.distQty*1>0 && item.distQty*1<item.warnDistQty*1" class="warn--text">库存紧张</span>
                              <span v-else-if="item.distQty*1<=0" class="red--text">暂时无货</span>
                              <span v-else class="defult--text">库存充足</span>
                            </p>
                          </div>
                       </li>
                       <li class="">￥{{item.orderQty*item.taxPrice|filterPrice}}</li>
                       <li class="">
                         <Button type="text" size="small" class="del-btn" @click.native="deleteCart(item.id, index)">删除
                         </Button>
                       </li>
                    </ul>
                    <div class="common-cart-table-con-style2" v-else>
                       <p class="cart-des">
                           <Checkbox v-model="item.checked" @click.prevent.native="supplierSelectItemAll(e, item)" :disabled="item.disabled">全选</Checkbox>
                           <em>{{item.setOrderPrompt}}</em>
                       </p>
                       <ul class="" v-for="(i, index1) in item.productSetList" :key="index1" :class="tableRowClassNameDe(i)">
                            <li class=""><Checkbox v-model="i.checked" @click.prevent.native="supplierSelectItem(e, i)" :disabled="i.distQty<=0"></Checkbox></li>
                            <li class="">
                                <div class="cart-name">
                                  <img :src="i.productImgUrl" alt="" :onerror="defaultPimg()" class="p-img" @click="toSupplierDetail(i, e.service)">
                                  <div class="p-name-wrap">
                                    <p class="p-name" @click="toSupplierDetail(i, e.service)">{{i.productName}}</p>
                                  </div>
                                </div>
                            </li>
                            <li class="">{{i.taxPrice}}</li>
                            <li class="">
                              <div class="cart-num">
                                  <InputNumber
                                    :min="i.minOrderQty*1"
                                    :max="999999"
                                    v-model="i.orderQty"
                                    :precision="i.qtyDecimalPlace*1"
                                    :ref="i.id" :active-change="false"
                                    @on-focus="(a)=>qtyFocus(a,i.id)"
                                    @on-change="(a)=>qtyChange(a,e,i,i.$index)"></InputNumber>
                                  <p class="p-store" v-if="userData.showDistQty==='true'">库存：{{i.distQty}}</p>
                                  <p class="p-store" v-else>
                                    <span v-if="i.distQty*1>0 && i.distQty*1<i.warnDistQty*1" class="warn--text">库存紧张</span>
                                    <span v-else-if="i.distQty*1<=0" class="red--text">暂时无货</span>
                                    <span v-else class="defult--text">库存充足</span>
                                  </p>
                                </div>
                            </li>
                            <li class="">￥{{i.orderQty*i.taxPrice|filterPrice}}</li>
                            <li class="">
                              <Button type="text" size="small" class="del-btn" @click.native="deleteCart(i.id, index)">删除
                              </Button>
                            </li>
                       </ul>
                    </div>
                 </div>
                </div>
                <div class="tab-footer">
                  <div class="tab-footer-l">
                    <Checkbox v-model="e.selectAll" @click.prevent.native="supplierSelectAll(e,e.suppilerId,index)">全选
                    </Checkbox>
                    <Button class="btn" type="text" @click="deleteSelect(e, index)">删除选中商品</Button>
                    <!--<Button class="btn" type="text">清除失效商品</Button>-->
                  </div>
                  <div class="tab-footer-r">
                    <span class="text">已选中 <em class="red--text">{{e.selectCount}}</em>种</span>
                    <span class="text">合计金额：</span>
                    <span class="price">¥{{e.selectAmount}}</span>
                    <Button class="btn" type="error" :disabled="loading" @click="toSettlement(e)">去结算
                    </Button>
                  </div>
                </div>
              </div>
            </div>
            <Row v-else>
              <Col span="24">
                <div class="search-result">
                  <img src="../../assets/images/empty/cart.png" alt="" class="search-img">
                  <span class="search-info">购物车竟然是空的！</span>
                  <a href="javascript:void(0)" @click="toJump"><span>去逛逛>></span></a>
                </div>
              </Col>
            </Row>
          </div>
        </TabPane>
      </Tabs>
    </div>
  </Modal>

</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core'
  import * as opt from './options'

  export default {
    components: {},
    data() {
      return {
        tabName: 'commonCart',
        tabHeight: 500,
        dialog: null,
        windowHeight: '',
        allChecked: true,
        commonSelectPro: [],
        commonTotalAmount: 0.00,

        columns: opt.commonHeader,
        selectPro: [],
        totalAmount: 0,
        selectArr: [],
        initWatchData: false,
        deleteSuccess: false,
        defaultProps: {
          children: 'productSetList',
          label: 'productName'
        }
      }
    },
    computed: {
      ...mapState([
        'loading',
        'cartDialogVisible',
        'addSuccess',
        'selectedArr',
        'selectedSupplierArr'
      ]),
      ...mapGetters([
        'cartProductData',
        'cartSupplierProductData',
        'userData',
        'getCommonCartNum',
        'getSupplierCartNum',
        'maxRechargeAmount'
      ])
    },
    watch: {
      'addSuccess': 'handleAddSuccess',
      cartProductData: {
        handler(val, oldVal) {
          console.log(val)
          let temp1 = []
          let temp2 = []
          let temp3 = []
          let temp4 = []
          this.commonSelectPro = []
          this.commonTotalAmount = 0.00
          val.forEach(e => {
            temp2 = []
            // 添加选中的商品
            if (e.checked && !e.productList.length) {
              this.commonSelectPro.push(e)
            }
            // 处理系列商品
            if (e.productList.length) {
              temp4 = []
              // 遍历系列商品
              e.productList.forEach(i => {
                if (i.checked) {
                  temp2.push(i)
                  // 添加选中的商品
                  this.commonSelectPro.push(i)
                }
                if (i.distQty <= 0) {
                 temp4.push(i)
                }
              })
              console.log('系列商品长度：', temp2.length, e.productList.length - temp4.length)
              // 系列商品的全选与反全选
              if (temp2.length === (e.productList.length - temp4.length)) {
                if (e.productList.length === temp4.length) {
                  e.disabled = true
                  e.checked = false
                } else {
                  e.checked = true
                }
              } else {
                e.checked = false
              }
            }
            // 自营购车全选与反全选flag
            if (e.checked) {
              temp1.push(e)
            }
            if (e.distQty <= 0) {
              temp3.push(e)
            }
          })
          console.log('商品长度:', temp1.length, temp3.length, this.cartProductData.length - temp3.length)
          // 自营购车全选与反全选
          if (temp1.length === (this.cartProductData.length - temp3.length)) {
            this.allChecked = true
          } else {
            this.allChecked = false
          }
          // 筛选库存大于0的商品
          this.commonSelectPro = this.commonSelectPro.filter(e => {
            return e.distQty > 0
          })
          // 合计金额
          this.commonSelectPro.forEach(e => {
            this.commonTotalAmount = (parseFloat(this.commonTotalAmount) + parseFloat(e.orderPrice * e.orderQty)).toFixed(2)
          })
          console.log('自营选中的商品:', this.commonSelectPro)
        },
        deep: true
      },
      cartSupplierProductData: {
        handler(val, oldval) {
          if (this.initWatchData) {
            console.log('监听成功')
            this.handleSupplierChecked(val)
          }
        },
        deep: true
      }
    },
    created() {
      console.log('cartdialog created ')
      this.handleBaseDialog({visible: false, type: 'cartDialogVisible'})
    },
    mounted() {
      this.dialog = this.$refs.dialog
    },
    methods: {
      ...mapActions([
        'getCartData',
        'deleteCartProduct',
        'saveCartId',
        'addToCart',
        'addToDateCart',
        'saveCommonCartNum',
        'saveProductInfo',
        'saveProductSeriesInfo',
        'saveProductDateInfo',
        'handleBaseDialog',
        'saveSelectedId',
        'saveSelectedSupplierId',

        'getSupplierCartData',
        'deleteSupplierCartProduct',
        'saveSupplierCartId',
        'addToSupplierCart',
        'saveSupplierCartNum',
        'saveSupplierProductInfo',
        'saveSupplierProductSeriesInfo',
        'addProductSuccess',

        'saveCommonSettlementInfo',
        'saveSupplierSettlementInfo',
        'getMaxRechargeAmount'

      ]),
      dialogChange(v) {
        console.log(v)
        if (v) {
          this.initWatchData = true
          this.deleteSuccess = false
          this.initCommonData()
          this.initSupplierData()
          if (this.getCommonCartNum == 0 && this.getSupplierCartNum > 0) {
            this.tabName = 'supplierCart'
          } else {
            this.tabName = 'commonCart'
          }
          this.$nextTick(() => {
            this.dialog.scrollTop = 0
          })
          this.windowHeight = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop
          window.scrollTo(0, 0)
          let h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
          this.tabHeight = h - 190
        } else {
          this.initWatchData = false
          window.scrollTo(0, this.windowHeight)
          this.handleBaseDialog({visible: false, type: 'cartDialogVisible'})
          if (this.deleteSuccess) {
            // 通知 删除成功  更新页面订货数量  放在删除成功逻辑中会影响 选中状态
            this.addProductSuccess(this.$route.path + '?' + new Date().getTime())
          }
        }
      },
      // 自营商品单选
      commonSelectItem(v, v2) {
        v.checked = !v.checked
      },
      // 自营系列商品全选与反全选
      commonSelectItemAll(v) {
        v.checked = !v.checked
        v.productList.forEach(e => {
          if (v.checked) {
            if (e.distQty > 0) {
              e.checked = true
            }
          } else {
            e.checked = false
          }
        })
      },
      // 自营购车全选与反全选
      commonSelectAll() {
        this.allChecked = !this.allChecked
        this.cartProductData.forEach(e => {
          if (this.allChecked) {
            if (e.distQty > 0) {
              e.checked = true
            }
          } else {
            e.checked = false
          }
          e.productList.forEach(i => {
            if (this.allChecked) {
              if (i.distQty > 0) {
                i.checked = true
              }
            } else {
              i.checked = false
            }
          })
        })
      },
      // 直送处理选中改变(初始化)
      handleSupplierChecked(data) {
        let temp1 = []
        let temp2 = []
        let temp3 = []
        let temp4 = []
        data.forEach(e => {
          temp1 = []
          temp3 = []
          this.selectPro = []
          e.selectCount = 0
          e.selectAmount = '0.00'
          e.fsoSupplierProductDtos.forEach(i => {
            temp2 = []
            // 添加选中的商品
            if (i.checked && !i.productSetList.length) {
              this.selectPro.push(i)
            }
            if (i.productSetList.length) {
              temp4 = []
              // 遍历系列商品
              i.productSetList.forEach(el => {
                if (el.checked) {
                  temp2.push(el)
                  // 添加选中的商品
                  this.selectPro.push(el)
                }
                if (el.distQty <= 0) {
                  temp4.push(el)
                }
              })
              console.log('直送系列商品长度：', temp2.length, i.productSetList.length - temp4.length)
              // 系列商品的全选与反全选
              if (temp2.length === (i.productSetList.length - temp4.length)) {
                if (i.productSetList.length === temp4.length) {
                  // 系列商品的库存全为0，禁用checkbox
                  i.disabled = true
                  i.checked = false
                } else {
                  // 选中
                  i.checked = true
                }
              } else {
                // 不选中
                i.checked = false
              }
            }
            // 直送购车全选与反全选flag
            if (i.checked) {
              temp1.push(i)
            }
            if (i.distQty <= 0) {
              temp3.push(i)
            }
          })
          console.log('直送商品长度:', temp1.length, temp3.length, e.fsoSupplierProductDtos.length - temp3.length)
          // 直送购车全选与反全选
          if (temp1.length === (e.fsoSupplierProductDtos.length - temp3.length)) {
            e.selectAll = true
          } else {
            e.selectAll = false
          }
          // 筛选库存大于0的商品
          this.selectPro = this.selectPro.filter(a => {
            return a.distQty > 0
          })
          // 合计
          e.selectCount = this.selectPro.length
          this.selectPro.forEach(a => {
            e.selectAmount = (parseFloat(e.selectAmount) + parseFloat(a.taxPrice * a.orderQty)).toFixed(2)
          })
          console.log('直送选中的商品:', this.selectPro)
        })
        this.initWatchData = false
      },
      // 直送商品单选处理
      handleSupplierItemChecked(e) {
        let temp1 = []
        let temp2 = []
        let temp3 = []
        let temp4 = []
        this.selectPro = []
        e.selectCount = 0
        e.selectAmount = '0.00'
        e.fsoSupplierProductDtos.forEach(i => {
          temp2 = []
          // 添加选中的商品
          if (i.checked && !i.productSetList.length) {
            this.selectPro.push(i)
          }
          if (i.productSetList.length) {
            temp4 = []
            // 遍历系列商品
            i.productSetList.forEach(el => {
              if (el.checked) {
                temp2.push(el)
                // 添加选中的商品
                this.selectPro.push(el)
              }
              if (el.distQty <= 0) {
                temp4.push(el)
              }
            })
            console.log('直送系列商品长度：', temp2.length, i.productSetList.length - temp4.length)
            // 系列商品的全选与反全选
            if (temp2.length === (i.productSetList.length - temp4.length)) {
              if (i.productSetList.length === temp4.length) {
                // 系列商品的库存全为0，禁用checkbox
                i.disabled = true
                i.checked = false
              } else {
                // 选中
                i.checked = true
              }
            } else {
              // 不选中
              i.checked = false
            }
          }
          // 直送购车全选与反全选flag
          if (i.checked) {
            temp1.push(i)
          }
          if (i.distQty <= 0) {
            temp3.push(i)
          }
        })
        console.log('直送商品长度:', temp1.length, temp3.length, e.fsoSupplierProductDtos.length - temp3.length)
        // 直送购车全选与反全选
        if (temp1.length === (e.fsoSupplierProductDtos.length - temp3.length)) {
          e.selectAll = true
        } else {
          e.selectAll = false
        }
        // 筛选库存大于0的商品
        this.selectPro = this.selectPro.filter(a => {
          return a.distQty > 0
        })
        // 合计
        e.selectCount = this.selectPro.length
        this.selectPro.forEach(a => {
           e.selectAmount = (parseFloat(e.selectAmount) + parseFloat(a.taxPrice * a.orderQty)).toFixed(2)
        })
        console.log('直送选中的商品:', this.selectPro)
      },
      // 直送商品单选
      supplierSelectItem(a, v) {
        v.checked = !v.checked
        this.handleSupplierItemChecked(a)
      },
      // 直送系列商品全选与反全选
      supplierSelectItemAll(a, v) {
        a.selectAmount = '0.00'
        a.selectCount = '0'
        v.checked = !v.checked
        v.productSetList.forEach(e => {
          if (v.checked) {
            if (e.distQty > 0) {
              e.checked = true
            }
          } else {
            e.checked = false
          }
        })
        let temp1 = []
        let temp2 = []
        this.selectPro = []
        a.fsoSupplierProductDtos.forEach(i => {
          if (i.checked) {
            temp1.push(i)
            if (!i.productSetList.length) {
              this.selectPro.push(i)
            }
          } else {
            temp2.push(i)
          }
          i.productSetList.forEach(e => {
            if (e.checked) {
              this.selectPro.push(e)
            }
          })
        })
        console.log(temp1.length, a.fsoSupplierProductDtos.length, temp2.length)
        if (temp1.length && temp1.length === (a.fsoSupplierProductDtos.length - temp2.length)) {
          a.selectAll = true
        } else {
          a.selectAll = false
        }
        // 筛选库存大于0的商品
        this.selectPro = this.selectPro.filter(a => {
            return a.distQty > 0
        })
        // 合计
        a.selectCount = this.selectPro.length
        this.selectPro.forEach(item => {
          a.selectAmount = (parseFloat(a.selectAmount) + parseFloat(item.taxPrice * item.orderQty)).toFixed(2)
        })
        console.log('直送选中的商品:', this.selectPro)
      },
      // 直送购车全选与反全选
      supplierSelectAll(v) {
        v.selectAll = !v.selectAll
        this.selectPro = []
        v.selectCount = 0
        v.selectAmount = '0.00'
        v.fsoSupplierProductDtos.forEach(e => {
          if (v.selectAll) {
            if (e.distQty > 0) {
              e.checked = true
              if (!e.productSetList.length) {
                this.selectPro.push(e)
              }
            }
          } else {
            e.checked = false
          }
          e.productSetList.forEach(i => {
            if (v.selectAll) {
              if (i.distQty > 0) {
                i.checked = true
                this.selectPro.push(i)
              }
            } else {
              i.checked = false
            }
          })
        })
        // 筛选库存大于0的商品
        this.selectPro = this.selectPro.filter(a => {
            return a.distQty > 0
        })
        // 合计
        v.selectCount = this.selectPro.length
        this.selectPro.forEach(a => {
          v.selectAmount = (parseFloat(v.selectAmount) + parseFloat(a.taxPrice * a.orderQty)).toFixed(2)
        })
        console.log('直送选中的商品:', this.selectPro)
      },
      // 添加成功 更新数量
      handleAddSuccess(v) {
        let path = v.split('?')[0]
        if (path == this.$route.path) {
          if (this.tabName == 'commonCart') {
            this.initCommonData()
          } else {
            this.initSupplierData()
          }
        }
      },
      // 初始化 自营购物车数量
      initCommonData() {
        // 首次进购物车 默认全部选中，库存不足的不选中
        this.getCartData({pageSize: 9999}).then(() => {
          this.cartProductData.forEach(item => {
            if (item.distQty > 0) {
              // this.$refs.table.toggleRowSelection(item, true)
            }
          })
        })
      },
      // 初始化 直送购物车数量
      initSupplierData() {
        this.getSupplierCartData({pageSize: 9999}).then(() => {
          this.initWatchData = true
          this.cartSupplierProductData.forEach(item => {
            item.fsoSupplierProductDtos.forEach(i => {
              if (i.distQty > 0) {
                // this.$refs[item.suppilerId][0].toggleRowSelection(i, true)
              }
            })
          })
        })
      },
      // 切换tab 是否 刷新数据
      tabClick() {
      },
      // 直送跳转
      jump(service) {
        this.handleBaseDialog({visible: false, type: 'cartDialogVisible'})
        if (service === '0') {
          this.$router.push({path: '/index/fwproduct'})
        } else {
          this.$router.push({path: '/index/supplierproduct'})
        }
      },
      toJump() {
        this.handleBaseDialog({visible: false, type: 'cartDialogVisible'})
        this.$router.push({path: '/index/home'})
      },
      // 自营 ==全选或者非全选
      // commonSelectAll(v) {
      //   this.check = v
      //   this.$refs.table.toggleAllSelection()
      // },
      // 直送 ==全选或者非全选  (多个表格 全选失败)
      selectAll(v, id, index) {
        this.cartSupplierProductData[index].selectAll = v
        this.$refs[id][0].toggleAllSelection()
      },
      // 处理能不能被选中
      handleCheck(row, index) {
        if (row.distQty == 0) {
          return 0
        } else {
          return 1
        }
      },
      // 处理row颜色
      tableRowClassName({row, rowIndex}) {
        if (row.distQty == 0) {
          return 'row-gery'
        } else if (parseInt(row.orderQty) > parseInt(row.distQty)) {
          return 'row-red'
        } else {
          return ''
        }
      },
      tableRowClassNameDe(row) {
        if (row.distQty == 0) {
          return 'row-gery'
        } else if (parseInt(row.orderQty) > parseInt(row.distQty)) {
          return 'row-red'
        } else {
          return ''
        }
      },
      // 自营 选中改变时候
      handleCommonSelectionChange(v) {
        // 只取库存大于0 的商品列表数据
        let arr = this.cartProductData.filter(item => item.distQty != '0')
        if (v.length == arr.length) {
          this.check = true
        } else {
          this.check = false
        }

        this.commonSelectPro = v
        this.commonTotalAmount = 0
        this.commonSelectPro.forEach(item => {
          let amount = (parseFloat(item.orderPrice) * parseFloat(item.orderQty)).toFixed(2)
          this.commonTotalAmount += parseFloat(amount)
        })
      },
      // 直送 选中改变时候 ======
      handleSelectionChange(v, id, tableList, index) {
        console.log(v)
        console.log(tableList)
        let distArr = tableList.filter(item => item.distQty != '0')
        if (v.length == distArr.length) {
          this.cartSupplierProductData[index].selectAll = true
        } else {
          this.cartSupplierProductData[index].selectAll = false
        }
        this.selectPro = v
        let amount = 0
        if (v.length) {
          v.forEach(i => {
            amount += (parseFloat(i.taxPrice) * parseFloat(i.orderQty))
            this.cartSupplierProductData[index].selectAmount = parseFloat(amount).toFixed(2)
          })
        } else {
          this.cartSupplierProductData[index].selectAmount = '0.00'
        }
        this.cartSupplierProductData[index].selectCount = v.length
        //
        let arr = []
        let obj = {key: id, arr: v}
        if (this.selectArr.length) {
          arr = this.selectArr.filter(item => item.key != id)
        }
        arr.push(obj)
        this.selectArr = arr
      },

      commonQtyFocus(e, id) {
        console.log(this.$refs[id])
        setTimeout(() => {
          this.$refs[id][0].$el.querySelector('input').select()
        }, 10)
      },
      qtyFocus(e, id) {
        setTimeout(() => {
          // this.$refs[id][0].$el.querySelector('input').click()
          this.$refs[id][0].$el.querySelector('input').select()
        }, 10)
      },

      // 自营==数量切换时候
      commonQtyChange(v, row, index) {
        console.log(v)
        console.log(row)
        console.log(index)
        if (v) {
          this.handleCommonClear(row)
        } else {
          this.$nextTick(() => {
            row.orderQty = row.minOrderQty
            this.handleCommonClear(row)
          })
        }
      },
      handleCommonClear(row) {
        this.commonTotalAmount = 0
        this.commonSelectPro.forEach(item => {
          let amount = (parseFloat(item.orderPrice) * parseFloat(item.orderQty)).toFixed(2)
          this.commonTotalAmount += parseFloat(amount)
        })
        if (row.productType == 2) {
          this.addCommonDateCart(row)
        } else {
          this.addCommonCart(row)
        }
      },

      // 直送== 数量切换时候
      qtyChange(v, row, item, id) {
        console.log(v)
        if (v) {
          this.handleSupplierClear(row, item, id)
        } else {
          this.$nextTick(() => {
            row.orderQty = row.minOrderQty
            this.handleSupplierClear(row, item, id)
          })
        }
      },

      handleSupplierClear(row, item, id) {
        // let amount = 0
        // let arr = []
        // arr = this.selectArr.filter(item => item.key == id)[0]

        // if (arr) {
        //   this.cartSupplierProductData.forEach(item => {
        //     if (item.suppilerId == id) {
        //       arr.arr.forEach(i => {
        //         amount += (parseFloat(i.taxPrice) * parseFloat(i.orderQty))
        //         item.selectAmount = parseFloat(amount).toFixed(2)
        //       })
        //     }
        //   })
        // }
        this.handleSupplierItemChecked(row)
        this.addCart(item)
      },

      // 自营==切换后 重新请求购物车接口
      addCommonCart(row) {
        let self = this
        let params = {
          orderQty: row.orderQty || '',
          dcId: row.distDcId,
          productId: row.productId
        }
        self.addToCart(params).then(res => {
          let data = res.data
          if (data.status == 0) {
            row.id = data.data.id
            console.log(row)
            this.$forceUpdate()
          } else {
            self.$Modal.error({
              title: '温馨提示',
              content: data.message,
              onOk: () => {
                setTimeout(() => {
                  self.$refs[row.id][0].$el.querySelector('input').select()
                }, 10)
              }
            })
          }
        })
      },
      // 生产期间商品切换后重新请求购物车接口
      addCommonDateCart(row) {
        let self = this
        let params = []
        params.push({
          orderQty: row.orderQty,
          dcId: row.distDcId,
          productId: row.productId,
          periodId: row.periodId
        })
        this.addToDateCart({data: JSON.stringify(params)}).then(res => {
          console.log(res.data)
          let data = res.data
          if (data.status == 0) {
            row.id = data.data.cartList[0].id
            console.log(row)
            this.$forceUpdate()
          } else {
            let msg = data.message.replace(/\n\n/g, '</p></br><p>')
            msg = '<div style="max-height: 500px;overflow: auto"><p>' + msg + '</p></div>'
            self.$Modal.error({
              title: '温馨提示',
              content: msg,
              width: 600,
              onOk: () => {
              }
            })
          }
        })
      },
      // 直送==切换后 重新请求购物车接口
      addCart(row) {
        let self = this
        let params = {
          orderQty: row.orderQty || '',
          supplierId: row.supplierId,
          productId: row.productId
        }
        self.addToSupplierCart(params).then(res => {
          let data = res.data
          if (data.status == 0) {
            row.id = data.data.cartList[0].id
            console.log(row)
            this.$forceUpdate()
          } else {
            self.$Modal.error({
              title: '温馨提示',
              content: data.message,
              onOk: () => {
                setTimeout(() => {
                  self.$refs[row.id].$el.querySelector('input').select()
                }, 10)
              }
            })
          }
        })
      },

      // 自营==去结算 在当前页面进行判断
      async toCommonSettlement() {
        let self = this

        if (self.commonSelectPro.length) {
          let arr = self.commonSelectPro.map(item => {
            return item.id
          })
          let params = {
            ids: arr.join(',')
          }
          let {data} = await api.getCommonSettlement(params)
          if (data.status == 1) {
            let msg = data.message.replace(/\n\n/g, '</p></br><p>')
            msg = '<div style="max-height: 500px;overflow: auto"><p>' + msg + '</p></div>'
            self.$Modal.error({
              title: '温馨提示',
              content: msg,
              width: 600,
              onOk: () => {
              }
            })
          } else {
            api.getMaxRechargeAmount().then(res => {
              console.log(res)
              if (res.data.status == 0) {
                self.saveCartId(arr.join(','))
                self.saveCommonSettlementInfo(Object.assign({}, data.data, res.data.data))
                self.handleBaseDialog({visible: true, type: 'commonSettlementDialogVisible'})
              }
            })
          }
        } else {
          self.$Notice.info({
            desc: '请至少选择一种商品！'
          })
        }
      },

      // 直送==去结算
      async toSettlement(v) {
        let self = this
        this.handleSupplierItemChecked(v)
        if (self.selectPro.length) {
          let arr = []
          if (self.selectPro.length) {
            arr = self.selectPro.map(item => {
              return item.id
            })
            let params = {
              ids: arr.join(',')
            }
            let {data} = await api.getSupplierSettlement(params)
            if (data.status == 1) {
              let msg = data.message.replace(/\n\n/g, '</p></br><p>')
              msg = '<div style="max-height: 500px;overflow: auto"><p>' + msg + '</p></div>'
              self.$Modal.error({
                title: '温馨提示',
                content: msg,
                width: 600,
                onOk: () => {
                }
              })
            } else {
              api.getMaxRechargeAmount().then(res => {
                console.log(res)
                if (res.data.status == 0) {
                  self.saveSupplierCartId(arr.join(','))
                  self.saveSupplierSettlementInfo(Object.assign({}, data.data, res.data.data))
                  self.handleBaseDialog({visible: true, type: 'supplierSettlementDialogVisible'})
                }
              })
            }
          } else {
            self.$Notice.info({
              desc: '请至少选择一种商品！'
            })
          }
        } else {
          self.$Notice.info({
            desc: '请至少选择一种商品！'
          })
        }
      },

      // 自营删除选中项
      commonDeleteSelect() {
        let arr = this.commonSelectPro.map(item => {
          return item.id
        })
        if (arr.length) {
          this.commonDeleteCart(arr.join(','))
        }
      },
      // 删除 单个商品
      commonDeleteCart(id) {
        this.$Modal.confirm({
          title: '温馨提示',
          content: '<p>选中的商品删除后将无法恢复，是否确认删除？</p>',
          onOk: () => {
            this.handleCommonDelete(id)
          },
          onCancel: () => {
          }
        })
      },
      // 删除购物车 商品
      handleCommonDelete(id) {
        let self = this
        let params = {
          delIds: id
        }
        // 首先存储已经选中的项
        let arr = []
        this.commonSelectPro.forEach(item => {
          arr.push(item.id)
        })
        self.saveSelectedId(arr)
        console.log(this.selectedArr)
        self.deleteCartProduct(params).then(res => {
          let data = res.data
          if (data.status == 0) {
            self.$Notice.success({
              desc: '删除成功！'
            })
            self.deleteSuccess = true
            self.saveCommonCartNum(data.data.totalQty)
            // 通知 删除成功  更新页面订货数量
            // self.addProductSuccess(self.$route.path + '?' + new Date().getTime())

            self.getCartData({}).then(() => {
              let temp1 = []
              let temp2 = []
              // 首先将存储已经选中的项 赋值到table数据中，来进行选中
              self.selectedArr.forEach(item => {
                self.cartProductData.forEach(i => {
                  i.checked = false
                  if (i.id == item) {
                    temp1.push(i)
                  }
                  if (i.productList.length) {
                    i.productList.forEach(e => {
                      e.checked = false
                      if (e.id == item) {
                        temp2.push(e)
                      }
                    })
                  }
                })
              })
              temp1.forEach(e => {
                e.checked = true
              })
              temp2.forEach(e => {
                e.checked = true
              })
              // self.cartProductData.forEach(item => {
              //   if (item.selected) {
              //     self.$refs.table.toggleRowSelection(item, true)
              //   }
              // })
            })
          }
        })
      },
      // 打开详情
      toCommonDetail(row) {
        console.log(row)
        this.saveProductInfo(row.productId)
        if (row.productSetId) this.saveProductSeriesInfo(row.productSetId)
        if (row.periodId) this.saveProductDateInfo(row.periodId)
        if (row.productType == '0') {
          this.handleBaseDialog({visible: true, type: 'productDetailVisible'})
        }
        if (row.productType == '1') {
          this.handleBaseDialog({visible: true, type: 'productSeriesDetailVisible'})
        }
        if (row.productType == '2') {
          this.handleBaseDialog({visible: true, type: 'productDateDetailVisible'})
        }
      },
      // 打开直送商品详情
      toSupplierDetail(row, service) {
        console.log(row, service)
        if (service == '0') {
          row.service = '服务商'
        } else {
          row.service = ''
        }
        this.saveSupplierProductInfo(row)
        this.saveSupplierProductSeriesInfo(row.productSetId)
        if (row.productSetId == '0') {
          this.handleBaseDialog({visible: true, type: 'supplierDetailVisible'})
        } else {
          this.handleBaseDialog({visible: true, type: 'supplierSeriesDetailVisible'})
        }
      },
      // 直送删除选中项
      deleteSelect(v, index) {
        this.handleSupplierItemChecked(v)
        let arr = []
        if (this.selectPro.length) {
          arr = this.selectPro.map(item => {
            return item.id
          })
          if (arr.length) {
            this.deleteCart(arr.join(','), index)
          }
        }
      },
      // 直送删除单项
      deleteCart(id, index) {
        this.$Modal.confirm({
          title: '温馨提示',
          content: '<p>选中的商品删除后将无法恢复，是否确认删除？</p>',
          onOk: () => {
            this.handleDelete(id, index)
          },
          onCancel: () => {
          }
        })
      },
      // 删除购物车 商品
      handleDelete(id, index) {
        let self = this
        let params = {
          delIds: id
        }

        // 首先存储已经选中的项
        let arr = []
        self.selectPro.forEach(item => {
          arr.push(item.id)
        })
        self.saveSelectedSupplierId(arr)
        console.log(arr)
        self.deleteSupplierCartProduct(params).then(res => {
          let data = res.data
          if (data.status == 0) {
            self.$Notice.success({
              desc: '删除成功！'
            })
            self.deleteSuccess = true
            self.saveSupplierCartNum(data.data.totalQty)
            // 通知 删除成功  更新页面订货数量
            // self.addProductSuccess(self.$route.path + '?' + new Date().getTime())
            console.log(self.selectedSupplierArr)
            self.getSupplierCartData({}).then(() => {
              self.handleSupplierChecked(self.cartSupplierProductData)
              // 首先将存储已经选中的项 赋值到table数据中，来进行选中
              // self.selectedSupplierArr.forEach(item => {
              //   self.cartSupplierProductData.forEach(i => {
              //     console.log(i.selectAll)
              //     i.fsoSupplierProductDtos.forEach(j => {
              //       // if (j.id == item) {
              //       //   j.selected = true
              //       self.$refs[i.suppilerId][0].toggleRowSelection(j, true)
              //       // }
              //       // return j
              //     })
              //   })
              // })
              console.log(self.cartSupplierProductData)
              // self.cartSupplierProductData.forEach(item => {
              //   item.fsoSupplierProductDtos.forEach(i => {
              //     if (i.selected) {
              //       self.$refs[item.suppilerId][0].toggleRowSelection(i, true)
              //     }
              //   })
              // })
            })
          }
        })
      },
      // 关闭弹窗
      closeDialog() {
        this.handleBaseDialog({visible: false, type: 'commonSettlementDialogVisible'})
        this.handleBaseDialog({visible: false, type: 'supplierSettlementDialogVisible'})
      }
    }
  }
</script>

<style lang="less">
  .ivu-tabs-nav .ivu-tabs-tab {
    font-size: 16px;
    font-weight: 700;
  }

  .red--text {
    color: #E61E10!important;
  }
  .defult--text{
    color: #444!important;
  }
  .warn--text {
    color: #e69c2e!important;
  }

  .ivu-tabs-nav .ivu-tabs-tab:hover {
    color: #E61E10;
  }

  .el-checkbox__input.is-checked .el-checkbox__inner, .el-checkbox__input.is-indeterminate .el-checkbox__inner {
    background-color: #E61E10;
    border-color: #E61E10;
  }

  .cart-wrap {
    /*overflow: auto;*/
    margin-top: -10px;

    .menu-wrap {
      position: -webkit-sticky;
      position: sticky;
      top: 0;
    }
  }

  .table-footer {
    position: -webkit-sticky;
    position: sticky;
    bottom: 0;
    z-index: 1000;
  }

  .common-cart {
    width: 100%;
    min-height: 500px;
    background-color: #ffffff;
    overflow: auto;
    .row-gery {
      background-color: #fbfbfb;
      color: #d9d9d9;
    }

    .row-red {
      color: #E61E10;
    }

    .mine-header {
      height: 35px;
      line-height: 35px;
      margin-left: 10px;
    }

    .common-cart-table {
      .cart-name {
        position: relative;
        display: flex;

        .p-name-wrap {
          padding-left: 10px;

          .p-name {
            cursor: pointer;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            line-clamp: 2;
            -webkit-box-orient: vertical;
          }
          .p-name-area{
            margin-top: 10px;
          }
        }

        .p-img {
          height: 80px;
          width: 80px;
          border: 1px solid #ebeef5;
          border-radius:5px;
          cursor: pointer;
        }
      }

      .cart-num {
        .p-store {
          padding-top: 5px;
        }
      }

      .del-btn:hover {
        background-color: #ebf7ff;
      }

      .tab-footer {
        display: flex;
        justify-content: space-between;
        padding: 0 0 0 15px;
        background-color: #f5f5f5;
        margin-top: 5px;
        height: 45px;
        line-height: 45px;
        position: relative;
        z-index: 1000;
        .tab-footer-l {
          .btn:hover {
            background-color: #f5f5f5;
          }
        }

        .tab-footer-r {
          .text {
            padding-left: 15px;
          }

          .price {
            font-size: 16px;
            font-weight: 600;
            color: #E61E10;
            margin-right: 20px;
          }

          .btn {
            border: 0;
            border-radius: 0;
            width: 100px;
            height: 45px;
          }
        }
      }
    }
  }

  .supplier-cart {
    width: 100%;
    min-height: 500px;
    border-bottom: 1px solid #cccccc;
    background-color: #ffffff;
    overflow: auto;

    .row-gery {
      background-color: #fbfbfb;
      color: #d9d9d9;
    }

    .row-red {
      color: #E61E10;
    }

    .mine-header {
      height: 35px;
      line-height: 35px;
      margin-left: 10px;
    }

    .supplier-cart-table {
      .supplier-cart-table-item{
        border:1px solid #E8E8E8;
        margin-bottom: 15px;
      }
      .tab-header {
        height: 35px;
        line-height: 35px;
        background-color: #FAFAFA;
        margin-bottom: 10px;
        .tab-item {
          text-align: center;
        }
      }

      .table {
        margin-bottom: 20px;
      }

      .cart-name {
        position: relative;
        display: flex;

        .p-name-wrap {
          padding-left: 10px;

          .p-name {
            cursor: pointer;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            line-clamp: 2;
            -webkit-box-orient: vertical;
          }
        }

        .p-img {
          height: 80px;
          width: 80px;
          border: 1px solid #cccccc;
          cursor: pointer;
        }
      }

      .cart-num {
        .p-store {
          padding-top: 5px;
        }
      }

      .del-btn:hover {
        background-color: #ebf7ff;
      }
      .tab-header {
        display: flex;
        padding: 0 25px;
        height: 40px;
        line-height: 40px;
        border-bottom: 1px solid #FAFAFA;
        background-color: #FAFAFA;

        .way {
          display: flex;
          margin-left: 20px;
          width: 300px;
          cursor: pointer;

          .way-name {
            display: inline-block;
            max-width: 220px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }
        }
      }
      .tab-header-item{
        border-bottom: 1px solid #E8E8E8;
      }
      .tab-footer {
        display: flex;
        justify-content: space-between;
        padding: 0 0 0 25px;
        background-color: #FAFAFA;
        margin-top: 5px;
        height: 45px;
        line-height: 45px;
        // margin-bottom: 30px;

        .tab-footer-l {
          display: flex;

          .btn:hover {
            background-color: #F5F8FA;
          }
        }

        .tab-footer-r {
          .text {
            padding-left: 15px;
          }

          .price {
            font-size: 16px;
            font-weight: 600;
            color: #E61E10;
            margin-right: 20px;
          }

          .btn {
            border: 0;
            border-radius: 0;
            width: 100px;
            height: 45px;
          }
        }
      }
    }
  }

  .search-result {
    width: 100%;
    display: flex;
    justify-content: center;
    flex-direction: column;
    align-items: center;

    .search-img {
      width: 280px;
      height: 280px;
    }

    .search-info {
      font-size: 16px;
      height: 30px;
      line-height: 30px;
    }
  }
  // 购物车new
  .common-cart-table{
     border:1px solid #ebeef5;
  }
  .common-cart-table-header{
    border-bottom:1px solid #ebeef5;
    background: #FAFAFA;
    ul{
      display: flex;
      height: 35px;
      li{
        height: 100%;
        width:calc((100% - 700px) / 4);
        text-align: center;
        line-height: 35px;
        // border-right:1px solid #ebeef5;
        &.product{
          width: 630px;
        }
        &.checkbox{
          width: 70px;
          padding:0 10px;
        }
        &:last-child{
          border-right:0px solid #ebeef5;
        }
      }
    }
  }
  .common-cart-table-con{
    .common-cart-table-con-item{
      border-bottom:1px solid #ebeef5;
      .common-cart-table-con-style2{
        p.cart-des{
          padding: 15px 24px;
          // border-bottom:1px solid #ebeef5;
        }
        ul{
          display: flex;
          height:90px;
          align-items: center;
          li{
            height: 100%;
            width:calc((100% - 700px) / 4);
            text-align: center;
            line-height: 90px;
            // border-bottom:1px solid #ebeef5;
            &:first-child{
              width: 70px;
              padding:0px 10px 0 50px;
            }
            &:nth-child(2){
              width: 630px;
              text-align: left;
              box-sizing: border-box;
              line-height: 20px;
              padding:5px 0 5px 20px;
            }
            &:nth-child(4){
              padding: 18px 0;
              line-height: 20px;
            }
         }
        }
      }
      .common-cart-table-con-style1{
         display: flex;
         height:90px;
         li{
            height: 100%;
            width:calc((100% - 700px) / 4);
            text-align: center;
            line-height: 90px;
            // border-bottom:1px solid #ebeef5;
            &:first-child{
              width: 70px;
              padding:0px 10px 0 10px;
            }
            &:nth-child(2){
              width: 630px;
              text-align: left;
              box-sizing: border-box;
              line-height: 20px;
              padding:5px 0 5px 0;
            }
            &:nth-child(4){
              padding: 18px 0;
              line-height: 20px;
            }
         }
      }
    }
  }
</style>
