<template>
  <Modal
    :value="supplierSettlementDialogVisible"
    title="订单详情"
    :mask-closable="false"
    footer-hide
    width="1300"
    :styles="{top: '10px'}"
    @on-visible-change="dialogChange"
    @on-cancel="closeDialog"
  >
  <!-- 用于调试 -->
  <!-- <template>
         <i-form :model="settlementInfo" label-position="left" :label-width="100">
            <Form-item label="账户可用余额">
                <i-input v-model="settlementInfo.availableBalance"></i-input>
            </Form-item>
            <Form-item label="订单总金额">
                <i-input v-model="settlementInfo.totalAmount"></i-input>
            </Form-item>
            <Form-item label="实际支付金额">
                <i-input v-model="settlementInfo.taotalPayAmount"></i-input>
            </Form-item>
            <Form-item label="限制金额">
                <i-input v-model="settlementInfo.maxRechargeAmount"></i-input>
            </Form-item>
            <Form-item>
                <i-button type="primary" @click="handleSubmit('formValidate')">提交</i-button>
            </Form-item>
         </i-form>
    </template> -->
    <div class="common-settlement" ref="supplierDialog" :style="{height:tabHeight+'px'}">
      <div class="mine-header">
        <Breadcrumb>
          <BreadcrumbItem>购物车</BreadcrumbItem>
          <BreadcrumbItem>厂商直送商品</BreadcrumbItem>
          <BreadcrumbItem>订单详情</BreadcrumbItem>
        </Breadcrumb>
      </div>

      <div class="address-header">
        <h3 class="settle-header">确认收货地址</h3>
        <p class="address-add red--text" @click="addAddress(settlementInfo.subCustomerId)">新增收货地址</p>
      </div>

      <div class="common-wrap">
        <div v-if="!showMoreAddress">
          <Radio class="address-item address-text" :value="true">
            <span :title="settlementInfo.address">{{settlementInfo.address | cutAddress}} </span>
            <span style="margin-left: 10px">{{settlementInfo.contactor}}</span>
            <span style="margin-left: 10px">{{settlementInfo.mobilePhone}}</span>
            <Badge style="margin-left: 15px"  v-if="settlementInfo.isDefaultReceiveAddress==1"
                   text="默认地址" type="warning"></Badge>
            <Button type="text" @click="editAddress(settlementInfo.receiveAddressId)" class="address-item-edit">修改本地址
            </Button>
          </Radio>
        </div>
        <div v-else-if="showMoreAddress && getAddressList.length">
          <RadioGroup v-model="receiveAddressId" vertical class="address-group" @on-change="handleRadioChange">
            <Radio class="address-item" v-for="(item,index) in getAddressList" :key="index" :label="item.id"
                   :class="{'address-text':receiveAddressId==item.id}">
              <span :title="item.fullAddress">{{item.fullAddress | cutAddress}}</span>
              <span style="margin-left: 10px">{{item.receiver}}</span>
              <span style="margin-left: 10px">{{item.receiveMobilePhone}}</span>
              <Badge v-show="item.isDefault==1" style="margin-left: 15px" text="默认地址" type="warning"></Badge>
              <Button type="text" @click="editAddress(item.id)" class="address-item-edit">修改本地址</Button>
            </Radio>
          </RadioGroup>
        </div>
        <div class="address-more" v-show="getAddressList.length>1">
          <div @click="changeAddress" class="address-more-btn">
            {{showMoreAddress?'收起地址':'查看更多'}}
            <Icon v-if="!showMoreAddress" type="ios-arrow-down"/>
            <Icon v-else type="ios-arrow-up"/>
          </div>
        </div>
      </div>

      <div class="address-header">
        <h3 class="settle-header">确认订单信息</h3>
      </div>

      <div class="common-wrap">
        <Table border v-if="productsList.length" size="small" :columns="columns"
               ref="table"
               :data="productsList">
          <template slot-scope="{ row }" slot="name">
            <div class="cart-name">
              <img :src="row.productImgUrl" :onerror="defaultPimg()" alt="" class="p-img">
              <div class="p-name-wrap">
                <p class="p-name">{{row.productName}}</p>
              </div>
            </div>
          </template>
          <template slot-scope="{ row }" slot="num">
            <div class="cart-num">
              <!--<InputNumber :min="1" v-model="row.orderQty"></InputNumber>-->
              <p>{{row.orderQty}}</p>
              <!--<p class="p-store">库存：{{row.distQty}}</p>-->
            </div>
          </template>
          <template slot-scope="{ row }" slot="price">
            <p>¥{{row.taxPrice }}</p>
          </template>
        </Table>
        <Row class="common-footer">
          <Col span="18">
            <div class="item">
              <p>备注信息：</p>
              <form action="javascript:void(0)">
                <Input class="ipt" type="textarea" :maxlength="200" v-model.trim="description"/>
              </form>
            </div>
          </Col>
          <Col span="6">
            <div>
              <p class="r-price"><span>商品总额：</span> <span class="red--text">¥{{settlementInfo.totalAmount}}</span></p>
              <div class="r-item-other" v-if="!settlementInfo.isService">
                <div class="r-item"><span>物流费：</span><span>¥{{settlementInfo.totalDeliveryFeeCalcAmount}}</span></div>
                <p class="r-item"><span>物流减免：</span><span>-¥{{settlementInfo.totalDeliveryFeeReduceAmount}}</span></p>
                <p class="r-item"><span>物流费调整：</span><span>-¥0.00</span></p>
              </div>

              <p class="r-item" v-if="!settlementInfo.isService"><span>实付物流费：</span><span class="red--text">¥{{settlementInfo.totalPayDeliveryFeeReduceAmount}}</span>
              </p>

            </div>
          </Col>
        </Row>
        <Row class="common-footer line">
          <Col span="18">
            &nbsp;
          </Col>
          <Col span="6">
            <div>
              <p class="r-price red--text"><span>订单总金额：</span><span>¥{{settlementInfo.taotalPayAmount}}</span></p>
              <p class="r-item"><span>账户可用金额：</span><span>¥{{settlementInfo.availableBalance}}</span></p>
              <Button type="error" :disabled="loading" class="btn" @click="handleSettlement">发送并结算</Button>
            </div>
          </Col>
        </Row>
        <Row>
          <Col>
            <div class="footer-address-result">
              <span>{{settlementInfo.address}} </span>
              <span style="margin-left: 10px">{{settlementInfo.contactor}}</span>
              <span style="margin-left: 10px">{{settlementInfo.mobilePhone}}</span>
            </div>
          </Col>
        </Row>
      </div>
    </div>

  </Modal>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core'
  import * as opt from './options'

  export default {
    name: 'SupplierCartSettlement',
    data() {
      return {
        supplierDialog: null,
        tabHeight: '',
        columns: opt.commonSettlementHeader,
        settlementInfo: {},
        productsList: [],
        description: '',
        payPassword: '',

        showMoreAddress: false,
        receiveAddressId: ''
      }
    },
    computed: {
      ...mapState([
        'loading',
        'supplierCartId',
        'supplierSettlementDialogVisible',
        'supplierSettlementInfo',
        'addressEdit'
      ]),
      ...mapGetters([
        'cartProductData',
        'getSupplierCartNum',
        'getAddressList'
      ])
    },
    watch: {
      'addressEdit': 'handleAddress'
    },
    created() {
      this.initData()
    },
    mounted() {
      this.supplierDialog = this.$refs.supplierDialog
    },
    methods: {
      ...mapActions([
        'deleteCartProduct',
        'saveSupplierCartNum',
        'handleBaseDialog',
        'saveOrderStatus',
        'addProductSuccess',
        'handleBasicInfo',
        'getReceiverAddress',
        'saveSupplierSettlementInfo'
      ]),
      initData() {
        this.handleBaseDialog({visible: false, type: 'supplierSettlementDialogVisible'})
      },
      dialogChange(v) {
        console.log(v)
        this.showMoreAddress = false
        if (v) {
          this.$nextTick(() => {
            this.supplierDialog.scrollTop = 0
          })
          let h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
          this.tabHeight = h - 95
          this.getSettlement()
          this.getReceiverAddress(this.settlementInfo.subCustomerId)
          this.receiveAddressId = this.settlementInfo.receiveAddressId
        } else {
          this.handleBaseDialog({visible: false, type: 'supplierSettlementDialogVisible'})
        }
      },
      // 获取结算详情
      getSettlement() {
        this.settlementInfo = this.supplierSettlementInfo
        this.productsList = this.supplierSettlementInfo.products
      },
      // 进行结算前先进性判断 余额是否够支付 该订单金额
      handleSettlement() {
        if (this.settlementInfo.taotalPayAmount == 0) {
          this.toSettlement()
        } else {
          let temp = {
            supplierCartId: this.supplierCartId,
            description: this.description,
            payPassword: this.payPassword
          }
          this.saveSupplierSettlementInfo(Object.assign({}, this.supplierSettlementInfo, temp))
          this.settlementInfo = this.supplierSettlementInfo
          this.handleBaseDialog({visible: true, type: 'payMethodDialogVisible', orderType: 2})
        }
        // if (this.settlementInfo.taotalPayAmount * 1 > 0 && parseFloat(this.settlementInfo.taotalPayAmount) > parseFloat(this.settlementInfo.availableBalance)) {
        //   let amount = parseFloat(this.settlementInfo.taotalPayAmount) - parseFloat(this.settlementInfo.availableBalance)
        //   amount = amount.toFixed(2)
        //   let message = `<p>您的资金账户可用余额不足，还需要充值 <span style="color:#E61E10">¥ ${amount}</span>，</p><p>去充值吧！</p>`
        //   this.$Modal.error({
        //     title: '温馨提示',
        //     content: message,
        //     width: 435,
        //     onOk: () => {
        //       this.handleBaseDialog({visible: false, type: 'supplierSettlementDialogVisible'})
        //       this.handleBaseDialog({visible: false, type: 'cartDialogVisible'})
        //       this.$router.push({path: '/mine/recharge', query: {amount: amount}})
        //     }
        //   })
        // } else {
        //   this.toSettlement()
        // }
      },
      // 进行结算
      async toSettlement() {
        let self = this
        let params = {
          ids: self.supplierCartId,
          provOrderNo: '',
          description: self.description,
          payPassword: self.payPassword,
          receiveAddressId: self.receiveAddressId || ''
        }
        let {data} = await api.getSupplierOrderSend(params)
        if (data.status == 0) {
          self.$Notice.success({
            desc: data.message
          })
          let num = self.getSupplierCartNum - self.settlementInfo.totalQty
          self.saveSupplierCartNum(num)
          // 通知 结算成功  更新 页面订货数量
          self.addProductSuccess(self.$route.path + '?' + new Date().getTime())
          self.handleBaseDialog({visible: false, type: 'supplierSettlementDialogVisible'})
          self.handleBaseDialog({visible: false, type: 'cartDialogVisible'})

          self.saveOrderStatus({type: 'supplierOrder', status: '3', name: '1'})
          self.handleBaseDialog({visible: true, type: 'orderDialogVisible'})
        } else {
          self.$Modal.error({
            title: '温馨提示',
            content: data.message,
            onOk: () => {
            }
          })
        }
        console.log(data)
      },
      // 关闭弹窗
      closeDialog() {
        this.handleBaseDialog({visible: false, type: 'supplierSettlementDialogVisible'})
      },
      // 是否展示更多地址数据=====================================================================
      changeAddress() {
        this.showMoreAddress = !this.showMoreAddress
      },
      // 切换地址 1.需要刷新订单信息（物流费）
      handleRadioChange(v) {
        console.log(v)
        this.showMoreAddress = false
        this.toSupplierSettlement()
      },
      // 修改地址
      editAddress(id) {
        this.handleBasicInfo({id: id, from: 'supplierSettlement'})
        this.handleBaseDialog({visible: true, type: 'addAddressVisible', title: '编辑'})
      },
      // 新增地址
      addAddress(id) {
        this.handleBasicInfo({subCustomerId: id, from: 'supplierSettlement'})
        this.handleBaseDialog({visible: true, type: 'addAddressVisible', title: '新增'})
      },
      // 修改完成 1.需要刷新地址信息 2.刷新订单信息
      handleAddress(v) {
        let path = v.split('?')[0]
        if (path == 'supplierSettlement') {
          this.toSupplierSettlement()
          this.getReceiverAddress(this.settlementInfo.subCustomerId)
        }
      },
      // 修改地址后 更新订单信息
      async toSupplierSettlement(v) {
        let self = this
        let params = {
          ids: self.supplierCartId,
          receiveAddressId: self.receiveAddressId
        }
        let {data} = await api.getSupplierSettlement(params)
        if (data.status == 1) {
          let msg = data.message.replace(/\n\n/g, '</p></br><p>')
          msg = '<div style="max-height: 500px;overflow: auto"><p>' + msg + '</p></div>'
          self.$Modal.error({
            title: '温馨提示',
            content: msg,
            width: 600,
            onOk: () => {
            }
          })
        } else {
          let result = data.data
          self.saveSupplierSettlementInfo(Object.assign({}, this.supplierSettlementInfo, result))
          this.settlementInfo = this.supplierSettlementInfo
          self.getSettlement()
        }
      }
    }
  }
</script>

<style lang="less">
  @import "settlement";
</style>
