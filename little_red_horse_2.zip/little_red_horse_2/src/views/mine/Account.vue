<template>
  <div class="account">
    <div class="mine-header">
      <Breadcrumb>
        <BreadcrumbItem to="/mine/personalcenter">个人中心</BreadcrumbItem>
        <BreadcrumbItem>资金账户</BreadcrumbItem>
      </Breadcrumb>
    </div>
    <div class="account-wrap">
      <p class="account-text">可用余额：
        <span>¥</span>
        <span>{{availableBalance}}</span>
      </p>
      <p class="account-text">账户余额：
        <span>¥</span>
        <span>{{balance}}</span>
      </p>
      <Button type="error" :disabled="loading" @click="recharge">充值</Button>
    </div>
    <div class="account-type" v-loading="loading">
      <Tabs :value="tabName" type="card" @on-click="tabChange">
        <TabPane label="全部" name="all">
          <div class="pane-all">
            <Table size="small" border :height="tableHeight" :columns="columns" :data="allList"></Table>
          </div>
        </TabPane>
        <TabPane label="收入" name="income">
          <div class="pane-income">
            <Table size="small" border :height="tableHeight" :columns="columns" :data="incomeList"></Table>
          </div>
        </TabPane>
        <TabPane label="支出" name="pay">
          <div class="pane-pay">
            <Table size="small" border :height="tableHeight" :columns="columns" :data="payList"></Table>
          </div>
        </TabPane>
      </Tabs>

      <div class="account-type-selector">
        <DatePicker type="daterange" show-week-numbers placement="bottom-end"
                    v-model="date"
                    :clearable="false"
                    :editable="false"
                    split-panels
                    format="yyyy-MM-dd"
                    @on-change="dateChange"
                    class="selector-date"></DatePicker>
        <Button type="error" :disabled="loading" @click="search">搜索</Button>
      </div>

    </div>

  </div>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'
  import * as opt from './options'
  // import ProductPage from '../../common/Product-Page'

  export default {
    name: 'Account',
    components: {
      // ProductPage
    },
    data() {
      return {
        tabName: 'all',
        begDate: '',
        endData: '',
        availableBalance: '',
        balance: '',

        allList: [],
        allData: {},
        incomeList: [],
        incomeData: {},
        payList: [],
        payData: {},
        date: [],
        tableHeight: '',
        columns: opt.AccountHeader,

        pageIndex: 1,
        pageSize: 999999
      }
    },
    computed: {
      ...mapState([
        'loading'
      ]),
      ...mapGetters([])
    },
    created() {
      this.initData()
    },
    methods: {
      ...mapActions([]),
      initData() {
        this.tableHeight = 500
        this.begDate = this.$moment().subtract(3, 'months').format('YYYY-MM-DD')
        this.endDate = this.$moment().format('YYYY-MM-DD')
        this.date = [this.begDate, this.endDate]
        this.getBalanceData()
      },
      // 获取充值记录
      async getBalanceData() {
        let self = this
        let params = {
          begDate: self.begDate + ' 00:00:00',
          endDate: self.endDate + ' 23:59:59',
          pageIndex: self.pageIndex,
          pageSize: self.pageSize
        }
        let {data} = await api.getBalance(params)
        self.balance = data.data.balance
        self.availableBalance = data.data.availableBalance
        let obj = data.data.detailInfo
        let arr = data.data.detailInfo.list
        self.allData = obj
        self.allList = arr
        self.incomeList = arr.filter(item => item.direction == 1)
        self.payList = arr.filter(item => item.direction == 2)
      },
      handlePageChange(v) {
        window.scrollTo(0, 200)
        this.pageIndex = v.pageIndex
        this.getData()
      },
      handlePageSizeChange(v) {
        window.scrollTo(0, 200)
        this.pageSize = v.pageSize
        this.getData()
      },
      // 时间切换时候
      dateChange(v) {
        console.log(v)
        this.begDate = v[0]
        this.endDate = v[1]
      },
      // 搜索
      search() {
        this.getBalanceData()
      },
      tabChange(v) {
        console.log(v)
      },
      // 充值
      recharge() {
        this.$router.replace({path: '/mine/recharge'})
      }
    }
  }
</script>

<style lang="less">
  .account {
    width: 100%;
    padding: 10px;
    border: 1px solid #e5e5e5;
    background-color: #ffffff;

    .mine-header {
      height: 35px;
      line-height: 35px;
      margin-left: 10px;
    }

    .account-wrap {
      margin-left: 30px;
      margin-top: 20px;

      .account-text {
        display: inline-block;
        height: 35px;
        line-height: 35px;
        width: 220px;
        font-size: 14px;
        font-weight: 600;

        span {
          color: red;
        }
      }
    }

    .account-type {
      margin-top: 40px;
      position: relative;

      &-selector {
        position: absolute;
        top: 0;
        right: 3px;

        .selector-date {
          width: 220px;
          padding: 0 10px;
        }
      }

      .pane-all {
      }
    }
  }
</style>
