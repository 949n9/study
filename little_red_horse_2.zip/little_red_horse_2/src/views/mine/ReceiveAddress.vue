<template>
  <div class="address">
    <div class="mine-header">
      <Breadcrumb>
        <BreadcrumbItem to="/mine/personalcenter">个人中心</BreadcrumbItem>
        <BreadcrumbItem>收货地址</BreadcrumbItem>
      </Breadcrumb>
    </div>
    <div class="address-add" v-if="userData.admin==1">
      <Button :disabled="loading" @click="addUnit" class="red--text" type="default">
        <Icon type="md-add-circle"/>
        新增收货地址
      </Button>
      <span class="address-add-tip"
            v-show="getAddressList.length>15">温馨提示：您已创建{{getAddressList.length}}个收货地址，最多可创建20个</span>
    </div>

    <div class="address-table">
      <div class="pane-all">
        <Table :columns="columns" :data="getAddressList" :height="tableHeight" :loading="loading" border size="small">
          <template slot="fullAddress" slot-scope="{ row }">
            <p>
              <Badge text="默认" type="warning" v-if="row.isDefault==1"></Badge>
              {{row.fullAddress}}
            </p>
          </template>
          <template slot="action" slot-scope="{ row }">
            <Button @click="editAddress(row)" size="small" type="text" v-if="userData.admin==1">编辑</Button>
            <Button @click="deleteAddress(row)" size="small" type="text"
                    v-show="getAddressList.length>1 && row.isDefault==0 && userData.admin==1">删除
            </Button>
            <Button @click="editDefault(row)" size="small" style="margin-left: 20px;" type="text"
                    v-show="row.isDefault==0 && userData.admin==1">设为默认地址
            </Button>
          </template>
        </Table>
      </div>
    </div>
  </div>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'
  import * as opt from './options'

  export default {
    name: 'ReceiveAddress',
    components: {},
    data() {
      return {
        subCustomerId: '',
        tableHeight: '',
        columns: opt.addressHeader
      }
    },
    computed: {
      ...mapState([
        'loading',
        'addAddressVisible',
        'addressEdit'
      ]),
      ...mapGetters([
        'userData',
        'getAddressList'
      ])
    },
    watch: {
      'addressEdit': 'handleAddress'
    },
    created() {
      this.subCustomerId = this.userData.subCustomerId
      this.handleBaseDialog({visible: false, type: 'addAddressVisible'})
      this.initData()
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'handleBasicInfo',
        'getReceiverAddress'
      ]),
      handleAddress(v) {
        console.log(v)

        let path = v.split('?')[0]
        if (path == 'delivery') {
          this.initData()
        }
      },
      initData() {
        this.tableHeight = 500
        this.getReceiverAddress(this.subCustomerId)
      },
      // 增加收货地址单位
      addUnit() {
        this.handleBasicInfo({subCustomerId: this.subCustomerId, from: 'delivery'})
        this.handleBaseDialog({visible: true, type: 'addAddressVisible', title: '新增'})
      },
      // 编辑收货地址
      editAddress(row) {
        console.log(row)
        row.from = 'delivery'
        this.handleBasicInfo(row)
        this.handleBaseDialog({visible: true, type: 'addAddressVisible', title: '编辑'})
      },
      // 删除收货 地址
      deleteAddress(row) {
        this.$Modal.confirm({
          title: '温馨提示',
          content: '<p>您确定要删除该收货地址吗？</p>',
          onOk: () => {
            this.handleDelete(row)
          },
          onCancel: () => {
          }
        })
      },
      async handleDelete(row) {
        let self = this
        let params = {
          id: row.id
        }
        let {data} = await api.getDeleteReceiveAddress(params)
        if (data.status == 0) {
          self.initData()
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 设为默认
      async editDefault(row) {
        let self = this
        console.log(row)
        // let params = Object.assign(row, {isDefault: 1})
        row.isDefault = 1
        let {data} = await api.getUpdateReceiveAddress(row)
        console.log(data)
        if (data.status == 0) {
          self.initData()
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      }
    }
  }
</script>

<style lang="less">
  .address {
    width: 100%;
    padding: 10px;
    border: 1px solid #e5e5e5;
    background-color: #ffffff;

    .mine-header {
      height: 35px;
      line-height: 35px;
      margin-left: 10px;
    }

    .address-add {
      padding: 20px 0;
      display: flex;
      align-items: flex-end;

      &-tip {
        margin-left: 20px;
        color: #999999;
      }
    }

    .address-table {
      margin-top: 40px;
      position: relative;

      .pane-all {
      }

      .table-address {
        width: 100%;
        text-align: center;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
    }
  }
</style>
