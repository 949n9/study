<template>
  <div class="order-unit">
    <div class="mine-header">
      <Breadcrumb>
        <BreadcrumbItem to="/mine/personalcenter">个人中心</BreadcrumbItem>
        <BreadcrumbItem>本单位人员管理</BreadcrumbItem>
      </Breadcrumb>
    </div>
    <div class="order-unit-add">
      <Button type="default" class="red--text" :disabled="loading" @click="addUnit">
        <Icon type="md-add-circle"/>
        新增本单位人员
      </Button>
    </div>
    <div class="order-unit-table">
      <Tabs :value="tabName" type="card" @on-click="tabNameClick">
        <TabPane label="全部" name="all">
          <div class="pane-all">
            <Table size="small" border :height="tableHeight" :columns="columns" :data="allList">
              <template slot-scope="{ row }" slot="status">
                <span>{{row.useStatus == '0' ? '在用' : '停用'}}</span>
              </template>
              <template slot-scope="{ row }" slot="action">
                <Button v-if="userData.admin==1 " type="text" size="small" @click="edit(row)">编辑</Button>
              </template>
            </Table>
          </div>
        </TabPane>
        <TabPane label="在用" name="using">
          <div class="pane-all">
            <Table size="small" border :height="tableHeight" :columns="columns" :data="usingList">
              <template slot-scope="{ row }" slot="status">
                <span v-if="row.useStatus=='0'">在用</span>
                <span v-else>停用</span>
              </template>
              <template slot-scope="{ row }" slot="action">
                <Button v-if="userData.admin==1 " type="text" size="small" @click="edit(row)">编辑</Button>
              </template>
            </Table>
          </div>
        </TabPane>
        <TabPane label="停用" name="unusing">
          <div class="pane-all">
            <Table size="small" border :height="tableHeight" :columns="columns" :data="unusingList">
              <template slot-scope="{ row }" slot="status">
                <span v-if="row.useStatus=='0'">在用</span>
                <span v-else>停用</span>
              </template>
              <template slot-scope="{ row }" slot="action">
                <Button v-if="userData.admin==1 " type="text" size="small" @click="edit(row)">编辑</Button>
              </template>
            </Table>
          </div>
        </TabPane>
      </Tabs>
      <div class="order-unit-table-search">
        <form action="javascript:void(0)">
          <Input class="header-ipt" :maxlength="10" @on-enter="searchUnit" v-model.trim="searchCondition" clearable placeholder="本单位人员姓名/手机号"/>
        </form>
        <Button type="error" :disabled="loading" @click="searchUnit" class="order-unit-table-search-btn">搜索</Button>
      </div>
    </div>
    <customer-dialog @editUser="editUser"></customer-dialog>
  </div>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'
  import * as opt from './options'
  import CustomerDialog from './components/AddCustomerDialog'

  export default {
    name: 'UnitManage',
    components: {
      CustomerDialog
    },
    data() {
      return {
        name: '',
        tabName: 'all',
        allList: [],
        usingList: [],
        unusingList: [],
        tableHeight: '',
        columns: opt.unitHeader,
        searchCondition: ''
      }
    },
    computed: {
      ...mapState([
        'addCustomerVisible',
        'loading'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    created() {
      this.handleBaseDialog({visible: false, type: 'addCustomerVisible'})
      this.initData()
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'handleBasicInfo'
      ]),
      initData() {
        this.tableHeight = 500
        this.getListData()
      },
      // 弹窗中 进行编辑触发
      editUser(v) {
        console.log(v)
        this.getListData()
      },
      // 增加本单位人员
      addUnit() {
        this.handleBaseDialog({visible: true, type: 'addCustomerVisible', title: '新增'})
      },
      tabNameClick(v) {
        console.log(v)
        this.tabName = v
      },
      searchUnit() {
        this.tabName = 'all'
        console.log(this.tabName)
        this.getListData()
      },
      // 获取 列表数据
      async getListData() {
        let self = this
        let params = {
          searchCondition: self.searchCondition,
          pageSize: 99999
        }
        let {data} = await api.getUserList(params)
          console.log(data)
        if (data.status == 0) {
          let arr = data.data.list
          arr.forEach(item => {
            item.dataAuthType = item.dataAuthType == 0 ? '全部' : '指定订货单位'
          })
          self.allList = arr
          self.usingList = arr.filter(item => item.useStatus == 0)
          self.unusingList = arr.filter(item => item.useStatus == 1)
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 编辑
      edit(row) {
        this.handleBasicInfo(row)
        this.handleBaseDialog({visible: true, type: 'addCustomerVisible', title: '编辑'})
      }
    }
  }
</script>

<style lang="less">
  .order-unit {
    width: 100%;
    padding: 10px;
    border: 1px solid #e5e5e5;
    background-color: #ffffff;

    .mine-header {
      height: 35px;
      line-height: 35px;
      margin-left: 10px;
    }

    .order-unit-add {
      padding: 20px 0;
      display: flex;
      justify-content: space-between;

      .ipt {
        width: 350px;
      }
    }

    .order-unit-table {
      margin-top: 40px;
      position: relative;

      &-selector {
        position: absolute;
        top: 0;
        right: 3px;

        .selector-date {
          width: 200px;
          padding: 0 10px;
        }
      }
      &-search{
        display: flex;
        position: absolute;
        top: -10px;
        right: 0;
        &-btn{
          margin-left: 10px;
        }
      }

      .pane-all {
      }
    }
  }
</style>
