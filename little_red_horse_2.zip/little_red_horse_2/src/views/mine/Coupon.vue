<template>
  <div class="coupon">
    <div class="mine-header">
      <Breadcrumb>
        <BreadcrumbItem to="/mine/personalcenter">个人中心</BreadcrumbItem>
        <BreadcrumbItem>优惠券</BreadcrumbItem>
      </Breadcrumb>
    </div>
    <div class="coupon-type">
      <Tabs :value="tabName" type="card" @on-click="tabNameChange">
        <TabPane label="可领取" name="availableGetList">
          <div class="pane-com" v-if="availableGetList.length>0">
            <!-- <Table size="small" :height="tableHeight" :columns="columns" :data="incomeList"></Table> -->
            <div class="pane-item pane-item-unused" v-for="(item, index) in availableGetList" :key="index" @click="openDetail(item)">
               <div class="pane-item-dot" v-if="item.receive">
                 <img src="@/assets/images/coupon/coupon_available.png" alt="" srcset="">
               </div>
               <div class="pane-item-top">
                   <p class="price"><span>￥</span>{{item.value}}</p>
                   <p class="type">{{item.categoryName}}</p>
                   <p class="data">{{item.begDate}}至{{item.endDate}}</p>
               </div>
               <div class="pane-item-bottom">
                  <p class="code">名称：{{item.useNote}}</p>
                  <p class="des">使用说明：{{item.description.length>22?item.description.substr(0, 22)+'...':item.description.substr(0, 22)}}
                      <Poptip trigger="hover" word-wrap width="300" padding="8px 0" v-if="item.description.length>22">
                        <span>查看</span>
                        <div slot="content">
                           <p class="item-title">使用说明</p>
                           <div class="item-des">{{item.description}}</div>
                        </div>
                      </Poptip>
                  </p>
               </div>
               <div class="pane-item-button" v-if="item.receive" @click.stop="goAvailableProduct(item)">查看适用商品</div>
               <div class="pane-item-button" v-else @click.stop="getCoupon(item)">立即领取</div>
            </div>
          </div>
          <div v-else class="no-coupon">无可领取的优惠劵</div>
        </TabPane>
        <TabPane :label="`未使用（${couponNum}）`" name="unUsed">
          <div class="pane-com" v-if="unUsedList.length>0">
            <!-- <Table size="small" :height="tableHeight" :columns="columns" :data="incomeList"></Table> -->
            <div class="pane-item pane-item-unused" v-for="(item, index) in unUsedList" :key="index" @click="openDetail(item)">
               <div class="pane-item-num">{{item.num}}张</div>
               <div class="pane-item-top">
                   <p class="price"><span>￥</span>{{item.value}}</p>
                   <p class="type">{{item.categoryName}}</p>
                   <p class="data">{{item.begDate}}至{{item.endDate}}</p>
               </div>
               <div class="pane-item-bottom">
                  <p class="code">名称：{{item.useNote}}</p>
                  <p class="des">使用说明：{{item.description.length>22?item.description.substr(0, 22)+'...':item.description.substr(0, 22)}}
                      <Poptip trigger="hover" word-wrap width="300" padding="8px 0" v-if="item.description.length>22">
                        <span>查看</span>
                        <div slot="content">
                           <p class="item-title">使用说明</p>
                           <div class="item-des">{{item.description}}</div>
                        </div>
                      </Poptip>
                  </p>
               </div>
               <div class="pane-item-button" v-if="true" @click.stop="goAvailableProduct(item)">查看适用商品</div>
            </div>
          </div>
          <div v-else class="no-coupon">无未使用的优惠劵</div>
        </TabPane>
        <TabPane label="已使用" name="used">
          <div class="pane-com" v-if="usedList.length>0">
            <!-- <Table size="small" :height="tableHeight" :columns="columns" :data="payList"></Table> -->
            <div class="pane-item pane-item-used" v-for="(item, index) in usedList" :key="index" @click="openDetail(item)">
               <div class="pane-item-top">
                   <p class="price"><span>￥</span>{{item.value}}</p>
                   <p class="type">{{item.categoryName}}</p>
                   <p class="data">{{item.begDate}}至{{item.endDate}}</p>
               </div>
               <div class="pane-item-bottom">
                  <p class="code">名称：{{item.useNote}}</p>
                  <p class="des">使用说明：{{item.description.length>22?item.description.substr(0, 22)+'...':item.description.substr(0, 22)}}
                      <Poptip trigger="hover" word-wrap width="300" padding="8px 0" v-if="item.description.length>22">
                        <!-- <span>查看</span> -->
                        <div slot="content">
                           <p class="item-title">使用说明</p>
                           <div class="item-des">{{item.description}}</div>
                        </div>
                      </Poptip>
                  </p>
               </div>
               <img class="dot" src="../../assets/images/coupon/coupon_used_dot.png" alt="" srcset="">
            </div>
          </div>
          <div v-else class="no-coupon">无已经使用过的优惠劵</div>
        </TabPane>
        <TabPane label="已过期" name="expired">
          <div class="pane-com" v-if="expiredList.length>0">
            <!-- <Table size="small" :height="tableHeight" :columns="columns" :data="payList"></Table> -->
            <div class="pane-item pane-item-expired" v-for="(item, index) in expiredList" :key="index" @click="openDetail(item)">
               <div class="pane-item-top">
                   <p class="price"><span>￥</span>{{item.value}}</p>
                   <p class="type">{{item.categoryName}}</p>
                   <p class="data">{{item.begDate}}至{{item.endDate}}</p>
               </div>
               <div class="pane-item-bottom">
                  <p class="code">名称：{{item.useNote}}</p>
                  <p class="des">使用说明：{{item.description.length>22?item.description.substr(0, 22)+'...':item.description.substr(0, 22)}}
                      <Poptip trigger="hover" word-wrap width="300" padding="8px 0" v-if="item.description.length>22">
                        <!-- <span>查看</span> -->
                        <div slot="content">
                           <p class="item-title">使用说明</p>
                           <div class="item-des">{{item.description}}</div>
                        </div>
                      </Poptip>
                  </p>
               </div>
               <img class="dot" src="../../assets/images/coupon/coupon_overdue_dot.png" alt="" srcset="">
            </div>
          </div>
          <div v-else class="no-coupon">无已经过期的优惠劵</div>
        </TabPane>
      </Tabs>
    </div>
    <Modal
      v-model="couponDetailsVisible"
      title="优惠券详情"
      :mask-closable="false"
      :footer-hide="true"
      scrollable
      @on-visible-change="change">
      <ul class="coupon_wrap">
          <li class="coupon_wrap_item"><em>优惠劵编号：</em><span>{{couponDetail.code}}</span></li>
          <li class="coupon_wrap_item"><em>优惠券种类：</em><span>{{couponDetail.categoryName}}</span></li>
          <li class="coupon_wrap_item"><em>面值：</em><span>{{couponDetail.value}}</span></li>
          <li class="coupon_wrap_item"><em>有效期：</em><span>{{`${couponDetail.begDate} 到 ${couponDetail.endDate}`}}</span></li>
          <li class="coupon_wrap_item"><em>使用要求：</em><span>{{couponDetail.useNote}}</span></li>
          <li class="coupon_wrap_item"><em>使用状态：</em><span>{{couponDetail.statusText}}</span></li>
          <li class="coupon_wrap_item"><em>优惠券摘要：</em><span>{{couponDetail.description}}</span></li>
      </ul>
    </Modal>
  </div>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import * as opt from './options'
  import api from '../../core/index'

  export default {
    name: 'Coupon',
    data() {
      return {
        tabName: 'availableGetList',
        allList: [],
        availableGetList: [],
        unUsedList: [],
        usedList: [],
        expiredList: [],
        tableHeight: '',
        columns: opt.CouponHeader,
        couponDetailsVisible: false,
        couponNum: 0
      }
    },
    computed: {
      ...mapState([
        'couponDetail',
        'handleSuccess'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    created() {
      this.initData()
    },
    watch: {
      'handleSuccess': 'orderStatusChange'
    },
    methods: {
      ...mapActions([
        'saveCouponDetail'
      ]),
      initData() {
        this.getCouponData(3)
        this.getCouponNum()
      },
      orderStatusChange() {
        this.getCouponData()
      },
      openDetail(item) {
        if (item.status == 0) item.statusText = '未使用'
        if (item.status == 1) item.statusText = '已使用'
        if (item.status == 2) item.statusText = '已过期'
        if (item.status == 3) item.statusText = '可领取'
        this.saveCouponDetail(item)
        // this.couponDetailsVisible = true
      },
      tabNameChange(v) {
        console.log(v)
        this.tabName = v
        if (v == 'availableGetList') this.getCouponData(3)
        if (v == 'unUsed') this.getCouponData(0)
        if (v == 'used') this.getCouponData(1)
        if (v == 'expired') this.getCouponData(2)
      },
      goAvailableProduct(item) {
        console.log(this.tabName)
        this.$router.push({name: 'couponproduct', query: {conponId: item.productGroupId}})
      },
      // 领取优惠券
      async getCoupon(item) {
        let {data} = await api.getCoupon({
          couponId: item.id
        })
        console.log(data)
        if (data.status == 0) {
          item.receive = true
        }
      },
      async getCouponNum(item) {
        let {data} = await api.getCouponNum()
        console.log(data)
        if (data.status == 0) {
          this.couponNum = data.data.couponTotalCount
        }
      },
      // 获取优惠券列表
      async getCouponData(status) {
        let {data} = await api.getCouponList({
          useStatus: status
        })
        console.log(data)
        if (data.status == 0) {
          data.data.list.forEach(e => {
            console.log(e)
            e.value = parseFloat(e.value).toFixed(2)
            e.receive = false
          })
          if (status == 3) this.availableGetList = data.data.list
          if (status == 0) this.unUsedList = data.data.list
          if (status == 1) this.usedList = data.data.list
          if (status == 2) this.expiredList = data.data.list
          // this.unUsedList = data.data.list.filter(e => { return e.status == 0 })
          // this.usedList = data.data.list.filter(e => { return e.status == 1 })
          // this.expiredList = data.data.list.filter(e => { return e.status == 2 })
        }
      }
    }
  }
</script>

<style lang="less">
  .coupon {
    width: 100%;
    padding: 10px;
    height: 800px;
    border: 1px solid #e5e5e5;
    background-color: #ffffff;
    .mine-header {
      height: 35px;
      line-height: 35px;
      margin-left: 10px;
    }
    .coupon-type {
      margin-top: 40px;
      position: relative;
      padding:0 15px;
      &-selector {
        position: absolute;
        top: 0;
        right: 3px;
        .selector-date {
          width: 200px;
          padding: 0 10px;
        }
      }
      .pane-all {
      }
      .pane-com {
        height: 600px;
        overflow-y: auto;
        position: relative;
      }
      .no-coupon{
        text-align: center;
        margin-top: 50px;
      }
    }
  }
  .coupon_wrap_item{
      font-size: 14px;
      color: #030303;
      padding:2px 0;
      display: flex;
      em{
          margin-right: 10px;
          color: #666;
          width: calc(100% - 400px);
      }
      span{
        width: 400px;
      }
  }
  .pane-item {
    width:calc((100% - 60px) / 4);
    height: 294px;
    background-size: 100% 100%;
    float: left;
    margin-right: 20px;
    margin-bottom: 20px;
    position: relative;
    cursor: pointer;
    &.pane-item-unused{
      background: url('../../assets/images/coupon/coupon_unused_bg.png') no-repeat;
    }
    &.pane-item-used{
      background: url('../../assets/images/coupon/coupon_other.png') no-repeat;
    }
    &.pane-item-expired{
      background: url('../../assets/images/coupon/coupon_other.png') no-repeat;
    }
    &:nth-child(4n){
      margin-right: 0px;
    }
    .dot{
      position: absolute;
      bottom: 10px;
      right: 10px;
    }
    .pane-item-top{
      color: #ffffff;
      text-align: center;
      padding: 30px 0;
      p{
        &.price{
           font-size: 30px;
           font-weight: bold;
           span{
              font-size: 20px;
              font-weight: 600;
           }
        }
        &.type{
          font-size: 18px;
          margin: 5px 0 5px;
          font-weight: 200;
        }
        &.data{
          font-size: 12px;
          font-weight: 200;
        }
      }
    }
    .pane-item-bottom{
       font-size: 12px;
       padding:20px 15px 0;
       color: #666;
       p{
         &.code{
           margin-bottom: 8px;
         }
         &.des{
          //  display: flex;
           height: 40px;
          //  em{
          //    display: block;
          //    width: 70px;
          //  }
           span{
             color: #E61E10;
           }
         }
       }
    }
    .pane-item-button{
       color: #E61E10;
       padding: 3px 12px;
       margin: 5px auto 0;
       width: 60%;
       text-align: center;
       border: 1px solid #E61E10;
       border-radius: 30px;
    }
    .pane-item-button1{
       color: #E61E10;
       padding: 3px 12px;
       margin: 5px auto 0;
       width: 60%;
       text-align: center;
       border: 1px solid #E61E10;
       border-radius: 30px;
    }
    .pane-item-dot{
       position: absolute;
       right:0;
       z-index: 100;
       img{
         width: 100px;
         height: 70px;
       }
    }
    .pane-item-num{
      position: absolute;
      top: 10px;
      right: 10px;
      width: 32px;
      height: 32px;
      text-align: center;
      line-height: 32px;
      background: #ffffff;
      font-size: 13px;
      border-radius: 32px;
    }
    .item-title{
      border-bottom:1px solid #dddddd;
      padding: 0px 16px 5px;
      color: #000;
      font-size: 14px;
    }
    .item-des{
      padding:8px 16px 0;
    }
  }
</style>
