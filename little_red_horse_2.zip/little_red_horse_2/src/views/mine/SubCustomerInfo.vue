<template>
  <div class="subcustomer-info">
    <div class="mine-header">
      <Breadcrumb>
        <BreadcrumbItem to="/mine/personalcenter">个人中心</BreadcrumbItem>
        <BreadcrumbItem>本店信息</BreadcrumbItem>
      </Breadcrumb>
    </div>

    <div class="subcustomer-info-form">
      <Form :label-width="110" :model="formItem" label-position="right"
            ref="formValidate">
        <FormItem class="form-item" label="门店名称：">
          <p>{{formItem.subCustomerName}}</p>
        </FormItem>
        <FormItem class="form-item" label="联系人：">
          <div class="item" v-if="showName">
            <Input :maxlength="10" @on-blur="handleBlur" class="ipt" clearable placeholder="" ref="name"
                   v-model="customerName">
            </Input>
            <Button @click="saveCustomer('name')" type="text">
              保存
            </Button>
            <Button @click="handleCancel('name')" type="text">
              取消
            </Button>
          </div>
          <div class="item" v-else>
            <p class="item-text">{{formItem.subCustomerContactName}}</p>
            <Button @click="editCustomer('name')" type="text" v-show="!showPhone && userData.admin==1">
              <Icon size="14" type="md-create"/>
              修改
            </Button>
          </div>
        </FormItem>
        <FormItem class="form-item" label="手机：">
          <div class="item" v-if="showPhone">
            <Input :maxlength="11" @on-blur="handleBlur" class="ipt" clearable placeholder="请输入手机号码" ref="phone"
                   v-model="customerPhone"></Input>
            <Button @click="saveCustomer('phone')" type="text">
              保存
            </Button>
            <Button @click="handleCancel('phone')" type="text">
              取消
            </Button>
          </div>
          <div class="item" v-else>
            <p class="item-text">{{formItem.subCustomerMobilePhone}}</p>
            <Button @click="editCustomer('phone')" type="text" v-show="!showName && userData.admin==1">
              <Icon size="14" type="md-create"/>
              修改
            </Button>
          </div>
        </FormItem>

        <FormItem class="form-item" label="门店地址：">
          <p>{{formItem.subCustomerAddress}}</p>
        </FormItem>

        <FormItem class="form-item" label="服务商业务员：">
          <p>{{formItem.subCustomerProviderUserName}}</p>
        </FormItem>

        <FormItem class="form-item" label="营业执照：">
          <div style="display: flex">
            <div class="add-up-load-img" v-if="formItem.licenseImgUrl">
              <img :onerror="defaultPimg()" :src="formItem.licenseImgUrl" @click="openImgModal(formItem.licenseImgUrl)"
                   alt=""
                   class="img">
            </div>
          </div>
        </FormItem>
        <FormItem class="form-item" label="门头照：">
          <div style="display: flex">
            <div class="add-up-load-img" v-if="formItem.doorHeadImgUrl">
              <img :onerror="defaultPimg()" :src="formItem.doorHeadImgUrl"
                   @click="openImgModal(formItem.doorHeadImgUrl)" alt=""
                   class="img">
            </div>
          </div>
        </FormItem>
        <FormItem class="form-item" label="店内照：">
          <div style="display: flex">
            <div class="add-up-load-img" v-if="formItem.storeInternalImgUrl">
              <img :onerror="defaultPimg()" :src="formItem.storeInternalImgUrl"
                   @click="openImgModal(formItem.storeInternalImgUrl)" alt=""
                   class="img">
            </div>
          </div>
        </FormItem>
      </Form>
    </div>
    <Modal footer-hide title=" " v-model="imgModal">
      <img :onerror="defaultPimg()" :src="bigImg" style="width: 100%">
    </Modal>
  </div>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'
  // import * as opt from './options'
  // import validator from '../../utils/validator'

  export default {
    name: 'SubCustomerInfo',
    components: {},
    data() {
      return {
        formItem: {},
        customerName: '',
        customerPhone: '',
        imgModal: false,
        bigImg: '',
        showName: false,
        showPhone: false
      }
    },
    computed: {
      ...mapState([
        'loading'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    created() {
      this.initData()
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'handleBasicInfo'
      ]),
      initData() {
        this.getSubDetailInfo()
      },
      // 获取 订货单位详情
      async getSubDetailInfo() {
        let self = this
        let params = {
          id: self.userData.subCustomerId,
          status: 1
        }
        let {data} = await api.getSubDetail(params)
        console.log(data)
        if (data.status == 0) {
          self.formItem = data.data
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      editCustomer(type) {
        this.showName = type == 'name'
        this.showPhone = type == 'phone'
        this.$nextTick(() => {
          this.$refs[type].focus()
        })
        this.customerName = this.formItem.subCustomerContactName
        this.customerPhone = this.formItem.subCustomerMobilePhone
      },
      // 点击取消
      handleCancel() {
        this.showName = false
        this.showPhone = false
      },
      handleBlur() {
      },
      // 保存
      saveCustomer(type) {
        this.handleUpdate()
      },
      async handleUpdate() {
        let self = this
        let params = {
          id: self.userData.subCustomerId,
          subCustomerContactName: self.customerName,
          subCustomerMobilePhone: self.customerPhone
        }
        let {data} = await api.getUpdateSubInfo(params)
        if (data.status == 0) {
          this.showName = false
          this.showPhone = false
          self.$Notice.success({
            desc: data.message
          })
          this.getSubDetailInfo()
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 看大图showPhone
      openImgModal(url) {
        this.imgModal = true
        this.bigImg = url
      }
    }
  }
</script>

<style lang="less">
  .subcustomer-info {
    width: 100%;
    padding: 10px;
    border: 1px solid #e5e5e5;
    background-color: #ffffff;

    .mine-header {
      height: 35px;
      line-height: 35px;
      margin-left: 10px;
    }

    .subcustomer-info-form {
      margin-top: 20px;
      padding-left: 100px;
      position: relative;

      .form-item {
        margin-bottom: 5px;
      }

      .ipt-no-outline {
        border: none;
      }

      .item {
        display: flex;

        .item-text {
          width: 80px;
        }
      }

      .ipt {
        width: 200px;
      }

      .add-up-load-img {
        text-align: center;
        position: relative;
        height: 80px;
        width: 80px;

        .img {
          border: 1px solid #cccccc;
          height: 80px;
          width: 80px;
          padding: 2px;
          cursor: pointer;
        }
      }
    }
  }
</style>
