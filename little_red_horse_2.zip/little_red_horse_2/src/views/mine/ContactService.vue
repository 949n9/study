<template>
  <div class="contact-service">
  </div>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'

  export default {
    name: 'ContactService',
    data() {
      return {}
    },

    created() {
      this.initData()
    },
    computed: {
      ...mapState([]),
      ...mapGetters([
        'userData'
      ])
    },
    methods: {
      ...mapActions([]),
      initData() {
        this.easemobim = window.easemobim || {}
        this.easemobim.config = {
          hide: true,
          autoConnect: true
        }
        let pany = document.querySelector('.easemobim-chat-panel')
        if (pany) {
          pany.style.display = 'block'
        }
        this.easemobim.bind({
          configId: 'c16fad54-5784-4a5d-b929-b4a53c5b86ff',
          // agentName: '1439281489@qq.com',
          visitor: {
            trueName: this.userData.imName,
            qq: '',
            phone: this.userData.imMobilePhone,
            companyName: this.userData.imCompany,
            userNickname: this.userData.imNickName,
            description: '',
            email: this.userData.imEmail
          }
        })
      }
    }
  }
</script>

<style lang="less">
  .contact-service {
    width: 100%;
    height: 500px;
    border: 1px solid #e5e5e5;
    background-color: #ffffff;
  }
</style>
