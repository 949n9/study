<template>
  <div class="recharge-list">
    <div class="mine-header">
      <Breadcrumb>
        <BreadcrumbItem to="/mine/recharge">充值</BreadcrumbItem>
        <BreadcrumbItem>充值记录</BreadcrumbItem>
      </Breadcrumb>
    </div>

    <div class="m-header account-header">
      <!--<div class="item">-->
      <!--<span>充值方式：</span>-->
      <!--<Select v-model="payType" style="width:200px" placeholder="" clearable>-->
      <!--<Option v-for="item in payTypeList" :value="item.value" :key="item.value">{{ item.label }}</Option>-->
      <!--</Select>-->
      <!--</div>-->
      <div class="item">
        <span>提交人：</span>
        <form action="javascript:void(0)">
          <Input class="header-ipt" :maxlength="10" v-model.trim="createEmpName" clearable/>
        </form>
      </div>
      <div class="item">
        <span>提交日期：</span>
        <DatePicker type="daterange" placement="bottom-end"
                    :editable="false"
                    split-panels
                    v-model="date"
                    format="yyyy-MM-dd"
                    @on-change="dateChange"
                    style="width: 200px"
                    class="selector-date"></DatePicker>
      </div>
      <div class="item">
        <Button type="error" :disabled="loading" @click="search">搜索</Button>
      </div>
      <div class="item">
        <Button type="default" :disabled="loading" @click="exportExcel">导出</Button>
      </div>
    </div>

    <div class="account-type" v-loading="loading">
      <Table size="small" border :height="tableHeight" :columns="columns" ref="table" :data="payList">
        <template slot-scope="{ row }" slot="action">
          <Button type="text" size="small" style="margin-right: 5px" @click="show(row)">查看</Button>
        </template>
      </Table>
      <product-page style="margin-top: 5px;" :pageInfo="payData" @pageChange="handlePageChange"
                    @pageSizeChange="handlePageSizeChange">
      </product-page>
    </div>

    <Modal
      v-model="detailWrap"
      class="m-modal"
      title="">
      <div class="modal-amount">
        <p>充值金额：<span class="amount">¥{{detailInfo.chargeAmount}}</span></p>
      </div>
      <div class="modal-wrap">
        <p>当前状态：<span>{{detailInfo.payStatusName}}</span></p>
        <p>支付方式：<span>{{detailInfo.payTypeName}}</span></p>
        <p>充值方式：<span>{{detailInfo.chargeTypeName}}</span></p>
        <div v-show="detailInfo.payType==3||detailInfo.payType==4" class="bank">
          <span>银&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;行：</span><img :src="detailInfo.bankLogo" alt="">
        </div>
        <p>提交时间：<span>{{detailInfo.createTime}}</span></p>
        <p>确认时间：<span>{{detailInfo.payTime}}</span></p>
        <p>提&nbsp;&nbsp;交&nbsp;人：<span>{{detailInfo.createUserName}}</span></p>
      </div>

      <div slot="footer" style="text-align: center">
        <Button type="error" style="width: 150px" :loading="loading" @click="closeModal">关闭</Button>
      </div>
    </Modal>

    <Modal
      v-model="underDetailWrapDone"
      class="m-modal"
      title="">
      <div class="modal-amount">
        <p>充值金额：<span class="amount">¥{{detailInfo.transferAmount}}</span></p>
      </div>
      <div class="modal-wrap">
        <h3>转账账户</h3>
        <p>开户名称：<span>{{detailInfo.toTransferName}}</span></p>
        <p>开户银行：<span>{{detailInfo.toBankName}}</span></p>
        <p>银行账号：<span>{{detailInfo.toBankNo}}</span></p>
        <p></p>
        <p><span class="red--text">*</span>转账姓名：<span>{{detailInfo.fromTransferName}}</span></p>
        <p><span class="red--text">*</span>转账银行卡：<span>{{detailInfo.fromBankNo}}</span></p>
        <p><span class="red--text">*</span>联系电话：<span>{{detailInfo.mobilePhone}}</span></p>
        <p><span class="red--text">*</span>转账凭证：</p>
        <img :src="detailInfo.transferVoucher" alt="" class="img" @click="openImg(detailInfo.transferVoucher)">
      </div>
      <div slot="footer" style="text-align: center">
        <Button type="error" style="width: 150px" :loading="loading" @click="closeModal">关闭</Button>
      </div>
    </Modal>

    <Modal
      v-model="underDetailWrap"
      class="m-modal"
      title="">
      <div class="modal-amount">
        <p>充值金额：
          <InputNumber class="recharge-list-input"
                       ref="modalIpt"
                       @on-focus="(a)=>qtyFocus(a,'modalIpt')"
                       :max="200000" :min="0" v-model="detailInfo.transferAmount"
                       :precision="2" :active-change="false"
                       @on-change="onChange"
                       placeholder="单笔金额不能超过200000元"></InputNumber>
        </p>
      </div>
      <div class="modal-wrap">
        <h3>转账账户</h3>
        <p>开户名称：<span>{{detailInfo.toTransferName}}</span></p>
        <p>开户银行：<span>{{detailInfo.toBankName}}</span></p>
        <p>银行账号：<span>{{detailInfo.toBankNo}}</span></p>
        <p></p>
        <div class="list-bank-content">
          <Form ref="bank" :model="detailInfo" :label-width="110">
            <FormItem label="转账姓名：" class="ivu-form-item-required" style="margin-bottom: 5px">
              <Input v-model="detailInfo.fromTransferName" :maxlength="10" class="ipt" clearable
                     placeholder="请输入付款人姓名！"></Input>
            </FormItem>
            <FormItem label="转账银行卡：" class="ivu-form-item-required" style="margin-bottom: 5px;position:relative;">
              <div class="bank-tip" v-show="showBankNo">
                <span class="tip-text">{{detailInfo.fromBankNo|cut4}}</span>
              </div>
              <Input v-model="detailInfo.fromBankNo" class="ipt" clearable
                     @on-change="handleChange"
                     @on-focus="handleFocus"
                     @on-blur="handleBlur"
                     :maxlength="24"
                     placeholder="请输入银行卡号！"></Input>
            </FormItem>
            <FormItem label="联系电话：" class="ivu-form-item-required" style="margin-bottom: 5px">
              <Input v-model="detailInfo.mobilePhone" :maxlength="11" class="ipt" clearable
                     @on-change="handlePhoneChange"
                     placeholder="请输入联系电话！"></Input>
            </FormItem>
            <FormItem label="转账凭证：" class="ivu-form-item-required">
              <div style="display: flex;justify-content: flex-start">
                <div class="list-bank-load-img" v-if="detailInfo.transferVoucher">
                  <img :src="detailInfo.transferVoucher" alt="" class="load-img"
                       @click="openImg(detailInfo.transferVoucher)">
                  <Icon type="md-close" color="white" class="list-remove" size="20" @click="removeImg"/>
                </div>
                <div class="list-up-load-wrap" v-else>
                  <input type="file" title="" @change="doUpload" class="ipt"
                         accept="image/gif,image/jpeg,image/jpg,image/png"/>
                  <Icon type="md-add" style="font-weight: 700" size="30"/>
                  <p>上传凭证</p>
                </div>
              </div>
            </FormItem>
          </Form>
        </div>
      </div>
      <div slot="footer" style="text-align: center">
        <Button type="error" style="width: 150px" :loading="loading" @click="handleSubmit">保存</Button>
      </div>
    </Modal>

    <Modal title="" v-model="imgModal" footer-hide>
      <img :src="bigImg" style="width: 100%">
    </Modal>
  </div>
</template>
<script>

  import {mapActions, mapGetters, mapState} from 'vuex'
  import api from '../../core/index'
  import * as opt from './options'
  import ProductPage from '../../common/Product-Page'

  export default {
    name: 'RechargeList',
    components: {
      ProductPage
    },
    data() {
      return {
        imgModal: false,
        bigImg: '',
        detailWrap: false,
        underDetailWrap: false,
        underDetailWrapDone: false,
        payTypeList: [
          {
            label: '微信',
            value: 1
          }, {
            label: '支付宝',
            value: 2
          }, {
            label: '转账',
            value: 3
          }
        ],
        payType: '',
        createEmpName: '',
        begDate: '',
        endData: '',

        payList: [],
        payData: {},
        date: [],
        tableHeight: '',
        columns: opt.RechargeHeader,
        detailInfo: {},
        showBankNo: false,

        pageIndex: 1,
        pageSize: 50
      }
    },
    computed: {
      ...mapState([
        'loading'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    created() {
      this.initData()
    },
    methods: {
      ...mapActions([]),
      initData() {
        this.tableHeight = 500
        this.begDate = this.$moment().subtract(3, 'months').format('YYYY-MM-DD')
        this.endDate = this.$moment().format('YYYY-MM-DD')
        this.date = [this.begDate, this.endDate]
        this.getData()
      },
      // 获取充值记录
      getData() {
        this.getListData().then(res => {
          console.log(res)
          this.payData = res
          this.payList = res.list
        })
      },
      getListData(size) {
        let self = this
        let params = {
          payType: self.payType,
          payStatus: '',
          pageIndex: self.pageIndex,
          pageSize: size ? 999999 : self.pageSize,
          createEmpName: self.createEmpName,
          begDate: self.begDate ? self.begDate + ' 00:00:00' : '',
          endDate: self.endDate ? self.endDate + ' 23:59:59' : ''
        }
        return new Promise((resolve, reject) => {
          api.getChargeList(params).then(res => {
            let data = res.data
            if (data.status == '0') {
              resolve(data.data)
            } else {
              self.$Notice.error({
                desc: data.message
              })
            }
          })
        })
      },
      handlePageChange(v) {
        window.scrollTo(0, 200)
        this.pageIndex = v.pageIndex
        this.getData()
      },
      handlePageSizeChange(v) {
        window.scrollTo(0, 200)
        this.pageSize = v.pageSize
        this.getData()
      },
      // 打开大图
      openImg(url) {
        this.imgModal = true
        this.bigImg = url
      },
      qtyFocus(e, id) {
        console.log(id)
        setTimeout(() => {
          // this.$refs[id].$el.querySelector('input').click()
          this.$refs[id].$el.querySelector('input').select()
        }, 10)
      },
      // 处理值为0的状态 清空0
      onChange(v) {
        if (v == 0) {
          setTimeout(() => {
            this.detailInfo.transferAmount = null
          }, 400)
        }
      },
      // 时间切换时候
      dateChange(v) {
        console.log(v)
        this.begDate = v[0]
        this.endDate = v[1]
      },
      // 查看详情 打开 弹窗
      show(row) {
        if (row.chargeType == 3) {
          // 1 未确认
          if (row.payStatus == 1) {
            this.underDetailWrap = true
          } else {
            this.underDetailWrapDone = true
          }
          this.getInDetail(row.id)
        } else {
          this.detailWrap = true
          this.getOnDetail(row.id)
        }
      },
      // 线上详情
      async getOnDetail(id) {
        let self = this
        let params = {
          chargeId: id
        }
        let {data} = await api.getOnlineDetail(params)
        if (data.status == '0') {
          self.detailInfo = data.data
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 线下详情
      async getInDetail(id) {
        let self = this
        let params = {
          id: id
        }
        let {data} = await api.getTransferDetail(params)
        if (data.status == '0') {
          self.detailInfo = data.data
          self.detailInfo.transferAmount = self.detailInfo.transferAmount * 1
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      closeModal() {
        this.detailWrap = false
        this.underDetailWrapDone = false
      },
      removeImg() {
        this.detailInfo.transferVoucher = ''
      },
      // 搜索
      search() {
        this.getData()
      },
      // 导出Excel
      exportExcel() {
        if (this.payList.length) {
          this.getListData(999999).then(res => {
            this.$refs.table.exportCsv({
              filename: '充值记录',
              columns: this.columns,
              data: res.list
            })
          })
        }
      },
      // 更新 银行转账信息
      handleSubmit() {
        if (this.detailInfo.transferAmount == '' || this.detailInfo.transferAmount == null) {
          this.$Notice.error({
            desc: '请输入充值金额'
          })
        } else {
          this.bankRecharge()
        }
      },
      // 公司转账
      async bankRecharge() {
        let self = this
        let bankNo = self.detailInfo.fromBankNo.replace(/\s+/g, '')
        let params = {
          id: self.detailInfo.id,
          transferAmount: self.detailInfo.transferAmount,
          fromTransferName: self.detailInfo.fromTransferName,
          fromBankNo: bankNo,
          mobilePhone: self.detailInfo.mobilePhone,
          transferVoucher: self.detailInfo.transferVoucher
        }
        let {data} = await api.getUpdateBank(params)
        if (data.status == 0) {
          self.$Notice.success({
            desc: data.message
          })
          self.underDetailWrap = false
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 上传公司凭证
      doUpload(e) {
        let self = this
        let client = new OSS.Wrapper({
          region: 'oss-cn-beijing',
          accessKeyId: this.userData.ossAccessKeyId,
          accessKeySecret: this.userData.ossAccessKeySecret,
          bucket: this.userData.ossBucketName
        })
        let file = e.target.files[0]
        let imgSize = file.size
        console.log(imgSize)
        if (imgSize > 100 * 1024 * 1024) {
          self.$Notice.error({
            desc: '上传图片大小不能大于100M'
          })
          return
        }
        let type = file.type.substring(6)
        let fileName = this.userData.ossUploadPath + this.$moment().format('YYYYMMDD/') + this.userData.subCustomerId + '' + this.$moment().format('_YYYY_MM_DD_HH_mm_ss') + '.' + type
        client.multipartUpload(fileName, file).then(function (result) {
          console.log(result)
          console.log(self.userData)
          if (result.res.status == 200) {
            self.detailInfo.transferVoucher = self.userData.ossImgUrl + '/' + result.name
          }
        }).catch(function (err) {
          console.log(err)
        })
      },
      // 显示银行卡号
      handleFocus() {
        this.showBankNo = true
      },
      // 失去焦点时候隐藏
      handleBlur() {
        this.showBankNo = false
      },
      // 银行卡号输入时候 进行分割
      handleChange() {
        console.log(this.detailInfo.fromBankNo)
        let bankNo = this.detailInfo.fromBankNo + ''

        this.$nextTick(() => {
          bankNo = bankNo.replace(/[^\d]/g, '')
          this.detailInfo.fromBankNo = bankNo.replace(/[\s]/g, '').replace(/(\d{4})(?=\d)/g, '$1 ')
        })
      },
      // 处理手机号录入
      handlePhoneChange() {
        let mobilePhone = this.detailInfo.mobilePhone + ''
        this.$nextTick(() => {
          this.detailInfo.mobilePhone = mobilePhone.replace(/[^\d]/g, '')
        })
      }
    }
  }
</script>

<style lang="less">
  .ivu-input-number-handler-wrap {
    display: none;
  }

  .recharge-list-input {
    width: 180px;
  }

  .list-bank-content {
    .bank-tip {
      position: absolute;
      left: 0;
      top: -29px;
      width: 250px;
      z-index: 1;
      height: 30px;
      line-height: 30px;
      padding-left: 5px;
      border: 1px solid #CCCCCC;
      background-color: #fce96e;

      .tip-text {
        color: #ed4014;
        font-size: 18px;
        font-weight: 600;
      }
    }

    .list-up-load-wrap {
      height: 100px;
      width: 100px;
      background-color: #f9f9f9;
      text-align: center;
      padding: 15px;
      border: 1px dashed #dcdee2;
      cursor: pointer;
      position: relative;

      p {
        font-size: 14px;
      }

      .ipt {
        position: absolute;
        left: 0;
        top: 0;
        opacity: 0;
        z-index: 10;
        width: 100%;
        height: 100%;
      }
    }

    .list-up-load-wrap:hover {
      border: 1px dashed #E61E10;
    }

    .list-bank-load-img {
      text-align: center;
      position: relative;
      height: 100px;
      width: 100px;

      .load-img {
        border: 1px solid #cccccc;
        height: 100px;
        width: 100px;
        padding: 2px;
        cursor: pointer;
      }

      .list-remove {
        position: absolute;
        right: 4px;
        top: 4px;
        background: #585858;
        padding: 3px;
        z-index: 99999;
        display: none;
      }
    }

    .list-bank-load-img:hover {
      .list-remove {
        display: block;
      }
    }

  }

  .recharge-list {
    width: 100%;
    padding: 10px;
    border: 1px solid #e5e5e5;
    background-color: #ffffff;

    .mine-header {
      height: 35px;
      line-height: 35px;
      margin-left: 10px;
    }

    .account-header {
      margin: 10px 0 10px 30px;

      .account-text {
        display: inline-block;
        height: 35px;
        line-height: 35px;
        width: 220px;
        font-size: 14px;
        font-weight: 600;

        span {
          color: red;
        }
      }
    }
  }

  .m-modal {
    .modal-amount {
      margin-top: 20px;
      padding: 0 20px;
      height: 50px;
      line-height: 50px;
      background-color: #F7F8FA;

      p {
        font-size: 14px;
        font-weight: 600;
      }

      .amount {
        font-size: 16px;
        color: #E61E10;
      }
    }

    .modal-wrap {
      padding: 20px;

      p {
        font-size: 14px;
        height: 30px;
        line-height: 30px;
      }

      .bank {
        position: relative;
        display: flex;
        align-items: center;

        span {
          font-size: 14px;
          display: inline-block;
          text-align: right;
          width: 67px;
        }
      }

      .red--text {
        color: #E61E10;
        margin-left: -3px;
        margin-right: 3px;
      }

      .img {
        margin-left: 85px;
        width: 100px;
        height: 100px;
      }

      .ipt {
        width: 250px;
      }
    }
  }

</style>
