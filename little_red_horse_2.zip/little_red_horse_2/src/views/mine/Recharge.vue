<template>
  <div class="recharge">
    <div>
      <div class="mine-header">

        <Breadcrumb>
          <BreadcrumbItem to="/mine/personalcenter">个人中心</BreadcrumbItem>
          <BreadcrumbItem>充值</BreadcrumbItem>
        </Breadcrumb>
      </div>
      <div class="recharge-wrap">
        <div class="recharge-wrap-header">
          <span class="recharge-text">充值金额：</span>
          <form action="javascript:void(0)">
            <InputNumber class="recharge-input"
                         ref="amountIpt"
                         @on-focus="(a)=>qtyFocus(a,'amountIpt')"
                         :max="200000" :min="0" v-model="amount"
                         :precision="2" :active-change="false"
                         @on-change="onChange"
                         :placeholder="`单笔金额不能超过${rechargeAmount(payType)}元`"></InputNumber>
            <span style="margin-left: 5px">元</span>
          </form>
          <div style="margin-left: 50px;">
            <Button type="text" to="/mine/rechargelist">
              <Icon type="md-create" size="16"/>
              充值记录
            </Button>
          </div>

        </div>
        <div class="radio-wrap">
          <Button class="radio-item" :class="{'item-select':amount==1000}" @click="selectAmount(1000)">
            1000 元
            <Icon v-show="amount==1000" type="md-checkmark" class="btn-check"/>
            <span v-show="amount==1000" class="btn-check-bg"></span>
          </Button>
          <Button class="radio-item" :class="{'item-select':amount==2000}" @click="selectAmount(2000)">
            2000 元
            <Icon v-show="amount==2000" type="md-checkmark" class="btn-check"/>
            <span v-show="amount==2000" class="btn-check-bg"></span>
          </Button>
          <Button class="radio-item" :class="{'item-select':amount==3000}" @click="selectAmount(3000)">
            3000 元
            <Icon v-show="amount==3000" type="md-checkmark" class="btn-check"/>
            <span v-show="amount==3000" class="btn-check-bg"></span>
          </Button>
          <Button class="radio-item" :class="{'item-select':amount==5000}" @click="selectAmount(5000)">
            5000 元
            <Icon v-show="amount==5000" type="md-checkmark" class="btn-check"/>
            <span v-show="amount==5000" class="btn-check-bg"></span>
          </Button>
          <Button class="radio-item" :class="{'item-select':amount==8000}" @click="selectAmount(8000)">
            8000 元
            <Icon v-show="amount==8000" type="md-checkmark" class="btn-check"/>
            <span v-show="amount==8000" class="btn-check-bg"></span>
          </Button>
          <Button class="radio-item" :class="{'item-select':amount==10000}" @click="selectAmount(10000)">
            10000 元
            <Icon v-show="amount==10000" type="md-checkmark" class="btn-check"/>
            <span v-show="amount==10000" class="btn-check-bg"></span>
          </Button>
        </div>
      </div>
      <div class="recharge-type">
        <Tabs value="card" type="card" @on-click="tabClick">
          <TabPane label="网银支付" name="card">
            <div class="pane-card">
              <RadioGroup v-model="bankCard" class="radio-pay-wrap">
                <div class="radio-pay-item" v-for="(item,index) in brankList" :key="index">
                  <Radio class="radio-pay-radio" :label="item.id">
                    <img :src="item.icon" alt="" class="radio-pay-img">
                  </Radio>
                </div>
              </RadioGroup>
              <ul class="content-tip">
                <li>
                  <em class="red--text">*</em> 温馨提示：
                </li>
                <li class="item">
                  各银行的支付限额各不相同，具体请点击查看“<a :href="bankHref">各银行的支付限额</a>”。支付金额较大时需插U盾。
                </li>
              </ul>
              <div class="recharge-submit">
                <Button style="width: 120px" :disabled="loading" type="error" @click="bankCardSubmit">充值</Button>
              </div>
            </div>
          </TabPane>

          <TabPane label="微信支付" name="weixin">
            <div class="pane-weixin">
              <RadioGroup v-model="payType" class="pay-header">
                <Radio class="header-item" label="weixin">
                  <img src="../../assets/images/pay/weixin@2x.png" alt="" class="header-item-img">
                </Radio>
              </RadioGroup>
              <ul class="content-tip">
                <li>
                  <em class="red--text">*</em> 温馨提示：
                </li>
                <li class="item">
                  由于政策原因，使用微信绑定的“信用卡”做在线充值时，如果经常金额较大，有时会被禁止用信用卡支付。
                </li>
                <li class="item">
                  如果遇到这种情况，可以改为使用微信绑定的<b>储蓄卡或余额</b>进行支付。
                </li>
              </ul>

              <div class="recharge-submit">
                <Button style="width: 120px" type="error" @click="zwRecharge">充值</Button>
              </div>

            </div>
          </TabPane>
          <TabPane label="支付宝" name="zhifubao">
            <div class="pane-weixin">
              <RadioGroup v-model="payType" class="pay-header">
                <Radio class="header-item" label="zhifubao">
                  <img src="../../assets/images/pay/zhifubao@2x.png" alt="" class="header-item-img">
                </Radio>
              </RadioGroup>

              <ul class="content-tip">
                <li>
                  <em class="red--text">*</em> 温馨提示：
                </li>
                <li class="item">
                  由于政策原因，使用支付宝绑定的“信用卡”做在线充值时，如果经常金额较大，有时会被禁止用信用卡支付。
                </li>
                <li class="item">
                  如果遇到这种情况，可以改为使用支付宝绑定的<b>储蓄卡或余额</b>进行支付。
                </li>
              </ul>

              <div class="recharge-submit">
                <Button style="width: 120px" type="error" @click="zwRecharge">充值</Button>
              </div>

            </div>
          </TabPane>
          <TabPane label="线下转账" name="bank">
            <div class="pane-bank">
              <div class="bank-header">
                <p class="item-first">请转账到以下账户：</p>
                <p class="item"><b>开户名称：</b>
                  <span id="name">{{transferInfo.toTransferName}} </span>
                  <button @click="handleCopy('copyName')"
                          ref="copyName"
                          data-clipboard-action="copy"
                          data-clipboard-target="#name"
                          class="item-copy"
                  >复制
                  </button>
                </p>
                <p class="item"><b>开户银行：</b>
                  <span id="bank">{{transferInfo.toBankName}}</span>
                  <button @click="handleCopy('copyBank')"
                          ref="copyBank"
                          data-clipboard-action="copy"
                          data-clipboard-target="#bank"
                          class="item-copy"
                  >复制
                  </button>
                </p>
                <p class="item"><b>账&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;号：</b>
                  <span id="no">{{transferInfo.toBankNo|cut4}}</span>
                  <button @click="handleCopy('copyNo')"
                          ref="copyNo"
                          data-clipboard-action="copy"
                          data-clipboard-target="#no"
                          class="item-copy"
                  >复制
                  </button>
                </p>
              </div>
              <div class="tranf-people-info">
                 <h4>付款人信息:</h4>
                 <div class="tranf-people-info-no" v-if="!inlineTransferData.length">
                    <p>还没有付款人信息，快去新增吧</p>
                 </div>
                 <div class="tranf-people-info-content" v-if="inlineTransferData.length">
                   <ul class="">
                      <li>转账姓名：{{defaultTransferData.fromTransferName}}<span v-if="defaultTransferData.isDefault==1">默认</span><em @click="moreTranfInfo()">更多付款人></em></li>
                      <li>转账银行卡：{{defaultTransferData.fromBankNo}}</li>
                      <li>联系电话：{{defaultTransferData.mobilePhone}}</li>
                   </ul>
                 </div>
                 <div class="new-btn" @click="addNewTranfInfo()">+新增付款人信息</div>
              </div>
              <div class="bank-content">
                <Form ref="bank" :model="formValidate" :rules="ruleValidate" :label-width="120">
                  <!-- <FormItem label="转账姓名：" prop="fromTransferName">
                    <Input v-model="formValidate.fromTransferName" :maxlength="10" class="ipt" clearable
                           placeholder="请输入付款人姓名！"></Input>
                  </FormItem>
                  <FormItem label="转账银行卡：" prop="fromBankNo" style="position: relative">
                    <div class="bank-tip" v-show="showBankNo">
                      <span class="tip-text">{{formValidate.fromBankNo|cut4}}</span>
                    </div>
                    <Input v-model="formValidate.fromBankNo" clearable
                           @on-change="handleChange"
                           @on-focus="handleFocus"
                           @on-blur="handleBlur"
                           :maxlength="24" class="ipt" placeholder="请输入银行卡号！"></Input>
                  </FormItem>
                  <FormItem label="联系电话：" prop="mobilePhone">
                    <Input v-model="formValidate.mobilePhone" :maxlength="11" class="ipt" clearable
                           @on-change="handlePhoneChange"
                           placeholder="请输入联系电话！"></Input>
                  </FormItem> -->
                  <FormItem label="转账凭证：" class="ivu-form-item-required">
                    <p class="grey--text"> 请上传一张清晰的转账小票照片或转账截图</p>
                    <div style="display: flex">
                      <div class="bank-up-load-wrap">
                        <input type="file" title="" @change="doUpload" class="ipt"
                               accept="image/gif,image/jpeg,image/jpg,image/png"/>
                        <Icon type="md-add" style="font-weight: 700" size="30"/>
                        <p>上传凭证</p>
                      </div>

                      <div class="bank-up-load-img" v-if="resultImg">
                        <img :src="resultImg" alt="" class="img" @click="openImgModal(resultImg)">
                        <Icon type="md-close" color="white" class="bank-remove" size="20" @click="removeImg"/>
                      </div>

                      <div class="bank-up-load-img" v-if="!resultImg">
                        <img :src="defaultImg" alt="" class="img" @click="openImgModal(defaultImg)">
                        <p class="eg-img">线上转账传图示例</p>
                      </div>
                      <div class="bank-up-load-img" v-if="!resultImg">
                        <img :src="defaultImg2" alt="" class="img" @click="openImgModal(defaultImg2)">
                        <p class="eg-img">柜台转账传图示例</p>
                      </div>
                    </div>
                  </FormItem>
                </Form>
                <ul class="content-tip">
                  <li>
                    <em class="red--text">*</em> 温馨提示：
                  </li>
                  <li class="item">
                    1.受银行处理影响，网银转账可能有一定时间的延迟，因此，可能会在您提交上述信息后延迟一些时间，我方才能确认并充值到您的资金账户。
                  </li>
                  <li class="item">
                    2.转账金额小于20000元时，建议用“ <b>微信支付、支付宝</b> ”扫码支付，或“ <b>储蓄卡</b> ”在线支付，可以实时完成充值。
                  </li>
                </ul>
              </div>
              <div class="recharge-submit">
                <Button style="width: 120px" type="error" @click="bankSubmit">提交</Button>
              </div>
            </div>
          </TabPane>
        </Tabs>
      </div>
    </div>

    <Modal title="示例图" v-model="imgModal" footer-hide>
      <img :src="bigImg" style="width: 100%">
    </Modal>
    <Modal v-model="newTranfInfoViable" :title="editType=='new'?'新增付款人信息':'编辑'" width="600"
           :mask-closable="false">
        <div style="padding: 0 80px;">
          <Form ref="bank" :model="formValidate" :rules="ruleValidate" :label-width="120">
              <FormItem label="转账姓名：" prop="fromTransferName">
                <Input v-model="formValidate.fromTransferName" :maxlength="10" class="ipt" clearable
                      placeholder="请输入付款人姓名！"></Input>
              </FormItem>
              <FormItem label="转账银行卡：" prop="fromBankNo" style="position: relative">
                <div class="bank-tip" v-show="showBankNo">
                    <span class="tip-text">{{formValidate.fromBankNo|cut4}}</span>
                </div>
                <Input v-model="formValidate.fromBankNo" clearable
                       @on-focus="handleFocus"
                       @on-blur="handleBlur"
                       :maxlength="24" class="ipt" placeholder="请输入银行卡号！"></Input>
              </FormItem>
              <FormItem label="联系电话：" prop="mobilePhone">
                  <Input v-model="formValidate.mobilePhone" :maxlength="11" class="ipt" clearable
                        @on-change="handlePhoneChange"
                        placeholder="请输入联系电话！"></Input>
              </FormItem>
              <Checkbox style="margin-left: 120px;" v-if="editType=='update'" v-model="formValidate.isDefault" :disabled="disable" @on-change="checkedChange">设为默认付款人</Checkbox>
          </Form>
        </div>
        <div slot="footer">
            <Button type="primary" size @click="submitInfo">保存</Button>
        </div>
    </Modal>
    <Modal v-model="moreTranfInfoViable" title="选择付款人信息" width="600"
           :mask-closable="false"
           style="height: 500px;"
           @on-ok="confirmSelect()"
           >
        <div class="tranf-info-con">
            <RadioGroup v-model="fromBankNo" style="width: 100%;" @on-change="selectChange">
                <div class="radio-pay-item" v-for="(item,index) in inlineTransferData" :key="index">
                  <Radio class="radio-tranf-radio" :label="item.fromBankNo" style="width: 100%;">
                    <section class="adio-pay-item-con">
                      <div class="adio-pay-item-con-left">
                         <ul class="">
                                <li>转账姓名：{{item.fromTransferName}}<span v-if="item.isDefault==1">默认</span></li>
                                <li>转账银行卡：{{item.fromBankNo}}</li>
                                <li>联系电话：{{item.mobilePhone}}</li>
                          </ul>
                      </div>
                    </section>
                  </Radio>
                  <div class="adio-pay-item-con-right">
                          <div class="option-btn" @click.stop="updateTransfer(item)">编辑</div>
                          <div class="option-btn" @click.stop="deleteTranfer(item.id)" v-if="item.isDefault==0">删除</div>
                          <div class="option-btn" @click.stop="setDefault(item)" v-if="item.isDefault==0">设为默认</div>
                  </div>
                </div>
              </RadioGroup>
        </div>
    </Modal>
    <Modal v-model="wxModal" :title="payType=='weixin'?'微信支付':'支付宝支付'" width="600"
           :mask-closable="false"
           @on-cancel="wxModalClose"
           footer-hide>
      <div class="wx-modal">
        <h3>请您在 <b class="red--text">5分钟</b> 内完成支付</h3>
        <p class="">如果支付后1分钟内未得到“支付成功”的提示，请关闭本窗口，</p>
        <p>稍后再点击本功能右上角的“充值记录”按钮，查看支付“状态”，以确定是否支付成功。</p>
        <div class="wx-modal-content">
          <p>客户名称：<span class="red--text">{{payInfo.customerName}}</span></p>
          <p>充值单号：<span class="red--text">{{payInfo.code}}</span></p>
          <p>充值金额：<span class="red--text">¥{{payInfo.chargeAmount}}</span></p>
        </div>
        <div class="wx-modal-img" v-loading="imgLoading">
          <img :src="payInfo.qrCodeImgUrl" alt="" class="code-img">
          <p v-if="payType=='weixin'">请使用微信扫描二维码！</p>
          <p v-if="payType=='zhifubao'">请使用支付宝扫描二维码！</p>
        </div>
        <ul class="content-tip">
          <li>
            <em class="red--text">*</em> 温馨提示：
          </li>
          <li class="item" v-if="payType=='weixin'">
            由于政策原因，使用微信绑定的“信用卡”做在线充值时，如果经常金额较大，有时会被禁止用信用卡支付。
            如果遇到这种情况，可以改为使用微信绑定的<b>储蓄卡或余额</b>进行支付。
          </li>
          <li class="item" v-if="payType=='zhifubao'">
            由于政策原因，使用支付宝绑定的“信用卡”做在线充值时，如果经常金额较大，有时会被禁止用信用卡支付。
            如果遇到这种情况，可以改为使用支付宝绑定的<b>储蓄卡或余额</b>进行支付。
          </li>
        </ul>
      </div>
    </Modal>

    <Modal v-model="successModal" :closable="false" title="" width="450" :mask-closable="false">
      <div class="success-modal">
        <div class="success-header">
          <Icon type="md-checkmark-circle" color="#19be6b" size="56" style="margin-top: -14px"/>
          <span>您已成功充值 <em>¥{{payResult.payAmount}}</em>元</span>
        </div>
        <div class="success-content">
          <p>账户余额： <span>¥{{payResult.balance}}</span></p>
          <p>可用余额： <span>¥{{payResult.availableBalance}}</span></p>
        </div>
      </div>
      <div slot="footer">
        <Button type="error" :loading="loading" @click="closeModal">确定</Button>
      </div>
    </Modal>
  </div>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'
  import * as opt from '../../utils/options'

  export default {
    name: 'Recharge',
    inject: ['reload'],
    data() {
      return {
        bankHref: opt.bankHref,
        amount: null,
        payType: 'card',
        bankCard: '',
        creditCard: '',
        transferInfo: {},
        brankList: [],
        formValidate: {
          fromTransferName: '',
          fromBankNo: '',
          mobilePhone: '',
          transferVoucher: '',
          isDefault: '1'
        },
        ruleValidate: {
          fromTransferName: [
            {required: true, message: '请输入付款人姓名！', trigger: 'blur'}
          ],
          fromBankNo: [
            {required: true, message: '请输入银行卡号！', trigger: 'blur'}
          ],
          mobilePhone: [
            {required: true, message: '请输入联系电话！', trigger: 'blur'}
          ],
          resultImg: [
            {required: true, message: '请上传转账凭证！', trigger: 'change'}
          ]
        },
        imgModal: false,
        defaultImg: opt.defaultBankImg,
        defaultImg2: opt.defaultBanKImg2,
        resultImg: '',
        bigImg: '',
        payInfo: {},
        payResult: {},
        timer: null,
        wxModal: false,
        successModal: false,
        imgLoading: false,

        copyName: null,
        copyBank: null,
        copyNo: null,
        showBankNo: false,
        maxRechargeAmount: {},
        inlineTransferData: [],
        defaultTransferData: {},
        newTranfInfoViable: false,
        moreTranfInfoViable: false,
        editType: 'new',
        fromBankNo: '',
        temp: [],
        isDefault: false,
        disable: false
      }
    },
    created() {
      console.log(this.userData)
      console.log(this.$route.query.amount)
      let amount = this.$route.query.amount
      if (amount) {
        this.amount = amount * 1
      }
      this.initData()
    },
    mounted() {
      this.copyName = new this.$clipboard(this.$refs.copyName)
      this.copyBank = new this.$clipboard(this.$refs.copyBank)
      this.copyNo = new this.$clipboard(this.$refs.copyNo)
    },
    computed: {
      ...mapState([
        'loading'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    beforeDestroy() {
      clearInterval(this.timer)
    },
    watch: {
      '$route': 'routeChange'
    },
    methods: {
      ...mapActions([]),
      initData() {
        this.getTransfer()
        this.getBankData()
        this.getMaxRechargeAmount()
        this.getTransferData()
      },
      routeChange(v) {
        console.log(v)
        console.log(this.$route.path)
        let amount = this.$route.query.amount

        this.$nextTick(() => {
          if (amount) {
            this.amount = amount * 1
          } else {
            this.amount = null
          }
        })
      },
      selectAmount(amount) {
        this.amount = amount
      },
      // 处理值为0的状态 清空0
      onChange(v) {
        if (v == 0) {
          console.log(this.amount)
          setTimeout(() => {
            this.amount = null
          }, 400)
        }
      },
      qtyFocus(e, id) {
        console.log(id)
        setTimeout(() => {
          this.$refs[id].$el.querySelector('input').select()
        }, 10)
      },
      // 付款人信息改变的时候
      selectChange(v) {
        console.log(v)
        this.temp = this.inlineTransferData.filter(e => {
          return e.fromBankNo === v
        })[0]
      },
      // 确认
      confirmSelect() {
        this.formValidate = this.inlineTransferData.filter(e => {
          return e.fromBankNo === this.fromBankNo
        })[0]
        // this.formValidate = Object.assign({}, this.formValidate, this.temp)
        this.defaultTransferData = this.formValidate
        this.moreTranfInfoViable = false
      },
      // 新增转账人信息
      addNewTranfInfo() {
        this.formValidate = {
          fromTransferName: '',
          fromBankNo: '',
          mobilePhone: '',
          isDefault: '1'
        }
        this.editType = 'new'
        this.newTranfInfoViable = true
      },
      // 更多转账人信息
      moreTranfInfo() {
        this.moreTranfInfoViable = true
      },
      // 保存新增付款人信息
      submitInfo() {
        console.log(this.formValidate)
        if (this.editType === 'update') this.updateTransferData()
        if (this.editType === 'new') this.addTransferData()
      },
      // 线下转账的 信息
      async getBankData() {
        let self = this
        let {data} = await api.getBankList({})
        console.log(data)
        if (data.status == 0) {
          self.brankList = data.data.list
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 线下转账的 信息
      async getTransfer() {
        let self = this
        self.loadData2 = true
        let {data} = await api.getTransferDetail({})
        console.log(data)
        if (data.status == 0) {
          self.loadData2 = false
          self.transferInfo = data.data
          self.fromBankNo = data.data.fromBankNo
          self.defaultTransferData = data.data
        }
      },
      // 获取充值的限制额度
      async getMaxRechargeAmount() {
        let {data} = await api.getMaxRechargeAmount()
        if (data.status == 0) {
          this.maxRechargeAmount = data.data
        }
      },
      // 获取线下转账人信息
      async getTransferData() {
        let {data} = await api.getInlineDetail({
          pageSize: 1000,
          pagePage: 1
        })
        console.log(data)
        if (data.status == 0) {
          this.inlineTransferData = data.data.list
          // this.defaultTransferData = this.inlineTransferData.filter(e => {
          //   return e.isDefault == '1'
          // })[0]
        }
      },
      // 添加转账人信息
      async addTransferData() {
        let {data} = await api.getAddTranferInfo({
          fromTransferName: this.formValidate.fromTransferName,
          fromBankNo: this.formValidate.fromBankNo,
          mobilePhone: this.formValidate.mobilePhone,
          isDefault: !this.inlineTransferData.length ? '1' : '0'
        })
        console.log(data)
        if (data.status == 0) {
          this.$Notice.success({
            desc: '添加成功'
          })
          this.newTranfInfoViable = false
          this.getTransferData()
        } else {
          this.$Modal.error({
            title: '温馨提示',
            content: data.message,
            onOk: () => {
            },
            onCancel: () => {
            }
          })
        }
      },
      // 编辑转账人信息
      updateTransfer(item) {
        console.log(item)
        if (item.isDefault == '1') this.disable = true
        else this.disable = false
        this.newTranfInfoViable = true
        this.editType = 'update'
        this.formValidate = {
          fromTransferName: item.fromTransferName,
          fromBankNo: item.fromBankNo,
          mobilePhone: item.mobilePhone,
          isDefault: item.isDefault === '1' ? true : false,
          id: item.id
        }
        console.log(this.formValidate)
      },
      async updateTransferData() {
        let {data} = await api.getUpdateTranferInfo({
          fromTransferName: this.formValidate.fromTransferName,
          fromBankNo: this.formValidate.fromBankNo,
          mobilePhone: this.formValidate.mobilePhone,
          isDefault: this.formValidate.isDefault ? '1' : '0',
          id: this.formValidate.id
        })
        console.log(data)
        if (data.status == 0) {
          this.$Notice.success({
            desc: '操作成功'
          })
          this.newTranfInfoViable = false
          // this.defaultTransferData = this.formValidate
          this.getTransferData()
        } else {
          this.$Modal.error({
            title: '温馨提示',
            content: data.message,
            onOk: () => {
            },
            onCancel: () => {
            }
          })
        }
      },
      setDefault(item) {
        // this.fromBankNo = item.fromBankNo
        this.formValidate = {
          fromTransferName: item.fromTransferName,
          fromBankNo: item.fromBankNo,
          mobilePhone: item.mobilePhone,
          isDefault: 1,
          id: item.id
        }
        this.updateTransferData()
      },
      // 删除转账人信息
      deleteTranfer(id) {
        this.$Modal.confirm({
          title: '温馨提示',
          content: '确定要删除？',
          onOk: () => {
            this.deleteTranferData(id)
          }
        })
      },
      async deleteTranferData(id) {
        let {data} = await api.getDeleteTranferInfo({
          id: id
        })
        console.log(data)
        if (data.status == 0) {
          this.$Notice.success({
            desc: '删除成功'
          })
          this.getTransferData()
        } else {
          this.$Notice.error({
            desc: data.message
          })
        }
      },
      // 设为默认
      async seDefault(id) {
        let {data} = await api.getUpdateTranferInfo({
          fromTransferName: this.formValidate.fromTransferName,
          fromBankNo: this.formValidate.fromBankNo,
          mobilePhone: this.formValidate.mobilePhone,
          IsDefault: this.formValidate.IsDefault,
          id: id
        })
        console.log(data)
        if (data.status == 0) {
          this.$Notice.success({
            desc: '添加成功'
          })
          this.newTranfInfoViable = false
          this.getTransferData()
        }
      },
      checkedChange(v) {
        this.formValidate.isDefault = v
        // v ? this.formValidate.isDefault = '1' : this.formValidate.isDefault = '0'
        console.log(this.formValidate.isDefault)
      },
      // 看大图
      openImgModal(url) {
        this.imgModal = true
        this.bigImg = url
      },
      // 不同支付方式的限额
      rechargeAmount(name) {
        if (name === 'card') return this.formatAmount(this.maxRechargeAmount.onlineMaxRechargeAmount, 2)
        if (name === 'weixin' || name === 'zhifubao') return this.formatAmount(this.maxRechargeAmount.maxRechargeAmount, 2)
        if (name === 'bank') return this.formatAmount(this.maxRechargeAmount.maxRransferAmount, 2)
      },
      // 选择哪种支付方式时候
      tabClick(name) {
        console.log(name)
        this.payType = name
      },
      // 支付宝微信支付 可能存在金额超过单次充值额度
      async handlePay(payType) {
        let self = this
        self.imgLoading = true
        let params = {
          payType: payType,
          transferAmount: this.amount
        }
        let {data} = await api.getOnlineRecharge(params)
        console.log(data)
        if (data.status == 0) {
          self.wxModal = true
          self.payInfo = data.data
          self.imgLoading = false
          this.checkPayStatus()
        } else {
          self.$Modal.confirm({
            title: '温馨提示',
            content: data.message,
            onOk: () => {
            }
          })
        }
      },
      // 检查支付状态  设置最长 5分钟 内支付完
      checkPayStatus() {
        let self = this
        let longTime = 5 * 60 * 1000
        this.timer = setInterval(() => {
          longTime -= 3000
          console.log(longTime)
          if (longTime < 0) {
            clearInterval(self.timer)
          } else {
            self.checkStatus()
          }
        }, 3000)
      },
      async checkStatus() {
        let self = this
        let params = {
          paymentId: self.payInfo.paymentId
        }
        let {data} = await api.getPayStatus(params)
        if (data.status == 0) {
          if (data.data.payStatus == 3) {
            console.log('充值成功')
            self.successModal = true
            self.payResult = data.data
            clearInterval(self.timer)
          }
        }
      },
      // 储蓄卡支付
      bankCardSubmit() {
        if (this.amount == '' || this.amount == null) {
          this.$Notice.info({
            desc: '请输入充值金额！'
          })
        } else if (this.bankCard == '') {
          this.$Notice.info({
            desc: '请选择银行卡！'
          })
        } else {
          console.log(this.bankCard)
          this.handleCardPay(3, this.bankCard)
        }
      },

      // 信用卡支付
      creditCardSubmit() {
        if (this.amount == '' || this.amount == null) {
          this.$Notice.info({
            desc: '请输入充值金额！'
          })
        } else if (this.creditCard == '') {
          this.$Notice.info({
            desc: '请选择信用卡！'
          })
        } else {
          console.log(this.creditCard)
          this.handleCardPay(4, this.creditCard)
        }
      },
      // 打开新窗口
      openWin(url) {
        let a = document.createElement('a')
        a.setAttribute('href', url)
        a.setAttribute('target', '_blank')
        document.body.appendChild(a)
        a.click()
      },
      // 储蓄卡 信用卡支付
      async handleCardPay(type, bankId) {
        let self = this
        let backUrl = location.href
        backUrl = backUrl.replace('recharge', 'rechargelist')
        let params = {
          payType: type,
          transferAmount: self.amount,
          frontUrl: backUrl,
          bankId: bankId
        }
        console.log(params)
        let {data} = await api.getOnlineRecharge(params)
        if (data.status == 0) {
          // window.open(data.data.url)
          self.openWin(data.data.url)
          self.$Modal.confirm({
            title: '温馨提示',
            content: '<p>请您在新打开的页面上完成充值。</p>' +
              '<p>充值完成后，根据您的情况点击下面按钮。</p>',
            okText: '充值成功',
            cancelText: '充值失败',
            closable: false,
            onOk: () => {
              self.$router.push({path: '/mine/rechargelist'})
            },
            onCancel: () => {
            }
          })
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 支付宝或者微信充值
      zwRecharge() {
        if (this.amount == '' || this.amount == null) {
          this.$Notice.info({
            desc: '请输入充值金额！'
          })
        } else {
          if (this.payType == 'weixin') {
            this.handlePay(1)
          } else if (this.payType == 'zhifubao') {
            this.handlePay(2)
          }
        }
      },
      // 公司转账
      bankSubmit() {
        if (this.amount == '' || this.amount == null) {
          this.$Notice.error({
            desc: '请输入充值金额！'
          })
        } else {
          this.$refs['bank'].validate((valid) => {
            if (valid) {
              this.bankRecharge()
            } else {
            }
          })
        }
      },
      // 公司转账
      async bankRecharge() {
        let self = this
        if (this.amount == '' || this.amount == null) {
          return
        }
        let bankNo = self.formValidate.fromBankNo.replace(/\s+/g, '')
        let params = {
          transferAmount: self.amount,
          fromTransferName: self.formValidate.fromTransferName,
          fromBankNo: bankNo,
          mobilePhone: self.formValidate.mobilePhone,
          transferVoucher: self.resultImg
        }
        let {data} = await api.getPayBank(params)
        if (data.status == 0) {
          self.$Modal.success({
            title: '温馨提示',
            content: '<p>已提交成功，经我方确认已收到款项后，即可完成充值。' +
              '受银行处理影响，网银转账可能有一定时间的延迟，因此，可能会在您提交上述信息后延迟一些时间，我方才能确认并充值到您的资金账户。' +
              '您可以查看“充值记录”，当本笔记录状态由“未确认”变为“已支付”后，即表示已充值成功。</p>',
            onOk: () => {
              self.$router.push({path: '/mine/rechargelist'})
            }
          })
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 上传公司凭证
      doUpload(e) {
        let self = this
        let client = new OSS.Wrapper({
          region: 'oss-cn-beijing',
          accessKeyId: this.userData.ossAccessKeyId,
          accessKeySecret: this.userData.ossAccessKeySecret,
          bucket: this.userData.ossBucketName
        })
        let file = e.target.files[0]
        let imgSize = file.size
        console.log(imgSize)
        if (imgSize > 100 * 1024 * 1024) {
          self.$Notice.error({
            desc: '上传图片大小不能大于100M'
          })
          return
        }

        let type = file.type.substring(6)
        let fileName = this.userData.ossUploadPath + this.$moment().format('YYYYMMDD/') + this.userData.subCustomerId + '' + this.$moment().format('_YYYY_MM_DD_HH_mm_ss') + '.' + type
        client.multipartUpload(fileName, file).then(function (result) {
          console.log(result)
          console.log(self.userData)
          if (result.res.status == 200) {
            self.resultImg = self.userData.ossImgUrl + '/' + result.name
          }
        }).catch(function (err) {
          console.log(err)
        })
      },
      // 删除已经上传的图片
      removeImg() {
        this.resultImg = ''
      },
      // 支付成功弹窗关闭时候
      closeModal() {
        this.successModal = false
        this.wxModal = false
        this.$router.push({path: '/mine/rechargelist'})
      },
      // 微信、支付宝 支付弹窗关闭时候
      wxModalClose() {
        clearInterval(this.timer)
      },
      // 进行复制
      handleCopy(name) {
        let self = this
        let copyName = self.copyName
        let copyBank = self.copyBank
        let copyNo = self.copyNo
        switch (name) {
          case 'copyName':
            copyName.on('success', function () {
            })
            break
          case 'copyBank':
            copyBank.on('success', function () {
            })
            break
          case 'copyNo':
            copyNo.on('success', function () {
            })
            break
        }
      },
      // 显示银行卡号
      handleFocus() {
        this.showBankNo = true
      },
      // 失去焦点时候隐藏
      handleBlur() {
        this.showBankNo = false
      },
      // 银行卡号输入时候 进行分割
      handleChange() {
        console.log(this.formValidate.fromBankNo)
        let bankNo = this.formValidate.fromBankNo + ''

        this.$nextTick(() => {
          bankNo = bankNo.replace(/[^\d]/g, '')
          this.formValidate.fromBankNo = bankNo.replace(/[\s]/g, '').replace(/(\d{4})(?=\d)/g, '$1 ')
        })
      },
      // 处理手机号录入
      handlePhoneChange() {
        let mobilePhone = this.formValidate.mobilePhone + ''
        this.$nextTick(() => {
          this.formValidate.mobilePhone = mobilePhone.replace(/[^\d]/g, '')
        })
      }
    }
  }
</script>

<style lang="less">

  .ivu-input {
    font-size: 14px;
  }

  .wx-modal {
    .red--text {
      color: #E61E10;
    }

    h3 {
      text-align: center;
      font-size: 18px;
      margin-bottom: 30px;
    }

    p {
      font-size: 14px;
      color: #333333;
    }

    &-content {
      padding-top: 20px;
      padding-left: 205px;
    }

    &-img {
      text-align: center;
      margin-top: 5px;

      .code-img {
        display: inline-block;
        width: 150px;
        height: 150px;
        border: 1px solid #cccccc;
      }

      p {
        color: #2d8cf0;
      }
    }

    .content-tip {
      font-size: 12px;
      padding-top: 20px;

      .item {
        margin-left: 20px;
        font-size: 12px;
      }
    }
  }

  .success-modal {
    .success-header {
      height: 143px;
      line-height: 143px;
      width: 100%;
      background-color: #F7FFF3;
      text-align: center;

      span {
        font-size: 20px;
      }

      em {
        font-size: 30px;
        color: #E61E10;
      }
    }

    .success-content {
      text-align: center;

      p {
        padding-top: 10px;
        font-size: 14px;
      }

      span {
        font-size: 16px;
        color: #E61E10;
      }
    }

    .success-footer {
      margin-top: 20px;
      text-align: center;

      .btn {
        margin: 0 10px;
      }
    }
  }

  .recharge {
    width: 100%;
    padding: 10px;
    border: 1px solid #e5e5e5;
    background-color: #ffffff;

    .mine-header {
      height: 35px;
      line-height: 35px;
      margin-left: 10px;
    }

    .recharge-wrap {
      margin-left: 50px;
      margin-top: 20px;

      &-header {
        display: flex;
        width: 100%;

        .recharge-text {
          display: inline-block;
          height: 35px;
          line-height: 35px;
          font-size: 14px;
        }

        .recharge-input {
          width: 190px;
        }
      }

      .radio-wrap {
        margin-left: 70px;
        margin-top: 20px;
        width: 300px;

        .radio-item {
          width: 80px;
          margin-right: 20px;
          margin-top: 10px;
          position: relative;

          .btn-check {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 12px;
            color: #ffffff;
            font-weight: 700;
            z-index: 111;
          }

          .btn-check-bg::before {
            content: "";
            width: 0px;
            height: 0px;
            border-left: 20px solid transparent;
            border-right: 20px solid #ed4014;
            border-bottom: 20px solid transparent;
            position: absolute;
            top: 0px;
            right: 0px;
          }
        }

        .item-select {
          border: 1px solid #E61E10;
        }
      }
    }

    .recharge-type {
      padding-top: 40px;

      .content-tip {
        font-size: 14px;
        padding-top: 20px;

        .item {
          margin-left: 20px;
          font-size: 14px;
        }
      }

      .pane-card {
        .ivu-radio {
          top: -10px;
        }

        .radio-pay-wrap {
          display: flex;
          flex-direction: row;
          flex-wrap: wrap;

          .radio-pay-item {
            border: 1px solid #cccccc;
            padding: 5px 5px 3px 5px;
            margin: 10px 30px 10px 0;

            .radio-pay-radio {
            }
          }
        }
      }

      .pane-weixin {
        padding: 20px;

        .pay-header {
          .ivu-radio {
            height: 40px;
            line-height: 40px;
          }

          .header-item {
            border: 1px solid #cccccc;
            padding: 5px 10px;
            position: relative;
            width: 180px;
            height: 50px;
            margin-right: 40px;

            &-img {
              width: 107px;
              height: 36px;
              position: absolute;
              top: 5px;
              left: 40px;
            }
          }
        }

        .wrap-zhifubao {
          height: 310px;
          width: 100%;
          background-color: #F7F8FA;
          margin-top: 40px;
          display: flex;
          align-items: center;
          justify-content: center;

          .img {
            border: 1px solid #cccccc;
            background-color: #ffffff;
            width: 180px;
            height: 180px;
          }
        }

        .wrap-weixin {
          height: 310px;
          width: 100%;
          background-color: #F7F8FA;
          margin-top: 40px;
          display: flex;
          justify-content: space-around;

          &-l {
            margin-top: 20px;
            padding-top: 40px;
            text-align: center;

            .img {
              border: 1px solid #cccccc;
              background-color: #ffffff;
              width: 180px;
              height: 180px;
            }

            .em {
              color: #42AE3C;
            }

            .text {
              font-size: 16px;
              margin-top: 20px;
            }
          }

          &-r {
            margin-top: 10px;
          }
        }

        &-img {
          width: 200px;
          height: 200px;
        }
      }

      .pane-zhifubao {
      }

      .pane-bank {
        padding: 10px;

        .bank-header {
          background-color: #F7F8FA;
          padding: 20px;

          .item-first {
            font-size: 16px;
          }

          .item {
            margin-left: 40px;
            font-size: 14px;
          }

          p {
            line-height: 24px;
            color: #666666;
          }
        }

        .bank-content {
          padding: 20px 0;

          .bank-tip {
            position: absolute;
            left: 0;
            top: -29px;
            width: 250px;
            z-index: 1;
            height: 30px;
            line-height: 30px;
            padding-left: 5px;
            border: 1px solid #CCCCCC;
            background-color: #fce96e;

            .tip-text {
              color: #ed4014;
              font-size: 18px;
              font-weight: 600;
            }
          }

          .ipt {
            width: 363px;
          }

          .bank-up-load-wrap {
            height: 120px;
            width: 120px;
            background-color: #f9f9f9;
            text-align: center;
            padding: 25px;
            border: 1px dashed #dcdee2;
            cursor: pointer;
            position: relative;

            p {
              font-size: 14px;
            }

            .ipt {
              position: absolute;
              left: 0;
              top: 0;
              opacity: 0;
              z-index: 10;
              width: 100%;
              height: 100%;
            }
          }

          .bank-up-load-wrap:hover {
            border: 1px dashed #E61E10;
          }

          .bank-up-load-img {
            text-align: center;
            margin-left: 30px;
            position: relative;
            height: 120px;
            width: 120px;

            .img {
              border: 1px solid #cccccc;
              height: 120px;
              width: 120px;
              padding: 2px;
              cursor: pointer;
            }

            .bank-remove {
              position: absolute;
              right: 4px;
              top: 4px;
              background: #585858;
              padding: 3px;
              display: none;
            }

            .eg-img {
              position: absolute;
              bottom: 0;
              left: 0;
              width: 120px;
              height: 25px;
              line-height: 25px;
              font-size: 12px;
              color: #ffffff;
              background-color: #999999;
            }
          }

          .bank-up-load-img:hover {
            .bank-remove {
              display: block;
            }
          }

        }
      }
    }

    .recharge-submit {
      margin-top: 50px;
      text-align: center;
    }
    .tranf-people-info{
      h4{
        color: #333333;
        font-size: 14px;
        margin: 20px 20px 10px;
      }
      &-no{
        margin-left: 35px;
        p{
          color: #999999;
          font-size: 12px;
          margin-bottom: 10px;
        }
      }
      &-content{
        margin-left: 35px;
        li{
          margin-bottom: 5px;
          &:first-child{
            span{
              background: #F7B62D;
              font-size: 12px;
              color: #ffffff;
              padding: 1px 8px;
              border-radius: 34px;
              margin: 0 0px 0 10px;
            }
            em{
              cursor: pointer;
              color: #4385FF;
              margin-left: 100px;
            }
          }
        }
      }
    }
    .new-btn{
      cursor: pointer;
      margin-left: 35px;
      width: 120px;
      color: #FF3000;
      font-size: 12px;
      padding: 2px 0px;
      text-align: center;
      border: 1px solid #FF3000;
      border-radius: 4px;
    }
  }
  .tranf-info-con{
     height: 500px;
     overflow-y: scroll;
     padding:0px 20px;
     margin:10px 0;
     .radio-pay-item{
       padding: 10px 0;
       border-bottom:1px #dddddd dashed;
       display: flex;
       justify-content: space-between;
     }
     .adio-pay-item-con-right{
       width: 180px!important;
       justify-content: flex-end;

     }
     .adio-pay-item-con{
      display: flex!important;
      justify-content: space-between;
      // width: 100%;
      &-left{
        li{
          margin-bottom: 5px;
          &:first-child{
            span{
              background: #F7B62D;
              font-size: 12px;
              color: #ffffff;
              padding: 1px 8px;
              border-radius: 34px;
              margin: 0 100px 0 10px;
            }
          }
        }
      }
      &-right{
        display: flex;
        align-items: center;
        .option-btn{
          color: #5584FF;
          cursor: pointer;
          padding: 0 10px;
        }
      }
    }
    .radio-tranf-radio{
      display: flex;
      align-items: center;
      width: calc(100% - 150px)!important;
      span{
        margin-right: 20px;
      }
    }
  }
</style>
