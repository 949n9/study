export const AccountHeader = [
  {
    title: '单号',
    align: 'center',
    key: 'code'
  },
  {
    title: '时间',
    align: 'center',
    key: 'bizTime',
    sortable: true,
    width: 160
  },
  {
    title: '变动类型',
    align: 'center',
    key: 'categoryName'
  },
  {
    title: '收入（元）',
    align: 'center',
    key: 'changeAmountIn',
    sortable: true,
    sortMethod: (a, b, type) => type === 'asc' ? a - b : b - a
  },
  {
    title: '支出（元）',
    align: 'center',
    key: 'changeAmountOut',
    sortable: true,
    sortMethod: (a, b, type) => type === 'asc' ? a - b : b - a
  },
  {
    title: '账户余额（元）',
    align: 'center',
    key: 'balance',
    sortable: true,
    sortMethod: (a, b, type) => type === 'asc' ? a - b : b - a,
    width: 140
  },
  {
    title: '摘要',
    align: 'center',
    sortable: true,
    key: 'description'
  }
]

export const RechargeHeader = [
  {
    title: '充值方式',
    align: 'center',
    key: 'chargeTypeName',
    width: 110
  }, {
    title: '支付方式',
    align: 'center',
    key: 'payTypeName',
    width: 110
  },
  {
    title: '提交人',
    align: 'center',
    key: 'createUserName',
    width: 100
  },
  {
    title: '提交时间',
    align: 'center',
    key: 'createTime',
    sortable: true,
    width: 180
  },
  {
    title: '确认时间',
    align: 'center',
    key: 'payTime',
    sortable: true,
    width: 180
  },
  {
    title: '充值金额（元）',
    align: 'center',
    key: 'chargeAmount',
    width: 140,
    sortable: true,
    sortMethod: (a, b, type) => type === 'asc' ? a - b : b - a
  },
  {
    title: '状态',
    align: 'center',
    sortable: true,
    key: 'payStatusName'
  },
  {
    title: '操作',
    slot: 'action',
    align: 'center'
  }
]
export const CouponHeader = [
  {
    title: '优惠券名称',
    key: 'code'
  },
  {
    title: '优惠券类目',
    key: 'code'
  },
  {
    title: '有效期',
    key: 'bizTime',
    width: 150
  },
  {
    title: '类目',
    key: 'categoryName'
  },
  {
    title: '适用范围',
    key: 'changeAmountIn'
  },
  {
    title: '状态',
    key: 'changeAmountOut'
  }
]
export const orderUnitHeader = [
  {
    title: '订货单位名称',
    key: 'subCustomerName',
    align: 'center'
  },
  {
    title: '联系人',
    key: 'subCustomerContactName',
    width: 100,
    align: 'center'
  },
  {
    title: '手机号',
    key: 'subCustomerMobilePhone',
    width: 120,
    align: 'center'
  },
  {
    title: '收货地址',
    slot: 'address',
    align: 'center'
  },
  {
    title: '状态',
    slot: 'useStatus',
    width: 80,
    align: 'center'
  },
  {
    title: '操作',
    slot: 'action',
    align: 'center'
  }
]
export const addressHeader = [
  {
    title: '收货人',
    key: 'receiver',
    width: 100,
    align: 'center'
  },
  {
    title: '手机号',
    key: 'receiveMobilePhone',
    width: 120,
    align: 'center'
  },
  {
    title: '其他电话',
    key: 'receiveTelePhone',
    width: 120,
    align: 'center'
  },
  {
    title: '收货地址',
    key: 'receiveAddress',
    align: 'center'
  },
  {
    title: '详细地址',
    slot: 'fullAddress',
    align: 'center'
  },
  {
    title: '操作',
    slot: 'action',
    width: 230,
    align: 'center'
  }
]
export const unitHeader = [
  {
    title: '本单位人员姓名',
    align: 'center',
    key: 'name'
  },
  {
    title: '手机号',
    align: 'center',
    key: 'mobilePhone'
  },
  {
    title: '功能权限',
    align: 'center',
    key: 'roleName'
  },
  {
    title: '数据权限',
    align: 'center',
    key: 'dataAuthType'
  },
  {
    title: '状态',
    align: 'center',
    slot: 'status'
  },
  {
    title: '操作',
    align: 'center',
    slot: 'action'
  }
]
