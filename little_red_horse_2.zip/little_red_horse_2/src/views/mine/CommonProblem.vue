<template>
  <div class="common-problem">
    <div class="mine-header">
      <Breadcrumb>
        <BreadcrumbItem to="/mine/personalcenter">个人中心</BreadcrumbItem>
        <BreadcrumbItem>常见问题</BreadcrumbItem>
      </Breadcrumb>
    </div>
    <div class="problem">
        <iframe src="http://mall.redhoma.cn/question_pc/" frameborder="0"></iframe>
    </div>

  </div>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import * as opt from './options'

  export default {
    name: 'Coupon',
    data() {
      return {
        tabName: 'all',
        allList: [],
        incomeList: [],
        payList: [],
        tableHeight: '',
        columns: opt.CouponHeader
      }
    },
    computed: {
      ...mapState([]),
      ...mapGetters([])
    },
    created() {
      this.initData()
      console.log(window.configs)
    },
    methods: {
      ...mapActions([]),
      initData() {
        this.getBalanceData()
      },
      // 获取充值记录
      async getBalanceData() {
      }
    }
  }
</script>

<style lang="less">
  .common-problem {
    width: 100%;
    padding: 10px;
    height: 1200px;
    border: 1px solid #e5e5e5;
    background-color: #ffffff;
    .mine-header {
      height: 35px;
      line-height: 35px;
      margin-left: 10px;
    }
    .problem {
      margin-top: 20px;
      position: relative;
      height: 1100px;
      &-selector {
        position: absolute;
        top: 0;
        right: 3px;
        .selector-date {
          width: 200px;
          padding: 0 10px;
        }
      }
      .pane-all {
      }
      iframe{
          width: 100%;
          height: 100%;
      }
    }
  }
</style>
