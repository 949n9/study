<template>
  <div class="edit-login-pwd">
    <div class="mine-header">
      <Breadcrumb>
        <BreadcrumbItem to="/mine/personalcenter">个人中心</BreadcrumbItem>
        <BreadcrumbItem>修改登录密码</BreadcrumbItem>
      </Breadcrumb>
    </div>
    <div class="edit-login-pwd-wrap">
      <Form ref="formValidate" :model="formItem" :label-width="120" :rules="ruleValidate">
        <FormItem label="原密码：" prop="oldPassword">
          <Input class="ipt" type="password" :maxlength="50" v-model="formItem.oldPassword"
                 placeholder="请输入原密码"></Input>
        </FormItem>
        <FormItem label="新密码：" prop="newPassword" class="ivu-form-item-required">
          <Poptip placement="right" width="280">
            <Input class="ipt" type="password" :maxlength="20" v-model="formItem.newPassword"
                   placeholder="请输入新密码"></Input>
            <div slot="content">
              <p>密码必须是8位或8位以上字母和数字组合！</p>
              <p>不可以全是数字，也不可以全是字母！</p>
            </div>
          </Poptip>
        </FormItem>
        <FormItem label="确认新密码：" prop="confirmPassword" class="ivu-form-item-required">
          <Input class="ipt" type="password" :maxlength="20" v-model="formItem.confirmPassword"
                 placeholder="确认新密码" @on-enter="handleSubmit('formValidate')"></Input>
        </FormItem>
        <FormItem>
          <Button type="primary" :disabled="loading" @click="handleSubmit('formValidate')">确定</Button>
        </FormItem>
      </Form>
    </div>

  </div>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'
  import validator from '../../utils/validator'

  export default {
    name: 'EditLoginPwd',
    data() {
      const validatePassCheck = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('确认新密码！'))
        } else if (value !== this.formItem.newPassword) {
          callback(new Error('两次输入的密码不一致！'))
        } else {
          callback()
        }
      }
      return {
        formItem: {
          oldPassword: '',
          newPassword: '',
          confirmPassword: ''
        },
        ruleValidate: {
          oldPassword: [
            {required: true, message: '请输入原密码！', trigger: 'blur'}
          ],
          newPassword: [
            {validator: validator.validateNewPass, trigger: 'blur'}
          ],
          confirmPassword: [
            {validator: validatePassCheck, trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapState([
        'loading'
      ]),
      ...mapGetters([])
    },
    created() {
      this.initData()
    },
    methods: {
      ...mapActions([]),
      initData() {
      },
      handleSubmit(name) {
        this.$refs[name].validate((valid) => {
          if (valid) {
            this.submit()
          } else {
          }
        })
      },
      // 获取充值记录
      async submit() {
        let self = this
        let params = {
          oldPassword: self.formItem.oldPassword,
          newPassword: self.formItem.newPassword,
          confirmPassword: self.formItem.confirmPassword
        }
        let {data} = await api.getUpdatePassword(params)
        if (data.status == 0) {
          self.$Notice.success({
            desc: data.message
          })
          self.clearForm()
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
        console.log(data)
      },
      clearForm() {
        this.formItem = {
          oldPassword: '',
          newPassword: '',
          confirmPassword: ''
        }
      }
    }
  }
</script>

<style lang="less">
  .edit-login-pwd {
    width: 100%;
    height: 500px;
    padding: 10px;
    border: 1px solid #e5e5e5;
    background-color: #ffffff;

    .mine-header {
      height: 35px;
      line-height: 35px;
      margin-left: 10px;
    }

    .edit-login-pwd-wrap {
      margin-top: 40px;
      padding-left: 100px;
      position: relative;

      .ipt {
        width: 200px;
      }
    }
  }
</style>
