<template>
  <div class="order-unit">
    <div class="mine-header">
      <Breadcrumb>
        <BreadcrumbItem to="/mine/personalcenter">个人中心</BreadcrumbItem>
        <BreadcrumbItem>门店管理</BreadcrumbItem>
      </Breadcrumb>
    </div>
    <!--<div class="order-unit-add">-->
    <!--<Button type="default" class="red&#45;&#45;text" :disabled="loading" @click="addUnit">-->
    <!--<Icon type="md-add-circle"/>-->
    <!--新增订货单位-->
    <!--</Button>-->
    <!--</div>-->

    <div class="order-unit-table">
      <Tabs :value="tabName" type="card">
        <TabPane label="全部" name="all">
          <div class="pane-all">
            <Table size="small" border :loading="loading" :height="tableHeight" :columns="columns" :data="allList">
              <template slot-scope="{ row }" slot="useStatus">
                <span v-if="row.status=='0'">审核中</span>
                <div v-else>
                  <span v-if="row.useStatus=='0'">在用</span>
                  <span v-else>停用</span>
                </div>
              </template>
              <template slot-scope="{ row }" slot="address">
                <p :title="row.subCustomerAddress" class="table-address">
                  {{row.subCustomerAddress}}</p>
                <Button v-if="row.status!=0" type="text" size="small" class="red--text" @click="showAddress(row)">查看更多
                </Button>
              </template>
              <template slot-scope="{ row }" slot="action">
                <Button type="text" size="small" style="margin-right: 5px" @click="show(row)">查看</Button>
                <Button @click="edit(row)" size="small" type="text" v-show="row.status!='0' && userData.admin==1">编辑
                </Button>
              </template>
            </Table>
          </div>
        </TabPane>

        <TabPane label="审核中" name="audit">
          <div class="pane-all">
            <Table size="small" border :loading="loading" :height="tableHeight" :columns="columns" :data="auditList">
              <template slot-scope="{ row }" slot="useStatus">
                <span v-if="row.status=='0'">审核中</span>
                <div v-else>
                  <span v-if="row.useStatus=='0'">在用</span>
                  <span v-else>停用</span>
                </div>
              </template>
              <template slot-scope="{ row }" slot="address">
                <p :title="row.subCustomerAddress" class="table-address">
                  {{row.subCustomerAddress}}</p>
              </template>
              <template slot-scope="{ row }" slot="action">
                <Button type="text" size="small" style="margin-right: 5px" @click="show(row)">查看</Button>
              </template>
            </Table>
          </div>
        </TabPane>
        <TabPane label="在用" name="using">
          <div class="pane-all">
            <Table size="small" border :loading="loading" :height="tableHeight" :columns="columns" :data="usingList">
              <template slot-scope="{ row }" slot="useStatus">
                <span v-if="row.status=='0'">审核中</span>
                <div v-else>
                  <span v-if="row.useStatus=='0'">在用</span>
                  <span v-else>停用</span>
                </div>
              </template>
              <template slot-scope="{ row }" slot="address">
                <p :title="row.subCustomerAddress" class="table-address">
                  {{row.subCustomerAddress}}</p>
                <Button v-if="row.status!=0" type="text" size="small" class="red--text" @click="showAddress(row)">查看更多
                </Button>
              </template>
              <template slot-scope="{ row }" slot="action">
                <Button type="text" size="small" style="margin-right: 5px" @click="show(row)">查看</Button>
                <Button @click="edit(row)" size="small" type="text" v-show="row.status!='0' && userData.admin==1">编辑
                </Button>
              </template>
            </Table>
          </div>
        </TabPane>
        <TabPane label="停用" name="unusing">
          <div class="pane-all">
            <Table size="small" border :loading="loading" :height="tableHeight" :columns="columns" :data="unusingList">
              <template slot-scope="{ row }" slot="useStatus">
                <span v-if="row.status=='0'">审核中</span>
                <div v-else>
                  <span v-if="row.useStatus=='0'">在用</span>
                  <span v-else>停用</span>
                </div>
              </template>
              <template slot-scope="{ row }" slot="address">
                <p :title="row.receiveAddress" class="table-address">
                  {{row.receiveAddress}}</p>
                <Button v-if="row.status!=0" type="text" size="small" class="red--text" @click="showAddress(row)">查看更多
                </Button>
              </template>
              <template slot-scope="{ row }" slot="action">
                <Button type="text" size="small" style="margin-right: 5px" @click="show(row)">查看</Button>
                <Button @click="edit(row)" size="small" type="text" v-show="row.status!='0' && userData.admin==1">编辑
                </Button>
              </template>
            </Table>
          </div>
        </TabPane>
      </Tabs>
    </div>
    <unit-dialog @editUnit="editUnit"></unit-dialog>
  </div>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'
  import * as opt from './options'
  import UnitDialog from './components/AddUnitDialog'

  export default {
    name: 'OrderUnit',
    components: {
      UnitDialog
    },
    data() {
      return {
        name: '',
        tabName: 'all',
        allList: [],
        auditList: [],
        usingList: [],
        unusingList: [],
        tableHeight: '',
        columns: opt.orderUnitHeader
      }
    },
    computed: {
      ...mapState([
        'loading'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    created() {
      this.handleBaseDialog({visible: false, type: 'addUnitVisible'})
      this.initData()
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'handleBasicInfo'
      ]),
      initData() {
        this.tableHeight = 500
        this.getData()
      },
      // 弹窗中 进行编辑触发
      editUnit(v) {
        console.log(v)
        this.getData()
      },
      // 增加订货单位
      addUnit() {
        this.handleBaseDialog({visible: true, type: 'addUnitVisible', title: '新增'})
      },
      // 获取 订货单位列表
      async getData() {
        let self = this
        let params = {
          searchCondtion: '123',
          pageSize: 99999
        }
        let {data} = await api.getSubList(params)
        if (data.status == 0) {
          let arr = data.data.list
          self.allList = arr
          self.auditList = arr.filter(item => item.status == 0)
          self.usingList = arr.filter(item => item.status == 1 && item.useStatus == 0)
          self.unusingList = arr.filter(item => item.status == 1 && item.useStatus == 1)
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      show(row) {
        console.log(row)
        this.handleBaseDialog({visible: true, type: 'addUnitVisible', title: '详情'})
        this.handleBasicInfo(row)
      },
      edit(row) {
        this.handleBaseDialog({visible: true, type: 'addUnitVisible', title: '编辑'})
        this.handleBasicInfo(row)
      },
      // 查看收货信息
      showAddress(row) {
        this.$router.push({path: '/mine/deliveryaddress', query: {id: row.id}})
      }
    }
  }
</script>

<style lang="less">
  .order-unit {
    width: 100%;
    padding: 10px;
    border: 1px solid #e5e5e5;
    background-color: #ffffff;

    .mine-header {
      height: 35px;
      line-height: 35px;
      margin-left: 10px;
    }

    .order-unit-add {
      padding: 20px 0;
      display: flex;
      justify-content: space-between;

      .ipt {
        width: 350px;
      }
    }

    .order-unit-table {
      margin-top: 40px;
      position: relative;

      .pane-all {
      }

      .table-address {
        width: 100%;
        text-align: center;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
    }
  }
</style>
