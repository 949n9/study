<template>
  <Modal
    :value="addUnitVisible"
    :title="'订货单位-'+dialogTitle"
    :mask-closable="false"
    width="900"
    :styles="{top: '50px'}"
    :loading="loading"
    @on-visible-change="dialogChange"
  >
    <div class="modal-wrap" :style="{'max-height':tabHeight+'px'}" v-if="dialogTitle=='详情'">
      <Form label-position="right" :model="formItem" :label-width="110">
        <Row>
          <Col span="12" style="border-right: 1px dashed #cccccc">
            <!--<p class="form-title">基本信息：</p>-->
            <FormItem label="订货单位名称：" class="ivu-form-item-required">
              <Input class="ipt" readonly v-model="formItem.subCustomerName"
              ></Input>
            </FormItem>
            <FormItem label="联系人：" class="ivu-form-item-required">
              <Input class="ipt" readonly v-model="formItem.subCustomerContactName"
              ></Input>
            </FormItem>
            <FormItem label="手机：" class="ivu-form-item-required">
              <Input class="ipt" readonly v-model="formItem.subCustomerMobilePhone"
              ></Input>
            </FormItem>
            <FormItem label="单位地区：" class="ivu-form-item-required">
              <Input class="ipt" readonly v-model="formItem.customerAreaName"
              ></Input>
            </FormItem>
            <FormItem label="">
              <Input class="ipt" readonly v-model="formItem.subCustomerAddress"
                     type="textarea" :rows="2"></Input>
            </FormItem>
            <FormItem label="服务商业务员：" class="ivu-form-item-required">
              <Input class="ipt" readonly v-model="formItem.subCustomerProviderUserName"
              ></Input>
            </FormItem>
          </Col>

          <Col span="11">
            <!--<p class="form-title">基本信息：</p>-->
            <FormItem label="收货人：" v-show="baseInfo.status==0" class="ivu-form-item-required">
              <Input class="ipt" readonly v-model="formItem.receiverName"
              ></Input>
            </FormItem>
            <FormItem label="手机：" v-show="baseInfo.status==0" class="ivu-form-item-required">
              <Input class="ipt" readonly v-model="formItem.receiveMobilePhone"
              ></Input>
            </FormItem>
            <FormItem label="其他电话：" v-show="baseInfo.status==0">
              <Input class="ipt" readonly v-model="formItem.receiveTelephone"
              ></Input>
            </FormItem>
            <FormItem label="收货地址：" v-show="baseInfo.status==0" class="ivu-form-item-required">
              <Input class="ipt" readonly v-model="formItem.receiveRegionName"
              ></Input>
            </FormItem>
            <FormItem label="" v-show="baseInfo.status==0">
              <Input class="ipt" readonly v-model="formItem.receiveAddress"
                     type="textarea" :rows="2"></Input>
            </FormItem>
            <FormItem label="营业面积：" class="ivu-form-item-required">
              <Input class="ipt" readonly v-model="formItem.businessArea">
                <span slot="append">㎡</span>
              </Input>
            </FormItem>
            <FormItem label="状态：" v-show="baseInfo.status>0" class="ivu-form-item-required">
              <span>{{formItem.useStatusName}}</span>
            </FormItem>
            <FormItem label="营业执照：" v-if="formItem.licenseImgUrl">
              <div style="display: flex">
                <div class="add-up-load-img">
                  <img :src="formItem.licenseImgUrl" alt="" class="img" :onerror="defaultPimg()"
                       @click="openImgModal(formItem.licenseImgUrl)">
                </div>
              </div>
            </FormItem>
            <FormItem label="门头照：" v-if="formItem.doorHeadImgUrl">
              <div style="display: flex">
                <div class="add-up-load-img">
                  <img :src="formItem.doorHeadImgUrl" alt="" class="img" :onerror="defaultPimg()"
                       @click="openImgModal(formItem.doorHeadImgUrl)">
                </div>
              </div>
            </FormItem>
            <FormItem label="店内照：" v-if="formItem.storeInternalImgUrl">
              <div style="display: flex">
                <div class="add-up-load-img">
                  <img :src="formItem.storeInternalImgUrl" alt="" class="img" :onerror="defaultPimg()"
                       @click="openImgModal(formItem.storeInternalImgUrl)">
                </div>
              </div>
            </FormItem>
          </Col>
        </Row>
      </Form>
    </div>

    <div class="modal-wrap" :style="{'max-height':tabHeight+'px'}" v-else>
      <Form label-position="right" ref="formValidate" :model="formItem" :label-width="110" :rules="ruleValidate">
        <Row>
          <Col span="10" style="border-right: 1px dashed #cccccc">
            <!--<p class="form-title">基本信息：</p>-->
            <FormItem label="订货单位名称：" prop="subCustomerName">
              <Input :maxlength="50" class="ipt" readonly v-model="formItem.subCustomerName"
                     placeholder="请输入订货单位名称"></Input>
            </FormItem>
            <FormItem label="联系人：" prop="subCustomerContactName">
              <Input class="ipt" :maxlength="10" v-model="formItem.subCustomerContactName" clearable
                     placeholder="请输入联系人姓名"></Input>
            </FormItem>
            <FormItem label="手机：" prop="subCustomerMobilePhone" class="ivu-form-item-required">
              <Input class="ipt" :maxlength="11" v-model="formItem.subCustomerMobilePhone" clearable
                     placeholder="请输入手机号码"></Input>
            </FormItem>
            <FormItem label="单位地区：" class="ivu-form-item-required">
              <Cascader class="ipt" :data="areaData"
                        placeholder="请选择单位地区"
                        disabled
                        :load-data="loadData"
                        v-model="areaArr"></Cascader>
            </FormItem>
            <FormItem label="" prop="subCustomerAddress">
              <Input class="ipt" :maxlength="50" v-model="formItem.subCustomerAddress"
                     readonly
                     type="textarea" :rows="2" placeholder="请输入详细地址（必填）"></Input>
            </FormItem>
            <FormItem label="服务商业务员：" prop="subCustomerProviderUserId">
              <Select class="ipt" disabled placeholder="请选择业务员" v-model="formItem.subCustomerProviderUserId">
                <Option v-for="item in providerUsersList" :value="item.id" :key="item.id">{{ item.name }}</Option>
              </Select>
            </FormItem>
          </Col>

          <Col span="14">
            <!--<p class="form-title">基本信息：</p>-->
            <FormItem label="收货人：" v-show="dialogTitle=='新增'" prop="receiverName">
              <Input class="ipt" :maxlength="10" v-model="formItem.receiverName" clearable
                     placeholder="请输入收货人姓名"></Input>
            </FormItem>
            <FormItem label="手机：" v-show="dialogTitle=='新增'" prop="receiveMobilePhone" class="ivu-form-item-required">
              <Input class="ipt" :maxlength="11" v-model="formItem.receiveMobilePhone" clearable
                     placeholder="请输入收货人手机号码"></Input>
            </FormItem>
            <FormItem label="其他电话：" v-show="dialogTitle=='新增'" prop="receiveTelephone">
              <Input class="ipt" :maxlength="50" v-model="formItem.receiveTelephone" clearable
                     placeholder="请输入其他联系电话"></Input>
            </FormItem>
            <FormItem label="收货地址：" v-show="dialogTitle=='新增'" class="ivu-form-item-required">
              <Cascader class="ipt" :data="regionData"
                        disabled
                        placeholder="请选择收货地址"
                        :load-data="loadData2"
                        v-model="regionArr"></Cascader>
            </FormItem>
            <FormItem label="" v-show="dialogTitle=='新增'" prop="receiveAddress">
              <Input :maxlength="50" class="ipt" v-model="formItem.receiveAddress"
                     type="textarea" :rows="2" placeholder="请输入详细地址（必填）"></Input>
            </FormItem>
            <FormItem label="营业面积：" prop="businessArea">
              <Input :maxlength="6" @on-change="handleChange" class="ipt" readonly v-model="formItem.businessArea"
                     placeholder="请输入营业面积">
                <span slot="append">㎡</span>
              </Input>
            </FormItem>
            <FormItem label="状态：" v-show="dialogTitle=='编辑'" class="ivu-form-item-required">
              <i-switch @on-change="useStatusChange" disabled size="large" v-model="formItem.useStatus">
                <span slot="open">在用</span>
                <span slot="close">停用</span>
              </i-switch>
            </FormItem>

            <FormItem label="营业执照：" class="ivu-form-item-required">
              <p class="grey--text" style="margin-top: 8px;line-height: 18px;">请上传营业执照的清晰扫描件或照片，提交后不可更改</p>
              <div style="display: flex">
                <div class="add-up-load-img" v-if="formItem.licenseImgUrl">
                  <img :src="formItem.licenseImgUrl" alt="" class="img" :onerror="defaultPimg()"
                       @click="openImgModal(formItem.licenseImgUrl)">
                  <Icon v-if="dialogTitle=='新增'" type="md-close" class="remove-btn" color="white"
                        size="18"
                        @click="removeImg(1)"/>
                </div>
                <div class="add-up-load-wrap" v-else>
                  <input type="file" title="" @change="(e)=>doUpload(e,1)" class="ipt"
                         accept="image/gif,image/jpeg,image/jpg,image/png"/>
                  <Icon type="md-add" style="font-weight: 700" size="25"/>
                  <p>上传</p>
                </div>
                <div class="add-up-load-img" style="margin-left: 20px" v-if="!formItem.licenseImgUrl">
                  <img :src="yyImg" alt="" class="img" @click="openImgModal(yyImg)">
                  <span class="desc">示图例</span>
                </div>
              </div>
            </FormItem>
            <FormItem label="门头照：" class="ivu-form-item-required">
              <p class="grey--text">请上传门头的清晰照片，提交后不可更改</p>
              <div style="display: flex">
                <div class="add-up-load-img" v-if="formItem.doorHeadImgUrl">
                  <img :src="formItem.doorHeadImgUrl" alt="" class="img" :onerror="defaultPimg()"
                       @click="openImgModal(formItem.doorHeadImgUrl)">
                  <Icon v-if="dialogTitle=='新增'" type="md-close" color="white" class="remove-btn" size="18"
                        @click="removeImg(2)"/>
                </div>
                <div class="add-up-load-wrap" v-else>
                  <input type="file" title="" @change="(e)=>doUpload(e,2)" class="ipt"
                         accept="image/gif,image/jpeg,image/jpg,image/png"/>
                  <Icon type="md-add" style="font-weight: 700" size="25"/>
                  <p>上传</p>
                </div>
                <div class="add-up-load-img" style="margin-left: 20px" v-if="!formItem.doorHeadImgUrl">
                  <img :src="mtImg" alt="" class="img" @click="openImgModal(mtImg)">
                  <span class="desc">示图例</span>
                </div>
              </div>
            </FormItem>
            <FormItem label="店内照：" class="ivu-form-item-required">
              <p class="grey--text">请上传店内的清晰照片，提交后不可更改</p>
              <div style="display: flex">
                <div class="add-up-load-img" v-if="formItem.storeInternalImgUrl">
                  <img :src="formItem.storeInternalImgUrl" alt="" class="img" :onerror="defaultPimg()"
                       @click="openImgModal(formItem.storeInternalImgUrl)">
                  <Icon v-if="dialogTitle=='新增'" type="md-close" color="white" class="remove-btn" size="18"
                        @click="removeImg(3)"/>
                </div>
                <div class="add-up-load-wrap" v-else>
                  <input type="file" title="" @change="(e)=>doUpload(e,3)" class="ipt"
                         accept="image/gif,image/jpeg,image/jpg,image/png"/>
                  <Icon type="md-add" style="font-weight: 700" size="25"/>
                  <p>上传</p>
                </div>
                <div class="add-up-load-img" style="margin-left: 20px" v-if="!formItem.storeInternalImgUrl">
                  <img :src="dnImg" alt="" class="img" @click="openImgModal(dnImg)">
                  <span class="desc">示图例</span>
                </div>
              </div>
            </FormItem>
          </Col>
        </Row>
      </Form>
    </div>

    <Modal title=" " v-model="imgModal" footer-hide>
      <img :src="bigImg" style="width: 100%" :onerror="defaultPimg()">
    </Modal>

    <div slot="footer">
      <Button type="primary" size="large" v-if="dialogTitle=='详情'" @click="cancel">关闭</Button>
      <Button type="primary" size="large" v-if="dialogTitle=='新增'" @click="submit">提交</Button>
      <Button type="primary" size="large" v-if="dialogTitle=='编辑'" @click="submit">保存</Button>
    </div>
  </Modal>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../../core/index'
  import utils from '../../../utils/index'
  import validator from '../../../utils/validator'

  export default {
    name: '',
    data() {
      return {
        areaData: [],
        regionData: [],
        providerUsersList: [],
        tabHeight: '',

        bigImg: '',
        imgModal: false,

        fixedData: {
          customerName: '1',
          customerContactName: '1',
          customerMobilePhone: '15836912345',
          customerAreaId: '1',
          customerAddress: '1',
          customerUserMobilePhone: '15888888888'
        },
        formItem: {
          subCustomerName: '',
          subCustomerContactName: '',
          subCustomerMobilePhone: '',
          subCustomerAreaId: '',
          subCustomerAddress: '',
          subCustomerProviderUserId: '',
          receiveRegionId: '',
          receiverName: '',
          receiveMobilePhone: '',
          receiveTelephone: '',
          receiveAddress: '',
          businessArea: '',
          useStatus: true,
          licenseImgUrl: '',
          doorHeadImgUrl: '',
          storeInternalImgUrl: ''
        },
        areaArr: [],
        regionArr: [],
        ruleValidate: {
          subCustomerName: [
            {required: true, message: '请输入订货单位名称', trigger: 'blur'}
          ],
          subCustomerContactName: [
            {required: true, message: '请输入联系人姓名', trigger: 'blur'}
          ],
          subCustomerMobilePhone: [
            {validator: validator.validatePhone, trigger: 'change', msg: ''}
          ],
          subCustomerAddress: [
            {required: true, message: '请输入详细地区', trigger: 'blur'}
          ],
          subCustomerProviderUserId: [
            {required: true, message: '请选择业务员', trigger: 'change'}
          ],
          receiverName: [
            {required: true, message: '请输入收货人姓名', trigger: 'blur'}
          ],
          receiveMobilePhone: [
            {validator: validator.validatePhone, trigger: 'change', msg: '收货人'}
          ],
          receiveAddress: [
            {required: true, message: '请输入详细地址', trigger: 'blur'}
          ],
          businessArea: [
            {required: true, message: '请输入营业面积', trigger: 'blur'}
          ],
          licenseImgUrl: [
            {required: true, message: '请上传营业执照', trigger: 'change'}
          ],
          doorHeadImgUrl: [
            {required: true, message: '请上传门头照', trigger: 'change'}
          ],
          storeInternalImgUrl: [
            {required: true, message: '请上传店内照', trigger: 'change'}
          ]
        },
        // 营业执照地址：  // 门头照地址：  // 店内照地址：
        yyImg: 'https://aiqin.oss-cn-beijing.aliyuncs.com/attachment/xyapp/%E8%90%A5%E4%B8%9A%E6%89%A7%E7%85%A7.jpg',
        mtImg: 'https://aiqin.oss-cn-beijing.aliyuncs.com/attachment/xyapp/%E9%97%A8%E5%A4%B4%E7%85%A7.png',
        dnImg: 'https://aiqin.oss-cn-beijing.aliyuncs.com/attachment/xyapp/%E5%BA%97%E5%86%85%E7%85%A7.png'
      }
    },
    created() {
      this.getAreaList()
      this.getRegionList()
      this.getProviderUsers()
    },
    computed: {
      ...mapState([
        'loading',
        'addUnitVisible',
        'baseInfo',
        'dialogTitle'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'handleBasicInfo'
      ]),
      dialogChange(v) {
        if (v) {
          console.log(this.baseInfo)
          if (this.$refs['formValidate']) {
            this.$refs['formValidate'].resetFields()
          }
          this.handleOpen()
          let h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
          this.tabHeight = h - 200
        } else {
          this.cancel()
        }
      },
      // 切换用户状态
      useStatusChange(v) {
        console.log(v)
        console.log(this.formItem.useStatus)
      },
      // 处理是否是编辑
      handleOpen() {
        console.log(this.baseInfo)
        if (this.dialogTitle == '详情' || this.dialogTitle == '编辑') {
          this.getSubDetailInfo()
        } else {
          this.formItem = {}
        }
      },
      // 获取订货单位详情信息
      async getSubDetailInfo() {
        let self = this
        let params = {
          id: self.baseInfo.id,
          status: self.baseInfo.status
        }
        let {data} = await api.getSubDetail(params)
        console.log(data)
        let obj = data.data
        obj.useStatus = obj.useStatus === '0'
        self.formItem = obj

        // 处理地区反推到 名称
        let areaId = data.data.subCustomerAreaId
        let areaFirst = areaId.substring(0, 2) + '0000'
        self.areaArr = [areaFirst, areaId]

        let regionId = data.data.receiveRegionId
        let regionFirst = regionId.substring(0, 2) + '0000'
        let regionSecond = regionId.substring(0, 4) + '00'

        if (regionId.substring(5, 6) == '0') {
          self.regionArr = [regionFirst, regionId]
        } else {
          self.regionArr = [regionFirst, regionSecond, regionId]
        }
      },
      // 获取订货单位地区列表
      async getAreaList() {
        let self = this
        let params = {}
        let {data} = await api.getAreaList(params)
        console.log(data)
        let arr = data.data
        arr.forEach((item, index) => {
          item.label = item.name
          item.value = item.code
          item.loading = !item.isParent
        })
        self.areaData = arr
      },
      // 获取收货信息地区列表
      async getRegionList() {
        let self = this
        let params = {}
        let {data} = await api.getRegionList(params)
        console.log(data)
        let arr = data.data
        arr.forEach((item, index) => {
          item.label = item.name
          item.value = item.code
          item.loading = !item.isParent
        })
        self.regionData = arr
      },
      async loadData(item, callback) {
        console.log(item)
        item.loading = true

        let params = {
          parentId: item.id
        }
        let {data} = await api.getAreaList(params)

        let arr = data.data
        arr.forEach((item, index) => {
          item.label = item.name
          item.value = item.code
        })
        item.children = arr
        item.loading = false
        callback()
      },
      async loadData2(item, callback) {
        console.log(item)
        item.loading = true
        let params = {
          parentId: item.id
        }
        let {data} = await api.getRegionList(params)

        let arr = data.data
        arr.forEach((item, index) => {
          item.label = item.name
          item.value = item.code
          if (item.isParent) {
            item.loading = false
          }
        })
        item.children = arr
        item.loading = false
        callback()
      },
      submit() {
        console.log(this.formItem)
        this.$refs['formValidate'].validate((valid) => {
          if (valid) {
            this.handleSubmit()
          } else {
          }
        })
      },
      async getProviderUsers() {
        let self = this
        let {data} = await api.getProviderUsers({})
        console.log(data)
        self.providerUsersList = data.data.list
      },
      async handleSubmit() {
        let self = this
        let params = self.formItem
        if (self.dialogTitle == '编辑') {
          params.id = self.baseInfo.id
        }
        Object.assign(params, self.fixedData)
        console.log(params)
        params = JSON.stringify(params)
        params = JSON.parse(params)
        params.subCustomerAreaId = self.areaArr[self.areaArr.length - 1]
        params.receiveRegionId = self.regionArr[self.regionArr.length - 1]
        console.log(params)
        if (self.dialogTitle == '编辑') {
          params.useStatus = params.useStatus ? 0 : 1
          let {data} = await api.getUpdateSub(params)
          console.log(data)
          if (data.status == 0) {
            self.$Notice.success({
              desc: data.message
            })
            self.$emit('editUnit', 'add')
            self.cancel()
          } else {
            self.$Notice.error({
              desc: data.message
            })
          }
        } else {
          params.useStatus = 0
          let {data} = await api.getAddSub(params)
          console.log(data)
          if (data.status == 0) {
            self.$Notice.success({
              desc: data.message
            })
            self.$emit('editUnit', 'add')
            self.cancel()
          } else {
            self.$Notice.error({
              desc: data.message
            })
          }
        }
      },
      cancel() {
        this.formItem = {}
        this.areaArr = []
        this.regionArr = []
        this.handleBaseDialog({visible: false, type: 'addUnitVisible'})
        this.handleBasicInfo({})
        if (this.$refs['formValidate']) {
          this.$refs['formValidate'].resetFields()
        }
      },
      // 看大图
      openImgModal(url) {
        this.imgModal = true
        this.bigImg = url
      },
      // 删除已经上传的图片
      removeImg(type) {
        if (type == 1) {
          this.$set(this.formItem, 'licenseImgUrl', '')
        } else if (type == 2) {
          this.$set(this.formItem, 'doorHeadImgUrl', '')
        } else if (type == 3) {
          this.$set(this.formItem, 'storeInternalImgUrl', '')
        }
      },
      // 上传公司凭证
      doUpload(e, picIndex) {
        let self = this
        let client = new OSS.Wrapper({
          region: 'oss-cn-beijing',
          accessKeyId: this.userData.ossAccessKeyId,
          accessKeySecret: this.userData.ossAccessKeySecret,
          bucket: this.userData.ossBucketName
        })
        let file = e.target.files[0]
        let imgSize = file.size
        console.log(imgSize)
        if (imgSize > 100 * 1024 * 1024) {
          self.$Notice.error({
            desc: '上传图片大小不能大于100M'
          })
          return
        }
        let type = file.type.substring(6)
        let fileName = this.userData.ossCustomerUploadPath + this.$moment().format('YYYYMMDD/') + utils.uuid(28) + '.' + type
        client.multipartUpload(fileName, file).then(function (result) {
          console.log(result)
          console.log(self.userData)
          if (result.res.status == 200) {
            if (picIndex == 1) {
              self.$set(self.formItem, 'licenseImgUrl', self.userData.ossImgUrl + '/' + result.name)
            } else if (picIndex == 2) {
              self.$set(self.formItem, 'doorHeadImgUrl', self.userData.ossImgUrl + '/' + result.name)
            } else if (picIndex == 3) {
              self.$set(self.formItem, 'storeInternalImgUrl', self.userData.ossImgUrl + '/' + result.name)
            }
          }
        }).catch(function (err) {
          console.log(err)
        })
      },
      // 处理营业面积录入
      handleChange() {
        let businessArea = this.formItem.businessArea + ''
        businessArea = parseInt(businessArea) + ''
        this.$nextTick(() => {
          this.formItem.businessArea = businessArea.replace(/[^\d]/g, '')
        })
      }
    }
  }
</script>

<style lang="less">
  .modal-wrap {
    padding: 0 20px;
    position: relative;

    .form-title {
      font-size: 16px;
    }

    .form-r {
      padding-left: 20px;
    }

    .ipt {
      width: 200px;
    }

    .grey--text {
      color: #999999;
    }
  }

  .add-up-load-wrap {
    height: 80px;
    width: 80px;
    background-color: #f9f9f9;
    text-align: center;
    padding: 15px 0;
    border: 1px dashed #dcdee2;
    cursor: pointer;
    position: relative;

    p {
      font-size: 12px;
    }

    .ipt {
      position: absolute;
      left: 0;
      top: 0;
      opacity: 0;
      z-index: 10;
      width: 100%;
      height: 100%;
    }
  }

  .add-up-load-wrap:hover {
    border: 1px dashed #E61E10;
  }

  .add-up-load-img {
    text-align: center;
    position: relative;
    height: 80px;
    width: 80px;

    .desc {
      position: absolute;
      bottom: 0px;
      left: 0px;
      color: #ffffff;
      background-color: #999999;
      display: inline-block;
      width: 80px;
      height: 20px;
      line-height: 20px;
      text-align: center;
      font-size: 12px;
    }

    .img {
      border: 1px solid #cccccc;
      height: 80px;
      width: 80px;
      padding: 2px;
      cursor: pointer;
    }

    .remove-btn {
      position: absolute;
      right: 4px;
      top: 4px;
      background: #585858;
      padding: 3px;
      z-index: 99999;
      display: none;
    }
  }

  .add-up-load-img:hover {
    .remove-btn {
      display: block;
    }
  }
</style>
