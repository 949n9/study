<template>
  <Modal
    :value="addAddressVisible"
    :title="'收货地址-'+dialogTitle"
    :mask-closable="false"
    width="550"
    :styles="{top: '50px'}"
    :loading="loading"
    @on-visible-change="dialogChange"
  >
    <div class="modal-wrap">
      <Form label-position="right" ref="formValidate" :model="formItem" :label-width="110" :rules="ruleValidate">
        <FormItem label="收货人：" prop="receiver">
          <Input class="ipt" :maxlength="10" v-model="formItem.receiver" clearable
                 placeholder="请输入收货人姓名"></Input>
        </FormItem>
        <FormItem label="手机：" prop="receiveMobilePhone" class="ivu-form-item-required">
          <Input class="ipt" :maxlength="11" v-model="formItem.receiveMobilePhone" clearable
                 placeholder="请输入收货人手机号码"></Input>
        </FormItem>
        <FormItem label="其他电话：" prop="receiveTelePhone">
          <Input class="ipt" :maxlength="50" v-model="formItem.receiveTelePhone" clearable
                 placeholder="请输入其他联系电话"></Input>
        </FormItem>
        <FormItem label="收货地址：" class="ivu-form-item-required">
          <Cascader class="ipt" :data="regionData"
                    placeholder="请选择收货地址"
                    :load-data="loadData2"
                    v-model="regionArr">
          </Cascader>
        </FormItem>
        <FormItem label="" prop="receiveAddress">
          <Input class="ipt" :maxlength="50" v-model="formItem.receiveAddress"
                 type="textarea" :rows="2" placeholder="请输入详细地址（必填）"></Input>
        </FormItem>
        <FormItem label="状态：" v-show="dialogTitle=='编辑'" class="ivu-form-item-required">
          <Checkbox v-model="formItem.isDefault" :disabled="editAble">设为默认收货地址</Checkbox>
        </FormItem>
      </Form>
    </div>
    <div slot="footer">
      <Button type="primary" v-if="dialogTitle=='新增'" @click="submit">提交</Button>
      <Button type="primary" v-if="dialogTitle=='编辑'" @click="submit">保存</Button>
    </div>
  </Modal>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../../core/index'
  import validator from '../../../utils/validator'

  export default {
    name: '',
    data() {
      return {
        areaData: [],
        regionData: [],
        editAble: false,

        formItem: {
          receiver: '',
          receiveMobilePhone: '',
          receiveTelePhone: '',
          receiveAddress: '',
          isDefault: false
        },
        areaArr: [],
        regionArr: [],

        ruleValidate: {
          receiver: [
            {validator: validator.validateName, trigger: 'change', msg: ''}
          ],
          receiveMobilePhone: [
            {validator: validator.validatePhone, trigger: 'change', msg: '收货人'}
          ],
          receiveAddress: [
            {required: true, message: '请输入详细地址', trigger: 'blur'}
          ]
        }
      }
    },
    created() {
      this.getAreaList()
      this.getRegionList()
    },
    computed: {
      ...mapState([
        'loading',
        'addAddressVisible',
        'baseInfo',
        'dialogTitle'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'handleBasicInfo',
        'handleAddressEdit'
      ]),
      dialogChange(v) {
        if (v) {
          console.log(this.baseInfo)
          this.handleOpen()
        } else {
          this.cancel()
        }
      },
      // 处理是否是编辑
      handleOpen() {
        console.log(this.baseInfo)
        if (this.dialogTitle == '编辑') {
          this.getSubDetailInfo()
        } else {
          this.formItem = {}
        }
      },
      // 获取订货单位详情信息
      async getSubDetailInfo() {
        let self = this
        let params = {
          id: self.baseInfo.id
        }
        let {data} = await api.getReceiveAddressDetail(params)
        console.log(data)
        let obj = data.data
        self.editAble = obj.isDefault === '1'
        obj.isDefault = obj.isDefault === '1'
        self.formItem = obj

        // 处理地区反推到 名称
        let regionId = data.data.receiveRegionId
        let regionFirst = regionId.substring(0, 2) + '0000'
        let regionSecond = regionId.substring(0, 4) + '00'

        if (regionId.substring(5, 6) == '0') {
          self.regionArr = [regionFirst, regionId]
        } else {
          self.regionArr = [regionFirst, regionSecond, regionId]
        }
      },
      // 获取订货单位地区列表
      async getAreaList() {
        let self = this
        let params = {}
        let {data} = await api.getAreaList(params)
        console.log(data)
        let arr = data.data
        arr.forEach((item, index) => {
          item.label = item.name
          item.value = item.code
          item.loading = !item.isParent
        })
        self.areaData = arr
      },
      // 获取收货信息地区列表
      async getRegionList() {
        let self = this
        let params = {}
        let {data} = await api.getRegionList(params)
        console.log(data)
        let arr = data.data
        arr.forEach((item, index) => {
          item.label = item.name
          item.value = item.code
          item.loading = !item.isParent
        })
        self.regionData = arr
      },
      async loadData2(item, callback) {
        console.log(item)
        item.loading = true
        let params = {
          parentId: item.id
        }
        let {data} = await api.getRegionList(params)

        let arr = data.data
        arr.forEach((item, index) => {
          item.label = item.name
          item.value = item.code
          if (item.isParent) {
            item.loading = false
          }
        })
        item.children = arr
        item.loading = false
        callback()
      },
      submit() {
        console.log(this.formItem)
        this.$refs['formValidate'].validate((valid) => {
          console.log(valid)
          if (valid) {
            this.handleSubmit()
          }
        })
      },
      async handleSubmit() {
        let self = this
        let params = Object.assign({}, self.formItem)
        console.log(params)
        params.receiveTelePhone = self.formItem.receiveTelePhone || ''
        params.receiveRegionId = self.regionArr[self.regionArr.length - 1]
        console.log(params)
        if (self.dialogTitle == '编辑') {
          params.isDefault = params.isDefault ? 1 : 0
          params.id = self.baseInfo.id
          let {data} = await api.getUpdateReceiveAddress(params)
          console.log(data)
          if (data.status == 0) {
            self.$Notice.success({
              desc: data.message
            })
            // self.$emit('editUnit', 'add')
            self.handleAddressEdit(self.baseInfo.from + '?' + new Date().getTime())
            self.cancel()
          } else {
            self.$Notice.error({
              desc: data.message
            })
          }
        } else {
          params.subCustomerId = self.baseInfo.subCustomerId
          params.isDefault = 0

          let {data} = await api.getAddReceiveAddress(params)
          console.log(data)
          if (data.status == 0) {
            self.$Notice.success({
              desc: data.message
            })
            // self.$emit('editUnit', 'add')
            self.handleAddressEdit(self.baseInfo.from + '?' + new Date().getTime())
            self.cancel()
          } else {
            self.$Notice.error({
              desc: data.message
            })
          }
        }
      },
      cancel() {
        this.formItem = {}
        this.areaArr = []
        this.regionArr = []
        this.handleBaseDialog({visible: false, type: 'addAddressVisible'})
        this.handleBasicInfo({})
        if (this.$refs['formValidate']) {
          this.$refs['formValidate'].resetFields()
        }
      }
    }
  }
</script>

<style lang="less">
  .modal-wrap {
    padding: 0 10px;
    position: relative;

    .form-title {
      font-size: 16px;
    }

    .form-r {
      padding-left: 20px;
    }

    .ipt {
      width: 200px;
    }

    .grey--text {
      color: #999999;
    }
  }

  .add-up-load-wrap {
    height: 80px;
    width: 80px;
    background-color: #f9f9f9;
    text-align: center;
    padding: 15px 0;
    border: 1px dashed #dcdee2;
    cursor: pointer;
    position: relative;

    p {
      font-size: 12px;
    }

    .ipt {
      position: absolute;
      left: 0;
      top: 0;
      opacity: 0;
      z-index: 10;
      width: 100%;
      height: 100%;
    }
  }

  .add-up-load-wrap:hover {
    border: 1px dashed #E61E10;
  }

  .add-up-load-img {
    text-align: center;
    position: relative;
    height: 80px;
    width: 80px;

    .desc {
      position: absolute;
      bottom: 0px;
      left: 0px;
      color: #ffffff;
      background-color: #999999;
      display: inline-block;
      width: 80px;
      height: 20px;
      line-height: 20px;
      text-align: center;
      font-size: 12px;
    }

    .img {
      border: 1px solid #cccccc;
      height: 80px;
      width: 80px;
      padding: 2px;
      cursor: pointer;
    }

    .remove-btn {
      position: absolute;
      right: 4px;
      top: 4px;
      background: #585858;
      padding: 3px;
      z-index: 99999;
      display: none;
    }
  }

  .add-up-load-img:hover {
    .remove-btn {
      display: block;
    }
  }
</style>
