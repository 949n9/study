<template>
  <div>
    <Modal
      :value="addCustomerVisible"
      :title="'本单位人员-'+dialogTitle"
      :mask-closable="false"
      width="500"
      @on-visible-change="dialogChange"
    >
      <div class="modal-wrap">
        <Form label-position="right" ref="formValidate" :model="formItem" :label-width="120" :rules="ruleValidate">
          <Row>
            <Col span="24">
              <FormItem label="本单位人员姓名：" prop="name">
                <Input class="ipt" :maxlength="20" v-model.trim="formItem.name" clearable
                       placeholder="请输入姓名！"></Input>
              </FormItem>
              <FormItem label="手机：" prop="mobilePhone">
                <Input class="ipt" :maxlength="11" v-model.trim="formItem.mobilePhone" clearable
                       placeholder="请输入手机号码！"></Input>
              </FormItem>
              <FormItem label="功能权限：" prop="roleId">
                <Select v-model="formItem.roleId" class="ipt">
                  <Option v-for="item in roleList" :value="item.id" :key="item.id">{{ item.name }}</Option>
                </Select>
              </FormItem>
              <FormItem label="数据权限：" prop="dataAuthType">
                <Select v-model="formItem.dataAuthType" class="ipt" @on-change="dataAuthChange">
                  <Option v-for="item in dataAuthList" :value="item.id" :key="item.id">{{ item.name }}</Option>
                </Select>
              </FormItem>
              <FormItem label="订货单位：" prop="ccbDataAuthString" v-if="formItem.dataAuthType==1">
                <Select v-model="formItem.ccbDataAuthString" class="ipt">
                  <Option v-for="item in subList" :value="item.id" :key="item.id">{{ item.name }}</Option>
                </Select>
              </FormItem>
              <FormItem label="状态：" v-show="dialogTitle=='编辑'" class="ivu-form-item-required">
                <i-switch v-model="formItem.useStatus" @on-change="useStatusChange" size="large">
                  <span slot="open">在用</span>
                  <span slot="close">停用</span>
                </i-switch>
              </FormItem>
            </Col>
          </Row>
        </Form>
      </div>
      <div slot="footer">
        <Button type="primary" size="large" v-if="dialogTitle=='新增'"  @click="submit">提交</Button>
        <Button type="primary" size="large" v-if="dialogTitle=='编辑'"  @click="submit">保存</Button>
      </div>
    </Modal>
  </div>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../../core/index'

  export default {
    name: '',
    data() {
      return {
        roleList: [],
        dataAuthList: [
          {id: '0', name: '全部'},
          {id: '1', name: '指定订货单位'}
        ],
        subList: [],

        formItem: {
          name: '',
          mobilePhone: '',
          roleId: '',
          ccbDataAuthString: '',
          dataAuthType: '',
          useStatus: true,
          id: ''
        },
        ruleValidate: {
          name: [
            {required: true, message: '请输入姓名！', trigger: 'blur'}
          ],
          mobilePhone: [
            {required: true, message: '请输入手机号码！', trigger: 'blur'},
            {type: 'string', min: 11, message: '请输入正确的手机号码！', trigger: 'change'}
          ],
          roleId: [
            {required: true, message: '请选择功能权限！', trigger: 'change'}
          ],
          dataAuthType: [
            {required: true, message: '请选择数据权限！', trigger: 'change'}
          ],
          ccbDataAuthString: [
            {required: true, message: '请选择订货单位！', trigger: 'change'}
          ],
          useStatus: [
            {required: true, message: ' ', trigger: 'change'}
          ]
        }
      }
    },
    created() {
    },
    computed: {
      ...mapState([
        'addCustomerVisible',
        'baseInfo',
        'dialogTitle'
      ]),
      ...mapGetters([])
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'handleBasicInfo'
      ]),
      // 弹窗状态改变时候
      dialogChange(v) {
        console.log(v)
        if (v) {
          console.log(this.baseInfo)
          this.getRole()
          this.getDataAuth()
          this.handleOpen()
        } else {
          this.cancel()
        }
      },
      // 处理是否是编辑
      handleOpen() {
        console.log(this.baseInfo)
        if (this.dialogTitle == '编辑') {
          let info = this.baseInfo
          this.$nextTick(() => {
            this.formItem = {
              name: info.name,
              mobilePhone: info.mobilePhone,
              roleId: info.roleId,
              dataAuthType: info.dataAuthType == '指定订货单位' ? '1' : '0',
              ccbDataAuthString: info.dataAuthString || '',
              useStatus: info.useStatus == '0',
              id: info.id
            }
          })
        } else {
          this.formItem = {
            name: '',
            mobilePhone: '',
            roleId: '',
            ccbDataAuthString: '',
            dataAuthType: '',
            useStatus: true,
            id: ''
          }
        }
      },
      // 获取功能权限列表
      async getRole() {
        let self = this
        let {data} = await api.getCcbRoles()
        if (data.status == '0') {
          self.roleList = data.data.list
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      dataAuthChange(v) {
      },
      // 获取数据权限为1时候的 订货单位列表
      async getDataAuth() {
        let self = this
        let {data} = await api.getSelectSupplierList()
        if (data.status == '0') {
          self.subList = data.data.list
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 切换用户状态
      useStatusChange(v) {
        console.log(v)
        console.log(this.formItem.useStatus)
      },
      submit() {
        console.log(this.formItem)
        this.$refs['formValidate'].validate((valid) => {
          if (valid) {
            this.handleSubmit()
          } else {
            console.log('error')
          }
        })
      },
      async handleSubmit() {
        let self = this
        let params = {
          mobilePhone: self.formItem.mobilePhone,
          name: self.formItem.name,
          ccbRoleId: self.formItem.roleId,
          ccbDataAuthType: self.formItem.dataAuthType,
          ccbDataAuthString: self.formItem.ccbDataAuthString,
          useStatus: self.formItem.useStatus ? 0 : 1,
          id: self.formItem.id
        }
        console.log(params)
        let {data} = await api.getEditUserList(params)
        if (data.status == 0) {
          self.$Notice.success({
            desc: data.message
          })
          self.$emit('editUser', 'add')
          self.cancel()
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
        console.log(data)
      },
      cancel() {
        this.formItem = {}
        this.handleBaseDialog({visible: false, type: 'addCustomerVisible'})
        this.handleBasicInfo({})
        this.$refs['formValidate'].resetFields()
      }
    }
  }
</script>

<style lang="less">
  .modal-wrap {
    padding: 0 20px;
    .form-title {
      font-size: 16px;
    }
    .form-r {
      padding-left: 20px;
    }
    .ipt {
      width: 220px;
    }
  }
</style>
