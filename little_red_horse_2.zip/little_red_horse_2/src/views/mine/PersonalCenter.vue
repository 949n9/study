<template>
  <div class="personal-center">
    <Row>
      <Col span="6">
        <Card class="card-wrap card-wrap-first">
          <div class="card-wrap-img">
            <img src="../../assets/images/home.png" alt="" class="wrap-img">
          </div>
          <p class="card-wrap-title white--text">{{userData.subCustomerName}}</p>
          <p class="card-wrap-text white--text">
            <Icon type="md-person"/>&nbsp;{{userData.imName}}
          </p>
        </Card>
      </Col>
      <Col span="9">
        <Card class="card-wrap">
          <p slot="title" class="card-wrap-header">
            资金账户
          </p>
          <div class="card-wrap-content">
            <p class="card-wrap-text" @click="jump('/mine/account')">可用余额：
              <span>¥{{userInfo.availableBalance }}</span>
            </p>
            <p class="card-wrap-text" @click="jump('/mine/account')">账户余额：
              <span>¥{{userInfo.balance}}</span>
            </p>
          </div>
          <div class="card-wrap-content">
            <Button type="error" class="btn" to="/mine/recharge">充值</Button>
          </div>
        </Card>
      </Col>
      <Col span="9">
        <Card class="card-wrap">
          <p class="card-wrap-header" slot="title">优惠券</p>
          <div class="card-wrap-content" @click="jump('/mine/coupon')">
            <p class="card-wrap-text">
              <span>{{coupon.couponTotalCount}}</span>张
            </p>
            <p class="card-wrap-text">金额：
              <span>{{coupon.couponTotalAmount}}</span>
            </p>
          </div>
        </Card>
      </Col>
    </Row>

    <Row class="cell-wrap">
      <Col span="24">
        <div class="wrap-header">
          <p class="wrap-header-title">商城订单</p>
        </div>
      </Col>
      <Col span="12">
        <Card class="cell-item-wrap">
          <p class="cell-wrap-text">
            <Badge status="success"/>
            未发送订单
          </p>
          <Row class="card-wrap-content">
            <Col span="8">
              <Badge :count="orderCount.revokeQty*1" :offset="[6,8]" type="primary">
                <Button type="text" class="card-wrap-btn" @click="toJump('commonOrder','12','2')">已撤销</Button>
              </Badge>
            </Col>
            <Col span="8">
              <Badge :count="orderCount.sendBackQty*1 " :offset="[6,8]" type="primary">
                <Button type="text" class="card-wrap-btn" @click="toJump('commonOrder','4','2')">已退回</Button>
              </Badge>
            </Col>
          </Row>
        </Card>
      </Col>
      <Col span="12">
        <Card class="cell-item-wrap">
          <p class="cell-wrap-text">
            <Badge status="success"/>
            已发送订单
          </p>
          <Row class="card-wrap-content">
            <Col span="8">
              <Badge :count="orderCount.unVerifyQty*1 " :offset="[6,8]" type="primary">
                <Button type="text" class="card-wrap-btn" @click="toJump('commonOrder','1','1')">审核中</Button>
              </Badge>
            </Col>
            <Col span="8">
              <Button type="text" class="card-wrap-btn" @click="toJump('commonOrder','3','1')">已审核</Button>
            </Col>
          </Row>
        </Card>
      </Col>
    </Row>

    <Row class="cell-wrap">
      <Col span="24">
        <div class="wrap-header">
          <p class="wrap-header-title">厂商直送订单</p>
        </div>
      </Col>
      <Col span="12">
        <Card class="cell-item-wrap">
          <p class="cell-wrap-text">
            <Badge status="success"/>
            未发送订单
          </p>
          <Row class="card-wrap-content">
            <Col span="8">
              <Badge :count="supplyOrderCount.revokeQty*1" :offset="[6,8]" type="primary">
                <Button type="text" class="card-wrap-btn" @click="toJump('supplierOrder','1','2')">已撤销</Button>
              </Badge>
            </Col>
            <Col span="8">
              <Badge :count="supplyOrderCount.sendBackQty*1" :offset="[6,8]" type="primary">
                <Button type="text" class="card-wrap-btn" @click="toJump('supplierOrder','2','2')">已退回</Button>
              </Badge>
            </Col>
          </Row>
        </Card>
      </Col>
      <Col span="12">
        <Card class="cell-item-wrap">
          <p class="cell-wrap-text">
            <Badge status="success"/>
            已发送订单
          </p>
          <Row class="card-wrap-content">
            <Col span="4">
              <Badge :count="supplyOrderCount.unVerifyQty*1" :offset="[6,8]" type="primary">
                <Button type="text" class="card-wrap-btn" @click="toJump('supplierOrder','3','1')">审核中
                </Button>
              </Badge>
            </Col>
            <Col span="4">
              <Badge :count="supplyOrderCount.verifyQty*1" :offset="[6,8]" type="primary">
                <Button type="text" class="card-wrap-btn" @click="toJump('supplierOrder','4','1')">已审核</Button>
              </Badge>
            </Col>
            <Col span="4">
              <Badge :count="supplyOrderCount.deliverGoodsQty*1" :offset="[6,8]" type="primary">
                <Button type="text" class="card-wrap-btn" @click="toJump('supplierOrder','5','1')">已发货</Button>
              </Badge>
            </Col>
            <Col span="4">
              <Button type="text" class="card-wrap-btn" @click="toJump('supplierOrder','6','1')">已完成</Button>
            </Col>
          </Row>
        </Card>
      </Col>
    </Row>

    <Row class="cell-wrap">
      <Col span="4">
        <div class="cell-wrap-other">
          <img src="../../assets/images/user/chongzhi@3x.png" alt="" class="cell-wrap-other-img"
               @click="jump('/mine/recharge')">
          <p class="card-wrap-text">
            充值
          </p>
        </div>
      </Col>
      <Col span="4">
        <div class="cell-wrap-other">
          <Tooltip max-width="500"
                   :content="content">
            <img src="../../assets/images/user/shouhou@3x.png" alt="" class="cell-wrap-other-img">
          </Tooltip>
          <p class="card-wrap-text">
            退换/售后
          </p>
        </div>
      </Col>
      <Col span="4" v-if="userData.admin==1">
        <div class="cell-wrap-other">
          <img src="../../assets/images/user/dinghuodanwei@3x.png" alt="" class="cell-wrap-other-img"
               @click="jump('/mine/orderunit')">
          <p class="card-wrap-text">
            门店管理
          </p>
        </div>
      </Col>
      <Col span="4" v-if="userData.admin==1">
        <div class="cell-wrap-other">
          <img src="../../assets/images/user/bendanweirenyuan@3x.png" alt="" class="cell-wrap-other-img"
               @click="jump('/mine/unitmanage')">
          <p class="card-wrap-text">
            本单位人员管理
          </p>
        </div>
      </Col>
      <Col span="4">
        <div class="cell-wrap-other">
          <img src="../../assets/images/user/shoucangshangpin@3x.png" alt="" class="cell-wrap-other-img"
               @click="jump('/index/storeproduct')">
          <p class="card-wrap-text">
            我的收藏
          </p>
        </div>
      </Col>
    </Row>
  </div>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'

  export default {
    name: 'PersonalCenter',
    data() {
      return {
        userInfo: {},
        orderCount: {},
        supplyOrderCount: {},
        coupon: {},
        // content: '如果某个订单的商品因故要退货，可以点击查看这个订单，在订单详情页中有“联系客服”按钮，点击后可以联系卖方客服，沟通退货事宜，如果确认可退，您可以把要退的商品发给卖方，卖方确认收货后可以把相关款项退还到您的资金账户。'
        content: '如果某个订单的商品因故要退货，可以点击“联系客服”按钮，点击后可以联系卖方客服，沟通退货事宜，如果确认可退，您可以把要退的商品发给卖方，卖方确认收货后可以把相关款项退还到您的资金账户。'
      }
    },
    created() {
      this.initData()
    },
    computed: {
      ...mapState([
        'handleSuccess'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    watch: {
      'handleSuccess': 'orderStatusChange'
    },
    methods: {
      ...mapActions([
        'saveOrderStatus',
        'handleBaseDialog'
      ]),
      initData() {
        this.getUserInfo()
      },
      orderStatusChange() {
        this.getUserInfo()
      },
      async getUserInfo() {
        let self = this
        let {data} = await api.getUserCenter()
        console.log(data)
        if (data.status == 0) {
          self.userInfo = data.data
          self.orderCount = data.data.orderCount
          self.supplyOrderCount = data.data.supplyOrderCount
          self.coupon = {
            'couponTotalAmount': parseFloat(data.data.couponTotalAmount).toFixed(2),
            'couponTotalCount': data.data.couponTotalCount
          }
        }
      },
      // 订单详情 弹窗
      toJump(type, status, name) {
        this.saveOrderStatus({type: type, status: status, name: name})
        this.handleBaseDialog({visible: true, type: 'orderDialogVisible'})
      },
      // 跳转到  (订单 不同状态跳跳转)
      jump(path) {
        this.$router.push({
          path: path
        })
      }
    }
  }
</script>

<style lang="less">
  .personal-center {
    width: 100%;
    padding: 10px;

    .card-wrap {
      height: 200px;
      width: 100%;
      border-radius: 0;

      &-img {
        height: 95px;
        width: 95px;
        background: url("../../assets/images/yuan.png");
        margin: 0 auto;
        text-align: center;

        .wrap-img {
          width: 41px;
          height: 41px;
          display: inline-block;
          margin-top: 24px;
        }
      }

      .ivu-card-head {
        padding: 0px;
        width: 100%;
        line-height: 0;
      }

      &-header {
        width: 100%;
        height: 32px;
        line-height: 32px;
        padding-left: 14px;
        background-color: #F5F8FA;
      }

      &-title {
        display: inline-block;
        font-size: 16px;
        font-weight: 600;
        text-align: center;
        overflow: hidden;
        white-space: nowrap;
        width: 210px;
        text-overflow: ellipsis;
      }

      &-text {
        line-height: 25px;
        font-size: 14px;
        text-align: center;
        cursor: pointer;

        span {
          padding: 0 3px;
          font-size: 18px;
          color: #E61E10;
          font-weight: 600;
        }
      }

      &-content {
        text-align: center;
        padding-top: 20px;

        .btn {
          width: 100px;
        }
      }
    }

    .card-wrap:hover {
      box-shadow: none;
    }

    .card-wrap-first {
      background-image: url("../../assets/images/geren_bg.png");
    }

    .cell-wrap {
      border: 1px solid #ececec;
      margin: 10px 0;
      background-color: #ffffff;

      .wrap-header {
        height: 32px;
        line-height: 32px;
        background-color: #F5F8FA;

        &-title {
          margin-left: 14px;
          font-size: 14px;
          font-weight: 600;
        }
      }

      .cell-item-wrap {
        height: 160px;
        border-radius: 0;

        .cell-wrap-text {

        }

        .card-wrap-btn {
          font-weight: 600;
          font-size: 14px;
        }
      }

      .cell-wrap-other {
        text-align: center;
        height: 143px;
        padding: 30px 15px;

        &-img {
          height: 45px;
          width: 45px;
          cursor: pointer;
        }
      }
    }

    .cell-item-wrap:hover {
      box-shadow: none;
    }
  }
</style>
