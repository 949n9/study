<template>
  <div class="register">
    <div class="register-wrap">
      <Row>
        <Col span="4">&nbsp;</Col>
        <Col span="14" class="header-l">
          <img
            class="header-l-logo"
            src="../assets/images/logo.png"
          >
          <p class="header-l-name">母婴用品全品类一站式采购平台</p>
        </Col>
        <Col span="4" class="header-r">
          <img
            class="header-r-img"
            src="../assets/images/phone.png"
          >
          <div class="header-r-phone">
            <p class="phone-desc">官方服务热线</p>
            <p class="phone">4000686817</p>
          </div>
        </Col>
        <Col span="2">&nbsp;</Col>
      </Row>

      <Row class="register-tab">
        <Col span="4">&nbsp;</Col>
        <Col span="20">
          <Menu mode="horizontal" :active-name="activeName" @on-select="tabSelect"
                class="register-tab-menu">
            <MenuItem name="http://www.redhoma.cn/" class="menu-item">
              网站首页
            </MenuItem>

            <Submenu name="aboutUs" class="menu-item">
              <template slot="title">
                关于我们
              </template>
              <MenuItem name="http://www.redhoma.cn/page10">公司简介</MenuItem>
              <MenuItem name="http://www.redhoma.cn/page11">仓储物流</MenuItem>
              <MenuItem name="http://www.redhoma.cn/page9">联系我们</MenuItem>
            </Submenu>

            <MenuItem name="site" class="menu-item">
              母婴商城
            </MenuItem>
            <MenuItem name="http://www.redhoma.cn/page5" class="menu-item">
              招商签约
            </MenuItem>
            <MenuItem name="http://www.redhoma.cn/page6" class="menu-item">
              行业动态
            </MenuItem>
            <MenuItem name="http://www.redhoma.cn/page8" class="menu-item">
              加入我们
            </MenuItem>
          </Menu>
        </Col>
      </Row>

      <div class="register-form">

        <div class="m-form">
          <Form label-position="right" ref="customerForm" :model="customerForm" :label-width="120"
                :rules="customerRule">
            <FormItem class="ivu-form-item-required" label="手机：" prop="subCustomerMobilePhone">
              <Input :maxlength="11" class="ipt" clearable placeholder="请输入手机号码，该手机号将作为您的登录手机号" ref="phoneIpt"
                     v-model="customerForm.subCustomerMobilePhone"></Input>
            </FormItem>
            <FormItem class="ivu-form-item-required" label="手机验证码：" prop="phoneCode">
              <div class="m-form-wrap">
                <Input :maxlength="6" class="ipt" clearable placeholder="请输入手机验证码，一小时内有效" ref="phoneCode"
                       v-model="customerForm.phoneCode"></Input>
                <Button :disabled="!canClick" @click="sendCode" class="code-btn" type="default">{{codeMsg}}
                </Button>
              </div>
            </FormItem>
            <FormItem label="店名：" prop="subCustomerName">
              <Input :maxlength="50" class="ipt" clearable placeholder="请输入门店名称"
                     v-model="customerForm.subCustomerName"></Input>
            </FormItem>
            <FormItem label="联系人姓名：" prop="subCustomerContactName">
              <Input class="ipt" :maxlength="10" v-model="customerForm.subCustomerContactName" clearable
                     placeholder="请输入联系人姓名"></Input>
            </FormItem>

            <FormItem class="ivu-form-item-required" label="门店地址：">
              <Cascader class="ipt" :data="regionData"
                        placeholder="请选择门店地址"
                        :load-data="loadData2"
                        v-model="regionArr"></Cascader>
            </FormItem>
            <FormItem label="" prop="receiveAddress">
              <Input class="ipt" :maxlength="50" v-model="customerForm.receiveAddress"
                     type="textarea" :rows="2" placeholder="请输入详细地址（必填）"></Input>
            </FormItem>

            <FormItem label="营业执照：" class="ivu-form-item-required">
              <p class="grey--text" style="margin-top: 8px;line-height: 18px;">请上传营业执照的清晰扫描件或照片，提交后不可更改</p>
              <div style="display: flex">
                <div class="add-up-load-img" v-if="customerForm.licenseImgUrl">
                  <img :src="customerForm.licenseImgUrl" alt="" class="img"
                       @click="openImgModal(customerForm.licenseImgUrl)">
                  <Icon type="md-close" class="remove-btn" color="white"
                        size="18"
                        @click="removeImg(1)"/>
                </div>
                <div class="add-up-load-wrap" v-else>
                  <input type="file" title="" @change="(e)=>doUpload(e,1)" class="ipt"
                         accept="image/gif,image/jpeg,image/jpg,image/png"/>
                  <Icon type="md-add" style="font-weight: 700" size="25"/>
                  <p>上传</p>
                </div>
                <div class="add-up-load-img" style="margin-left: 20px" v-if="!customerForm.licenseImgUrl">
                  <img :src="yyImg" alt="" class="img" @click="openImgModal(yyImg)">
                  <span class="desc">示图例</span>
                </div>
              </div>
            </FormItem>
            <FormItem label="门头照：" class="ivu-form-item-required">
              <p class="grey--text">请上传门头的清晰照片，提交后不可更改</p>
              <div style="display: flex">
                <div class="add-up-load-img" v-if="customerForm.doorHeadImgUrl">
                  <img :src="customerForm.doorHeadImgUrl" alt="" class="img"
                       @click="openImgModal(customerForm.doorHeadImgUrl)">
                  <Icon type="md-close" color="white" class="remove-btn" size="18"
                        @click="removeImg(2)"/>
                </div>
                <div class="add-up-load-wrap" v-else>
                  <input type="file" title="" @change="(e)=>doUpload(e,2)" class="ipt"
                         accept="image/gif,image/jpeg,image/jpg,image/png"/>
                  <Icon type="md-add" style="font-weight: 700" size="25"/>
                  <p>上传</p>
                </div>
                <div class="add-up-load-img" style="margin-left: 20px" v-if="!customerForm.doorHeadImgUrl">
                  <img :src="mtImg" alt="" class="img" @click="openImgModal(mtImg)">
                  <span class="desc">示图例</span>
                </div>
              </div>
            </FormItem>
            <FormItem label="店内照：" class="ivu-form-item-required">
              <p class="grey--text">请上传店内的清晰照片，提交后不可更改</p>
              <div style="display: flex">
                <div class="add-up-load-img" v-if="customerForm.storeInternalImgUrl">
                  <img :src="customerForm.storeInternalImgUrl" alt="" class="img"
                       @click="openImgModal(customerForm.storeInternalImgUrl)">
                  <Icon type="md-close" color="white" class="remove-btn" size="18"
                        @click="removeImg(3)"/>
                </div>
                <div class="add-up-load-wrap" v-else>
                  <input type="file" title="" @change="(e)=>doUpload(e,3)" class="ipt"
                         accept="image/gif,image/jpeg,image/jpg,image/png"/>
                  <Icon type="md-add" style="font-weight: 700" size="25"/>
                  <p>上传</p>
                </div>
                <div class="add-up-load-img" style="margin-left: 20px" v-if="!customerForm.storeInternalImgUrl">
                  <img :src="dnImg" alt="" class="img" @click="openImgModal(dnImg)">
                  <span class="desc">示图例</span>
                </div>
              </div>
            </FormItem>

            <FormItem label="" prop="isAgree">
              <CheckboxGroup v-model="customerForm.isAgree">
                <Checkbox label="" style="display: flex;align-items: center">
                  <p style="margin-left: 5px">我已阅读并同意<a href="javascript:void(0)"
                                                        @click="jump('policy')">《小红马平台服务协议》</a>
                  </p>
                </Checkbox>
              </CheckboxGroup>
            </FormItem>
            <FormItem label="" style="text-align: center">
              <Button @click="toSubmit" class="btn" size="large" style="width: 335px" type="primary">提交
              </Button>
            </FormItem>
          </Form>
        </div>

      </div>

    </div>

    <Modal
      v-model="policyModal"
      title="小红马平台服务协议"
      width="1000"
      :styles="{top: '40px'}"
      :mask-closable="false"
      @on-cancel="closeModal">
      <iframe :src="policyUrl" style="width: 970px;height: 500px;border: 0;"></iframe>
      <div slot="footer" style="text-align: center">
        <Button type="default" style="width: 150px" @click="closeModal">取消</Button>
        <Button type="error" style="width: 150px" @click="argee2register">同意并继续</Button>
      </div>
    </Modal>

    <Modal title=" " v-model="imgModal" footer-hide>
      <img :src="bigImg" style="width: 100%">
    </Modal>
  </div>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../core/index'
  import utils from '../utils/index'
  import validator from '../utils/validator'
  import * as options from '../utils/options'

  export default {
    name: 'register',
    components: {},
    data() {
      return {
        ossData: {},
        policyUrl: options.ServicePolicy,
        policyModal: false,
        current: -1,
        activeName: 'site',
        regionData: [],

        codeMsg: '获取验证码',
        totalTime: 60,
        canClick: true,
        clock: null,

        bigImg: '',
        imgModal: false,

        customerForm: {
          subCustomerMobilePhone: '',
          phoneCode: '',
          subCustomerName: '',
          subCustomerContactName: '',

          licenseImgUrl: '',
          doorHeadImgUrl: '',
          storeInternalImgUrl: '',

          receiveRegionId: '',
          receiveAddress: '',

          isAgree: []
        },
        regionArr: [],

        customerRule: {
          subCustomerMobilePhone: [
            {validator: validator.validatePhone, trigger: 'change', msg: ''}
          ],
          phoneCode: [
            {required: true, message: '请输入手机验证码', trigger: 'blur'}
          ],
          subCustomerName: [
            {required: true, message: '请输入门店名称', trigger: 'blur'}
          ],
          subCustomerContactName: [
            {required: true, message: '请输入联系人姓名', trigger: 'blur'}
          ],
          receiveAddress: [
            {required: true, message: '请输入门店详细地址', trigger: 'blur'}
          ],
          isAgree: [
            {required: true, type: 'array', min: 1, message: '请阅读并同意《小红马平台服务协议》', trigger: 'change'}
          ]
        },
        // 营业执照地址：  // 门头照地址：  // 店内照地址：
        yyImg: options.yyImg,
        mtImg: options.mtImg,
        dnImg: options.dnImg
      }
    },
    computed: {
      ...mapState([
        'loading'
      ]),
      ...mapGetters([])
    },
    created() {
      setTimeout(() => {
        this.policyModal = true
      }, 800)

      this.initData()
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'selectSub',
        'saveCommonCartNum',
        'saveSupplierCartNum'
      ]),
      initData() {
        this.getOssData()
        this.getRegionList()
      },
      // 获取oss上传信息
      async getOssData() {
        let self = this
        let params = {
          platform: 'ad',
          version: '123'
        }
        let {data} = await api.getVersion(params)
        if (data.status == 0) {
          self.ossData = data.data
        }
        console.log(data)
      },

      // 获取收货信息地区列表
      async getRegionList() {
        let self = this
        let params = {}
        let {data} = await api.getRegionList(params)
        console.log(data)
        let arr = data.data
        arr.forEach((item, index) => {
          item.label = item.name
          item.value = item.code
          item.loading = !item.isParent
        })
        self.regionData = arr
      },
      async loadData2(item, callback) {
        console.log(item)
        item.loading = true
        let params = {
          parentId: item.id
        }
        let {data} = await api.getRegionList(params)

        let arr = data.data
        arr.forEach((item, index) => {
          item.label = item.name
          item.value = item.code
          if (item.isParent) {
            item.loading = false
          }
        })
        item.children = arr
        item.loading = false
        callback()
      },

      // 提交
      toSubmit() {
        this.$refs['customerForm'].validate((valid) => {
          if (valid) {
            if (this.regionArr.length <= 0) {
              this.$Notice.error({
                desc: '请选择门店地址'
              })
              return
            } else {
              this.customerForm.receiveRegionId = this.regionArr[this.regionArr.length - 1]
            }

            if (this.customerForm.licenseImgUrl == '') {
              this.$Notice.error({
                desc: '请上传营业执照'
              })
              return
            }
            if (this.customerForm.doorHeadImgUrl == '') {
              this.$Notice.error({
                desc: '请上传门头照'
              })
              return
            }
            if (this.customerForm.storeInternalImgUrl == '') {
              this.$Notice.error({
                desc: '请上传店内照'
              })
              return
            }

            this.handleSubmit()
          }
        })
      },
      // 处理提交
      async handleSubmit() {
        let self = this
        let params = {}
        Object.assign(params, self.customerForm)
        console.log(params)

        let {data} = await api.getCustomerRegister(params)
        if (data.status == 0) {
          // self.$Notice.success({
          //   desc: data.message
          // })
          self.$Modal.success({
            title: '温馨提示',
            content: data.data.registerPromptMessage,
            onOk: () => {
              self.$router.push({path: '/login'})
            }
          })
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },

      tabSelect(name) {
        console.log(name)
        if (name == 'site') {
          this.$router.push({path: '/login'})
        } else {
          window.open(name)
        }
      },
      // 看大图
      openImgModal(url) {
        this.imgModal = true
        this.bigImg = url
      },
      // 删除已经上传的图片
      removeImg(type) {
        if (type == 1) {
          this.$set(this.customerForm, 'licenseImgUrl', '')
        } else if (type == 2) {
          this.$set(this.customerForm, 'doorHeadImgUrl', '')
        } else if (type == 3) {
          this.$set(this.customerForm, 'storeInternalImgUrl', '')
        }
      },
      // 上传公司凭证
      doUpload(e, picIndex) {
        let self = this
        let client = new OSS.Wrapper({
          region: 'oss-cn-beijing',
          accessKeyId: this.ossData.ossAccessKeyId,
          accessKeySecret: this.ossData.ossAccessKeySecret,
          bucket: this.ossData.ossBucketName
        })
        let file = e.target.files[0]
        let imgSize = file.size
        console.log(imgSize)
        if (imgSize > 100 * 1024 * 1024) {
          self.$Notice.error({
            desc: '上传图片大小不能大于100M'
          })
          return
        }
        let type = file.type.substring(6)
        let fileName = this.ossData.ossCustomerUploadPath + this.$moment().format('YYYYMMDD/') + utils.uuid(28) + '.' + type
        client.multipartUpload(fileName, file).then(function (result) {
          console.log(result)
          console.log(self.ossData)
          if (result.res.status == 200) {
            if (picIndex == 1) {
              self.$set(self.customerForm, 'licenseImgUrl', self.ossData.ossImgUrl + '/' + result.name)
            } else if (picIndex == 2) {
              self.$set(self.customerForm, 'doorHeadImgUrl', self.ossData.ossImgUrl + '/' + result.name)
            } else if (picIndex == 3) {
              self.$set(self.customerForm, 'storeInternalImgUrl', self.ossData.ossImgUrl + '/' + result.name)
            }
          }
        }).catch(function (err) {
          console.log(err)
        })
      },
      // 关闭注册页面 取消注册
      closeModal() {
        this.$router.push({path: '/login'})
      },
      // 同意注册
      argee2register() {
        this.initData()
        this.policyModal = false
        this.$refs.phoneIpt.focus()
      },
      // 跳转到相关外链
      jump(type) {
        let url = options.ServicePolicy
        window.open(url)
      },
      // 发送验证码
      sendCode() {
        this.$refs.customerForm.validateField('subCustomerMobilePhone')
        if (utils.isPhone(this.customerForm.subCustomerMobilePhone)) {
          this.handleSend()
          this.countDown()
          this.$refs.phoneCode.focus()
        }
      },
      async handleSend() {
        let self = this
        let params = {
          mobilePhone: self.customerForm.subCustomerMobilePhone
        }
        let {data} = await api.getSendRegisterCode(params)
        if (data.status == 0) {
          console.log(data.message)
        } else {
          self.$Notice.error({
            desc: data.message
          })
          clearInterval(this.clock)
          this.codeMsg = '获取验证码'
          this.totalTime = 60
          this.canClick = true
        }
      },
      countDown() {
        if (!this.canClick) return
        this.canClick = false
        this.codeMsg = this.totalTime + 's后重新发送'
        this.clock = setInterval(() => {
          this.totalTime--
          this.codeMsg = this.totalTime + 's后重新发送'
          if (this.totalTime < 0) {
            clearInterval(this.clock)
            this.codeMsg = '重新发送'
            this.totalTime = 60
            this.canClick = true
          }
        }, 1000)
      }
    }
  }
</script>

<style lang="less">
  .register {
    position: relative;
    background-color: #ffffff;
    width: 100%;
    min-width: 1000px;

    .register-wrap {
      margin: 0 auto;

      .header-l {
        height: 88px;
        line-height: 88px;
        display: flex;

        &-logo {
          width: 200px;
          height: 60px;
          margin-top: 12px;
        }

        &-name {
          margin-left: 20px;
          font-size: 26px;
          font-family: 微软雅黑;
          color: rgb(47, 47, 47);
        }
      }

      .header-r {
        display: flex;
        align-items: center;
        margin-top: 20px;

        &-img {
          width: 61px;
          height: 53px;
        }

        &-phone {
          margin-left: 10px;

          .phone-desc {
            font-size: 13px;
            font-family: 微软雅黑;
          }

          .phone {
            font-size: 24px;
            font-weight: 700;
            color: #E61E10;
            font-family: 微软雅黑;
          }
        }
      }

      .m-footer {
        padding-top: 20px;

        p {
          height: 20px;
          line-height: 20px;
          text-align: center;
          white-space: nowrap;
        }
      }
    }

    .register-tab {
      background: #fcfcfc;

      .register-tab-menu {
        height: 60px;
        line-height: 60px;
        background: #fcfcfc;

        .menu-item {
          font-size: 18px;
          font-weight: 600;
        }
      }
    }

    .register-form {
      width: 1200px;
      margin: 0 auto;
      min-width: 1000px;
      position: relative;

      .m-form {
        width: 450px;
        padding-top: 20px;
        margin: 0 auto;

        &-wrap {
          display: flex;
          justify-content: space-between;

          .ipt {
            width: 200px;
          }

          .code-btn {
            width: 120px;
            color: #ffffff;
            background-color: #E61E10;
          }
        }

        .btn {
          width: 100px;
        }

        .add-up-load-wrap {
          height: 80px;
          width: 80px;
          background-color: #f9f9f9;
          text-align: center;
          padding: 15px 0;
          border: 1px dashed #dcdee2;
          cursor: pointer;
          position: relative;

          p {
            font-size: 12px;
          }

          .ipt {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            z-index: 10;
            width: 100%;
            height: 100%;
          }
        }

        .add-up-load-wrap:hover {
          border: 1px dashed #E61E10;
        }

        .add-up-load-img {
          text-align: center;
          position: relative;
          height: 80px;
          width: 80px;

          .desc {
            position: absolute;
            bottom: 0px;
            left: 0px;
            color: #ffffff;
            background-color: #999999;
            display: inline-block;
            width: 80px;
            height: 20px;
            line-height: 20px;
            text-align: center;
            font-size: 12px;
          }

          .img {
            border: 1px solid #cccccc;
            height: 80px;
            width: 80px;
            padding: 2px;
            cursor: pointer;
          }

          .remove-btn {
            position: absolute;
            right: 4px;
            top: 4px;
            background: #585858;
            padding: 3px;
            z-index: 99999;
            display: none;
          }
        }

        .add-up-load-img:hover {
          .remove-btn {
            display: block;
          }
        }
      }
    }
  }
</style>
