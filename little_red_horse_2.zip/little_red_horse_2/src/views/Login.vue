<template>
  <div class="login">
    <div class="login-wrap">
      <Row>
        <Col span="4">&nbsp;</Col>
        <Col span="14" class="header-l">
          <img
            class="header-l-logo"
            src="../assets/images/logo.png"
          >
          <p class="header-l-name">母婴用品全品类一站式采购平台</p>
        </Col>
        <Col span="4" class="header-r">
          <img
            class="header-r-img"
            src="../assets/images/phone.png"
          >
          <div class="header-r-phone">
            <p class="phone-desc">官方服务热线</p>
            <p class="phone">4000686817</p>
          </div>
        </Col>
        <Col span="2">&nbsp;</Col>
      </Row>

      <Row class="login-tab">
        <Col span="4">&nbsp;</Col>
        <Col span="20">
          <Menu mode="horizontal" :active-name="activeName" @on-select="tabSelect"
                class="login-tab-menu">
            <MenuItem name="http://www.redhoma.cn/" class="menu-item">
              网站首页
            </MenuItem>

            <Submenu name="aboutUs" class="menu-item">
              <template slot="title">
                关于我们
              </template>
              <MenuItem name="http://www.redhoma.cn/page10">公司简介</MenuItem>
              <MenuItem name="http://www.redhoma.cn/page11">仓储物流</MenuItem>
              <MenuItem name="http://www.redhoma.cn/page9">联系我们</MenuItem>
            </Submenu>

            <MenuItem name="site" class="menu-item">
              母婴商城
            </MenuItem>
            <MenuItem name="http://www.redhoma.cn/page5" class="menu-item">
              招商签约
            </MenuItem>
            <MenuItem name="http://www.redhoma.cn/page6" class="menu-item">
              行业动态
            </MenuItem>
            <MenuItem name="http://www.redhoma.cn/page8" class="menu-item">
              加入我们
            </MenuItem>
          </Menu>
        </Col>
      </Row>

      <div style="display: flex;justify-content: center">
        <div class="login-wrap-form">
          <div class="m-login-form">
            <Card :bordered="false" style="width: 320px;height: 330px;">
              <div class="form-title">
                <p class="title">{{loginTitle}}</p>
              </div>

              <div class="form-wrap">
                <Form v-show="pwdLogin" ref="pwdForm" :model="pwdForm" :rules="pwdRule" :label-width="10">
                  <FormItem prop="user">
                    <Input size="large" type="text" :maxlength="30" autofocus v-model.trim="pwdForm.user" clearable
                           placeholder="用户名">
                      <Icon type="md-person" slot="prepend"></Icon>
                    </Input>
                  </FormItem>
                  <FormItem prop="password">
                    <Input size="large" type="password" v-model="pwdForm.password" :maxlength="30"
                           placeholder="密码">
                      <Icon type="md-lock" slot="prepend"></Icon>
                    </Input>
                  </FormItem>
                  <FormItem prop="code" style="margin-bottom: 12px">
                    <div class="code-wrap">
                      <Input size="large" v-model="pwdForm.code" :maxlength="4"
                             class="code-wrap-ipt" @on-enter="submit('pwdForm')" placeholder="请输入验证码">
                        <Icon type="md-checkmark-circle" color="#19be6b" v-show="pwdForm.code==code" slot="suffix"/>
                      </Input>
                      <div class="code-wrap-msg" @click="generatedCode">
                        <span class="msg-text">{{code}}</span>
                      </div>
                    </div>
                  </FormItem>
                  <FormItem style="margin-bottom: 2px">
                    <p>登录即为已阅读并同意<a href="javascript:void(0)" @click="jump('policy')">《小红马平台服务协议》</a></p>
                  </FormItem>
                  <FormItem style="margin-bottom: 2px">
                    <Button type="error" size="large" :loading="loading" long @click="submit('pwdForm')">登录</Button>
                  </FormItem>
                  <FormItem style="margin-bottom: 2px">
                    <span type="text" class="phone-login" @click="changeLoginType">手机快捷登录</span>
                    <span style="float: right;color: #2d8cf0;cursor: pointer" @click="handleRegister">立即注册</span>
                  </FormItem>
                </Form>

                <Form v-show="!pwdLogin" ref="phoneForm" :model="phoneForm" :rules="phoneRule" :label-width="10">
                  <FormItem prop="phone" style="margin-top: 20px">
                    <Input size="large" type="text" :maxlength="30" autofocus v-model.trim="phoneForm.phone" clearable
                           placeholder="手机号">
                      <Icon type="md-phone-portrait" slot="prepend"></Icon>
                    </Input>
                  </FormItem>
                  <FormItem prop="msgCode" style="margin-bottom: 52px">
                    <div class="code-wrap">
                      <Input size="large" v-model="phoneForm.msgCode" :maxlength="6"
                             ref="phoneCode"
                             class="code-wrap-ipt" @on-enter="submit('phoneForm')" placeholder="请输入手机验证码">
                      </Input>
                      <Button class="code-btn" type="default" :disabled="!canClick" @click="sendCode">{{codeMsg}}
                      </Button>
                    </div>
                  </FormItem>
                  <FormItem style="margin-bottom: 2px">
                    <p>登录即为已阅读并同意<a href="javascript:void(0)" @click="jump('policy')">《小红马平台服务协议》</a></p>
                  </FormItem>
                  <FormItem style="margin-bottom: 2px">
                    <Button type="error" size="large" :loading="loading" long @click="submit('phoneForm')">登录</Button>
                  </FormItem>
                  <FormItem style="margin-bottom: 2px;">
                    <span type="text" class="phone-login" @click="changeLoginType">密码登录</span>
                    <span style="float: right;color: #2d8cf0;cursor: pointer" @click="handleRegister">立即注册</span>
                  </FormItem>
                </Form>
              </div>
            </Card>
          </div>
        </div>
      </div>

      <Row>
        <Col span="6">&nbsp;</Col>
        <Col span="12" class="m-footer">
          <p>版权所有：上海小红马供应链有限公司 备案号：<a href="javascript:void(0)">沪ICP备19001589号</a></p>
          <p> 公司地址：上海市松江区九亭镇沪松公路1117号</p>
          <p>邮编：201615</p>
        </Col>
        <Col span="6">&nbsp;</Col>
      </Row>
      <customer-list></customer-list>
    </div>
  </div>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../core/index'
  import CustomerList from '../components/CustomerList'
  import utils from '../utils/index'
  import * as options from '../utils/options'
  import * as types from '@/store/mutation_types'

  export default {
    name: 'login',
    components: {
      CustomerList
    },
    data() {
      const validateCode = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入验证码'))
        } else {
          if (this.pwdForm.code !== this.code) {
            callback(new Error('请输入正确的验证码'))
          }
          callback()
        }
      }
      const validatePhone = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入手机号码'))
        } else {
          if (!utils.isPhone(this.phoneForm.phone)) {
            callback(new Error('请输入正确的手机号码'))
          }
          callback()
        }
      }
      return {
        pwdForm: {
          user: '',
          password: '',
          code: ''
        },
        phoneForm: {
          phone: '',
          msgCode: ''
        },
        code: '',
        pwdRule: {
          user: [
            {required: true, message: '请输入用户名', trigger: 'blur'}
          ],
          password: [
            {required: true, message: '请输入密码', trigger: 'blur'}
          ],
          code: [
            {validator: validateCode, trigger: 'change'}
          ]
        },
        phoneRule: {
          phone: [
            {validator: validatePhone, trigger: 'blur'}
          ],
          msgCode: [
            {required: true, message: '请输入手机验证码', trigger: 'blur'}
          ]
        },
        pwdLogin: true,
        loginTitle: '密码登录',
        activeName: 'site',

        codeMsg: '获取验证码',
        totalTime: 60,
        canClick: true,
        clock: null
      }
    },
    computed: {
      ...mapState([
        'loading'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    mounted() {
      this.generatedCode()
    },
    created() {
      this.handleBaseDialog({visible: false, type: 'CustomerListVisible'})
      this.initData()
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'selectSub',
        'saveCommonCartNum',
        'saveSupplierCartNum'
      ]),
      generatedCode() {
        const random = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        let code = ''
        for (let i = 0; i < 4; i++) {
          let index = Math.floor(Math.random() * 10)
          code += random[index]
        }
        console.log(code)
        this.code = code
      },
      // 清空数据
      initData() {
        this.$Modal.remove()
        // 为了实现在退出时候，隐藏客服弹窗，在登录后清除掉样式
        let pany = document.querySelector('.easemobim-chat-panel')
        if (pany) {
          pany.style.display = 'none'
        }
        this.loginOut()
      },
      async loginOut() {
        let {data} = await api.LogOut()
        console.log(data)
        if (data.status == 0) {
          localStorage.removeItem('vuex')
        }
      },
      tabSelect(name) {
        console.log(name)
        if (name != 'site') {
          window.open(name)
        }
      },
      // 跳转到相关外链
      jump(type) {
        let url = type === 'policy' ? options.ServicePolicy : options.BeianUrl
        window.open(url)
      },
      // 切换登录方式
      changeLoginType() {
        this.pwdLogin = !this.pwdLogin
        this.loginTitle = this.pwdLogin ? '密码登录' : '手机快捷登录'
        this.$refs['phoneForm'].resetFields()
      },
      submit(name) {
        this.$refs[name].validate((valid) => {
          if (valid) {
            this.toLogin()
          }
        })
      },

      // 账号密码登录   手机号登录
      async toLogin() {
        let self = this
        let params = {
          loginId: self.pwdLogin ? self.pwdForm.user : self.phoneForm.phone,
          password: self.pwdLogin ? self.pwdForm.password : self.phoneForm.msgCode,
          loginType: self.pwdLogin ? 1 : 2
        }
        let {data} = await api.login(params)

        if (data.status == 0) {
          this.$store.commit(types.USER_INFO, data.data)
          if (data.data.size == 1) {
            let subCustomerId = data.data.subCustomerId
            // 选择部门
            self.selectSub({subCustomerId: subCustomerId}).then(res => {
              let data = res.data
              if (data.status == 0) {
                console.log(data.data.totalQty)
                self.saveCommonCartNum(data.data.totalQty)
                self.saveSupplierCartNum(data.data.supplierTotalQty)
                this.$store.commit(types.USER_INFO, Object.assign({}, data.data, this.userData))
                self.$router.replace({name: 'home'})
                // 进行刷新操作，清除浏览器缓存
                // self.reload()
                // window.location.reload(true)
                let query = {
                  supplierId: this.userData.supplierId,
                  userId: this.userData.userId,
                  subcustomerId: this.userData.subCustomerId,
                  intoTypeId: 2,
                  recordType: 1,
                  deviceType: 'pc',
                  sysVersion: window.navigator.appVersion,
                  programType: 3
                }
                api.getGetActionTime(query).then(res => {
                })
              }
            })
          } else {
            self.handleBaseDialog({visible: true, type: 'CustomerListVisible'})
          }
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },

      // 发送验证码
      sendCode() {
        this.$refs.phoneForm.validateField('phone')
        if (utils.isPhone(this.phoneForm.phone)) {
          this.handleSend()
          this.countDown()
          this.$refs.phoneCode.focus()
        }
      },
      async handleSend() {
        let self = this
        let params = {
          loginId: self.phoneForm.phone
        }
        let {data} = await api.getSendPhoneCode(params)
        if (data.status == 0) {
          console.log(data.message)
        } else {
          self.$Notice.error({
            desc: data.message
          })
          clearInterval(this.clock)
          this.codeMsg = '获取验证码'
          this.totalTime = 60
          this.canClick = true
        }
      },
      countDown() {
        if (!this.canClick) return
        this.canClick = false
        this.codeMsg = this.totalTime + 's后重新发送'
        this.clock = setInterval(() => {
          this.totalTime--
          this.codeMsg = this.totalTime + 's后重新发送'
          if (this.totalTime < 0) {
            clearInterval(this.clock)
            this.codeMsg = '重新发送'
            this.totalTime = 60
            this.canClick = true
          }
        }, 1000)
      },
      handleRegister() {
        this.$router.push({path: '/register'})
      }
    }
  }
</script>

<style lang="less">
  .login {
    position: relative;
    background-color: #ffffff;
    width: 100%;
    min-width: 1000px;

    .login-wrap {
      margin: 0 auto;

      .header-l {
        height: 88px;
        line-height: 88px;
        display: flex;

        &-logo {
          width: 200px;
          height: 60px;
          margin-top: 12px;
        }

        &-name {
          margin-left: 20px;
          font-size: 26px;
          font-family: 微软雅黑;
          color: rgb(47, 47, 47);
        }
      }

      .header-r {
        display: flex;
        align-items: center;
        margin-top: 20px;

        &-img {
          width: 61px;
          height: 53px;
        }

        &-phone {
          margin-left: 10px;

          .phone-desc {
            font-size: 13px;
            font-family: 微软雅黑;
          }

          .phone {
            font-size: 24px;
            font-weight: 700;
            color: #E61E10;
            font-family: 微软雅黑;
          }
        }
      }

      .m-bg {
        overflow-x: hidden;
        text-align: center;

        &-img {
          height: auto;
          width: 1920px;
          background-size: 100% 100%;
        }
      }

      .m-login-2code {
        position: absolute;
        right: 650px;
        top: 400px;
        z-index: 999;

        .m-2code-img {
          width: 140px;
          height: 140px;
        }
      }

      .m-footer {
        padding-top: 20px;

        p {
          height: 20px;
          line-height: 20px;
          text-align: center;
          white-space: nowrap;
        }
      }
    }

    .login-tab {
      background: #fcfcfc;

      .login-tab-menu {
        height: 60px;
        line-height: 60px;
        background: #fcfcfc;

        .menu-item {
          font-size: 18px;
          font-weight: 600;
        }

        /*.menu-item:hover{*/
        /*background: #ed4014;*/
        /*color: #ffffff;*/
        /*}*/
      }
    }

    .login-wrap-form {
      width: 1920px;
      height: 598px;
      position: relative;
      background: url("../assets/images/banner.png");

      .m-login-form {
        position: absolute;
        right: 80px;
        top: 80px;
        z-index: 999;

        .form-r-img {
          position: absolute;
          right: 5px;
          top: 5px;
          cursor: pointer;
          height: 50px;
          width: 50px;
        }

        .form-r-label {
          position: absolute;
          right: 55px;
          top: 10px;

          .tip {
            border: 1px solid #f3d995;
            padding: 5px 20px 5px 15px;
            background: #fefcee;
            position: relative;
            display: flex;

            .tip-text {
              color: #DF9C1F;
            }

            i {
              display: inline-block;
              padding: 4px 5px 0 0;
            }

            .arrow {
              position: absolute;
              right: -5px;
              top: 10px;
              display: inline-block;
              border-top: 1px solid;
              border-right: 1px solid;
              background-color: #fefcee;
              width: 10px;
              height: 10px;
              border-color: #f3d995;
              transform: rotate(45deg);
            }
          }
        }

        .form-title {
          .title {
            font-size: 16px;
            font-weight: 600;
          }
        }

        .form-wrap {
          padding: 15px 10px 20px 10px;

          &-code {
            position: relative;

            .code-img {
              position: absolute;
              left: 60px;
              padding: 5px;
              border: 1px solid #cccccc;
              width: 129px;
              height: 129px;
            }

            .code-delay {
              background-color: #ffffff;
              opacity: 0.95;
              padding-top: 20px;
              text-align: center;

              p {
                font-size: 14px;
                font-weight: 600;
                padding: 10px 0;
              }
            }

            .code-text {
              font-size: 14px;
              text-align: center;
            }
          }

          .phone-login {
            cursor: pointer;
            color: #E61E10;
          }

          .code-wrap {
            display: flex;
            justify-content: space-between;

            .code-wrap-ipt {
              width: 150px;
            }

            .code-btn {
              width: 96px;
              padding: 0;
              text-align: center;
              color: #ffffff;
              background-color: #E61E10;
            }

            .code-wrap-msg {
              width: 90px;
              height: 35px;
              line-height: 35px;
              text-align: center;
              background: linear-gradient(#e3e3e3, #E61E10);
              background: -webkit-linear-gradient(#e3e3e3, #E61E10);
              background: -o-linear-gradient(#e3e3e3, #E61E10);
              background: -moz-linear-gradient(#e3e3e3, #E61E10);
              cursor: pointer;

              .msg-text {
                color: #ffffff;
                font-style: italic;
                font-size: 20px;
                font-weight: 700;
                letter-spacing: 3px;
                text-shadow: 5px 2px 6px #999;
                moz-user-select: -moz-none;
                -moz-user-select: none;
                -o-user-select: none;
                -khtml-user-select: none;
                -webkit-user-select: none;
                -ms-user-select: none;
                user-select: none;
              }
            }
          }
        }
      }
    }
  }
</style>
