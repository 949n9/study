<template>
  <Modal
    :value="commonOrderDialogVisible"
    title="订单详情"
    :mask-closable="false"
    footer-hide
    width="1300"
    :styles="{top: '10px'}"
    @on-visible-change="dialogChange"
    @on-cancel="closeDialog"
  >
    <!-- 用于调试 -->
  <!-- <template>
         <i-form :model="settlementInfo" label-position="left" :label-width="100">
            <Form-item label="账户可用余额">
                <i-input v-model="settlementInfo.availableBalance"></i-input>
            </Form-item>
            <Form-item label="订单总金额">
                <i-input v-model="settlementInfo.totalAmount"></i-input>
            </Form-item>
            <Form-item label="实际支付金额">
                <i-input v-model="settlementInfo.taotalPayAmount"></i-input>
            </Form-item>
            <Form-item label="限制金额">
                <i-input v-model="settlementInfo.maxRechargeAmount"></i-input>
            </Form-item>
            <Form-item>
                <i-button type="primary" @click="handleSubmit('formValidate')">提交</i-button>
            </Form-item>
         </i-form>
    </template> -->
    <div v-loading="loading">
      <div class="common-settlement" ref="commonDialog" :style="{height:tabHeight+'px'}">
        <div class="mine-header">
          <Breadcrumb>
            <BreadcrumbItem>我的订单</BreadcrumbItem>
            <BreadcrumbItem>商城订单</BreadcrumbItem>
            <BreadcrumbItem>订单详情</BreadcrumbItem>
          </Breadcrumb>
        </div>
        <div class="common-wrap" v-show="Object.keys(orderTraceInfo).length">
          <div class="wrap-address">
            <div class="header">
              <p>物流信息</p>
            </div>

            <!--有物流信息时的展示-->
            <div v-if="orderTraceInfo.isSub" class="trace-wrap">
              <ul>
                <li v-for="(item,index) in orderTraceInfo.dataList" :key="index" class="trace-li">
                  <div class="trace-l">
                    <p class="trace-l-header" v-show="orderTraceInfo.dataList.length>1">包裹{{index+1}}</p>
                    <div class="trace-l-wrap">
                      <Poptip trigger="hover" placement="right" width="500">
                        <div class="trace-l-wrap-l" @mouseenter="searchOrderDetail(item.id)">
                          <img :src="item.productImgUrl" alt="" :onerror="defaultPimg()" class="trace-l-img">
                          <p class="trace-l-text">共{{item.productCount}}种商品</p>
                        </div>
                        <div slot="content">
                          <ul class="trace-product">
                            <li v-for="(p,index) in proList" :key="index" class="trace-product-li">
                              <img :src="p.imgUrl" alt="" class="trace-product-img" :onerror="defaultPimg()"
                                   @click="toDetail(p)">
                              <div style="margin-left: 10px;position: relative">
                                <h3 class="trace-product-name" @click="toDetail(p)">{{p.productName}}</h3>
                                <p>
                                  <span>订货数量：{{p.orderQty}}</span>
                                  <span class="trace-product-qty">实发数量：{{p.sendQty}}</span>
                                </p>
                                <p class="red--text trace-product-price">
                                  ¥{{p.taxPrice}}
                                </p>
                              </div>
                            </li>
                          </ul>
                        </div>
                      </Poptip>

                      <div class="trace-l-wrap-r">
                        <p>物流公司：<span>{{item.logisticsName}}</span></p>
                        <p>快递单号：<span :id="item.logisticsNo">{{item.logisticsNo}}</span></p>
                        <p>配送中心：<span>{{item.dcName}}</span></p>
                        <p>发货单号：<span :id="item.subOrderCode">{{item.subOrderCode}}</span>
                        </p>
                      </div>
                    </div>
                  </div>
                  <div class="trace-r">
                    <Timeline :class="[item.requireFold?'trace-r-fold':'trace-r-normal']">
                      <TimelineItem v-for="(i,index) in item.details" :key="index" color="green">
                        <p class="trace-wrap-header">{{i.msg}}</p>
                        <p class="trace-wrap-time">{{i.traceTime}}</p>
                      </TimelineItem>
                    </Timeline>
                    <Divider class="trace-r-change" v-if="item.details.length>3 && item.requireFold"
                             @click.native="changeTraceWrap(item)">
                      <span style="font-size: 13px">展开</span>
                      <Icon type="ios-arrow-down" size="18"/>
                    </Divider>
                    <Divider style="margin: 0;cursor: pointer" v-else-if="item.details.length>3 && !item.requireFold"
                             @click.native="changeTraceWrap(item)">
                      <span style="font-size: 13px">折叠</span>
                      <Icon type="ios-arrow-up" size="18"/>
                    </Divider>
                  </div>
                </li>
              </ul>
            </div>

            <!--还没有物流信息时候的展示-->
            <div v-else class="trace-wrap">
              <Timeline>
                <TimelineItem v-for="(item,index) in orderTraceInfo.dataList" :key="index" color="green">
                  <p class="trace-wrap-header">{{item.msg}}</p>
                  <p class="trace-wrap-time">{{item.traceTime}}</p>
                </TimelineItem>
              </Timeline>
            </div>

          </div>
        </div>

        <template v-if="settlementInfo.status==12||settlementInfo.status==4">
          <div class="address-header">
            <h3 class="settle-header">确认收货地址</h3>
            <p class="address-add red--text" @click="addAddress(settlementInfo.subCustomerId)">新增收货地址</p>
          </div>

          <div class="common-wrap">
            <div v-if="!showMoreAddress">
              <Radio class="address-item address-text" :value="true">
                <span :title="settlementInfo.address">{{settlementInfo.address | cutAddress}} </span>
                <span style="margin-left: 10px">{{settlementInfo.contactor}}</span>
                <span style="margin-left: 10px">{{settlementInfo.mobilePhone}}</span>
                <Button type="text" @click="editAddress(settlementInfo.receiveAddressId)" class="address-item-edit">
                  修改本地址
                </Button>
              </Radio>
            </div>
            <div v-else-if="showMoreAddress && getAddressList.length">
              <RadioGroup v-model="receiveAddressId" vertical class="address-group" @on-change="handleRadioChange">
                <Radio class="address-item" v-for="(item,index) in getAddressList" :key="index" :label="item.id"
                       :class="{'address-text':receiveAddressId==item.id}">
                  <span :title="item.fullAddress">{{item.fullAddress | cutAddress}}</span>
                  <span style="margin-left: 10px">{{item.receiver}}</span>
                  <span style="margin-left: 10px">{{item.receiveMobilePhone}}</span>
                  <Badge v-show="item.isDefault==1" style="margin-left: 15px" text="默认地址" type="warning"></Badge>
                  <Button type="text" @click="editAddress(item.id)" class="address-item-edit">修改本地址</Button>
                </Radio>
              </RadioGroup>
            </div>

            <div class="address-more" v-show="getAddressList.length>1">
              <div @click="changeAddress" class="address-more-btn">
                {{showMoreAddress?'收起地址':'查看更多'}}
                <Icon v-if="!showMoreAddress" type="ios-arrow-down"/>
                <Icon v-else type="ios-arrow-up"/>
              </div>
            </div>
          </div>

          <div class="address-header">
            <h3 class="settle-header">确认订单信息</h3>
          </div>
        </template>

        <div class="common-wrap">
          <div class="wrap-address">
            <div class="header">
              <p>订单信息</p>
            </div>
            <Row class="content">
              <Col span="8" class="item">
                <span>当前状态：<em class="red--text" style="font-weight: 600">{{settlementInfo.status==1?'审核中':settlementInfo.statusName}}</em></span>
              </Col>
            </Row>
            <Row class="content">
              <Col span="8" class="item">
                <span>订单编号：<em id="msg">{{settlementInfo.orderCode}}</em></span>
                <button @click="handleCopy"
                        ref="copy"
                        data-clipboard-action="copy"
                        data-clipboard-target="#msg"
                        class="item-copy"
                >复制
                </button>
              </Col>
              <Col span="8" class="item">
                <span>发送时间：{{settlementInfo.createTime}}</span>
              </Col>
            </Row>
            <Row class="content">
              <Col span="8" class="item">
                <span>发送人：{{settlementInfo.createEmpName}}</span>
              </Col>
              <Col span="8" class="item">
                <span>审核人：{{settlementInfo.approveEmpName}}</span>
              </Col>
              <Col span="8" class="item">
                <span>审核时间：{{settlementInfo.approveTime}}</span>
              </Col>
            </Row>
          </div>
        </div>

        <template v-if="settlementInfo.status==1||settlementInfo.status==3">
          <div class="common-wrap">
            <div class="wrap-address">
              <div class="header">
                <p>收货地址</p>
              </div>
              <Row class="content">
                <Col span="8" class="item">
                  <span>收货人：{{settlementInfo.contactor}}</span>
                </Col>
                <Col span="8" class="item">
                  <span>联系电话：{{settlementInfo.mobilePhone}}</span>
                </Col>
              </Row>
              <Row class="content">
                <Col class="item">
                  <p>收货地址：{{settlementInfo.address}}</p>
                </Col>
              </Row>
            </div>
          </div>
        </template>

        <div class="common-wrap">
          <Table border v-if="productsList.length" size="small" :columns="columns"
                 ref="table"
                 :data="productsList">
            <template slot-scope="{ row }" slot="name">
              <div class="cart-name">
                <img :src="row.imgUrl" alt="" class="p-img" :onerror="defaultPimg()" @click="toDetail(row)">
                <div class="p-name-wrap" @click="toDetail(row)">
                  <p class="p-name">{{row.productName}}</p>
                  <p style="margin:5px 0;color:#E61E10;" v-if="row.periodKey&&row.periodKey!=='null'">{{row.productDescription}}</p>
                  <Badge :text="'物流费减免：'+row.deliveryFeeReduceRate+'%'" class-name="p-wrap-badge">
                  </Badge>
                </div>
              </div>
            </template>
            <template slot-scope="{ row }" slot="num">
              <div class="cart-num" v-if="settlementInfo.status==12||settlementInfo.status==4">
                <InputNumber
                  :min="row.minOrderQty*1"
                  :max="999999"
                  v-model="row.orderQty"
                  :precision="row.qtyDecimalPlace*1"
                  :ref="row.id" :active-change="false"
                  @on-focus="(a)=>qtyFocus(a,row.id)"
                  @on-change="(a)=>qtyChange(a,row)"
                ></InputNumber>
                <p class="p-store" v-if="userData.showDistQty==='true'">库存：{{row.dcDistQty}}</p>
                <p class="p-store" v-else>
                  <span v-if="row.dcDistQty*1>0 && row.dcDistQty*1<row.warnDistQty*1" class="warn--text">库存紧张</span>
                  <span v-else-if="row.dcDistQty*1<=0" class="red--text">暂时无货</span>
                  <span v-else>库存充足</span>
                </p>
              </div>
              <div class="cart-num" v-else>
                <p>{{row.orderQty}}</p>
                <p v-if="row.sendQty*1>0">实发：{{row.sendQty}}</p>
              </div>
            </template>
            <template slot-scope="{ row }" slot="price">
              <p>¥{{row.orderPrice }}</p>
            </template>
            <template slot-scope="{ row }" slot="action">
              <Button type="text" @click="delectProduct(row)"
                      v-if="(settlementInfo.status=='12'||settlementInfo.status=='4')&&productsList.length>1">删除
              </Button>
            </template>
          </Table>
          <template>
            <div class="coupon-wrap" v-if="couponList.length">
              <div class="coupon-header" v-if="settlementInfo.status==12||settlementInfo.status==4"><span>优惠券</span>本订单可使用以下优惠券</div>
              <div class="coupon-header" v-if="settlementInfo.status==1||settlementInfo.status==3"><span>优惠券</span>本订单已经使用以下优惠券</div>
              <div class="coupon-list">
                <!-- <section class="coupon-type-list" v-for="e in couponList" :key="e.categoryId"> -->
                  <!-- <div class="coupon-list-header">{{e.categoryName}}</div> -->
                  <div class="coupon-list-item" :class="selectedStatus(item)" v-for="(item, index) in couponList" :key="index" @click="selectCoupon(item)">
                      <div class="item-top">
                        <p><em>￥</em><span class="price">{{item.value}}</span><span class="type">{{item.categoryName}}</span></p>
                      </div>
                      <div class="item-bottom">
                        <p class="date">{{item.begDate}}至{{item.endDate}}</p>
                        <p class="des">
                          <Tooltip theme="light" placement="bottom" max-width="200">
                            <p class="des" @click.stop="openCouponDetail(item)">[使用说明]</p>
                            <div slot="content">
                              <p>{{item.description}}</p>
                            </div>
                          </Tooltip>
                        </p>
                      </div>
                  </div>
                <!-- </section> -->
              </div>
            </div>
          </template>
          <Row class="common-footer">
            <Col span="18">
              <div class="item">
                <div>配送方式：由小红马优选物流送货
                  <Tooltip theme="light" placement="right-start">
                    <Icon size="20" type="ios-help-circle-outline" class="warn--text"/>
                    <div slot="content">
                      <p>物流费为小红马合作快递或物流公司</p>
                      <p>送货到店的费用，极少数偏远地区需</p>
                      <p>到附近的快递、物流站点自提或与站</p>
                      <p>点协商送货费用。</p>
                    </div>
                  </Tooltip>
                </div>
              </div>
              <div class="item">
                <p>备注信息：</p>
                <Input class="ipt" v-if="settlementInfo.status=='12'||settlementInfo.status=='4'" type="textarea"
                       :maxlength="200"
                       v-model.trim="description"/>
                <div class="remark" v-else :title="description">
                  {{ description}}
                </div>
              </div>
            </Col>
            <Col span="6">
              <div>
                <p class="r-price"><span>商品总额：</span><span class="red--text">¥{{settlementInfo.totalAmount}}</span></p>
                <div class="r-item-other">
                  <div class="r-item">
                    <span>物流费：</span>
                    <span>
                 <Tooltip theme="light" placement="left-end">
                <Icon size="20" type="ios-help-circle-outline" class="warn--text"/>
                <div slot="content">
                  <p v-html="cost"></p>
                </div>
              </Tooltip>
                ¥{{settlementInfo.totalDeliveryFeeCalcAmount}}
              </span>
                  </div>
                  <p class="r-item"><span>物流减免：</span><span>-¥{{settlementInfo.totalDeliveryFeeReduceAmount}}</span></p>
                  <p class="r-item"><span>物流费调整：</span><span>-¥0.00</span></p>
                </div>
                <p class="r-item"><span>实付物流费：</span><span class="red--text">¥{{settlementInfo.totalPayDeliveryFeeReduceAmount}}</span>
                </p>
                <p class="r-item"><span>优惠券：</span><span class="red--text">-¥{{settlementInfo.selectedCouponDiscountAmount}}</span></p>

              </div>
            </Col>
          </Row>
          <Row class="common-footer line">
            <Col span="17">
              &nbsp;
            </Col>
            <Col span="7">
              <div>
                <p class="r-price red--text"><span>订单总金额：</span><span>¥{{settlementInfo.taotalPayAmount}}</span></p>
                <p class="r-price red--text" v-if="settlementInfo.totalSendAmount*1>=0">
                  <span>订单实发总金额：</span>
                  <span>¥{{settlementInfo.totalSendAmount}}</span>
                </p>
                <p class="r-item" v-if="settlementInfo.status==12||settlementInfo.status==4"><span>账户可用金额：</span><span>¥{{settlementInfo.availableBalance}}</span>
                </p>
                <Button type="error" :disabled="loading" v-if="settlementInfo.status==1" class="btn"
                        @click="removeSettlement">
                  撤销订单
                </Button>
                <div style="display: flex;justify-content: space-between">
                  <Button :disabled="loading" v-if="settlementInfo.status==12||settlementInfo.status==4"
                          class="btn"
                          @click="deleteSettlement">
                    删除订单
                  </Button>
                  <Button type="error" :disabled="loading" v-if="settlementInfo.status==12||settlementInfo.status==4"
                          class="btn"
                          @click="handleSettlement">
                    发送并结算
                  </Button>
                </div>
              </div>
            </Col>
          </Row>
          <Row>
            <Col>
              <div v-if="settlementInfo.status==12||settlementInfo.status==4" class="footer-address-result">
                <span>{{settlementInfo.address}} </span>
                <span style="margin-left: 10px">{{settlementInfo.contactor}}</span>
                <span style="margin-left: 10px">{{settlementInfo.mobilePhone}}</span>
              </div>
            </Col>
          </Row>
        </div>

      </div>
    </div>
    <Modal
      v-model="couponDetailsVisible"
      title="优惠券详情"
      :mask-closable="false"
      :footer-hide="true"
      scrollable
      @on-visible-change="couponDetailChange">
      <ul class="coupon_wrap" v-if="couponDetail">
          <!-- <li class="coupon_wrap_item"><em>优惠劵编号：</em><span>{{couponDetail.code}}</span></li> -->
          <li class="coupon_wrap_item"><em>优惠券种类：</em><span>{{couponDetail.categoryName}}</span></li>
          <li class="coupon_wrap_item"><em>面值：</em><span>{{couponDetail.value}}</span></li>
          <li class="coupon_wrap_item"><em>有效期：</em><span>{{`${couponDetail.begDate} 到 ${couponDetail.endDate}`}}</span></li>
          <li class="coupon_wrap_item"><em>使用要求：</em><span>{{couponDetail.useNote}}</span></li>
          <!-- <li class="coupon_wrap_item"><em>使用状态：</em><span>{{couponDetail.statusText}}</span></li> -->
          <li class="coupon_wrap_item"><em>优惠券摘要：</em><span>{{couponDetail.description}}</span></li>
      </ul>
    </Modal>
  </Modal>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core'
  import * as opt from './options'

  export default {
    name: 'CommonOrderDetail',
    data() {
      return {
        commonDialog: null,
        tabHeight: '',
        dialogLoading: false,
        columns: opt.commonSettlementHeader,
        settlementInfo: {},
        productsList: [],
        couponList: [],
        couponDetail: {},
        couponDetailsVisible: false,
        description: '',
        payPassword: '',
        orderId: '',
        cost: '',
        copyBtn: null,
        orderTraceInfo: {},
        proList: [],
        savedArr: [],
        proIdInfo: [],

        showMoreAddress: false,
        receiveAddressId: '',
        couponIds: ''
      }
    },
    computed: {
      ...mapState([
        'loading',
        'commonOrderDialogVisible',
        'orderDetailId',
        'addressEdit',
        'commonSettlementInfo'
      ]),
      ...mapGetters([
        'userData',
        'getAddressList'
      ])
    },
    watch: {
      'addressEdit': 'handleAddress'
    },
    created() {
      this.initData()
    },
    mounted() {
      this.commonDialog = this.$refs.commonDialog
      this.copyBtn = new this.$clipboard(this.$refs.copy)
    },
    methods: {
      ...mapActions([
        'saveCommonCartNum',
        'saveProductInfo',
        'saveProductSeriesInfo',
        'saveProductDateInfo',
        'handleBaseDialog',
        'saveOrderStatus',
        'saveOrderId',
        'handleOrderStatus',
        'handleBasicInfo',
        'getReceiverAddress',
        'saveOrderInfo',
        'saveCommonSettlementInfo'
      ]),
      initData() {
        this.handleBaseDialog({visible: false, type: 'commonOrderDialogVisible'})
      },
      couponDetailChange(e) {
      },
      openCouponDetail(item) {
        if (item.status == 0) item.statusText = '未使用'
        if (item.status == 1) item.statusText = '已使用'
        if (item.status == 2) item.statusText = '已过期'
        this.couponDetail = item
        this.couponDetailsVisible = true
      },
      selectedStatus(item) {
        if (item.selected == 1) return ''
        if (item.selected == 0) return 'coupon-list-item-selected'
        if (item.selected == 2) return 'coupon-list-item-disable'
      },
      dialogChange(v) {
        console.log(v)
        this.showMoreAddress = false
        if (v) {
          this.$nextTick(() => {
            this.commonDialog.scrollTop = 0
          })
          let h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
          this.tabHeight = h - 95
          this.orderId = this.orderDetailId
          this.getOrderInfo()
        } else {
          this.saveOrderId('')
          this.handleBaseDialog({visible: false, type: 'commonOrderDialogVisible'})
        }
      },
      // 选择优惠券
      selectCoupon(item) {
        if (this.settlementInfo.status == 1 || this.settlementInfo.status == 3) return null
        if (item.selected == 2) return null
        if (item.selected == 0) {
          item.selected = 1
        } else {
          item.selected = 0
        }
        let temp = []
        this.couponList.forEach(e => {
          if (e.selected == 0) {
            temp.push(e)
          }
        })
        this.couponIds = temp.map(e => {
          return e.id
        }).join()
        this.selectCouponItem()
      },
      // 选择优惠券(请求接口)
      async selectCouponItem() {
        let self = this
        let params = {
          id: self.orderId,
          couponIds: self.couponIds,
          receiveAddressId: self.receiveAddressId || '',
          couponChooseType: 1
        }
        let {data} = await api.getOrderDetail(params)
        if (data.status == 0) {
          this.settlementInfo = data.data
          this.couponList = data.data.couponList
          api.getMaxRechargeAmount().then(res => {
            console.log(res)
            if (res.data.status == 0) {
              self.saveCommonSettlementInfo(Object.assign({}, data.data, res.data.data))
              self.settlementInfo = self.commonSettlementInfo
            }
          })
        } else {
          this.$Modal.error({
            title: '温馨提示',
            content: data.message,
            onOk: () => {
            }
          })
        }
      },
      // 获取结算详情
      async getOrderInfo() {
        let self = this
        let params = {
          id: self.orderId
        }
        self.dialogLoading = false
        self.settlementInfo = {}
        let {data} = await api.getOrderDetail(params)
        console.log(data)
        if (data.status == '0') {
          self.settlementInfo = data.data
          api.getMaxRechargeAmount().then(res => {
            console.log(res)
            if (res.data.status == 0) {
              self.saveCommonSettlementInfo(Object.assign({}, data.data, res.data.data))
              self.settlementInfo = self.commonSettlementInfo
            }
          })
          self.couponList = self.settlementInfo.couponList
          self.description = data.data.description
          let temp = []
          this.couponList.forEach(e => {
            if (e.selected == 0) {
                temp.push(e)
            }
          })
          this.couponIds = temp.map(e => {
            return e.id
          }).join()
          let proArr = data.data.products
          proArr.forEach((item, index) => {
            item.orderQty = item.orderQty * 1
            item.id = new Date().getTime() + index
          })
          self.productsList = proArr
          let obj = self.settlementInfo.deliveryDcFeeCalcAmount
          let str = ''
          for (let key in obj) {
            console.log(key)
            console.log(obj[key])
            str += '<p>' + key + '：¥' + obj[key] + '元</p>'
          }
          self.cost = str
          console.log(str)
          self.dialogLoading = false
          if (self.settlementInfo.status == 3 || self.settlementInfo.status == 1) {
            self.getTranceInfo()
          } else {
            self.orderTraceInfo = {}

            this.receiveAddressId = this.settlementInfo.receiveAddressId
            this.getReceiverAddress(this.settlementInfo.subCustomerId)
          }
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 获取物流信息
      async getTranceInfo() {
        let self = this
        let params = {
          orderId: self.orderId
        }
        let {data} = await api.getOrderTrace(params)
        console.log(data)
        if (data.status == 0) {
          self.orderTraceInfo = data.data
        }
      },
      // 获取 物流单中订单明细
      searchOrderDetail(id) {
        console.log(id)
        if (this.savedArr.length) {
          if (this.savedArr.includes(id)) {
            let obj = this.proIdInfo.filter(item => item.id == id)[0]
            console.log(obj)
            this.proList = obj.obj
          } else {
            this.handleOrderDetail(id)
          }
        } else {
          this.handleOrderDetail(id)
        }
      },
      // 获取 物流单中订单明细
      async handleOrderDetail(id) {
        console.log(id)
        let self = this
        let params = {
          subOrderId: id,
          pageSize: 9999
        }
        let {data} = await api.getSoDcSubOrderDetail(params)
        console.log(data)
        if (data.status == 0) {
          self.proList = data.data.list
          self.savedArr.push(id)
          self.proIdInfo.push({id: id, obj: data.data.list})
        }
      },
      async productDelete(row) {
        let self = this
        let obj = {
          orderId: row.orderId,
          orderDetailId: row.detailId
        }
        let params = {
          details: JSON.stringify([obj])
        }
        let {data} = await api.getCommonOrderProductDelete(params)
        if (data.status == 0) {
          self.$Notice.success({
            desc: data.message
          })
          self.getOrderInfo()
          self.handleOrderStatus(new Date().getTime())
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 删除商品
      delectProduct(row) {
        this.$Modal.confirm({
          title: '温馨提示',
          content: '<p>商品删除后将无法恢复，是否确认删除？</p>',
          onOk: () => {
            this.productDelete(row)
          },
          onCancel: () => {
          }
        })
      },
      qtyFocus(e, id) {
        console.log(this.$refs[id])
        setTimeout(() => {
          // this.$refs[id].$el.querySelector('input').click()
          this.$refs[id].$el.querySelector('input').select()
        }, 10)
      },
      // 数量切换时候
      qtyChange(v, row) {
        console.log(v)
        console.log(row)
        if (v) {
          this.addCart(row)
        } else {
          this.$nextTick(() => {
            row.orderQty = row.minOrderQty
            this.addCart(row)
          })
        }
      },
      // 切换后 重新请求更新订单数量接口
      async addCart(row) {
        let self = this
        let obj = {
          orderId: row.orderId,
          orderDetailId: row.detailId,
          orderDetailQty: row.orderQty || ''
        }

        let params = {
          details: JSON.stringify([obj])
        }
        let {data} = await api.getUpdateCommonQty(params)
        if (data.status == '0') {
          self.getOrderInfo()
          self.handleOrderStatus(new Date().getTime())
        } else {
          self.$Modal.error({
            title: '温馨提示',
            content: data.message,
            onOk: () => {
              setTimeout(() => {
                this.productsList[row._index].orderQty = row.minOrderQty
                this.$refs[row.productId].$el.querySelector('input').select()
              }, 10)
            }
          })
        }
        console.log(data)
      },
      // 撤销订单
      removeSettlement() {
        this.$Modal.confirm({
          title: '温馨提示',
          content: '<p>订单撤销后，可以在“未发送订单列表”中查看这个订单，您确认要撤销本订单吗？</p>',
          onOk: () => {
            this.handleRemoveOrder()
          },
          onCancel: () => {
          }
        })
      },
      // 撤销订单
      async handleRemoveOrder() {
        let self = this
        let params = {
          orderId: self.orderId
        }
        let {data} = await api.getCommonOrderUnDo(params)
        if (data.status == '0') {
          self.$Notice.success({
            desc: data.message
          })
          self.saveOrderStatus({type: 'commonOrder', status: '12', name: '2'})
          self.handleOrderStatus(new Date().getTime())
          self.handleBaseDialog({visible: false, type: 'commonOrderDialogVisible'})
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 删除订单
      deleteSettlement() {
        this.$Modal.confirm({
          title: '温馨提示',
          content: '<p>订单删除后将无法恢复，是否确认删除此订单？</p>',
          onOk: () => {
            this.toDeleteSettlement()
          },
          onCancel: () => {
          }
        })
      },
      // 删除订单
      async toDeleteSettlement() {
        let self = this
        let params = {
          orderId: self.orderId
        }
        let {data} = await api.getOrderDelete(params)
        if (data.status == 0) {
          self.$Notice.success({
            desc: data.message
          })
          self.saveOrderStatus({type: 'commonOrder', status: '-1', name: '2'})
          self.handleOrderStatus(new Date().getTime())
          self.handleBaseDialog({visible: false, type: 'commonOrderDialogVisible'})
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 进行结算前先进性判断 余额是否够支付 该订单金额
      handleSettlement() {
        console.log(this.settlementInfo)
        this.saveOrderInfo(this.settlementInfo)
        if (this.settlementInfo.isFirstOrder == '1') {
          this.$Modal.confirm({
            title: '温馨提示',
            content: this.settlementInfo.firstOrderAlert,
            cancelText: '返回修改地址',
            okText: '确定',
            onOk: () => {
              this.confirmSend()
            },
            onCancel: () => {
              this.backFix()
            }
          })
        } else {
          if (this.settlementInfo.taotalPayAmount == 0) {
            this.toSettlement()
          } else {
            let temp = {
              couponIds: this.couponIds,
              orderId: this.orderId,
              description: this.description,
              payPassword: this.payPassword
            }
            this.saveCommonSettlementInfo(Object.assign({}, this.commonSettlementInfo, temp))
            this.settlementInfo = this.commonSettlementInfo
            this.handleBaseDialog({visible: true, type: 'payMethodDialogVisible', orderType: 3})
          }
        }
        // if (this.settlementInfo.taotalPayAmount == 0) {
        //   this.toSettlement()
        // } else {
        //   let temp = {
        //     couponIds: this.couponIds,
        //     orderId: this.orderId,
        //     description: this.description,
        //     payPassword: this.payPassword
        //   }
        //   this.saveCommonSettlementInfo(Object.assign({}, this.commonSettlementInfo, temp))
        //   this.settlementInfo = this.commonSettlementInfo
        //   this.handleBaseDialog({visible: true, type: 'payMethodDialogVisible', orderType: 3})
        // }
        // if (this.settlementInfo.taotalPayAmount * 1 > 0 && parseFloat(this.settlementInfo.taotalPayAmount) > parseFloat(this.settlementInfo.availableBalance)) {
        //   let amount = parseFloat(this.settlementInfo.taotalPayAmount) - parseFloat(this.settlementInfo.availableBalance)
        //   amount = amount.toFixed(2)
        //   let message = `<p>您的资金账户可用余额不足，还需要充值 <span style="color:#E61E10">¥ ${amount}</span>，</p><p>去充值吧！</p>`
        //   this.$Modal.error({
        //     title: '温馨提示',
        //     content: message,
        //     width: 435,
        //     onOk: () => {
        //       this.handleBaseDialog({visible: false, type: 'commonOrderDialogVisible'})
        //       this.handleBaseDialog({visible: false, type: 'orderDialogVisible'})
        //       this.$router.push({path: '/mine/recharge', query: {amount: amount}})
        //     }
        //   })
        // } else {
        //   this.toSettlement()
        // }
      },
      confirmSend() {
        console.log('确定')
        if (this.settlementInfo.taotalPayAmount == 0) {
          this.toSettlement()
        } else {
          let temp = {
            couponIds: this.couponIds,
            orderId: this.orderId,
            description: this.description,
            payPassword: this.payPassword
          }
          this.saveCommonSettlementInfo(Object.assign({}, this.commonSettlementInfo, temp))
          this.settlementInfo = this.commonSettlementInfo
          this.handleBaseDialog({visible: true, type: 'payMethodDialogVisible', orderType: 3})
        }
      },
      backFix() {
        console.log('取消，返回修改地址')
      },
      // 进行结算
      async toSettlement() {
        let self = this
        let params = {
          orderId: self.orderId,
          distFeeReduceRatio: self.settlementInfo.distFeeReduceRatio,
          distFeeReduceRuleId: self.settlementInfo.distFeeReduceRuleId,
          description: self.description,
          payPassword: self.payPassword,
          receiveAddressId: self.receiveAddressId || '',
          couponIds: self.couponIds
        }
        let {data} = await api.getOrderSend(params)
        if (data.status == '0') {
          self.$Notice.success({
            desc: data.message
          })
          self.saveOrderStatus({type: 'commonOrder', status: '1', name: '1'})
          self.handleOrderStatus(new Date().getTime())
          // self.useCouponSuccess(true)
          self.handleBaseDialog({visible: false, type: 'commonOrderDialogVisible'})
          self.handleBaseDialog({visible: false, type: 'orderDialogVisible'})
          self.$router.push({name: 'paysuccess', query: {amount: self.settlementInfo.taotalPayAmount}})
          // self.$Modal.success({
          //   title: '温馨提示',
          //   content: '<div margin:0 auto 30px;font-size: 18px!important;>订单发送成功！</div>' +
          //            '<p>下午16:00前发送的订单将于当天审核发出，请耐心等待。</p>' +
          //            '<p>为保障您的权益，请先验货，再签收！</p>',
          //   width: '450',
          //   onOk: () => {
          //     self.handleBaseDialog({visible: false, type: 'commonOrderDialogVisible'})
          //     // self.handleBaseDialog({visible: true, type: 'orderDialogVisible'})
          //   }
          // })
        } else {
          self.$Modal.error({
            title: '温馨提示',
            content: data.message,
            onOk: () => {
            }
          })
        }
        console.log(data)
      },
      // 进行复制
      handleCopy() {
        let self = this
        let clipboard = self.copyBtn
        clipboard.on('success', function () {
        })
      },
      // 查看详情
      toDetail(row) {
        // console.log(row)
        // this.saveProductInfo(row.productId)
        // this.handleBaseDialog({visible: true, type: 'productDetailVisible'})
        console.log(row)
        this.saveProductInfo(row.productId)
        if (row.productSetId) this.saveProductSeriesInfo(row.productSetId)
        if (row.periodId) this.saveProductDateInfo(row.periodId)
        if (row.productType == '0') {
          this.handleBaseDialog({visible: true, type: 'productDetailVisible'})
        }
        if (row.productType == '1') {
          this.handleBaseDialog({visible: true, type: 'productSeriesDetailVisible'})
        }
        if (row.productType == '2') {
          this.handleBaseDialog({visible: true, type: 'productDateDetailVisible'})
        }
      },
      closeDialog() {
        this.handleBaseDialog({visible: false, type: 'commonOrderDialogVisible'})
        this.proList = []
        this.savedArr = []
        this.proIdInfo = []
      },
      // 显示 或者隐藏物流详情
      changeTraceWrap(item) {
        console.log(item)
        item.requireFold = !item.requireFold
        if (item.requireFold) {
          this.$nextTick(() => {
            this.commonDialog.scrollTop = 0
          })
        }
      },
      // 是否展示更多地址数据  ================================================================
      changeAddress() {
        this.showMoreAddress = !this.showMoreAddress
      },
      // 切换地址 1.需要刷新订单信息（物流费）
      handleRadioChange(v) {
        console.log(v)
        this.showMoreAddress = false
        this.updateOrderData()
      },
      // 修改地址
      editAddress(id) {
        this.handleBasicInfo({id: id, from: 'commonOrderDetail'})
        this.handleBaseDialog({visible: true, type: 'addAddressVisible', title: '编辑'})
      },
      // 新增地址
      addAddress(id) {
        this.handleBasicInfo({subCustomerId: id, from: 'commonOrderDetail'})
        this.handleBaseDialog({visible: true, type: 'addAddressVisible', title: '新增'})
      },
      // 修改完成 1.需要刷新地址信息 2.刷新订单信息
      handleAddress(v) {
        let path = v.split('?')[0]
        if (path == 'commonOrderDetail') {
          this.updateOrderData()
          // this.getReceiverAddress(this.settlementInfo.subCustomerId)
        }
      },
      // 修改地址后 更新订单信息
      async updateOrderData() {
        let self = this
        let params = {
          orderId: self.orderId,
          receiveAddressId: self.receiveAddressId
        }
        let {data} = await api.getUpdateOrderReceiveAddress(params)
        if (data.status == 1) {
          let msg = data.message.replace(/\n\n/g, '</p></br><p>')
          msg = '<div style="max-height: 500px;overflow: auto"><p>' + msg + '</p></div>'
          self.$Modal.error({
            title: '温馨提示',
            content: msg,
            width: 600,
            onOk: () => {
            }
          })
        } else {
          self.selectCouponItem()
        }
      }
    }
  }
</script>

<style lang="less">
  @import "orderdetail";
</style>
