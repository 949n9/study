<template>
  <Modal
    :value="supplierOrderDialogVisible"
    title="订单详情"
    :mask-closable="false"
    footer-hide
    width="1200"
    :styles="{top: '10px'}"
    @on-visible-change="dialogChange"
    @on-cancel="closeDialog"
  >
  <!-- 用于调试 -->
  <!-- <template>
         <i-form :model="settlementInfo" label-position="left" :label-width="100">
            <Form-item label="账户可用余额">
                <i-input v-model="settlementInfo.availableBalance"></i-input>
            </Form-item>
            <Form-item label="订单总金额">
                <i-input v-model="settlementInfo.totalAmount"></i-input>
            </Form-item>
            <Form-item label="实际支付金额">
                <i-input v-model="settlementInfo.taotalPayAmount"></i-input>
            </Form-item>
            <Form-item label="限制金额">
                <i-input v-model="settlementInfo.maxRechargeAmount"></i-input>
            </Form-item>
            <Form-item>
                <i-button type="primary" @click="handleSubmit('formValidate')">提交</i-button>
            </Form-item>
         </i-form>
    </template> -->
    <div v-loading="loading">
      <div class="common-settlement" ref="commonDialog" v-loading="loading" :style="{height:tabHeight+'px'}">
        <div class="mine-header">
          <Breadcrumb>
            <BreadcrumbItem>我的订单</BreadcrumbItem>
            <BreadcrumbItem>厂商直送订单</BreadcrumbItem>
            <BreadcrumbItem>订单详情</BreadcrumbItem>
          </Breadcrumb>
        </div>
        <div>

          <template v-if="settlementInfo.status==1||settlementInfo.status==2">
            <div class="address-header">
              <h3 class="settle-header">确认收货地址</h3>
              <p class="address-add red--text" @click="addAddress(settlementInfo.subCustomerId)">新增收货地址</p>
            </div>

            <div class="common-wrap">
              <div v-if="!showMoreAddress">
                <Radio class="address-item address-text" :value="true">
                  <span :title="settlementInfo.address">{{settlementInfo.address | cutAddress}} </span>
                  <span style="margin-left: 10px">{{settlementInfo.contactor}}</span>
                  <span style="margin-left: 10px">{{settlementInfo.mobilePhone}}</span>
                  <Button type="text" @click="editAddress(settlementInfo.receiveAddressId)" class="address-item-edit">
                    修改本地址
                  </Button>
                </Radio>
              </div>
              <div v-else-if="showMoreAddress && getAddressList.length">
                <RadioGroup v-model="receiveAddressId" vertical class="address-group" @on-change="handleRadioChange">
                  <Radio class="address-item" v-for="(item,index) in getAddressList" :key="index" :label="item.id"
                         :class="{'address-text':receiveAddressId==item.id}">
                    <span :title="item.fullAddress">{{item.fullAddress | cutAddress}}</span>
                    <span style="margin-left: 10px">{{item.receiver}}</span>
                    <span style="margin-left: 10px">{{item.receiveMobilePhone}}</span>
                    <Badge v-show="item.isDefault==1" style="margin-left: 15px" text="默认地址" type="warning"></Badge>
                    <Button type="text" @click="editAddress(item.id)" class="address-item-edit">修改本地址</Button>
                  </Radio>
                </RadioGroup>
              </div>

              <div class="address-more" v-show="getAddressList.length>1">
                <div @click="changeAddress" class="address-more-btn">
                  {{showMoreAddress?'收起地址':'查看更多'}}
                  <Icon v-if="!showMoreAddress" type="ios-arrow-down"/>
                  <Icon v-else type="ios-arrow-up"/>
                </div>
              </div>
            </div>

            <div class="address-header">
              <h3 class="settle-header">确认订单信息</h3>
            </div>
          </template>

          <div class="common-wrap">
            <div class="wrap-address">
              <div class="header">
                <p>订单信息</p>
              </div>
              <Row class="content">
                <Col span="8" class="item">
                  <span>当前状态：<em class="red--text" style="font-weight: 600">{{settlementInfo.status===3?'审核中':settlementInfo.statusName}}</em></span>
                </Col>
                <Col span="8" class="item">
                  <span>进货渠道：{{settlementInfo.supplierName}}</span>
                  <Badge text="服务商" v-if="settlementInfo.isService" type="warning"
                         style="margin-top: 7px;margin-left: 10px;cursor: pointer;z-index: 1">
                  </Badge>
                  <span style="margin-left: 10px">{{settlementInfo.supplierMobilePhone}}</span>
                </Col>
              </Row>
              <Row class="content">
                <Col span="8" class="item">
                  <span>订单编号：<em id="msg2">{{settlementInfo.orderCode}}</em></span>
                  <button @click="handleCopy"
                          ref="copy"
                          data-clipboard-action="copy"
                          data-clipboard-target="#msg2"
                          class="item-copy"
                  >复制
                  </button>
                </Col>
                <Col span="8" class="item"
                     v-if="settlementInfo.status==3||settlementInfo.status==4||settlementInfo.status==5">
                  <span>预计到货日期：{{settlementInfo.planImpDate}}</span>
                </Col>
                <Col span="8" class="item">
                  <span>发送时间：{{settlementInfo.createTime}}</span>
                </Col>
              </Row>
              <Row class="content">
                <Col span="8" class="item">
                  <span v-if="settlementInfo.isService">订货人：{{settlementInfo.createEmpName}}</span>
                  <span v-else>发送人：{{settlementInfo.createEmpName}}</span>
                </Col>
                <Col span="8" class="item">
                  <span>审核人：{{settlementInfo.approveEmpName}}</span>
                </Col>
                <Col span="8" class="item">
                  <span>审核时间：{{settlementInfo.approveTime}}</span>
                </Col>
              </Row>
            </div>
          </div>

          <template
            v-if="settlementInfo.status==3||settlementInfo.status==4||settlementInfo.status==5||settlementInfo.status==6">
            <div class="common-wrap">
              <div class="wrap-address">
                <div class="header">
                  <p>收货地址</p>
                </div>
                <Row class="content">
                  <Col span="8" class="item">
                    <span>收货人：{{settlementInfo.contactor}}</span>
                  </Col>
                  <Col span="8" class="item">
                    <span>联系电话：{{settlementInfo.mobilePhone}}</span>
                  </Col>
                </Row>
                <Row class="content">
                  <Col class="item">
                    <p>收货地址：{{settlementInfo.address}}</p>
                  </Col>
                </Row>
              </div>
            </div>
          </template>

          <div class="common-wrap">
            <Table border v-if="productsList.length" size="small" :columns="columns"
                   ref="table"
                   :data="productsList">
              <template slot-scope="{ row }" slot="name">
                <div class="cart-name">
                  <img :src="row.productImgUrl" alt="" class="p-img" :onerror="defaultPimg()" @click="toDetail(row)">
                  <div class="p-name-wrap" @click="toDetail(row)">
                    <p class="p-name">{{row.productName}}</p>
                  </div>
                </div>
              </template>
              <template slot-scope="{ row }" slot="num">
                <div class="cart-num" v-if="settlementInfo.status==1||settlementInfo.status==2">
                  <InputNumber
                    :min="row.minOrderQty*1"
                    :max="999999"
                    v-model="row.orderQty"
                    :precision="row.qtyDecimalPlace*1"
                    :ref="row.productId" :active-change="false"
                    @on-focus="(a)=>qtyFocus(a,row.productId)"
                    @on-change="(a)=>qtyChange(a,row)"
                  ></InputNumber>
                  <p class="p-store" v-if="userData.showDistQty==='true'">库存：{{row.distQty}}</p>
                  <p class="p-store" v-else>
                    <span v-if="row.distQty*1>0&&row.distQty*1<row.warnDistQty*1" class="warn--text">库存紧张</span>
                    <span v-else-if="row.distQty*1<=0" class="red--text">暂时无货</span>
                    <span v-else>库存充足</span>
                  </p>
                </div>
                <div class="cart-num" v-else>
                  <p>{{row.orderQty}}</p>
                  <p v-if="row.sendQty*1>0">实发：{{row.sendQty}}</p>
                </div>
              </template>
              <template slot-scope="{ row }" slot="price">
                <p>¥{{row.taxPrice }}</p>
              </template>
              <template slot-scope="{ row }" slot="action">
                <Button type="text" @click="delectProduct(row)"
                        v-if="(settlementInfo.status=='1'||settlementInfo.status=='2')&&productsList.length>1">删除
                </Button>
              </template>
            </Table>
            <Row class="common-footer">
              <Col span="18">
                <div class="item">
                  <p>备注信息：</p>
                  <Input class="ipt" v-if="settlementInfo.status*1<3" type="textarea"
                         :maxlength="200"
                         v-model.trim="description"/>
                  <div class="remark" v-else :title="description">
                    {{ description}}
                  </div>
                </div>
                <div class="item">
                  <p>卖方备注：</p>
                  <div class="remark" :title="settlementInfo.supplierRemark">
                    {{ settlementInfo.supplierRemark}}
                  </div>
                </div>
              </Col>
              <Col span="6">
                <div>
                  <p class="r-price"><span>商品总额：</span><span class="red--text">¥{{settlementInfo.totalAmount}}</span>
                  </p>
                  <div class="r-item-other" v-if="!settlementInfo.isService">
                    <div class="r-item"><span>物流费：</span><span>¥{{settlementInfo.totalDeliveryFeeCalcAmount}}</span>
                    </div>
                    <p class="r-item"><span>物流减免：</span><span>-¥{{settlementInfo.totalDeliveryFeeReduceAmount}}</span>
                    </p>
                    <p class="r-item"><span>物流费调整：</span><span>-¥0.00</span></p>
                  </div>
                  <p class="r-item" v-if="!settlementInfo.isService"><span>实付物流费：</span><span class="red--text">¥{{settlementInfo.totalPayDeliveryFeeReduceAmount}}</span>
                  </p>
                </div>
              </Col>
            </Row>
            <Row class="common-footer line">
              <Col span="17">
                &nbsp;
              </Col>
              <Col span="7">
                <div>
                  <p class="r-price red--text"><span>订单总金额：</span><span>¥{{settlementInfo.taotalPayAmount}}</span></p>
                  <p class="r-price red--text" v-if="settlementInfo.totalSendAmount>=0">
                    <span>订单实发总金额：</span>
                    <span>¥{{settlementInfo.totalSendAmount}}</span>
                  </p>
                  <p class="r-item" v-if="settlementInfo.status==1||settlementInfo.status==2"><span>账户可用金额：</span><span>¥{{settlementInfo.availableBalance}}</span>
                  </p>
                  <Button type="error" :disabled="loading" v-if="settlementInfo.status==3" class="btn"
                          @click="removeSettlement">
                    撤销订单
                  </Button>
                  <Button type="error" :disabled="loading" v-if="settlementInfo.status==5"
                          class="btn"
                          @click="handleConfirm">
                    确认收货
                  </Button>
                  <div style="display: flex;justify-content: space-between">
                    <Button :disabled="loading" v-if="settlementInfo.status==1||settlementInfo.status==2"
                            class="btn"
                            @click="deleteSettlement">
                      删除订单
                    </Button>
                    <Button type="error" :disabled="loading" v-if="settlementInfo.status==1||settlementInfo.status==2"
                            class="btn"
                            @click="handleSettlement">
                      发送并结算
                    </Button>
                  </div>
                </div>
              </Col>
            </Row>
            <Row>
              <Col>
                <div v-if="settlementInfo.status==1||settlementInfo.status==2" class="footer-address-result">
                  <span>{{settlementInfo.address}} </span>
                  <span style="margin-left: 10px">{{settlementInfo.contactor}}</span>
                  <span style="margin-left: 10px">{{settlementInfo.mobilePhone}}</span>
                </div>
              </Col>
            </Row>
          </div>
        </div>
      </div>
    </div>
  </Modal>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core'
  import * as opt from './options'

  export default {
    name: 'SupplierOrderDetail',
    data() {
      return {
        commonDialog: null,
        tabHeight: '',
        columns: opt.commonSettlementHeader,
        settlementInfo: {},
        productsList: [],
        description: '',
        payPassword: '',
        orderId: '',
        copyBtn: null,

        showMoreAddress: false,
        receiveAddressId: ''
      }
    },
    computed: {
      ...mapState([
        'loading',
        'supplierOrderDialogVisible',
        'orderDetailId',
        'addressEdit',
        'supplierSettlementInfo'
      ]),
      ...mapGetters([
        'userData',
        'getAddressList'
      ])
    },
    watch: {
      'addressEdit': 'handleAddress'
    },
    mounted() {
      this.commonDialog = this.$refs.commonDialog
      this.copyBtn = new this.$clipboard(this.$refs.copy)
    },
    created() {
      this.initData()
    },
    methods: {
      ...mapActions([
        'saveSupplierCartNum',
        'saveSupplierProductInfo',
        'handleBaseDialog',
        'saveOrderStatus',
        'saveOrderId',
        'handleOrderStatus',
        'handleBasicInfo',
        'getReceiverAddress',
        'saveSupplierSettlementInfo'
      ]),
      initData() {
        this.handleBaseDialog({visible: false, type: 'supplierOrderDialogVisible'})
      },
      dialogChange(v) {
        console.log(v)
        this.showMoreAddress = false
        if (v) {
          this.$nextTick(() => {
            this.commonDialog.scrollTop = 0
          })
          let h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
          this.tabHeight = h - 95
          this.orderId = this.orderDetailId
          this.getOrderInfo()
        } else {
          this.saveOrderId('')
          this.handleBaseDialog({visible: false, type: 'supplierOrderDialogVisible'})
        }
      },
      // 获取结算详情
      async getOrderInfo() {
        let self = this
        let params = {
          id: self.orderId
        }
        self.settlementInfo = {}
        let {data} = await api.getSupplierOrderDetail(params)
        console.log(data)
        if (data.status == '0') {
          self.settlementInfo = data.data
          api.getMaxRechargeAmount().then(res => {
            console.log(res)
            if (res.data.status == 0) {
              self.saveSupplierSettlementInfo(Object.assign({}, data.data, res.data.data))
              self.settlementInfo = self.supplierSettlementInfo
            }
          })
          self.description = data.data.description
          // 转换数字类型
          let proArr = data.data.products
          proArr.forEach(item => {
            item.orderQty = item.orderQty * 1
          })
          self.productsList = proArr

          if (self.settlementInfo.status == 1 || self.settlementInfo.status == 2) {
            this.receiveAddressId = this.settlementInfo.receiveAddressId
            this.getReceiverAddress(this.settlementInfo.subCustomerId)
          }
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 删除商品
      async productDelete(row) {
        let self = this
        let obj = {
          orderId: self.settlementInfo.orderId,
          orderDetailId: row.id
        }
        let params = {
          details: JSON.stringify([obj])
        }
        let {data} = await api.getSupplierOrderProductDelete(params)
        if (data.status == 0) {
          self.$Notice.success({
            desc: data.message
          })
          self.getOrderInfo()
          self.handleOrderStatus(new Date().getTime())
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 删除商品
      delectProduct(row) {
        this.$Modal.confirm({
          title: '温馨提示',
          content: '<p>商品删除后将无法恢复，是否确认删除？</p>',
          onOk: () => {
            this.productDelete(row)
          },
          onCancel: () => {
          }
        })
      },
      qtyFocus(e, id) {
        console.log(id)
        setTimeout(() => {
          // this.$refs[id].$el.querySelector('input').click()
          this.$refs[id].$el.querySelector('input').select()
        }, 10)
      },
      // 数量切换时候
      qtyChange(v, row) {
        console.log(v)
        console.log(row)
        if (v) {
          this.addCart(row)
        } else {
          this.$nextTick(() => {
            row.orderQty = row.minOrderQty
            this.addCart(row)
          })
        }
      },
      // 切换后 重新请求更新订单数量接口
      async addCart(row) {
        let self = this
        let obj = {
          orderId: self.settlementInfo.orderId,
          orderDetailId: row.id,
          orderDetailQty: row.orderQty || ''
        }
        let params = {
          details: JSON.stringify([obj])
        }
        let {data} = await api.getUpdateSupplierQty(params)
        if (data.status == '0') {
          self.$Notice.success({
            desc: data.message
          })
          self.getOrderInfo()
          self.handleOrderStatus(new Date().getTime())
        } else {
          self.$Modal.error({
            title: '温馨提示',
            content: data.message,
            onOk: () => {
              setTimeout(() => {
                self.productsList[row._index].orderQty = row.minOrderQty
                this.$refs[row.productId].$el.querySelector('input').select()
              }, 10)
            }
          })
        }
      },
      // 确认收货
      handleConfirm() {
        this.$Modal.confirm({
          title: '温馨提示',
          content: '<p>如果您已收货，可以点击“确认收货”，</p><p>您确认后小红马将会把货款支付给商家。</p>',
          onOk: () => {
            this.toConfirm()
          },
          onCancel: () => {
          }
        })
      },
      async toConfirm() {
        let self = this
        let params = {
          orderId: self.orderId
        }
        let {data} = await api.getUpdateConfirmReceipt(params)
        if (data.status == '0') {
          self.$Notice.success({
            desc: data.message
          })
          self.saveOrderStatus({type: 'supplierOrder', status: '6', name: '1'})
          self.handleOrderStatus(new Date().getTime())
          self.handleBaseDialog({visible: false, type: 'supplierOrderDialogVisible'})
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },

      // 撤销订单
      removeSettlement() {
        this.$Modal.confirm({
          title: '温馨提示',
          content: '<p>订单撤销后，可以在“未发送订单列表”中查看这个订单，您确认要撤销本订单吗？</p>',
          onOk: () => {
            this.handleRemoveSettlement()
          },
          onCancel: () => {
          }
        })
      },
      // 撤销订单
      async handleRemoveSettlement() {
        let self = this
        let params = {
          orderId: self.orderId
        }
        let {data} = await api.getSupplierOrderUndo(params)
        if (data.status == '0') {
          self.$Notice.success({
            desc: data.message
          })
          self.saveOrderStatus({type: 'supplierOrder', status: '1', name: '2'})
          self.handleOrderStatus(new Date().getTime())
          self.handleBaseDialog({visible: false, type: 'supplierOrderDialogVisible'})
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 删除订单
      deleteSettlement() {
        this.$Modal.confirm({
          title: '温馨提示',
          content: '<p>订单删除后将无法恢复，是否确认删除此订单？</p>',
          onOk: () => {
            this.toDeleteSettlement()
          },
          onCancel: () => {
          }
        })
      },
      // 删除订单
      async toDeleteSettlement() {
        let self = this
        let params = {
          orderId: self.orderId
        }
        let {data} = await api.getSupplierOrderDelete(params)
        if (data.status == 0) {
          self.$Notice.success({
            desc: data.message
          })
          self.saveOrderStatus({type: 'supplierOrder', status: '-1', name: '2'})
          self.handleOrderStatus(new Date().getTime())
          self.handleBaseDialog({visible: false, type: 'supplierOrderDialogVisible'})
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 进行结算前先进性判断 余额是否够支付 该订单金额
      handleSettlement() {
        if (this.settlementInfo.taotalPayAmount == 0) {
          this.toSettlement()
        } else {
          let temp = {
            orderId: this.orderId,
            description: this.description,
            payPassword: this.payPassword
          }
          this.saveSupplierSettlementInfo(Object.assign({}, this.supplierSettlementInfo, temp))
          this.settlementInfo = this.supplierSettlementInfo
          this.handleBaseDialog({visible: true, type: 'payMethodDialogVisible', orderType: 4})
        }
        // if (this.settlementInfo.taotalPayAmount * 1 > 0 && parseFloat(this.settlementInfo.taotalPayAmount) > parseFloat(this.settlementInfo.availableBalance)) {
        //   let amount = parseFloat(this.settlementInfo.taotalPayAmount) - parseFloat(this.settlementInfo.availableBalance)
        //   amount = amount.toFixed(2)
        //   let message = `<p>您的资金账户可用余额不足，还需要充值 <span style="color:#E61E10">¥ ${amount}</span>，</p><p>去充值吧！</p>`
        //   this.$Modal.error({
        //     title: '温馨提示',
        //     content: message,
        //     width: 435,
        //     onOk: () => {
        //       this.handleBaseDialog({visible: false, type: 'supplierOrderDialogVisible'})
        //       this.handleBaseDialog({visible: false, type: 'orderDialogVisible'})
        //       this.$router.push({path: '/mine/recharge', query: {amount: amount}})
        //     }
        //   })
        // } else {
        //   this.toSettlement()
        // }
      },
      // 进行结算
      async toSettlement() {
        let self = this
        let params = {
          orderId: self.orderId,
          provOrderNo: '',
          description: self.description,
          payPassword: self.payPassword,
          receiveAddressId: self.receiveAddressId || ''
        }
        let {data} = await api.getSupplierOrderSend(params)
        if (data.status == 0) {
          self.$Notice.success({
            desc: data.message
          })
          self.saveOrderStatus({type: 'supplierOrder', status: '3', name: '1'})
          self.handleOrderStatus(new Date().getTime())
          self.handleBaseDialog({visible: false, type: 'supplierOrderDialogVisible'})
        } else {
          self.$Modal.error({
            title: '温馨提示',
            content: data.message,
            onOk: () => {
            }
          })
        }
        console.log(data)
      },
      // 进行复制
      handleCopy() {
        let self = this
        let clipboard = self.copyBtn
        clipboard.on('success', function () {
          // self.$Notice.success({
          //   desc: '复制成功'
          // })
        })
      },
      // 后台返回有 service
      toDetail(row) {
        row.service = this.settlementInfo.isService ? '服务商' : ''
        this.saveSupplierProductInfo(row)
        this.handleBaseDialog({visible: true, type: 'supplierDetailVisible'})
      },
      closeDialog() {
        this.handleBaseDialog({visible: false, type: 'supplierOrderDialogVisible'})
      },
      // 是否展示更多地址数据  ================================================================
      changeAddress() {
        this.showMoreAddress = !this.showMoreAddress
      },
      // 切换地址 1.需要刷新订单信息（物流费）
      handleRadioChange(v) {
        console.log(v)
        this.showMoreAddress = false
        this.updateOrderData()
      },
      // 修改地址
      editAddress(id) {
        this.handleBasicInfo({id: id, from: 'supplierOrderDetail'})
        this.handleBaseDialog({visible: true, type: 'addAddressVisible', title: '编辑'})
      },
      // 新增地址
      addAddress(id) {
        this.handleBasicInfo({subCustomerId: id, from: 'supplierOrderDetail'})
        this.handleBaseDialog({visible: true, type: 'addAddressVisible', title: '新增'})
      },
      // 修改完成 1.需要刷新地址信息 2.刷新订单信息
      handleAddress(v) {
        let path = v.split('?')[0]
        if (path == 'supplierOrderDetail') {
          this.updateOrderData()
        }
      },
      // 修改地址后 更新订单信息
      async updateOrderData() {
        let self = this
        let params = {
          orderId: self.orderId,
          receiveAddressId: self.receiveAddressId
        }
        let {data} = await api.getUpdateSupplierOrderReceiveAddress(params)
        if (data.status == 1) {
          let msg = data.message.replace(/\n\n/g, '</p></br><p>')
          msg = '<div style="max-height: 500px;overflow: auto"><p>' + msg + '</p></div>'
          self.$Modal.error({
            title: '温馨提示',
            content: msg,
            width: 600,
            onOk: () => {
            }
          })
        } else {
          self.getOrderInfo()
        }
      }
    }
  }
</script>

<style lang="less">
  @import "orderdetail";
</style>
