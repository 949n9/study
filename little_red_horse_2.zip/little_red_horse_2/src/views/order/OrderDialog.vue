<template>
  <Modal
    :value="orderDialogVisible"
    title="订单"
    :mask-closable="false"
    footer-hide
    width="1100"
    :loading="loading"
    :styles="{top: '10px'}"
    @on-visible-change="dialogChange"
    @on-cancel="closeDialog"
  >
    <div class="cart-wrap">
      <Tabs class="menu-wrap" v-model="tabName">
        <TabPane name="commonOrder" label="商城订单">
          <div class="order">
            <Menu
              mode="horizontal"
              :active-name="commonActiveName"
              @on-select="commonMenuSelect"
              class="order-header-menu"
            >
              <MenuItem name="2" class="menu-item">未发送 ({{unSendCommonCount}})</MenuItem>
              <MenuItem name="1">已发送 ({{sendCommonCount}})</MenuItem>
            </Menu>
            <div class="m-header order-header-search">
              <div class="item">
                <span>订单号</span>
                <Input class="header-ipt" :maxlength="30" v-model.trim="commonCode" clearable />
              </div>
              <div class="item">
                <span>发送日期</span>
                <DatePicker
                  type="daterange"
                  placement="bottom-end"
                  :editable="false"
                  split-panels
                  format="yyyy-MM-dd"
                  @on-change="commonDateChange"
                  class="selector-date"
                ></DatePicker>
              </div>
              <div class="item">
                <Button type="error" :disabled="loading" @click="commonSearch">搜索</Button>
              </div>
            </div>
            <div class="order-content" v-loading="loading">
              <Tabs
                type="card"
                v-model="commonStatus"
                @on-click="commonTabsClick"
                style="margin-bottom: -6px"
              >
                <TabPane
                  v-for="(item,index) in commonTabs"
                  :key="index"
                  :name="item.name"
                  :label="item.label"
                ></TabPane>
              </Tabs>

              <div
                class="pane-all"
                ref="content"
                v-show="commonOrderData.length"
                :style="{height:tabHeight+'px'}"
              >
                <Row class="pane-header" type="flex">
                  <Col span="8" class="pane-header-item">商品</Col>
                  <Col span="4" class="pane-header-item">收货人</Col>
                  <Col span="4" class="pane-header-item">合计</Col>
                  <Col span="4" class="pane-header-item">订单状态</Col>
                  <Col span="4" class="pane-header-item">操作</Col>
                </Row>
                <ul class="pane-content">
                  <li
                    class="pane-content-item"
                    v-for="(item,index) in commonOrderData"
                    :key="index"
                  >
                    <Row class="pane-header" type="flex">
                      <Col span="6">订单编号：{{item.code}}</Col>
                      <Col span="12">发送时间：{{item.createTime}}</Col>

                      <Col span="3" v-show="item.status==3||item.status==1">
                        <Poptip placement="bottom" trigger="hover" width="400">
                          <span style="cursor: pointer" @mouseenter="searchOrderTrace(item.id)">查看物流</span>
                          <div slot="content">
                            <div v-if="orderTraceInfo.isSub" class="order-trace-wrap">
                              <p
                                class="red--text to-detail"
                                @click="openDetail({id:item.id},'commonOrder')"
                              >查看详情</p>
                              <ul class="wrap-ul">
                                <li
                                  v-for="(item,index) in orderTraceInfo.dataList"
                                  :key="index"
                                  class="wrap-li"
                                >
                                  <p style="font-weight: 600;">包裹{{index+1}}</p>
                                  <p>
                                    {{item.logisticsName}}:
                                    <span>{{item.logisticsNo}}</span>
                                  </p>
                                  <div>
                                    <Timeline style="max-height: 35px;overflow: hidden">
                                      <TimelineItem
                                        v-for="(i,index) in item.details"
                                        :key="index"
                                        color="green"
                                      >
                                        <p style="font-weight: 600;">{{i.msg}}</p>
                                        <p>{{i.traceTime}}</p>
                                      </TimelineItem>
                                    </Timeline>
                                  </div>
                                </li>
                              </ul>
                            </div>
                            <!--还没有物流信息时候的展示-->
                            <div v-else class="order-trace-wrap">
                              <Timeline>
                                <TimelineItem
                                  v-for="(item,index) in orderTraceInfo.dataList"
                                  :key="index"
                                  color="green"
                                >
                                  <p style="font-weight: 600;">{{item.msg}}</p>
                                  <p>{{item.traceTime}}</p>
                                </TimelineItem>
                              </Timeline>
                            </div>
                          </div>
                        </Poptip>
                      </Col>

                      <Col span="3">
                        <div class="kefu-con" @click="openKefu()">
                          <img src="@/assets/images/detail/kefu_icon.png" alt />
                          <span>联系客服</span>
                        </div>
                      </Col>
                    </Row>
                    <Row class="item-content">
                      <Col span="8" class="item-p">
                        <div class="item-p-wrap">
                          <template v-for="(i,index) in item.imgUrls">
                            <img
                              :key="index"
                              :src="i"
                              :onerror="defaultPimg()"
                              alt
                              class="item-p-img"
                            />
                          </template>
                        </div>
                        <span>共{{item.totalQty}}种</span>
                      </Col>
                      <Col span="4" class="item">
                        <div>
                          <p>{{item.createEmpName}}</p>
                          <!--<p>15836900004</p>-->
                        </div>
                      </Col>
                      <Col span="4" class="item">
                        <div>
                          <p>¥{{item.totalAmount}}</p>
                          <!--<p>(含运费：¥100.00)</p>-->
                        </div>
                      </Col>
                      <Col span="4" class="item">
                        <div>
                          <p>{{item.status==1?'审核中':item.statusName}}</p>
                          <p>{{item.opinion}}</p>
                        </div>
                      </Col>
                      <Col span="4" class="item">
                        <div style="margin-top: 27px;display: flex">
                          <Button type="text" @click="openDetail(item,'commonOrder')">查看详情</Button>
                          <Button
                            type="text"
                            v-show="item.status=='12'||item.status=='4'"
                            @click="deleteCommonOrder(item)"
                          >删除</Button>
                          <Button
                            type="text"
                            v-show="item.status=='1'"
                            @click="removeCommonOrder(item)"
                          >撤销订单</Button>
                        </div>
                      </Col>
                    </Row>
                  </li>
                </ul>
              </div>
              <Row v-if="commonOrderData.length==0&&!loading">
                <Col span="24">
                  <div class="search-result" :style="{height:tabHeight+'px'}">
                    <img src="../../assets/images/empty/dingdan.png" alt class="search-img" />
                    <span class="search-info">还没有订单！</span>
                    <a href="javascript:void(0)" @click="toJump">
                      <span>去逛逛>></span>
                    </a>
                  </div>
                </Col>
              </Row>
            </div>

            <div style="text-align: center" v-show="commonOrderData.length">
              <Page
                :total="commonDataCount"
                :page-size="commonPageSize"
                :current="commonPageIndex"
                :page-size-opts="pageOpts"
                @on-change="commonPageChange"
                @on-page-size-change="commonPageSizeChange"
                show-elevator
                show-total
                show-sizer
              />
            </div>
          </div>
        </TabPane>
        <TabPane name="supplierOrder" label="厂商直送订单">
          <div class="order">
            <Menu
              mode="horizontal"
              :active-name="activeName"
              @on-select="menuSelect"
              class="order-header-menu"
            >
              <MenuItem name="2" class="menu-item">未发送 ({{unSendCount}})</MenuItem>
              <MenuItem name="1">已发送 ({{sendCount}})</MenuItem>
            </Menu>
            <div class="m-header order-header-search">
              <div class="item">
                <span>订单号</span>
                <Input class="header-ipt" :maxlength="30" v-model.trim="code" clearable />
              </div>

              <div class="item">
                <span>进货渠道</span>
                <Select v-model="supplierId" style="width:200px" clearable>
                  <Option
                    v-for="item in supplierArr"
                    :value="item.id"
                    :key="item.id"
                  >{{ item.name }}</Option>
                </Select>
              </div>

              <div class="item">
                <span>发送日期</span>
                <DatePicker
                  type="daterange"
                  placement="bottom-end"
                  :editable="false"
                  split-panels
                  format="yyyy-MM-dd"
                  @on-change="dateChange"
                  class="selector-date"
                ></DatePicker>
              </div>
              <div class="item">
                <Button type="error" :disabled="loading" @click="search">搜索</Button>
              </div>
            </div>

            <div class="order-content" v-loading="loading">
              <Tabs type="card" v-model="status" @on-click="tabsClick" style="margin-bottom: -6px">
                <TabPane
                  v-for="(item,index) in tabs"
                  :key="index"
                  :name="item.name"
                  :label="item.label"
                ></TabPane>
              </Tabs>

              <div
                class="pane-all"
                ref="content"
                v-if="orderData.length"
                :style="{height:tabHeight+'px'}"
              >
                <Row class="pane-header">
                  <Col span="8" class="pane-header-item">商品</Col>
                  <Col span="4" class="pane-header-item">收货人</Col>
                  <Col span="4" class="pane-header-item">合计</Col>
                  <Col span="4" class="pane-header-item">订单状态</Col>
                  <Col span="4" class="pane-header-item">操作</Col>
                </Row>
                <ul class="pane-content">
                  <li class="pane-content-item" v-for="(item,index) in orderData" :key="index">
                    <Row class="pane-header">
                      <Col span="6">订单编号：{{item.code}}</Col>
                      <Col span="6">发送时间：{{item.createTime}}</Col>
                      <Col span="12" style="display: flex">
                        <span
                          @click="jump(item.isService)"
                          style="cursor: pointer"
                        >进货渠道：{{item.supplierName}}</span>
                        <Badge
                          text="服务商"
                          v-if="item.isService"
                          @click.native="jump(item.isService)"
                          type="warning"
                          style="margin-top: 5px;margin-left: 10px;cursor: pointer;z-index: 1"
                        ></Badge>
                      </Col>
                    </Row>
                    <Row class="item-content">
                      <Col span="8" class="item-p">
                        <div class="item-p-wrap">
                          <template v-for="(i,index) in item.imgUrls">
                            <img
                              :key="index"
                              :src="i"
                              alt
                              :onerror="defaultPimg()"
                              class="item-p-img"
                            />
                          </template>
                        </div>
                        <span>共{{item.totalQty}}种</span>
                      </Col>
                      <Col span="4" class="item">
                        <div>
                          <p>{{item.createEmpName}}</p>
                          <!--<p>15836900004</p>-->
                        </div>
                      </Col>
                      <Col span="4" class="item">
                        <div>
                          <p>¥{{item.totalAmount}}</p>
                          <!--<p>(含运费：¥100.00)</p>-->
                        </div>
                      </Col>
                      <Col span="4" class="item">
                        <div>
                          <p>{{item.status==3?'审核中':item.statusName}}</p>
                          <p>{{item.opinion}}</p>
                        </div>
                      </Col>
                      <Col span="4" class="item">
                        <div style="display: flex;margin-top: 27px">
                          <Button type="text" @click="openDetail(item,'supplierOrder')">查看详情</Button>
                          <Button
                            type="text"
                            v-show="item.status=='1'||item.status=='2'"
                            @click="deleteOrder(item)"
                          >删除</Button>
                          <Button
                            type="text"
                            v-show="item.status=='3'"
                            @click="removeOrder(item)"
                          >撤销订单</Button>
                        </div>
                      </Col>
                    </Row>
                  </li>
                </ul>
              </div>
              <Row v-if="orderData.length==0&&!loading">
                <Col span="24">
                  <div class="search-result" :style="{height:tabHeight+'px'}">
                    <img src="../../assets/images/empty/dingdan.png" alt class="search-img" />
                    <span class="search-info">还没有订单！</span>
                    <router-link to="/index/home">
                      <a href="javascript:void(0)">
                        <span>去逛逛>></span>
                      </a>
                    </router-link>
                  </div>
                </Col>
              </Row>
            </div>
            <div style="text-align: center" v-show="orderData.length">
              <Page
                :total="dataCount"
                :page-size="pageSize"
                :current="pageIndex"
                :page-size-opts="pageOpts"
                @on-change="pageChange"
                @on-page-size-change="pageSizeChange"
                show-elevator
                show-total
                show-sizer
              />
            </div>
          </div>
        </TabPane>
      </Tabs>
    </div>
  </Modal>
</template>

<script>
import { mapState, mapGetters, mapActions } from 'vuex'
import api from '../../core'

export default {
  components: {},
  data() {
    return {
      tabName: 'commonOrder',
      tabHeight: 500,
      content: null,
      windowHeight: '',

      loading: false,

      commonActiveName: '1',
      commonStatus: '-1',
      commonOrderData: [],
      commonCode: '',
      commonBegDate: '',
      CommonEndDate: '',
      commonTabs: [
        { name: '-1', label: '全部' },
        { name: '12', label: '已撤销' },
        { name: '4', label: '已退回' }
      ],
      unSendCommonCount: 0,
      sendCommonCount: 0,
      commonDataCount: 0,
      commonPageIndex: 1,
      commonPageSize: 20,
      pageOpts: [20, 50, 100, 200],

      activeName: '1',
      status: '-1',
      orderData: [],
      code: '',
      begDate: '',
      endDate: '',
      supplierId: '',
      supplierArr: [],
      tabs: [
        { name: '-1', label: '全部' },
        { name: '1', label: '已撤销' },
        { name: '2', label: '已退回' }
      ],
      unSendCount: 0,
      sendCount: 0,

      dataCount: 0,
      pageIndex: 1,
      pageSize: 20,

      orderTraceInfo: {},
      savedTraceInfo: [],
      savedArr: [],
      tag: '',
      easemobim: {}
    }
  },
  computed: {
    ...mapState(['orderDialogVisible', 'orderStatus', 'handleSuccess']),
    ...mapGetters(['userData'])
  },
  watch: {
    handleSuccess: 'orderStatusChange'
  },
  created() {
    console.log('orderdialog created ')
    this.handleBaseDialog({ visible: false, type: 'orderDialogVisible' })
    // 客服相关
    this.easemobim = window.easemobim || {}
    this.easemobim.config = {
      hide: true,
      autoConnect: true
    }
  },
  mounted() {
    this.content = this.$refs.content
  },
  methods: {
    ...mapActions([
      'handleBaseDialog',
      'saveOrderStatus',
      'saveOrderId',
      'handleOrderStatus'
    ]),
    // 在订单详情中修改了订单的相关信息
    orderStatusChange() {
      this.tabName = this.orderStatus.type
      console.log(this.orderStatus)
      this.getOrderNum()
      if (this.tabName == 'commonOrder') {
        this.commonActiveName = this.orderStatus.name
        this.commonStatus = this.orderStatus.status
        this.initCommonData()
      } else {
        this.activeName = this.orderStatus.name
        this.status = this.orderStatus.status
        this.initSupplierData()
        this.getSubList()
      }
    },
    dialogChange(v) {
      console.log(v)
      if (v) {
        this.initStatus()
        this.getOrderNum()
        this.initCommonData()
        this.initSupplierData()
        this.getSubList()

        this.$nextTick(() => {
          this.content.scrollTop = 0
        })
        this.windowHeight =
          document.documentElement.scrollTop ||
          window.pageYOffset ||
          document.body.scrollTop
        window.scrollTo(0, 0)
        let h =
          window.innerHeight ||
          document.documentElement.clientHeight ||
          document.body.clientHeight
        this.tabHeight = h - 330
      } else {
        window.scrollTo(0, this.windowHeight)
        this.closeKefu()
        this.saveOrderStatus({})
        this.handleBaseDialog({ visible: false, type: 'orderDialogVisible' })
      }
    },
    // 初始化状态 status name
    initStatus() {
      this.tabName = this.orderStatus.type
      if (this.tabName == 'commonOrder') {
        this.commonActiveName = this.orderStatus.name
        this.commonStatus = this.orderStatus.status
      } else {
        this.activeName = this.orderStatus.name
        this.status = this.orderStatus.status
      }
    },
    // 获取菜单与订单数据
    initCommonData() {
      this.getCommonMenu()
      this.getCommonOrderData()
    },
    initSupplierData() {
      this.getSupplierMenu()
      this.getSupplierOrderData()
    },
    // 获取进货渠道
    async getSubList() {
      let self = this
      let { data } = await api.getCustomerSupplierList()
      if (data.status == 0) {
        self.supplierArr = data.data.list
      }
    },
    // 获取订单数量
    async getOrderNum() {
      let self = this
      let params = {
        begDate: self.commonBegDate,
        endDate: self.CommonEndDate,
        orderCode: self.commonCode,
        supplierId: self.supplierId
      }
      let { data } = await api.getUserCenter(params)
      console.log(data)
      if (data.status == 0) {
        let orderCount = data.data.orderCount
        self.unSendCommonCount =
          orderCount.revokeQty * 1 + orderCount.sendBackQty * 1
        self.sendCommonCount =
          orderCount.unVerifyQty * 1 + orderCount.verifyQty * 1
        let supplyOrderCount = data.data.supplyOrderCount
        self.unSendCount =
          supplyOrderCount.revokeQty * 1 + supplyOrderCount.sendBackQty * 1
        self.sendCount =
          supplyOrderCount.unVerifyQty * 1 +
          supplyOrderCount.verifyQty * 1 +
          supplyOrderCount.deliverGoodsQty * 1 +
          supplyOrderCount.finishQty * 1
      }
    },
    getCommonMenu() {
      if (this.commonActiveName == '2') {
        this.commonTabs = [
          { name: '-1', label: '全部' },
          { name: '12', label: '已撤销' },
          { name: '4', label: '已退回' }
        ]
      } else {
        this.commonTabs = [
          { name: '-1', label: '全部' },
          { name: '1', label: '审核中' },
          { name: '3', label: '已审核' }
        ]
      }
    },
    getSupplierMenu() {
      if (this.activeName == '2') {
        this.tabs = [
          { name: '-1', label: '全部' },
          { name: '1', label: '已撤销' },
          { name: '2', label: '已退回' }
        ]
      } else {
        this.tabs = [
          { name: '-1', label: '全部' },
          { name: '3', label: '审核中' },
          { name: '4', label: '已审核' },
          { name: '5', label: '已发货' },
          { name: '6', label: '已完成' }
        ]
      }
    },
    // 切换 发送未发送
    commonMenuSelect(name) {
      this.commonActiveName = name
      this.commonStatus = '-1'
      this.getCommonMenu()
      this.getCommonOrderData()
    },
    // 切换 发送未发送
    menuSelect(name) {
      this.activeName = name
      this.status = '-1'
      this.getSupplierMenu()
      this.getSupplierOrderData()
    },
    commonTabsClick(name) {
      this.commonPageIndex = 1
      this.commonStatus = name
      this.initCommonData()
    },
    tabsClick(name) {
      this.pageIndex = 1
      this.status = name
      this.getSupplierOrderData()
    },
    // 时间切换时候
    commonDateChange(v) {
      console.log(v)
      if (v[0] == '') {
        this.commonBegDate = ''
        this.CommonEndDate = ''
      } else {
        this.commonBegDate = v[0] + ' 00:00:00'
        this.CommonEndDate = v[1] + ' 59:59:59'
      }
    },
    // 时间切换时候
    dateChange(v) {
      console.log(v)
      if (v[0] == '') {
        this.begDate = ''
        this.endDate = ''
      } else {
        this.begDate = v[0] + ' 00:00:00'
        this.endDate = v[1] + ' 59:59:59'
      }
    },
    async getCommonOrderData() {
      let self = this
      let params = {
        pageIndex: self.commonPageIndex,
        pageSize: self.commonPageSize,
        status: self.commonStatus,
        sendType: self.commonActiveName,
        begDate: self.commonBegDate,
        endDate: self.CommonEndDate,
        code: self.commonCode
      }
      self.loading = true
      let { data } = await api.getOrderList(params)
      console.log(data)
      if (data.status == 0) {
        self.loading = false
        self.$nextTick(() => {
          self.content.scrollTop = 0
        })
        self.commonOrderData = data.data.list
        self.commonDataCount = data.data.dataCount
      }
    },
    async getSupplierOrderData() {
      let self = this
      let params = {
        status: self.status,
        sendType: self.activeName,
        begDate: self.begDate,
        endDate: self.endDate,
        code: self.code,
        supplierId: self.supplierId
      }
      self.loading = true
      let { data } = await api.getSupplierOrderList(params)
      console.log(data)
      if (data.status == 0) {
        self.loading = false
        self.$nextTick(() => {
          self.content.scrollTop = 0
        })
        self.orderData = data.data.list
        self.dataCount = data.data.dataCount
      }
    },
    // 搜索时候 搜索订单数量
    commonSearch() {
      this.commonPageIndex = 1
      this.getOrderNum()
      this.getCommonOrderData()
    },
    search() {
      this.pageIndex = 1
      this.getOrderNum()
      this.getSupplierOrderData()
    },
    // 查看订单
    openDetail(item, type) {
      if (type == 'commonOrder') {
        this.saveOrderStatus({
          type: 'commonOrder',
          status: this.commonStatus,
          name: this.commonActiveName
        })
        this.handleBaseDialog({
          visible: true,
          type: 'commonOrderDialogVisible'
        })
      } else {
        this.saveOrderStatus({
          type: 'supplierOrder',
          status: this.status,
          name: this.activeName
        })
        this.handleBaseDialog({
          visible: true,
          type: 'supplierOrderDialogVisible'
        })
      }
      this.saveOrderId(item.id)
    },
    // 删除订单
    deleteCommonOrder(row) {
      this.$Modal.confirm({
        title: '温馨提示',
        content: '<p>订单删除后将无法恢复，是否确认删除此订单？</p>',
        onOk: () => {
          this.handleDeleteCommonOrder(row)
        },
        onCancel: () => {}
      })
    },
    // 删除订单
    async handleDeleteCommonOrder(row) {
      let self = this
      let params = {
        orderId: row.id
      }
      let { data } = await api.getOrderDelete(params)
      if (data.status == 0) {
        self.$Notice.success({
          desc: data.message
        })
        self.getOrderNum()
        self.getCommonOrderData()
      }
    },
    // 撤销订单
    removeCommonOrder(row) {
      this.$Modal.confirm({
        title: '温馨提示',
        content:
          '<p>订单撤销后，可以在“未发送订单列表”中查看这个订单，您确认要撤销本订单吗？</p>',
        onOk: () => {
          this.handleRemoveCommonOrder(row)
        },
        onCancel: () => {}
      })
    },
    // 撤销订单
    async handleRemoveCommonOrder(row) {
      let self = this
      let params = {
        orderId: row.id
      }
      let { data } = await api.getOrderUndo(params)
      if (data.status == 0) {
        self.$Notice.success({
          desc: data.message
        })
        self.commonActiveName = '2'
        self.commonStatus = '12'
        self.getOrderNum()
        self.initCommonData()
        self.handleOrderStatus(new Date().getTime())
      }
    },

    // 删除订单
    deleteOrder(row) {
      this.$Modal.confirm({
        title: '温馨提示',
        content: '<p>订单删除后将无法恢复，是否确认删除此订单？</p>',
        onOk: () => {
          this.handleDeleteOrder(row)
        },
        onCancel: () => {}
      })
    },
    // 删除订单
    async handleDeleteOrder(row) {
      let self = this
      let params = {
        orderId: row.id
      }
      let { data } = await api.getSupplierOrderDelete(params)
      if (data.status == 0) {
        self.$Notice.success({
          desc: data.message
        })
        self.getOrderNum()
        self.getSupplierOrderData()
        self.handleOrderStatus(new Date().getTime())
      }
    },
    // 撤销订单
    removeOrder(row) {
      this.$Modal.confirm({
        title: '温馨提示',
        content:
          '<p>订单撤销后，可以在“未发送订单列表”中查看这个订单，您确认要撤销本订单吗？</p>',
        onOk: () => {
          this.handleRemoveOrder(row)
        },
        onCancel: () => {}
      })
    },
    // 撤销订单
    async handleRemoveOrder(row) {
      let self = this
      let params = {
        orderId: row.id
      }
      let { data } = await api.getSupplierOrderUndo(params)
      if (data.status == 0) {
        self.$Notice.success({
          desc: data.message
        })
        self.activeName = '2'
        self.status = '1'
        self.getOrderNum()
        self.initSupplierData()
        self.handleOrderStatus(new Date().getTime())
      }
    },
    // 关闭弹窗
    closeDialog() {
      console.log('关闭了 订单弹窗--')
      this.handleBaseDialog({
        visible: false,
        type: 'commonOrderDialogVisible'
      })
      // 清空存储的物流数据
      this.savedTraceInfo = []
      this.savedArr = []
      // this.handleBaseDialog({visible: false, type: 'supplierSettlementDialogVisible'})
    },
    // 去首页
    toJump() {
      this.handleBaseDialog({ visible: false, type: 'orderDialogVisible' })
      this.$router.push({ path: '/index/home' })
    },
    // 服务商商品页面
    jump(service) {
      this.handleBaseDialog({ visible: false, type: 'orderDialogVisible' })
      if (service) {
        this.$router.push({ path: '/index/fwproduct' })
      } else {
        this.$router.push({ path: '/index/supplierproduct' })
      }
    },
    commonPageChange(v) {
      window.scrollTo(0, 500)
      this.commonPageIndex = v
      this.initCommonData()
    },
    commonPageSizeChange(v) {
      this.commonPageSize = v
      this.initCommonData()
    },
    pageChange(v) {
      window.scrollTo(0, 500)
      this.pageIndex = v
      this.initSupplierData()
    },
    pageSizeChange(v) {
      this.pageSize = v
      this.initSupplierData()
    },
    // 查看物流信息
    searchOrderTrace(id) {
      if (this.savedArr.length) {
        if (this.savedArr.includes(id)) {
          let obj = this.savedTraceInfo.filter(item => item.id == id)[0]
          console.log(obj)
          this.orderTraceInfo = obj.obj
        } else {
          this.handleOrderTrace(id)
        }
      } else {
        this.handleOrderTrace(id)
      }
    },
    async handleOrderTrace(id) {
      let self = this
      let params = {
        orderId: id
      }
      let { data } = await api.getOrderTrace(params)
      console.log(data)
      if (data.status == 0) {
        self.orderTraceInfo = data.data
        self.savedArr.push(id)
        self.savedTraceInfo.push({ id: id, obj: data.data })
      }
    },
    openKefu() {
      console.log(this.userData)
      // 为了实现在退出时候，隐藏客服弹窗，在登录后清除掉样式
      let pany = document.querySelector('.easemobim-chat-panel')
      if (pany) {
        pany.style.display = 'block'
      }
      this.easemobim.bind({
        configId: 'c16fad54-5784-4a5d-b929-b4a53c5b86ff',
        // agentName: '1439281489@qq.com',
        visitor: {
          trueName: this.userData.imName,
          qq: '',
          phone: this.userData.imMobilePhone,
          companyName: this.userData.imCompany,
          userNickname: this.userData.imNickName,
          description: '',
          email: this.userData.imEmail
        }
      })
    },
    closeKefu() {
      let pany = document.querySelector('.easemobim-chat-panel')
      if (pany) {
        pany.style.display = 'none'
      }
    }
  }
}
</script>

<style lang="less">
.ivu-table-body {
  position: static !important;
}

.m-header {
  display: flex;
  height: 35px;
  line-height: 35px;
  flex-wrap: nowrap;

  .item {
    display: flex;
    padding-right: 20px;

    span {
      margin: 0 5px;
      display: inline-block;
      white-space: nowrap;
    }

    .header-ipt {
      width: 150px;
    }
  }
}

.order {
  width: 100%;
  padding: 10px;
  min-height: 500px;
  border: 1px solid #e5e5e5;
  background-color: #ffffff;
  overflow: auto;

  .order-header-menu {
    height: 40px;
    line-height: 40px;
  }

  .order-header-search {
    margin: 10px 20px;

    .selector-date {
      width: 240px;
    }
  }

  .order-content {
    .ivu-tabs-bar {
      padding-bottom: 0;
    }

    .pane-all {
      overflow: auto;
      position: relative;

      .pane-header {
        background-color: #f5f8fa;
        height: 30px;
        line-height: 30px;
        padding: 0 20px;

        .order-trace-wrap {
          position: relative;

          .to-detail {
            cursor: pointer;
            position: absolute;
            right: 5px;
            top: 2px;
          }

          .wrap-ul {
            max-height: 300px;
            overflow: auto;
          }

          .wrap-li {
            border-bottom: 1px solid #cccccc;
          }

          .wrap-li:last-child {
            border-bottom: none;
          }
        }

        .pane-header-item {
          text-align: center;
        }

        .pane-timeline {
          .content {
          }

          .content:first-child {
            font-size: 14px;
            font-weight: 600;
          }

          .time {
          }
        }
      }

      .pane-content {
        .pane-content-item {
          border: 1px solid #cccccc;
          margin-top: 5px;

          .item-content {
            height: 85px;

            .item-p {
              padding: 5px 5px;
              display: flex;
              align-items: center;
              justify-content: space-between;

              .item-p-wrap {
                width: 280px;
                overflow: hidden;
                white-space: nowrap;
              }
            }

            .item-p-img {
              height: 70px;
              width: 68px;
              border: 1px solid #cccccc;
              margin: 1px;
            }

            .item {
              height: 100%;
              text-align: center;
              border-left: 1px solid #cccccc;

              p {
                margin-top: 35px;
              }
            }
          }
        }
      }
    }
  }
}
.kefu-con {
  display: flex;
  align-items: center;
  cursor: pointer;
  img {
    display: block;
    width: 14px;
    height: 14px;
  }
  span {
    margin-left: 5px;
  }
}
</style>
