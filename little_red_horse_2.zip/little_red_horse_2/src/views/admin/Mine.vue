<template>
  <div class="mine">
    <m-header-table></m-header-table>
    <m-header-search></m-header-search>

    <div class="m-wrap">
      <div class="clearfix">
        <m-mine-menu class="fl"></m-mine-menu>
        <router-view class="fr" style="width: 1019px;"></router-view>
      </div>
    </div>
    <m-friend-service></m-friend-service>
    <m-friend-info></m-friend-info>
    <m-toolbar></m-toolbar>

    <product-detail></product-detail>
    <product-series-detail></product-series-detail>
    <product-deta-detail></product-deta-detail>
    <product-deta-brand-detail></product-deta-brand-detail>
    <supplier-product-detail></supplier-product-detail>
    <supplier-product-series-detail></supplier-product-series-detail>
    <common-brand-product-detail></common-brand-product-detail>
    <common-brand-product-series-detail></common-brand-product-series-detail>
    <supplier-brand-product-detail></supplier-brand-product-detail>
    <supplier-brand-product-series-detail></supplier-brand-product-series-detail>

    <cart-dialog></cart-dialog>
    <common-settlement-dialog></common-settlement-dialog>
    <supplier-settlement-dialog></supplier-settlement-dialog>

    <order-dialog></order-dialog>
    <common-order-detail-dialog></common-order-detail-dialog>
    <supplier-order-detail-dialog></supplier-order-detail-dialog>

    <add-address-dialog></add-address-dialog>
    <pay-method-dialog></pay-method-dialog>
  </div>
</template>

<script>
  import mFriendService from '../../common/Friend-Service'
  import mFriendInfo from '../../common/Friend-Info'
  import mHeaderTable from '../../common/Header-Table'
  import mHeaderSearch from '../../common/Header-Search'
  import mToolbar from '../../common/Toolbar'
  import mMineMenu from '../../common/Mine-Menu'
  import ProductDetail from '../index/components/ProductDetail'
  import ProductSeriesDetail from '../index/components/ProductSeriesDetail'
  import ProductDetaDetail from '../index/components/ProductDetaDetail'
  import ProductDetaBrandDetail from '../index/components/ProductDetaBrandDetail'
  import SupplierProductDetail from '../index/components/SupplierProductDetail'
  import SupplierProductSeriesDetail from '../index/components/SupplierProductSeriesDetail'
  import SupplierBrandProductDetail from '../index/components/SupplierBrandProductDetail'
  import CommonBrandProductDetail from '../index/components/CommonBrandProductDetail'
  import CartDialog from '../cart/CartDialog'
  import CommonSettlementDialog from '../cart/CommonSettlementDialog'
  import SupplierSettlementDialog from '../cart/SupplierSettlementDialog'
  import OrderDialog from '../order/OrderDialog'
  import CommonOrderDetailDialog from '../order/CommonOrderDetailDialog'
  import SupplierOrderDetailDialog from '../order/SupplierOrderDetailDialog'
  import AddAddressDialog from '../mine/components/AddAddressDialog'
  import PayMethodDialog from '../../components/PayMethod'

  export default {
    name: 'Index',
    components: {
      mFriendService,
      mFriendInfo,
      mHeaderTable,
      mHeaderSearch,
      mMineMenu,
      mToolbar,
      ProductDetail,
      ProductSeriesDetail,
      SupplierProductDetail,
      SupplierProductSeriesDetail,
      ProductDetaDetail,
      ProductDetaBrandDetail,
      SupplierBrandProductDetail,
      CommonBrandProductDetail,
      CartDialog,
      CommonSettlementDialog,
      SupplierSettlementDialog,
      OrderDialog,
      CommonOrderDetailDialog,
      SupplierOrderDetailDialog,
      AddAddressDialog,
      PayMethodDialog
    },
    data: () => ({}),
    created() {
      this.$Modal.remove()
    },
    methods: {}
  }
</script>

<style lang="less">
  .mine {
    background-color: #f5f5f5;
    width: 100%;
  }
</style>
