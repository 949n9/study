<template>
  <div class="index">
    <m-header-table></m-header-table>
    <m-header-search></m-header-search>

    <Affix>
      <m-header-menu></m-header-menu>
    </Affix>

    <router-view></router-view>

    <m-friend-service></m-friend-service>
    <m-friend-info></m-friend-info>

    <product-detail></product-detail>
    <product-series-detail></product-series-detail>
    <product-deta-detail></product-deta-detail>
    <product-deta-brand-detail></product-deta-brand-detail>
    <supplier-product-detail></supplier-product-detail>
    <supplier-product-series-detail></supplier-product-series-detail>
    <common-brand-product-detail></common-brand-product-detail>
    <common-brand-product-series-detail></common-brand-product-series-detail>
    <supplier-brand-product-detail></supplier-brand-product-detail>
    <supplier-brand-product-series-detail></supplier-brand-product-series-detail>
    <m-toolbar></m-toolbar>

    <cart-dialog></cart-dialog>
    <!-- <cart-dialog1></cart-dialog1> -->
    <common-settlement-dialog></common-settlement-dialog>
    <supplier-settlement-dialog></supplier-settlement-dialog>

    <order-dialog></order-dialog>
    <common-order-detail-dialog></common-order-detail-dialog>
    <supplier-order-detail-dialog></supplier-order-detail-dialog>

    <add-address-dialog></add-address-dialog>
    <sale-hou></sale-hou>
    <pay-method-dialog></pay-method-dialog>
  </div>
</template>

<script>
  import mFriendService from '../../common/Friend-Service'
  import mFriendInfo from '../../common/Friend-Info'
  import mHeaderTable from '../../common/Header-Table'
  import mHeaderSearch from '../../common/Header-Search'
  import mToolbar from '../../common/Toolbar'
  import mHeaderMenu from '../../common/Header-Menu'
  import ProductDetail from '../index/components/ProductDetail'
  import ProductSeriesDetail from '../index/components/ProductSeriesDetail'
  import ProductDetaDetail from '../index/components/ProductDetaDetail'
  import ProductDetaBrandDetail from '../index/components/ProductDetaBrandDetail'
  import SupplierProductDetail from '../index/components/SupplierProductDetail'
  import SupplierProductSeriesDetail from '../index/components/SupplierProductSeriesDetail'
  import SupplierBrandProductDetail from '../index/components/SupplierBrandProductDetail'
  import SupplierBrandProductSeriesDetail from '../index/components/SupplierBrandProductSeriesDetail'
  import CommonBrandProductDetail from '../index/components/CommonBrandProductDetail'
  import CommonBrandProductSeriesDetail from '../index/components/CommonBrandProductSeriesDetail'
  import CartDialog from '../cart/CartDialog'
  import CommonSettlementDialog from '../cart/CommonSettlementDialog'
  import SupplierSettlementDialog from '../cart/SupplierSettlementDialog'

  import OrderDialog from '../order/OrderDialog'
  import CommonOrderDetailDialog from '../order/CommonOrderDetailDialog'
  import SupplierOrderDetailDialog from '../order/SupplierOrderDetailDialog'
  import AddAddressDialog from '../mine/components/AddAddressDialog'
  import SaleHou from '../../components/SaleHou'
  import PayMethodDialog from '../../components/PayMethod'
  export default {
    name: 'Index',
    components: {
      mFriendService,
      mFriendInfo,
      mHeaderTable,
      mHeaderSearch,
      mHeaderMenu,
      mToolbar,
      ProductDetail,
      ProductSeriesDetail,
      ProductDetaDetail,
      ProductDetaBrandDetail,
      SupplierProductDetail,
      SupplierProductSeriesDetail,
      SupplierBrandProductDetail,
      SupplierBrandProductSeriesDetail,
      CommonBrandProductDetail,
      CommonBrandProductSeriesDetail,

      CartDialog,
      CommonSettlementDialog,
      SupplierSettlementDialog,
      OrderDialog,
      CommonOrderDetailDialog,
      SupplierOrderDetailDialog,
      AddAddressDialog,
      SaleHou,
      PayMethodDialog
    },
    data: () => ({}),
    created() {
      this.$Modal.remove()
      // 为了实现在退出时候，隐藏客服弹窗，在登录后清除掉样式
      let pany = document.querySelector('.easemobim-chat-panel')
      if (pany) {
        pany.style.display = 'none'
      }
    },
    methods: {}
  }
</script>

<style lang="less">
  .index {
    overflow: auto;
    background-color: #f5f5f5;
    width: 100%;
    position: relative;
  }
</style>
