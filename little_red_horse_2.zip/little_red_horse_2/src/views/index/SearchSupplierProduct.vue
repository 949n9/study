<template>
  <div class="recent-product">

    <div class="recent-wrap" ref="list">
      <Row v-if="fwProductData.list&&fwProductData.list.length">
        <template v-for="(item,index) in fwProductData.list">
          <Col span="4" :key="item.id" class="grid-wrap">
            <Card :key="index" class="p-wrap grid-wrap-fw">
              <div class="p-wrap-grid" @click="toDetail(item)">
                <img :src="item.imgUrl" :alt="item.productName" :onerror="defaultPimg()" class="p-wrap-grid-img">
              </div>
              <h4 class="p-wrap-name" @click="toDetail(item)" :title="item.productName">{{item.productName}}</h4>
              <p class="p-wrap-time">上架时间：{{item.firstImpTime|cutTime}}</p>
              <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                库存：{{item.dcDistQty}}
              </p>
              <p class="p-wrap-time" v-else>
                <span v-if="item.dcDistQty>0&&item.dcDistQty<item.warnDistQty" class="warn--text">库存紧张</span>
                <span v-else-if="item.dcDistQty<=0" class="red--text">暂时无货</span>
                <span v-else>库存充足</span>
              </p>
              <div class="p-wrap-line">
                <div>
                  <span class="p-wrap-time red--text">¥</span>
                  <span class="p-wrap-price">{{item.taxPrice}}</span>
                </div>
                <Button type="primary" v-if="item.taxPrice*1>0" class="order-btn" @click="toDetail(item)">订货
                  <em v-show="item.orderQty>0">({{item.orderQty}})</em>
                </Button>
              </div>
            </Card>
          </Col>
        </template>
      </Row>

      <Row v-else>
        <Col span="24">
          <div class="search-result">
            <img src="../../assets/images/empty/search.png" alt="" class="search-img">
            <span class="search-info">抱歉，没有找到相关商品内容！</span>
          </div>
        </Col>
      </Row>

      <product-page :pageInfo="fwProductData" @pageChange="handlePageChange"
                    @pageSizeChange="handlePageSizeChange">
      </product-page>

    </div>
  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import ProductPage from '../../common/Product-Page'

  export default {
    name: 'SearchSupplierProduct',
    components: {
      ProductPage
    },
    data: () => ({
      newPorudctList: [],
      orderCondition: '',
      orderConditionType: 'desc',
      productCategoryCode: '',
      productBrandId: '',
      productPropertyId: '',

      pageIndex: 1,
      pageSize: 50
    }),
    computed: {
      ...mapState([
        'searchInfo',
        'addSuccess',
        'loading'
      ]),
      ...mapGetters([
        'fwProductData',
        'userData'
      ])
    },
    watch: {
      'searchInfo': 'handleSearch',
      'addSuccess': 'handleAddSuccess'
    },
    created() {
      this.initData()
    },
    methods: {
      ...mapActions([
        'getFwData',
        'saveSupplierProductInfo',
        'handleBaseDialog',
        'saveSearchInfo'
      ]),
      handleAddSuccess(v) {
        console.log(v)
        let path = v.split('?')[0]
        if (path == this.$route.path) {
          this.initData()
        }
      },
      handleSearch(v) {
        console.log(v)
        if (Object.keys(this.searchInfo).length && this.searchInfo.type == 'fw') {
          this.initData()
        }
      },
      initData() {
        this.getFwData({
          pageIndex: this.pageIndex,
          pageSize: this.pageSize,
          productCondition: this.searchInfo.id,
          orderCondition: this.orderCondition,
          orderConditionType: this.orderConditionType,
          productCategoryCode: this.productCategoryCode,
          productBrandId: this.productBrandId,
          productPropertyId: this.productPropertyId,
          service: '服务商'
        })
      },

      handlePageChange(v) {
        window.scrollTo(0, 500)
        this.pageIndex = v.pageIndex
        this.initData()
      },
      handlePageSizeChange(v) {
        window.scrollTo(0, 500)
        this.pageSize = v.pageSize
        this.initData()
      },

      toDetail(row) {
        row.service = '服务商'
        this.saveSupplierProductInfo(row)
        this.handleBaseDialog({visible: true, type: 'supplierDetailVisible'})
      }
    }
  }
</script>

<style lang="less">

  .recent-product {
    background-color: #F5F5F5;
    overflow-x: hidden;

    .recent-wrap {
      margin: 20px auto;
      width: 1200px;
      background-color: #ffffff;
      padding: 20px 10px;

      .ivu-card-body:hover {
        border: 1px solid red;
        border-radius: 4px;
      }
    }
  }
</style>
