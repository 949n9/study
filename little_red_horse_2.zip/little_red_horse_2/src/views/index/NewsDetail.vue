<template>
  <div class="news-detail">
    <div class="news-detail-wrap">
      <div class="wrap-l">
        <div class="wrap-l-header">
          <Breadcrumb separator=">">
            <BreadcrumbItem to="/index/news">快讯</BreadcrumbItem>
            <BreadcrumbItem>正文</BreadcrumbItem>
          </Breadcrumb>
        </div>

        <div class="wrap-l-content">
          <p class="wrap-l-content-title" title="">
            {{newsDetail.title}}
          </p>

          <div class="wrap-l-content-view">
            <Icon type="ios-eye-outline" size="18" color="#797979"/>
            {{newsDetail.readCount}}人浏览
          </div>

          <p class="wrap-l-content-des" v-html="newsDetail.content">
          </p>

        </div>
      </div>

      <div class="wrap-r">
        <div class="wrap-r-product">
          <div class="wrap-r-header">
            <span>文中商品</span>
          </div>
          <ul class="product">
            <li class="product-item" v-for="(item,index) in hotList" :key="index" @click="toDetail(item)">
              <div class="product-item-img-wrap">
                <img src="" alt="" :onerror="defaultPimg()" class="product-item-img">
              </div>
              <div class="product-item-content">
                <p class="product-item-title">{{item.title}}</p>
                <div class="product-item-other">
                  去看看
                  <Icon size="16" color="#E61E10" type="ios-arrow-dropright-circle"/>
                </div>
              </div>
            </li>
          </ul>
        </div>

        <div class="wrap-r-news">
          <div class="news-header">
            <img src="../../assets/images/news/xiangguan.png" alt="" class="news-header-img">
          </div>

          <ul class="news">
            <li class="news-item" v-for="(item,index) in hotList" :key="index" @click="toDetail(item)">
              <p class="news-item-title">{{item.title}}</p>
              <p class="news-item-des">{{item.description}}</p>
              <div class="news-item-tip">
                <div>
                  <span class="tags" v-for="(i,j) in item.tags" :key="j">{{i}}</span>
                </div>
                <div>
                  <Icon type="ios-eye-outline" size="18" color="#797979"/>
                  {{item.readCount}}人浏览
                </div>
              </div>
            </li>
          </ul>
        </div>

      </div>
    </div>
  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'

  export default {
    name: 'NewsDetail',
    components: {},
    data: () => ({
      newsDetail: {},
      hotList: [],
      newsId: ''
    }),
    computed: {
      ...mapState([
        'loading'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    created() {
      this.saveSearchInfo({})
      this.saveSelectInfo({})
      this.initData()
    },
    watch: {},
    methods: {
      ...mapActions([
        'saveSearchInfo',
        'saveSelectInfo'
      ]),
      initData() {
        console.log(this.$route.params.id)
        this.newsId = this.$route.params.id || ''
        this.getHotList()
        this.getNewsDetail()
      },
      async getNewsDetail() {
        let self = this
        let params = {
          id: self.newsId
        }
        let {data} = await api.getArticleDetail(params)
        if (data.status == '0') {
          self.newsDetail = data.data[0]
        } else {

        }
      },
      // 浏览排行
      async getHotList() {
        let self = this
        let params = {
          pageIndex: 1,
          pageSize: 5,
          orderCondition: 'readCount',
          orderConditionType: 'desc'
        }
        let {data} = await api.getArticleList(params)
        if (data.status == '0') {
          self.hotList = data.data.list
          self.hotList.forEach(item => {
            item.tags = item.tags.split(' ')
          })
        } else {
        }
      },
      toDetail(item) {
        this.$router.push({
          path: '/index/news',
          query: {id: item.id}
        })
      }
    }
  }
</script>

<style lang="less">

  .news-detail {
    width: 100%;
    background-color: #F5F5F5;
    overflow-x: hidden;

    .news-detail-wrap {
      width: 1200px;
      margin: 0 auto;
      position: relative;
      display: flex;
      margin-top: 20px;
      margin-bottom: 60px;

      .wrap-l {
        width: 795px;
        background-color: #ffffff;

        .wrap-l-header {
          padding: 0 30px;
          height: 40px;
          line-height: 40px;
          border-bottom: 1px solid #D2D3D5;
        }

        .wrap-l-content {
          padding: 20px 20px 80px 20px;
          position: relative;

          &-title {
            font-size: 24px;
            font-weight: 600;
            color: #333;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }

          &-view {
            margin-top: 16px;
          }

          &-des {
            font-size: 14px;
            color: #666;
            margin-top: 40px;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            line-clamp: 2;
            -webkit-box-orient: vertical;
          }

          &-tip {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 470px;
            margin-top: 24px;
            display: flex;
            justify-content: space-between;

            .tags {
              margin-right: 8px;
            }

            .tags:hover {
              color: #E61E10;
            }
          }
        }
      }

      .wrap-r {
        position: absolute;
        right: 0;
        top: 0;
        width: 390px;

        .wrap-r-product {
          background-color: #ffffff;
          padding: 12px 13px;

          .wrap-r-header {
            height: 30px;
            line-height: 30px;
            font-weight: 600;
            font-size: 14px;
          }

          .product {
            .product-item {
              cursor: pointer;
              border-bottom: 1px solid #eeeeee;
              padding: 10px 0px;
              display: flex;
              width: 100%;
              &-img-wrap{
                width: 89px;
                height: 89px;
                border: 1px solid #CCCCCC;
                border-radius: 8px;
              }
              &-img {
                display: inline-block;
                width: 89px;
                height: 89px;
              }

              &-content {
                margin-left: 10px;
                position: relative;
                width: 100%;
              }

              &-title {
                font-size: 14px;
                color: #333;
                font-weight: 600;
                overflow: hidden;
                white-space: nowrap;
                text-overflow: ellipsis;
              }

              &-other {
                position: absolute;
                right: 20px;
                bottom: 0px;
                color: #E61E10;
              }
            }
          }
        }

        .wrap-r-news {
          margin-top: 12px;

          .news-header {
            width: 390px;
            height: 108px;
          }

          .news {
            background-color: #ffffff;
            padding: 10px;

            .news-item {
              cursor: pointer;
              border-bottom: 1px solid #eeeeee;
              height: 135px;
              padding: 10px 0;
              position: relative;

              &-title {
                font-size: 14px;
                color: #333;
                font-weight: 600;
                overflow: hidden;
                white-space: nowrap;
                text-overflow: ellipsis;
              }

              &-des {
                font-size: 14px;
                margin-top: 8px;
                color: #999;
                cursor: pointer;
                height: 65px;
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-line-clamp: 3;
                line-clamp: 3;
                -webkit-box-orient: vertical;
              }

              &-tip {
                position: absolute;
                bottom: 5px;
                left: 0;
                width: 350px;
                display: flex;
                justify-content: space-between;

                .tags {
                  margin-right: 8px;
                }

                .tags:hover {
                  color: #E61E10;
                }
              }
            }
          }
        }
      }
    }
  }
</style>
