<template>
  <div class="recent-product">

    <div style="margin-top: 10px">
      <sort-type @display="handleDisplay" @sort="handleSort" :displyShow="true"></sort-type>
    </div>

    <div class="recent-wrap" ref="list">
      <Row v-if="storeProductData.list && storeProductData.list.length">
        <template v-for="(item,index) in storeProductData.list">
          <Col span="4" :key="item.id" class="grid-wrap" v-show="displyType=='grid'">
            <Card :key="index" class="p-wrap grid-wrap-fw" @click.native="toDetail(item)" style="height:342px;">
              <!--<div class="p-wrap-unstore" @click="unStore">-->
              <!--<span >取消收藏</span>-->
              <!--</div>-->
              <div class="p-wrap-grid" @click="toDetail(item)">
                <img :src="item.imgUrl" :alt="item.productName" :onerror="defaultPimg()" class="p-wrap-grid-img">
              </div>
              <h4 class="p-wrap-name" @click="toDetail(item)" :title="item.productName">{{item.productName}}</h4>
              <p class="p-wrap-time">上架时间：{{item.firstImpTime|cutTime}}</p>
              <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                库存：{{item.dcDistQty}}
              </p>
              <p class="p-wrap-time" v-else>
                <span v-if="item.dcDistQty>0&&item.dcDistQty<item.warnDistQty" class="warn--text">库存紧张</span>
                <span v-else-if="item.dcDistQty<=0" class="red--text">暂时无货</span>
                <span v-else>库存充足</span>
              </p>
              <div>
                  <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice!=item.minPeriodPrice">
                    <span style="font-size:12px;">￥</span>{{item.minPeriodPrice}} -
                    <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                  </p>
                  <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice==item.minPeriodPrice">
                      <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                  </p>
                  <p class="p-wrap-price" v-if="item.productType!=2">
                      <span style="font-size:12px;">￥</span>{{item.taxPrice}}
                  </p>
              </div>
              <div class="clearfix">
                  <Button type="primary" long v-if="item.taxPrice*1>0" @click="toDetail(item)">订货
                    <em v-show="item.orderQty>0">({{item.orderQty}})</em>
                  </Button>
              </div>
            </Card>
          </Col>
        </template>
      </Row>

      <Row v-else>
        <Col span="24">
          <div class="search-result">
            <img src="../../assets/images/empty/search.png" alt="" class="search-img">
            <span class="search-info">抱歉，没有找到相关商品内容！</span>
          </div>
        </Col>
      </Row>

      <product-page :pageInfo="storeProductData" @pageChange="handlePageChange"
                    @pageSizeChange="handlePageSizeChange">
      </product-page>

    </div>
  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import SortType from '../../common/Sort-Type'
  import ProductPage from '../../common/Product-Page'

  export default {
    name: 'StoreProduct',
    components: {
      SortType,
      ProductPage
    },
    data: () => ({
      code: '',
      newPorudctList: [],
      orderCondition: '',
      orderConditionType: 'desc',
      productCategoryCode: '',
      productBrandId: '',
      productPropertyId: '',
      displyType: 'grid',

      pageIndex: 1,
      pageSize: 50
    }),
    computed: {
      ...mapState([
        'addSuccess',
        'loading'
      ]),
      ...mapGetters([
        'storeProductData',
        'userData'
      ])
    },
    created() {
      this.saveSearchInfo({})
      this.saveSelectInfo({})
      this.initData()
    },
    watch: {
      'addSuccess': 'handleAddSuccess'
    },
    methods: {
      ...mapActions([
        'getStoreData',
        'saveProductInfo',
        'saveProductSeriesInfo',
        'saveProductDateInfo',
        'handleBaseDialog',
        'saveSearchInfo',
        'saveSelectInfo'
      ]),
      handleAddSuccess(v) {
        console.log(v)
        let path = v.split('?')[0]
        if (path == this.$route.path) {
          this.initData()
        }
      },
      initData() {
        this.getStoreData({
          pageIndex: this.pageIndex,
          pageSize: this.pageSize,
          orderCondition: this.orderCondition,
          orderConditionType: this.orderConditionType,
          productCategoryCode: this.productCategoryCode,
          productBrandId: this.productBrandId,
          productPropertyId: this.productPropertyId
        })
      },
      handleSelectChange(v) {
        this.pageIndex = 1
        this.productCategoryCode = v.productCategoryCode
        this.productBrandId = v.productBrandId
        this.productPropertyId = v.productPropertyId
        this.initData()
      },
      handlePageChange(v) {
        window.scrollTo(0, 500)
        this.pageIndex = v.pageIndex
        this.initData()
      },
      handlePageSizeChange(v) {
        window.scrollTo(0, 500)
        this.pageSize = v.pageSize
        this.initData()
      },
      handleDisplay(v) {
        this.displyType = v
      },
      handleSort(v) {
        this.pageIndex = 1
        this.orderCondition = v.orderCondition
        this.orderConditionType = v.orderConditionType
        this.initData()
      },

      toDetail(row) {
        console.log(row)
        this.saveProductInfo(row.productId)
        this.saveProductSeriesInfo(row.productSetId)
        this.saveProductDateInfo('null')
        if (row.productType == '0') {
          this.handleBaseDialog({visible: true, type: 'productDetailVisible'})
        }
        if (row.productType == '1') {
          this.handleBaseDialog({visible: true, type: 'productSeriesDetailVisible'})
        }
        if (row.productType == '2') {
          this.handleBaseDialog({visible: true, type: 'productDateDetailVisible'})
        }
      }
    }
  }
</script>

<style lang="less">

  .recent-product {
    background-color: #F5F5F5;
    overflow-x: hidden;

    .recent-wrap {
      margin: 20px auto;
      width: 1200px;
      background-color: #ffffff;
      padding: 20px 10px;

      .ivu-card-body:hover {
        border: 1px solid red;
        border-radius: 4px;
      }
    }

    .recent-img {
      height: 200px;
      width: 100%;
      min-width: 1250px;
    }
  }
</style>
