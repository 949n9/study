<template>
  <div class="recent-product-search">
    <div>
      <selector-header-search @selectChange="handleSelectChange" :condition="filter"></selector-header-search>
    </div>

    <div>
      <sort-type @display="handleDisplay" @sort="handleSort" :displyShow="true"></sort-type>
    </div>

    <div class="recent-wrap" ref="list">
      <Row v-if="searchProductData.products.list&&searchProductData.products.list.length">
        <template v-for="(item,index) in searchProductData.products.list">
          <Col span="4" :key="item.id" class="grid-wrap" style="height:410px;">
            <Card :key="index" class="p-wrap grid-wrap-unified" @click.native="toDetail(item)" style="height:100%;">
              <div class="p-wrap-grid" @click="toDetail(item)">
                <img :src="item.imgUrl" :alt="item.productName" :onerror="defaultPimg()" class="p-wrap-grid-img">
              </div>
              <h4 class="p-wrap-name" @click="toDetail(item)" :title="item.productName">{{item.productName}}</h4>
              <div>
                  <!-- <Badge v-if="item.areaProduct==0" :text="'物流费减免：'+item.deliveryFeeReduceRate+'%'" class-name="p-wrap-badge">
                  </Badge> -->
                  <p v-if="item.areaProduct==0" class="p-wrap-time">上架时间：{{item.firstImpTime|cutTime}}</p>
                  <p v-if="item.areaProduct==1" style="height:22px;" class="p-wrap-time"></p>
                  <div class="p-wrap-from-servies" v-if="item.serviceType=='0'||item.serviceType=='1'">
                      <img src="../../assets/images/detail/icon_fuwushang.png" alt="" srcset="" v-if="item.serviceType=='1'">
                      <span @click.stop="goStore(item)">{{item.supplierName}}</span>
                  </div>
                  <div class="p-wrap-from" v-if="item.serviceType=='2'">
                      <img src="../../assets/images/detail/icon_shangchen.png" alt="" srcset="">
                      <span>{{'小红马商城'}}</span>
                  </div>
              </div>
              <p class="p-wrap-areaProduct-flag" v-if="item.areaProduct==1">控区控价</p>
              <p class="p-wrap-time" v-if="item.areaProduct==0" style="height:18px;margin:5px 0;"></p>
              <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                库存：{{item.dcDistQty}}
              </p>
              <p class="p-wrap-time" v-else>
                <span v-if="item.dcDistQty>0&&item.dcDistQty<item.warnDistQty" class="warn--text">库存紧张</span>
                <span v-else-if="item.dcDistQty<=0" class="red--text">暂时无货</span>
                <span v-else>库存充足</span>
              </p>
              <div v-if="item.areaProduct==0">
                  <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice!=item.minPeriodPrice">
                    <span style="font-size:12px;">￥</span>{{item.minPeriodPrice}} -
                    <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                  </p>
                  <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice==item.minPeriodPrice">
                      <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                  </p>
                  <p class="p-wrap-price" v-if="item.productType!=2">
                      <span style="font-size:12px;">￥</span>{{item.taxPrice}}
                  </p>
              </div>
              <div v-if="item.areaProduct==1" style="margin:10px 0;color:#E61E10;">
                  <span class="p-wrap-hide" v-if="item.approveStatus==0">加盟看价格</span>
                  <span class="p-wrap-hide" v-if="item.approveStatus==1">审核中</span>
                  <span class="p-wrap-hide" v-if="item.approveStatus==2">已退回</span>                  
              </div>
              <div class="clearfix" v-if="item.areaProduct==0">
                <Button type="primary" long v-if="item.taxPrice*1>0" @click="toDetail(item)">订货
                  <em v-show="item.orderQty>0">({{item.orderQty}})</em>
                </Button>
              </div>
              <div class="p-wrap-areaProduct" v-if="item.areaProduct==1">
                  <Button type="primary" class="button-primary" v-if="item.approveStatus==0">申请加盟</Button>
                  <Button class="disable-btn button-primary" v-if="item.approveStatus==1">审核中</Button>
                  <Button class="disable-btn button-primary" v-if="item.approveStatus==2">已退回</Button>
              </div>
            </Card>
          </Col>
        </template>
      </Row>

      <Row v-else>
        <Col span="24">
          <div class="search-result">
            <img src="../../assets/images/empty/search.png" alt="" class="search-img">
            <span class="search-info">抱歉，没有找到相关商品内容！</span>
          </div>
        </Col>
      </Row>

      <product-page :pageInfo="searchProductData.products" @pageChange="handlePageChange"
                    @pageSizeChange="handlePageSizeChange">
      </product-page>

    </div>
  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  // import api from '../../core/index'
  import ProductPage from '../../common/Product-Page'
  import SelectorHeaderSearch from '../../common/Selector-Header-Search'
  import SortType from '../../common/Sort-Type'
  // 搜索出来的商品
  export default {
    name: 'SearchCommonProduct',
    components: {
      ProductPage,
      SelectorHeaderSearch,
      SortType
    },
    data: () => ({
      orderCondition: '',
      orderConditionType: 'desc',
      categoryCode: '',
      brandId: '',
      propertyId: '',
      serviceType: '',
      filter: '',
      pageIndex: 1,
      pageSize: 50
    }),
    computed: {
      ...mapState([
        'searchInfo',
        'addSuccess',
        'loading'
      ]),
      ...mapGetters([
        'searchProductData',
        'userData'
      ])
    },
    watch: {
      'searchInfo': 'handleSearch',
      'addSuccess': 'handleAddSuccess'
    },
    created() {
      this.initData()
    },
    methods: {
      ...mapActions([
        'getProductUnifiedSearchData',
        'saveProductInfo',
        'saveProductSeriesInfo',
        'saveProductDateInfo',
        'saveProductDateInfo',
        'saveSupplierProductSeriesInfo',
        'saveSupplierProductInfo',
        'handleBaseDialog'
      ]),
      handleAddSuccess(v) {
        console.log(v)
        let path = v.split('?')[0]
        if (path == this.$route.path) {
          this.initData()
        }
      },
      handleSearch(v) {
        console.log(v)
        if (Object.keys(this.searchInfo).length && this.searchInfo.type == 'unified') {
          this.initData()
        }
      },
      initData() {
        console.log(this.searchInfo)
        this.getProductUnifiedSearchData({
          pageIndex: this.pageIndex,
          pageSize: this.pageSize,
          filter: this.searchInfo.id,
          orderCondition: this.orderCondition,
          orderConditionType: this.orderConditionType,
          categoryCode: this.categoryCode,
          brandId: this.brandId,
          serviceType: this.serviceType,
          propertyId: this.propertyId
        })
      },
      handleDisplay(v) {
        this.displyType = v
      },
      handleSort(v) {
        this.pageIndex = 1
        this.orderCondition = v.orderCondition
        this.orderConditionType = v.orderConditionType
        this.initData()
      },
      // 品类品牌服务类型筛选
      handleSelectChange(v) {
        this.pageIndex = 1
        this.categoryCode = v.productCategoryCode
        this.brandId = v.productBrandId
        this.serviceType = v.serviceType
        this.initData()
      },
      handlePageChange(v) {
        window.scrollTo(0, 500)
        this.pageIndex = v.pageIndex
        this.initData()
      },
      handlePageSizeChange(v) {
        window.scrollTo(0, 500)
        this.pageSize = v.pageSize
        this.initData()
      },
      // 进店
      goStore(row) {
        if (row.serviceType == '0') {
          this.$router.replace({name: 'franchisestoreproduct',
          query: {serviceType: '0', id: row.supplierId, tel: row.telephone, name: row.supplierName, areaProduct: row.areaProduct}})
        } else if (row.serviceType == '1') {
          this.$router.replace({name: 'franchisestoreproduct',
          query: {serviceType: '1', id: row.supplierId, tel: row.telephone, name: row.supplierName, areaProduct: row.areaProduct}})
        }
      },
      toDetail(row) {
        this.toProductDetail(row)
      }
    }
  }
</script>

<style lang="less">
  .ivu-card-body{
    height:100%;
  }
  .recent-product-search {
    background-color: #F5F5F5;
    overflow-x: hidden;

    .recent-wrap {
      margin: 20px auto;
      width: 1200px;
      background-color: #ffffff;
      padding: 20px 10px;
      .ivu-card-body:hover {
        border: 1px solid red;
        border-radius: 4px;
        box-sizing: border-box;
      }
    }

    .recent-img {
      height: 200px;
      width: 100%;
      min-width: 1250px;
    }
  }
</style>
