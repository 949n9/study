<template>
  <div class="pay_success recent-product">
    <div class="pay_success_top">
       <div class="pay_success_left">
          <div class="pay_success_icon">
            <img src="@/assets/images/pay/pay_success.png" alt="" srcset="">
            <p>成功支付<span>{{totalPayAmount}}</span>元</p>
          </div>
          <div class="pay_success_tip" v-if="type=='commonOrder'">
            <span>注意：</span>
            <em>每天16:00前支付并审核通过的订单，当天即可发货。 16:00后的订单，次日发出。</em>
          </div>
          <div class="pay_success_button">
            <div class="" @click="goHome()">返回首页</div>
            <!-- <div class="" @click="showOrder()">查看订单</div> -->
          </div>
       </div>
       <div class="pay_success_right">
          <img src="@/assets/images/pay/rqcode.png" alt="" srcset="">
          <p>微信扫码关注小红马公众号享受更多服务</p>
          <ul>
            <li><span></span><em>物流信息</em></li>
            <li><span></span><em>最大优惠</em></li>
            <li><span></span><em>动销方案</em></li>
            <li><span></span><em>开店秘籍</em></li>
            <li><span></span><em>市场行情</em></li>
          </ul>
       </div>
    </div>
    <div class="recent-wrap" ref="list">
      <Row v-if="guideProduct.list && guideProduct.list.length">
        <template>
          <div class="recommend_header">
            <div class="recommend_header_in">
                  <img src="@/assets/images/pay/icon_left.png" alt="" srcset="">
                  <span>{{guideProduct.title}}</span>
                  <img src="@/assets/images/pay/icon_right.png" alt="" srcset="">
            </div>
          </div>
        </template>
        <template v-for="(item,index) in guideProduct.list">
          <Col span="4" class="grid-wrap" :key="index">
            <Card :key="index" class="p-wrap" style="height: 342px" @click.native="toDetail(item)">
              <div class="p-wrap-grid" @click="toDetail(item)">
                <img :src="item.imgUrl" :alt="item.productName" :onerror="defaultPimg()" class="p-wrap-grid-img">
              </div>
              <h4 class="p-wrap-name" @click="toDetail(item)" :title="item.productName">
                <img src="@/assets/images/detail/icon_shangcheng.png" alt="" srcset="" v-if="item.serviceType==2">
                <img src="@/assets/images/detail/icon_service.png" alt="" srcset="" v-if="item.serviceType==1">
                <img src="@/assets/images/detail/icon_shangjia.png" alt="" srcset="" v-if="item.serviceType==0">
                {{item.productName}}
              </h4>
              <p class="p-wrap-areaProduct-flag" v-if="item.areaProduct==1">控区控价</p>
              <div class="p-wrap-line" v-if="item.areaProduct==0" style="height:26px;">
                <!-- <Badge :text="'物流费减免：'+item.deliveryFeeReduceRate+'%'" class-name="p-wrap-badge">
                </Badge> -->
              </div>
              <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                库存：{{item.dcDistQty}}
              </p>
              <p class="p-wrap-time" v-else>
                <span v-if="item.dcDistQty>0&&item.dcDistQty<item.warnDistQty" class="warn--text">库存紧张</span>
                <span v-else-if="item.dcDistQty<=0" class="red--text">暂时无货</span>
                <span v-else>库存充足</span>
              </p>
              <div v-if="item.areaProduct==0">
                <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice!=item.minPeriodPrice">
                    <span style="font-size:12px;">￥</span>{{item.minPeriodPrice}} -
                    <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                </p>
                <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice==item.minPeriodPrice">
                    <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                </p>
                <p class="p-wrap-price" v-if="item.productType!=2">
                    <span style="font-size:12px;">￥</span>{{item.taxPrice}}
                </p>
              </div>
              <div class="clearfix" v-if="item.areaProduct==0">
                <Button type="primary" long v-if="item.taxPrice*1>0" @click="toDetail(item)">订货
                  <em v-show="item.orderQty>0">({{item.orderQty}})</em>
                </Button>
              </div>
              <div class="p-wrap-areaProduct" v-if="item.areaProduct==1">
                  <Button type="primary" class="button-primary" v-if="item.approveStatus==0">申请加盟</Button>
                  <Button class="disable-btn button-primary" v-if="item.approveStatus==1">审核中</Button>
                  <Button class="disable-btn button-primary" v-if="item.approveStatus==2">已退回</Button>
              </div>
            </Card>
          </Col>
        </template>
      </Row>

      <!-- <Row v-else>
        <Col span="24">
          <div class="search-result">
            <img src="../../assets/images/empty/search.png" alt="" class="search-img">
            <span class="search-info">抱歉，没有找到相关商品内容！</span>
          </div>
        </Col>
      </Row> -->

      <product-page :pageInfo="guideProduct" @pageChange="handlePageChange"
                    @pageSizeChange="handlePageSizeChange">
      </product-page>
    </div>
  </div>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'
  import ProductPage from '../../common/Product-Page'

  export default {
    name: 'PaySuccess',
    components: {
      ProductPage
    },
    data() {
      return {
        pageIndex: 1,
        pageSize: 100,
        guideProduct: []
      }
    },
    computed: {
      ...mapState([
        'loading',
        'addSuccess'
      ]),
      ...mapGetters([
        'userData'
      ]),
      totalPayAmount() {
        return this.$route.query.amount
      },
      orderId() {
        return this.$route.query.orderId
      },
      type() {
        return this.$route.query.type
      }
    },
    created() {
      this.initData()
    },
    methods: {
      ...mapActions([
        'getPromotionData',
        'handleBaseDialog',
        'saveProductInfo',
        'saveProductSeriesInfo',
        'saveProductDateInfo',
        'saveSupplierProductInfo',
        'saveSupplierProductSeriesInfo',
        'saveSearchInfo',
        'saveSelectInfo',
        'saveOrderStatus',
        'saveOrderId'
      ]),
      initData() {
        api.getGuideProductList({
          pageIndex: this.pageIndex,
          pageSize: this.pageSize
        }).then(res => {
          console.log(res)
          if (res.data.status == 0) {
            this.guideProduct = res.data.data
          }
        })
      },
      goHome() {
        this.$router.push({name: 'home'})
      },
      // showOrder() {
      //   this.handleBaseDialog({visible: true, type: 'orderDialogVisible'})
      // },
      // 查看订单
      showOrder() {
        if (this.type == 'commonOrder') {
          this.saveOrderStatus({type: 'commonOrder', status: '1', name: '1'})
          this.handleBaseDialog({visible: true, type: 'commonOrderDialogVisible'})
        } else {
          this.saveOrderStatus({type: 'supplierOrder', status: '3', name: '1'})
          this.handleBaseDialog({visible: true, type: 'supplierOrderDialogVisible'})
        }
        this.saveOrderId(this.orderId)
      },
      handlePageChange(v) {
        window.scrollTo(0, 500)
        this.pageIndex = v.pageIndex
        this.initData()
      },
      handlePageSizeChange(v) {
        window.scrollTo(0, 500)
        this.pageSize = v.pageSize
        this.initData()
      },
      toDetail(row) {
        this.toProductDetail(row)
      }
    }
  }
</script>

<style lang="less">
.recent-product {
    background-color: #F5F5F5;
    overflow-x: hidden;

    .recent-wrap {
      margin: 20px auto;
      width: 1200px;
      background-color: #ffffff;
      padding: 20px 10px;

      .ivu-card-body:hover {
        border: 1px solid red;
        border-radius: 4px;
      }
    }
  }
.pay_success{
  width: 1200px;
  margin: 10px auto 0;
}
.pay_success_top{
  background: #F7FFF3;
  height: 348px;
  display: flex;
}
.pay_success_left{
   padding: 40px 120px 40px 100px;  
   .pay_success_icon{
      display: flex;
      justify-content: left;
      align-items: center;
      img{
        width: 50px;
        height: 50px;
        margin-right: 20px;
      }
      p{
        font-size: 20px;
        color: #000;
        font-weight: 400;
        span{
          color: #E61E10;
          font-size: 21px;
          font-weight: 600;
        }
      }
   }
   .pay_success_tip{
     margin: 40px 0 10px;
     display: flex;
     font-size: 20px;
     color: #4A4A4A;
     span{
      //  font-weight: 600;
     }
     em{
       display: block;
       width: 530px;
     }
   }
   .pay_success_button{
     display: flex;
     margin-left: 60px;
     margin-top: 40px;
     div{
       border:1px solid #DCDFE6;
       width: 120px;
       height: 40px;
       line-height: 40px;
       text-align: center;
       border-radius: 5px;
       font-size: 16px;
       cursor: pointer;
       margin-right: 20px;
     }
   }
}
.pay_success_right{
  position: relative;
  width: 370px;
  padding:40px 0px;
  img{
    display: block;
    width: 166px;
    height: 166px;
    margin: 0 auto;
    border-radius: 2px;
    border: 1px solid #dddddd;
  }
  p{
    width: 294px;
    height: 40px;
    line-height: 45px;
    text-align: center;
    margin: 10px auto;
    background: url('../../assets/images/pay/bg_gz.png');
    color:#ffffff;
    font-size: 14px;
  }
  ul{
    display: flex;
    align-items: center;
    color: #999999;
    font-size: 12px;
    justify-content: space-around;
    margin-top: 5px;
    li{
      display: flex;
      align-items: center;
    }
    span{
       width: 4px;
       height: 4px;
       background: #999999;
       border-radius: 4px;
       margin-right: 5px;
    }
  }
  &:before{
    display: block;
    position: absolute;
    content: '';
    height: 85%;
    width: 2px;
    background: #dddddd;
    left: -15px;
    top: 25px;
  }
}
.recommend_header{
  background: #ffffff;
  padding:30px 0;
}
.recommend_header_in{
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 300px;
  margin: 0px auto;
  background: #ffffff;
  span{
    font-size: 26px;
    margin: 0 15px;
    color: #000;
  }
}
</style>
