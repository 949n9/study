<template>
  <Modal
    :value="commonBrandDetailVisible"
    title="商品详情"
    :mask-closable="false"
    footer-hide
    width="1100"
    :styles="{top: '20px'}"
    @on-visible-change="dialogChange"
  >
    <div class="product-detail" ref="dialog" :style="{height:tabHeight+'px'}">
      <div class="product-wrap clearfix">
        <div class="p-l-wrap">
          <div class="p-img-wrap">
            <img-zoom width="398" height="398" :src="bannerImg" :bigsrc="bImg" :configs="configs" :videoUrl="videoUrl"
                      class="p-img"></img-zoom>
          </div>
          <div class="p-img-wrap-r" v-show="imgWrap">
            <img :src="bannerImg" alt="" class="p-img2" id="img2">
          </div>
          <div class="p-img-banner">
            <Button class="banner-l-btn" @click="toLeftPage">
              <Icon type="ios-arrow-back" size="18"/>
            </Button>
            <Button class="banner-r-btn" @click="toRightPage">
              <Icon type="ios-arrow-forward" size="18"/>
            </Button>
            <div class="banner-wrap" ref="imgList">
              <!--<img src="http://dlm.aiqin.com/263550/1_220.jpg?r=0.6682495737109339" alt="" class="banner-wrap-img">-->
              <template v-for="(item,index) in imgUrls">
                <img :key="index" :src="item[0]" alt="" class="banner-wrap-img"
                     :onerror="defaultPimg()"
                     @mouseenter="selectImg(index,item[0])"
                     :class="[imgId==index?'img-active':'']"
                     @click="selectImg(index,item[0])"/>
              </template>
            </div>
          </div>
        </div>
        <div class="p-r-wrap">
          <div class="p-title">
            <Badge v-show="productInfo.hotProductId!=0" text="热卖" class="p-title-badge fl">
            </Badge>
            <Badge v-show="productInfo.promotionId!=0" text="促销" class="p-title-badge fl">
            </Badge>
            <h3>{{productInfo.productName}}</h3>
          </div>

          <div v-if="productInfo.restrictionStatus==3">
            <div class="p-r-price" v-if="productInfo.brandRestrictionStatus==3">
              <div class="p-price-wrap">
                <span class="p-price-name">进价:</span>
                <span class="p-price-p">¥</span>
                <span class="p-price-value">{{productInfo.taxPrice}}</span>
              </div>
              <div class="p-price-wrap">
                <span class="p-price-name">建议零售价：¥{{productInfo.retailPrice}}</span>
              </div>
              <div class="p-news" v-if="productInfo.brandRestrictionStatus==3">
                <span class="p-news-badge" @click="feeReduceRateTip()">
                    {{'物流费减免'+productInfo.deliveryFeeReduceRate+'%'}}
                </span>
              </div>
            </div>
            <div class="p-news">
              <span class="p-price-date">进货渠道：小红马商城</span>
            </div>
            <div class="p-r-bottom">
              <div class="p-num" v-if="productInfo.brandRestrictionStatus=='3'">
                <form action="javascript:void(0)">
                  <InputNumber
                    ref="ipt"
                    :min="productInfo.minOrderQty*1"
                    :max="999999"
                    :precision="productInfo.qtyDecimalPlace*1"
                    @on-focus="(a)=>qtyFocus(a,'ipt')"
                    v-model="orderQty"></InputNumber>
                </form>
                <p class="p-qty" v-if="userData.showDistQty==='true'">
                  库存：{{productInfo.dcDistQty}}
                </p>
                <p v-else>
                  <span v-if="productInfo.dcDistQty*1>0 && productInfo.dcDistQty*1<productInfo.warnDistQty*1"
                        class="warn--text p-qty">库存紧张</span>
                  <span v-else-if="productInfo.dcDistQty*1<=0" class="red--text p-qty">暂时无货</span>
                  <span v-else class="p-qty">库存充足</span>
                </p>

              </div>
              <div v-if="productInfo.brandRestrictionStatus=='3'">
                <p class="p-store" v-show="productInfo.minOrderQty!=1"> 最小订货量是 <em class="green--text">{{productInfo.minOrderQty}}</em>
                </p>
                <p class="p-store" v-show="productInfo.qtyDecimalPlace==0&&productInfo.fragQty!=1">
                  订货数量必须是
                  <em class="green--text">{{productInfo.fragQty}}</em>
                  的整数倍
                </p>
              </div>
              <div class="p-btn">
                <Button class="addCart" @click="toSign" v-if="productInfo.brandRestrictionStatus=='0'">
                  申请加盟
                </Button>
                <Button class="addCart" style="background-color: #999999" disabled
                        v-if="productInfo.brandRestrictionStatus=='1'">
                  加盟审核中
                </Button>
                <Button class="addCart" style="background-color: #999999" disabled
                        v-if="productInfo.brandRestrictionStatus=='2'">
                  已退回
                </Button>
                <Button class="addCart" @click="addCart(4)" v-if="productInfo.brandRestrictionStatus=='3'">
                  <Icon type="md-cart"/>
                  加入购物车
                </Button>
                <div class="sale-container">
                   <img src="../../../assets/images/headicon/shouho.png" alt="" srcset="">
                   <span @click="openSale()">小红马售后流程</span>
                 </div>
              </div>
            </div>
          </div>
          <div v-if="Object.keys(productInfo).length && productInfo.restrictionStatus!=3">
            <div class="p-r-price">
              <div class="p-price-wrap">
                <span class="p-price-value">商品已下架</span>
              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="product-detail-wrap clearfix">
        <div class="p-recommend">
          <h3 class="p-recommend-title">热卖推荐</h3>
          <div class="p-recommend-list">
            <template v-for="(item,index) in hotList">
              <Card :key="index" class="p-recommend-p-wrap" @click.native="toDetail(item)">
                <div style="text-align:center">
                  <img :src="item.imgUrl" class="p-img">
                </div>
                <div>
                  <h4 class="p-name" :title="item.productName">{{item.productName}}</h4>
                </div>
                <div>
                  <h3 class="p-price">¥{{item.taxPrice}}</h3>
                </div>
              </Card>
            </template>
          </div>
        </div>
        <div class="p-info">
          <div :class="{'p-info-header-fixed':showCart}">
            <Menu mode="horizontal" :active-name="activeName" class="p-info-menu"
                  @on-select="itemSelect">
              <MenuItem name="1" :class="[activeName=='1'?'menu-item':'']">
                商品介绍
              </MenuItem>
              <MenuItem name="2" :class="[activeName=='2'?'menu-item':'']">
                商品信息
              </MenuItem>
              <!--<MenuItem name="3" :class="[activeName=='3'?'menu-item':'']">-->
              <!--附件-->
              <!--</MenuItem>-->
            </Menu>
            <div class="p-r-cart" v-show="showCart && productInfo.taxPrice>0">
              <div class="p-num">
                <form action="javascript:void(0)">
                  <InputNumber
                    ref="ipt2"
                    :min="productInfo.minOrderQty*1"
                    :max="999999"
                    :precision="productInfo.qtyDecimalPlace*1"
                    @on-focus="(a)=>qtyFocus(a,'ipt2')"
                    v-model="orderQty"></InputNumber>
                </form>
                <p class="p-qty" v-if="userData.showDistQty==='true'">
                  库存：{{productInfo.dcDistQty}}
                </p>
                <p v-else>
                  <span v-if="productInfo.dcDistQty*1>0 && productInfo.dcDistQty*1<productInfo.warnDistQty*1"
                        class="warn--text p-qty">库存紧张</span>
                  <span v-else-if="productInfo.dcDistQty*1<=0" class="red--text p-qty">暂时无货</span>
                  <span v-else class="p-qty">库存充足</span>
                </p>
              </div>
              <Poptip trigger="hover" width="300" placement="bottom-end">
                <div class="addCart2" @click="addCart">
                  <Icon type="md-cart"/>
                  加入购物车
                </div>
                <div slot="content" style="display: flex;">
                  <img :src="bannerImg" alt="" style="height: 100px;width: 100px;">
                  <div style="margin-left: 10px">
                    <p style="white-space: normal">{{productInfo.productName}}</p>
                    <p style="color: #E61E10;font-size: 16px;font-weight: 600">¥{{productInfo.taxPrice}}</p>
                  </div>
                </div>
              </Poptip>
            </div>
          </div>
          <div class="p-info-wrap">
            <div class="p-info-product-info" v-show="activeName=='2'">
              <Row>
                <Col span="8">
                  <p class="product-item">编号：<span>{{productInfo.productCode}}</span></p>
                  <p class="product-item">销售码：<span>{{productInfo.barCode}}</span></p>
                  <p class="product-item">规格：<span>{{productInfo.spec}}</span></p>
                  <p class="product-item">单位：<span>{{productInfo.unit}}</span></p>
                </Col>
                <Col span="8">
                  <p class="product-item">品类：<span>{{productInfo.productCategoryName}}</span></p>
                  <p class="product-item">品牌：<span>{{productInfo.productBrandName}}</span></p>
                  <p class="product-item">包装：<span>{{productInfo.pack}}</span></p>
                  <p class="product-item">拆零系数：<span>{{productInfo.fragQty}}</span></p>
                </Col>
                <Col span="16" v-if="productInfo.relaWeightTagCode!='-'">
                  <p class="product-item">发货商家：<em style="padding:0 10px;cursor: pointer;" @click="showImgFlag=!showImgFlag"></em><span>{{productInfo.relaWeightTagCode}}</span></p>
                </Col>
              </Row>
              <Row v-if="productInfo.relaWeightTagCode!='-'&&showImgFlag">
                <img style="width:100%;" :src="`https://redhoma.oss-cn-beijing.aliyuncs.com/seller/${productInfo.relaWeightTagCode}.jpg`" alt="" srcset="">
              </Row>
            </div>
            <div class="p-info-product-introduce" v-show="activeName=='1'">
              <!-- <div v-html="productInfo.baseInfo"></div> -->
              <img style="width: 100%;" :src="productInfo.productDetailImgUrl" alt="" srcset="">
            </div>
            <div class="p-info-product-extra" v-show="activeName=='3'">
              <ul class="extra-wrap">
                <li v-for="(item,index) in productAttachList" :key="index">
                  <a href="javascript:void(0) " @click="loadExtra(item)">
                    <span class="extra-item">{{item.fileName}}</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <Modal
        v-model="signVisible"
        title="温馨提示"
        @on-ok="ok"
        @on-cancel="cancel">
        <p>控区控价的品牌，只有在申请加盟通过后，才可以订货，您确认要申请加盟吗？</p>
      </Modal>

    </div>
  </Modal>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../../core/index'
  import ImgZoom from '../../../components/ImgZoom'

  export default {
    components: {
      ImgZoom
    },
    data: () => ({
      productInfo: {},
      imgUrls: [],
      imgId: 0,
      bannerImg: '',
      videoUrl: '',
      hotList: [],
      activeName: '1',
      orderQty: null,
      imgWrap: false,
      content: '',
      productAttachList: [],
      signVisible: false,
      bImg: '',
      tabHeight: '',
      configs: {
        width: 650,
        height: 450,
        maskWidth: 100,
        maskHeight: 100,
        maskColor: 'red',
        maskOpacity: 0.2
      },
      windowHeight: 0,
      showCart: false,
      dialog: null,
      showImgFlag: false
    }),
    computed: {
      ...mapState([
        'loading',
        'commonBrandDetailVisible',
        'productId'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    created() {
      console.log(this.commonBrandDetailVisible)
      console.log('弹窗 刷新')
      this.handleBaseDialog({visible: false, type: 'commonBrandDetailVisible'})
    },
    mounted() {
      this.dialog = this.$refs.dialog
      let self = this
      this.dialog.addEventListener('scroll', () => {
        // 满足两个条件 ： 在售（没有下架）  已加盟
        if (this.dialog.scrollTop > 500 && this.productInfo.brandRestrictionStatus == 3 && this.productInfo.restrictionStatus == 3) {
          self.showCart = true
          self.$refs.ipt2.$el.querySelector('input').select()
        } else {
          self.showCart = false
          self.$refs.ipt.$el.querySelector('input').select()
        }
      }, false)
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'saveProductInfo',
        'saveProductDateInfo',
        'addToCart',
        'saveCommonCartNum',
        'addProductSuccess'
      ]),
      openSale() {
        this.handleBaseDialog({visible: true, type: 'saleDetailVisible'})
      },
      dialogChange(v) {
        console.log(v)
        this.showImgFlag = false
        if (v) {
          this.activeName = '1'
          this.$nextTick(() => {
            this.dialog.scrollTop = 0
          })
          this.windowHeight = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop
          window.scrollTo(0, 0)
          this.getProductDetail()
          this.getHotList()
          this.getExtra()
          let h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
          this.tabHeight = h - 120
        } else {
          window.scrollTo(0, this.windowHeight)
          this.saveProductInfo('')
          this.orderQty = null
          this.handleBaseDialog({visible: false, type: 'commonBrandDetailVisible'})
        }
      },
      itemSelect(v) {
        this.activeName = v
        this.dialog.scrollTop = 510
      },
      qtyFocus(e, id) {
        console.log(this.$refs[id])
        console.log(id)
        setTimeout(() => {
          this.$refs[id].$el.querySelector('input').select()
        }, 10)
      },
      selectImg(v, url) {
        console.log(v)
        this.imgId = v
        this.bannerImg = url
        this.bImg = url.replace('w_350', 'w_800').replace('h_350', 'h_800')
        if (v + 1 > this.imgUrls.length / 2) {
          this.toRightPage()
        } else {
          this.toLeftPage()
        }
      },
      async getHotList() {
        let self = this
        let params = {
          pageIndex: 1,
          pageSize: 6,
          orderCondition: '',
          orderConditionType: 'desc'
        }
        let {data} = await api.getHotProductList(params)
        self.hotList = data.data.list
      },
      // 左边 上一页
      toLeftPage() {
        this.$nextTick(() => {
          let container = this.$refs.imgList
          console.log(container)
          container.scrollLeft += -3 * 80
        })
      },
      // 右边 下一页
      toRightPage() {
        console.log('to right')
        this.$nextTick(() => {
          let container = this.$refs.imgList
          console.log(container)
          container.scrollLeft += 3 * 80
        })
      },
      async getProductDetail() {
        let self = this
        let params = {
          productId: self.productId
        }
        self.$Spin.show()
        let {data} = await api.getProductDetailInfo(params)
        console.log(data)
        if (data.status == 0) {
          self.productInfo = data.data
          let qty = self.productInfo
          if (qty.orderQty == 0) {
            self.orderQty = null
          } else {
            self.orderQty = qty.orderQty * 1
          }
          self.imgUrls = data.data.imgUrls
          let img = self.imgUrls[0]
          console.log(self.imgUrls[0])
          console.log(self.bannerImg[0])
          self.bannerImg = img[0]
          self.bImg = self.bannerImg.replace('w_350', 'w_800').replace('h_350', 'h_800')
          self.videoUrl = data.data.videoUrl + '?' + new Date().getTime()
          self.$nextTick(() => {
            this.$refs.ipt.$el.querySelector('input').focus()
            this.$refs.ipt.$el.querySelector('input').select()
          })
        } else {
          self.$Notice.error({
            desc: data.message
          })
          self.handleBaseDialog({visible: false, type: 'productDetailVisible'})
        }
        self.$Spin.hide()
      },
      async getExtra() {
        let self = this
        let params = {
          productId: self.productId
        }
        let {data} = await api.getProductAttachList(params)
        console.log(data)
        if (data.status == 0) {
          self.productAttachList = data.data.list
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      ok() {
        this.signVisible = false
        this.handleSign()
      },
      toSign() {
        this.signVisible = true
      },
      cancel() {
        this.signVisible = false
      },
      // 申请加盟
      async handleSign() {
        let self = this
        let params = {
          bizType: 1,
          brandId: self.productInfo.brandId
        }
        let {data} = await api.getSupplierBrandApply(params)
        console.log(data.data)
        if (data.status == 0) {
          self.$Notice.success({
            desc: data.message
          })
          self.productInfo.brandRestrictionStatus = 1
          // 通知 添加成功
          self.addProductSuccess(self.$route.path + '?' + new Date().getTime())
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 添加到购物车
      addCart() {
        let self = this
        let params = {
          orderQty: self.orderQty,
          dcId: self.productInfo.dcId,
          productId: self.productInfo.productId
        }
        this.addToCart(params).then(res => {
          console.log(res.data)
          let data = res.data
          if (data.status == 0) {
            self.$Notice.success({
              desc: '添加成功'
            })
            self.saveCommonCartNum(data.data.totalQty)
            // 通知 添加成功
            self.addProductSuccess(self.$route.path + '?' + new Date().getTime())
            // self.getProductDetail()
          } else {
            self.$Modal.error({
              title: '温馨提示',
              content: data.message,
              onOk: () => {
                setTimeout(() => {
                  this.$refs.ipt.$el.querySelector('input').select()
                }, 10)
              }
            })
          }
        })
      },
      // 下载附件
      loadExtra(row) {
        let url = api.getLoadExtra
        console.log(url)
        // return
        window.open(url + '?id=' + row.id + '&type=product')
      },
      // 查看热卖的商品
      toDetail(row) {
        if (row.serviceType == '2') {
          this.saveProductInfo(row.productId)
          this.saveProductSeriesInfo(row.productSetId)
          this.saveProductDateInfo('null')
          this.handleBaseDialog({visible: false, type: 'productDetailVisible'})
          this.handleBaseDialog({visible: false, type: 'commonBrandDetailVisible'})
          this.handleBaseDialog({visible: false, type: 'productSeriesDetailVisible'})
          this.handleBaseDialog({visible: false, type: 'commonBrandSeriesDetailVisible'})
          this.handleBaseDialog({visible: false, type: 'productDateDetailVisible'})
          this.handleBaseDialog({visible: false, type: 'productBrandDateDetailVisible'})
          this.handleBaseDialog({visible: false, type: 'supplierDetailVisible'})
          this.handleBaseDialog({visible: false, type: 'supplierBrandDetailVisible'})
          this.handleBaseDialog({visible: false, type: 'supplierSeriesDetailVisible'})
          this.handleBaseDialog({visible: false, type: 'supplierBrandSeriesDetailVisible'})
          if (row.productType == '0' && row.areaProduct == '0') {
            this.handleBaseDialog({visible: true, type: 'productDetailVisible'})
          }
          if (row.productType == '0' && row.areaProduct == '1') {
            this.getProductDetail()
            this.getHotList()
            this.getExtra()
            this.handleBaseDialog({visible: true, type: 'commonBrandDetailVisible'})
          }
          if (row.productType == '1' && row.areaProduct == '0') {
            this.handleBaseDialog({visible: true, type: 'productSeriesDetailVisible'})
          }
          if (row.productType == '1' && row.areaProduct == '1') {
            this.handleBaseDialog({visible: true, type: 'commonBrandSeriesDetailVisible'})
          }
          if (row.productType == '2' && row.areaProduct == '0') {
            this.handleBaseDialog({visible: true, type: 'productDateDetailVisible'})
          }
          if (row.productType == '2' && row.areaProduct == '1') {
            this.handleBaseDialog({visible: true, type: 'productBrandDateDetailVisible'})
          }
        } else {
          if (row.serviceType == '1') {
            row.service = '服务商'
          }
          this.saveSupplierProductInfo(row)
          this.saveSupplierProductSeriesInfo(row.productSetId)
          if (row.productType == '0' && row.areaProduct == '0') {
            this.handleBaseDialog({visible: true, type: 'supplierDetailVisible'})
          }
          if (row.productType == '0' && row.areaProduct == '1') {
            this.handleBaseDialog({visible: true, type: 'supplierBrandDetailVisible'})
          }
          if (row.productType == '1' && row.areaProduct == '0') {
            this.handleBaseDialog({visible: true, type: 'supplierSeriesDetailVisible'})
          }
          if (row.productType == '1' && row.areaProduct == '1') {
            this.handleBaseDialog({visible: true, type: 'supplierBrandSeriesDetailVisible'})
          }
        }
      }
    }
  }
</script>

<style lang="less">
  @import "prodetail";

  .ivu-input-number-handler-wrap {
    display: none;
  }
</style>
