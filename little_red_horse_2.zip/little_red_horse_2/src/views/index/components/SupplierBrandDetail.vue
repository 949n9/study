<template>
  <div class="control-product-detail">
    <div class="mine-header detail-wrap">
      <Breadcrumb>
        <BreadcrumbItem to="/index/controlproduct">控区控价</BreadcrumbItem>
        <BreadcrumbItem>品牌详情</BreadcrumbItem>
      </Breadcrumb>
    </div>

    <div class="detail-header" v-if="Object.keys(brandInfo).length">
      <div class="header-wrap">
        <div class="img-wrap">
          <img :src="brandInfo.brandLogoUrl" alt="" class="img">
        </div>
        <div class="brand">
          <span class="brand-name">{{brandInfo.brandName}}</span>
          <Button class="brand-btn">{{brandStatus}}</Button>
          <p class="brand-way">供货渠道：{{brandInfo.supplierName}}</p>
        </div>
      </div>
    </div>

    <div class="brand-wrap" ref="list">
      <Row>
        <Col span="24" class="header-item">
          <p class="item-text">{{brandInfo.brandDescription}}</p>
        </Col>
        <Col span="24" class="header-item">
          <Button class="item-btn" @click="toSign" type="error" v-show="brandInfo.brandRestrictionStatus=='0'">
            申请加盟
          </Button>
        </Col>
      </Row>
      <Row v-if="brandList.length" style="margin-top: 40px">
        <template v-for="(item,index) in brandList">
          <Col span="4" :key="item.id" class="grid-wrap">
            <Card :key="index" v-if="bizType==1" class="p-wrap grid-wrap-brand2" @click.native="toDetail(item)" style="height:342px;">
              <div class="p-wrap-grid" @click="toDetail(item)">
                <img :src="item.imgUrl" :alt="item.productName" :onerror="defaultPimg()" class="p-wrap-grid-img">
              </div>
              <h4 class="p-wrap-name" @click="toDetail(item)" :title="item.productName">{{item.productName}}</h4>
              <!-- <Badge :text="'物流费减免：'+item.deliveryFeeReduceRate+'%'" class-name="p-wrap-badge">
              </Badge> -->
              <div v-if="brandInfo.brandRestrictionStatus!=3" style="height:40px;"></div>
              <div v-if="brandInfo.brandRestrictionStatus==3">
                <p class="p-wrap-time">上架时间：{{item.firstImpTime|cutTime}}</p>
                <!-- <div class="p-wrap-from">
                    <img src="../../../assets/images/detail/icon_shangchen.png" alt="" srcset="">
                    <span>{{'小红马商城直供'}}</span>
                </div> -->
                <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                  库存：{{item.dcDistQty}}
                </p>
                <p class="p-wrap-time" v-else>
                  <span v-if="item.dcDistQty*1>0 && item.dcDistQty*1 < item.warnDistQty*1" class="warn--text p-qty">库存紧张</span>
                  <span v-else-if="item.dcDistQty*1 <=0" class="red--text p-qty">暂时无货</span>
                  <span v-else class="p-qty">库存充足</span>
                </p>
              </div>
              <div class="p-wrap-line">
                <div class="p-wrap-brand" v-if="brandInfo.brandRestrictionStatus==3">
                  <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice!=item.minPeriodPrice">
                    <span style="font-size:12px;">￥</span>{{item.minPeriodPrice}} -
                    <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                  </p>
                  <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice==item.minPeriodPrice">
                      <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                  </p>
                  <p class="p-wrap-price" v-if="item.productType!=2">
                      <span style="font-size:12px;">￥</span>{{item.taxPrice}}
                  </p>
                </div>
                <div class="p-wrap-brand" v-else>
                  <span class="red--text" style="font-weight: 600"></span>
                </div>
              </div>
              <div class="clearfix">
                  <Button type="primary" long v-if="brandInfo.brandRestrictionStatus==3&&item.taxPrice*1>0" @click="toDetail(item)">订货
                    <em v-show="item.orderQty>0">({{item.orderQty}})</em>
                  </Button>
                  <Button type="primary" long v-else @click="toDetail(item)">立即抢购
                  </Button>
              </div>
            </Card>
            <Card :key="index" v-else class="p-wrap grid-wrap-brand" @click.native="toSupplierDetail(item)" style="height:320px;">
              <div class="p-wrap-grid" @click="toSupplierDetail(item)">
                <img :src="item.imgUrl" :alt="item.productName" :onerror="defaultPimg()" class="p-wrap-grid-img">
              </div>
              <h4 class="p-wrap-name" @click="toSupplierDetail(item)" :title="item.productName">
                {{item.productName}}
              </h4>
              <div v-if="brandInfo.brandRestrictionStatus==3">
                <div class="p-wrap-from-servies">
                    <!-- <img src="../../../assets/images/detail/icon_fuwushang.png" alt="" srcset=""> -->
                    <span @click.stop="goStore(item)">{{item.supplierName}}</span>
                </div>
                <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                  库存：{{item.dcDistQty}}
                </p>
                <p class="p-wrap-time" v-else>
                  <span v-if="item.dcDistQty*1>0 && item.dcDistQty*1<item.warnDistQty*1" class="warn--text p-qty">库存紧张</span>
                  <span v-else-if="item.dcDistQty*1<=0" class="red--text p-qty">暂时无货</span>
                  <span v-else class="p-qty">库存充足</span>
                </p>
              </div>
              <div v-if="brandInfo.brandRestrictionStatus!=3" style="height:40px;"></div>
              <div class="p-wrap-line">
                <div class="p-wrap-brand" v-if="brandInfo.brandRestrictionStatus==3">
                  <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice!=item.minPeriodPrice">
                    <span style="font-size:12px;">￥</span>{{item.minPeriodPrice}} -
                    <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                  </p>
                  <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice==item.minPeriodPrice">
                      <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                  </p>
                  <p class="p-wrap-price" v-if="item.productType!=2">
                      <span style="font-size:12px;">￥</span>{{item.taxPrice}}
                  </p>
                </div>
                <div class="p-wrap-brand" v-else>
                  <span class="red--text" style="font-weight: 600"></span>
                </div>
                <Button type="primary" class="order-btn" v-if="brandInfo.brandRestrictionStatus==3 && item.taxPrice*1>0"
                        @click="toSupplierDetail(item)">订货
                  <em v-show="item.orderQty>0">({{item.orderQty}})</em>
                </Button>
                <Button type="primary" long v-else @click="toSupplierDetail(item)">立即抢购
                </Button>
              </div>
            </Card>
          </Col>
        </template>
      </Row>

      <Row v-if="brandList.length==0 && !loading">
        <Col span="24">
          <div class="search-result">
            <img src="../../../assets/images/empty/search.png" alt="" class="search-img">
            <span class="search-info">抱歉，没有找到相关商品内容！</span>
          </div>
        </Col>
      </Row>
    </div>
    <Modal
      v-model="signVisible"
      title="温馨提示"
      @on-ok="ok"
      @on-cancel="cancel">
      <p>控区控价的品牌，只有在申请加盟通过后，才可以订货，您确认要申请加盟吗？</p>
    </Modal>
  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../../core/index'

  export default {
    components: {},
    data: () => ({
      brandId: '',
      bizType: '2',
      brandInfo: {},
      brandList: [],
      brandStatus: '',
      signVisible: false
    }),
    computed: {
      ...mapState([
        'addSuccess',
        'loading'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    created() {
      this.brandId = this.$route.query.id
      this.bizType = this.$route.query.bizType
      this.initData()
      this.handleBaseDialog({visible: false, type: 'supplierBrandDetailVisible'})
    },
    watch: {
      'addSuccess': 'handleAddSuccess'
    },
    methods: {
      ...mapActions([
        'saveProductInfo',
        'saveSupplierProductInfo',
        'saveProductSeriesInfo',
        'saveProductDateInfo',
        'saveSupplierProductSeriesInfo',
        'handleBaseDialog'
      ]),
      handleAddSuccess(v) {
        console.log(v)
        let path = v.split('?')[0]
        if (path == this.$route.path) {
          this.initData()
        }
      },
      initData() {
        this.getBrand({})
      },
      async getBrand() {
        let self = this
        let params = {
          bizType: self.bizType,
          brandId: self.brandId
        }
        let {data} = await api.getSupplierBrandDetail(params)
        console.log(data.data.list)

        if (data.status == 0) {
          self.brandInfo = data.data.brandInfo
          self.brandList = data.data.list
          self.brandStatus = self.status2Name(self.brandInfo.brandRestrictionStatus)
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      status2Name(status) {
        let name = ''
        switch (status) {
          case '0':
            name = '可申请加盟'
            break
          case '1':
            name = '加盟审核中'
            break
          case '2':
            name = '已退回'
            break
          case '3':
            name = '已加盟'
            break
        }
        return name
      },
      cancel() {
        this.signVisible = false
      },
      toSign() {
        this.signVisible = true
      },
      ok() {
        this.signVisible = false
        this.handleSign()
      },
      // 申请加盟
      async handleSign() {
        let self = this
        let params = {
          bizType: self.bizType,
          brandId: self.brandId
        }
        let {data} = await api.getSupplierBrandApply(params)
        console.log(data.data)
        if (data.status == 0) {
          self.$Notice.success({
            desc: data.message
          })
          self.initData()
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      goStore(row) {
        this.$router.push({name: 'franchisestoreproduct',
        query: {serviceType: '1', id: row.supplierId, tel: row.supplierTelephone, name: row.supplierName}})
      },
      toDetail(row) {
        console.log(row)
        this.saveProductInfo(row.productId)
        this.saveProductSeriesInfo(row.productSetId)
        this.saveProductDateInfo('null')        
        if (row.productType == '0') {
          this.handleBaseDialog({visible: true, type: 'commonBrandDetailVisible'})
        }
        if (row.productType == '1') {
          this.handleBaseDialog({visible: true, type: 'commonBrandSeriesDetailVisible'})
        }
        if (row.productType == '2') {
          this.handleBaseDialog({visible: true, type: 'productDateBrandDetailVisible'})
        }
      },
      toSupplierDetail(row) {
        console.log(row)
        row.service = '服务商'
        this.saveSupplierProductInfo(row)
        this.saveSupplierProductSeriesInfo(row.productSetId)
        if (row.productType == '0') {
          this.handleBaseDialog({visible: true, type: 'supplierBrandDetailVisible'})
        } 
        if (row.productType == '1') {
          this.handleBaseDialog({visible: true, type: 'supplierBrandSeriesDetailVisible'})
        }
      }
    }
  }
</script>

<style lang="less">

  .control-product-detail {
    background-color: #F5F5F5;

    .mine-header {
      height: 35px;
      line-height: 35px;
      margin-left: 10px;
    }

    .detail-wrap {
      margin: 0px auto;
      width: 1200px;
    }

    .detail-header {
      width: 100%;
      height: 200px;
      background: url("../../../assets/images/banner/banddetail.png");

      .header-wrap {
        margin: 0px auto;
        width: 1200px;
        padding: 20px;
        height: 200px;
        position: relative;

        .img-wrap {
          width: 147px;
          height: 147px;
          background: #ffffff;
          border-radius: 5px;

          .img {
            margin-top: 29px;
            height: 87px;
            width: 147px;
          }
        }

        .brand {
          position: absolute;
          top: 40px;
          left: 200px;

          &-name {
            display: inline-block;
            font-size: 24px;
            font-weight: 600;
          }

          &-btn {
            margin-top: -14px;
            margin-left: 10px;
            border-radius: 16px;
            box-shadow: none;
          }

          &-way {
            margin-top: 15px;
            background-color: #FF9445;
            font-size: 20px;
            font-weight: 600;
            border-radius: 5px;
            padding: 0 16px;
            color: #ffffff;
          }
        }
      }
    }

    .brand-wrap {
      margin: 20px auto;
      width: 1200px;
      background-color: #ffffff;
      padding: 20px 10px;

      .header-item {
        padding: 10px;

        .item-text {
          font-size: 16px;
        }

        .item-btn {
          width: 240px;
        }
      }
    }

    .control-row {
      padding: 10px 0;

      .brand-content {
        margin-top: 10px;
        display: flex;
        padding: 10px;

        .brand-item {
          cursor: pointer;

          .logo {
          }
        }
      }
    }
  }
</style>
