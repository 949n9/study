export const controlColumns = [
  {
    title: '品牌名称',
    key: 'brandName',
    align: 'center'
  },
  {
    title: '供货渠道名称',
    key: 'supplierName',
    align: 'center'
  },
  {
    title: '申请人',
    key: 'createUserName',
    align: 'center'
  },
  {
    title: '申请日期',
    key: 'createTime',
    align: 'center'
  },
  {
    title: '操作',
    slot: 'action',
    align: 'center'
  }
]
export const controlColumns2 = [
  {
    title: '品牌名称',
    key: 'brandName',
    align: 'center'
  },
  {
    title: '供货渠道名称',
    key: 'supplierName',
    align: 'center'
  },
  {
    title: '申请人',
    key: 'createUserName',
    align: 'center'
  },
  {
    title: '申请日期',
    key: 'createTime',
    align: 'center'
  }, {
    title: '审核人',
    key: 'approveUserName',
    align: 'center'
  },
  {
    title: '审核时间',
    key: 'approveTime',
    align: 'center'
  },
  {
    title: '操作',
    slot: 'action',
    align: 'center'
  }
]

export const controlColumns3 = [
  {
    title: '品牌名称',
    key: 'brandName',
    align: 'center'
  },
  {
    title: '供货渠道名称',
    key: 'supplierName',
    width: 200,
    align: 'center'
  },
  {
    title: '申请人',
    key: 'createUserName',
    align: 'center'
  },
  {
    title: '申请日期',
    key: 'createTime',
    width: 150,
    align: 'center'
  }, {
    title: '审核人',
    key: 'approveUserName',
    align: 'center'
  },
  {
    title: '审核时间',
    key: 'approveTime',
    width: 150,
    align: 'center'
  },
  {
    title: '退回原因',
    key: 'approveOption',
    width: 300,
    align: 'center'
  },
  {
    title: '操作',
    slot: 'action',
    align: 'center'
  }
]
