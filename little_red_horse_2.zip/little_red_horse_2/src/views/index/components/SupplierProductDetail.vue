<template>
  <Modal
    :value="supplierDetailVisible"
    title="商品详情"
    :mask-closable="false"
    footer-hide
    width="1100"
    :styles="{top: '20px'}"
    @on-visible-change="dialogChange">
    <div class="product-detail" ref="dialog" :style="{height:tabHeight+'px'}">
      <div class="product-wrap clearfix">
        <div class="p-l-wrap">
          <div class="p-img-wrap">
            <img-zoom width="398" height="398" :src="bannerImg" :bigsrc="bImg" :configs="configs" :videoUrl="videoUrl"
                      class="p-img"></img-zoom>
          </div>
          <div class="p-img-banner">
            <Button class="banner-l-btn" @click="toLeftPage">
              <Icon type="ios-arrow-back" size="18"/>
            </Button>
            <Button class="banner-r-btn" @click="toRightPage">
              <Icon type="ios-arrow-forward" size="18"/>
            </Button>
            <div class="banner-wrap" ref="imgList">
              <template v-for="(item,index) in imgUrls">
                <img :key="index" :src="item[0]" alt="" class="banner-wrap-img"
                     :onerror="defaultPimg()"
                     @mouseenter="selectImg(index,item[0])"
                     :class="[imgId==index?'img-active':'']"
                     @click="selectImg(index,item[0])"/>
              </template>
            </div>
          </div>
          <!--<div class="p-l-star" @click="toggleStore" v-show="productInfo.restrictionStatus==3">-->
          <!--<Icon type="md-star" style="color: #E61E10;margin-top: -5px" size="20" v-if="store"/>-->
          <!--<Icon type="md-star-outline" style="margin-top: -5px" size="20" v-else/>-->
          <!--<span v-if="store">取消收藏</span>-->
          <!--<span v-else>收藏商品 </span>-->
          <!--</div>-->
        </div>
        <div class="p-r-wrap">
          <div class="p-title">
            <Badge v-show="productInfo.taxPrice<=0" text="赠品" class="p-title-badge fl">
            </Badge>
            <h3>{{productInfo.productName}}</h3>
          </div>
          <div class=tip-word v-if="productInfo.tipWords">
             <img src="@/assets/images/detail/tip.png" alt="">
             <span>{{productInfo.tipWords}}</span>
          </div>
          <div v-if="productInfo.restrictionStatus==3">
            <div class="p-r-price">
              <div class="p-price-wrap">
                <span class="p-price-name">进价:</span>
                <span class="p-price-p">¥</span>
                <span class="p-price-value">{{productInfo.taxPrice}}</span>
              </div>
              <div class="p-price-wrap">
                <span class="p-price-name">建议零售价：¥{{productInfo.retailPrice}}</span>
              </div>
              <div class="p-promotion-word" v-if="productInfo.promotionWords"><span>{{productInfo.promotionWords}}</span></div>
            </div>
            <!--<div class="p-news">-->
            <!--<span class="p-price-date">末次进货日期：{{productInfo.lastTime}}</span>-->
            <!--<span class="p-price-date">末次进货量：{{productInfo.lastQty}}</span>-->
            <!--<span class="p-price-date">末次进货价格：{{productInfo.lastTaxPrice}}</span>-->
            <!--</div>-->
            <!-- <div class="p-news">
              <span class="p-price-date">{{productInfo.supplierName}}</span>
            </div> -->
            <div class="p-r-date" v-if="productInfo.producePeriod">
              <p class="text">生产期间：{{productInfo.producePeriod}}</p>
            </div>
            <div class="p-r-bottom" v-show="productInfo.taxPrice>0">
              <div class="p-num">
                <form action="javascript:void(0)">
                  <InputNumber
                    ref="ipt"
                    :min="productInfo.minOrderQty*1"
                    :max="999999"
                    :precision="productInfo.qtyDecimalPlace*1"
                    @on-focus="(a)=>qtyFocus(a,'ipt')"
                    v-model="orderQty"></InputNumber>
                </form>

                <p class="p-qty" v-if="userData.showDistQty==='true'">
                  库存：{{productInfo.distQty}}
                </p>
                <p v-else>
                  <span v-if="productInfo.distQty*1>0 && productInfo.distQty*1<productInfo.warnDistQty*1"
                        class="warn--text p-qty">库存紧张</span>
                  <span v-else-if="productInfo.distQty*1<=0" class="red--text p-qty">暂时无货</span>
                  <span v-else class="p-qty">库存充足</span>
                </p>

              </div>
              <div>
                <p class="p-store" v-show="productInfo.minOrderQty!=1"> 最小订货量是 <em class="green--text">{{productInfo.minOrderQty}}</em>
                </p>
                <p class="p-store" v-show="productInfo.qtyDecimalPlace==0&&productInfo.fragQty!=1">
                  订货数量必须是
                  <em class="green--text">{{productInfo.fragQty}}</em>
                  的整数倍
                </p>
              </div>
              <div class="p-btn">
                <Button class="addCart" @click="addCart">
                  <Icon type="md-cart"/>
                  加入购物车
                </Button>
                <div class="sale-container">
                   <img src="../../../assets/images/headicon/shouho.png" alt="" srcset="">
                   <span @click="openSale()">小红马售后流程</span>
                </div>
              </div>
            </div>
          </div>
          <div v-if="Object.keys(productInfo).length && productInfo.restrictionStatus!=3">
            <div class="p-r-price">
              <div class="p-price-wrap">
                <span class="p-price-value">商品已下架</span>
              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="product-detail-wrap clearfix">
        <div class="p-recommend">
          <!-- <div class="p-recommend-store-info" :class="{'servies-bg': productInfo.isService==1}">
             <div class="store-info-left">
               <img src="../../../assets/images/detail/store_icon.png" alt="">
              </div>
             <div class="store-info-right">
                <p class="store-info-right-name">
                  <em>{{productInfo.supplierName||productInfo.recommends[0].supplierName}}</em><span v-show="productInfo.isService==1">服务商</span>
                </p>
                <p class="store-info-right-tel">
                  <img src="../../../assets/images/detail/phone_icon.png" alt="" srcset="">
                  <span>客服热线：{{productInfo.supplierTelephone||productInfo.recommends[0].supplierTelephone}}</span>
                </p>
                <div class="div-button" @click="goStore()">进店逛逛</div>
             </div>
          </div> -->
          <h3 class="p-recommend-title">店铺推荐</h3>
          <div class="p-recommend-list">
            <template v-for="(item,index) in productInfo.recommends">
              <Card :key="index" class="p-recommend-p-wrap" @click.native="toDetail(item)">
                <div style="text-align:center">
                  <img :src="item.imgUrl" :onerror="defaultPimg()" class="p-img">
                </div>
                <div>
                  <h4 class="p-name" @click="toDetail(item)" :title="item.productName">{{item.productName}}</h4>
                </div>
                <div>
                  <h3 class="p-price">¥{{item.taxPrice}}</h3>
                </div>
              </Card>
            </template>
          </div>
        </div>
        <div class="p-info">
          <div :class="{'p-info-header-fixed':showCart}">
            <Menu mode="horizontal" :active-name="activeName" class="p-info-menu"
                  @on-select="itemSelect">
              <MenuItem name="1" :class="[activeName=='1'?'menu-item':'']">
                商品介绍
              </MenuItem>
              <MenuItem name="2" :class="[activeName=='2'?'menu-item':'']">
                商品信息
              </MenuItem>
              <!--<MenuItem name="3" :class="[activeName=='3'?'menu-item':'']">-->
              <!--附件-->
              <!--</MenuItem>-->
            </Menu>
            <div class="p-r-cart" v-show="showCart && productInfo.taxPrice>0">
              <div class="p-num">
                <form action="javascript:void(0)">
                  <InputNumber
                    ref="ipt2"
                    :min="productInfo.minOrderQty*1"
                    :max="999999"
                    :precision="productInfo.qtyDecimalPlace*1"
                    @on-focus="(a)=>qtyFocus(a,'ipt2')"
                    v-model="orderQty"></InputNumber>
                </form>
                <p class="p-qty" v-if="userData.showDistQty==='true'">
                  库存：{{productInfo.distQty}}
                </p>
                <p v-else>
                  <span v-if="productInfo.distQty*1>0 && productInfo.distQty*1<productInfo.warnDistQty*1"
                        class="warn--text p-qty">库存紧张</span>
                  <span v-else-if="productInfo.distQty*1<=0" class="red--text p-qty">暂时无货</span>
                  <span v-else class="p-qty">库存充足</span>
                </p>
              </div>

              <Poptip trigger="hover" width="300" placement="bottom-end">
                <div class="addCart2" @click="addCart">
                  <Icon type="md-cart"/>
                  加入购物车
                </div>
                <div slot="content" style="display: flex;">
                  <img :src="bannerImg" alt="" style="height: 100px;width: 100px;">
                  <div style="margin-left: 10px">
                    <p style="white-space: normal">{{productInfo.productName}}</p>
                    <p style="color: #E61E10;font-size: 16px;font-weight: 600">¥{{productInfo.taxPrice}}</p>
                  </div>
                </div>
              </Poptip>

            </div>
          </div>
          <div class="p-info-wrap">
            <div class="p-info-product-info" v-show="activeName=='2'">
              <Row>
                <Col span="8">
                  <p class="product-item">编号：<span>{{productInfo.productCode}}</span></p>
                  <p class="product-item">销售码：<span>{{productInfo.barCode}}</span></p>
                  <p class="product-item">规格：<span>{{productInfo.spec}}</span></p>
                  <p class="product-item">单位：<span>{{productInfo.unit}}</span></p>
                </Col>
                <Col span="8">
                  <p class="product-item">品类：<span>{{productInfo.productCategoryName}}</span></p>
                  <p class="product-item">品牌：<span>{{productInfo.productBrandName}}</span></p>
                  <p class="product-item">包装：<span>{{productInfo.pack}}</span></p>
                  <p class="product-item">拆零系数：<span>{{productInfo.fragQty}}</span></p>
                </Col>
              </Row>
            </div>
            <div class="p-info-product-introduce" v-show="activeName=='1'">
              <!-- <div v-html="productInfo.baseInfo"></div> -->
              <img style="width: 100%;" :src="productInfo.productDetailImgUrl" alt="" srcset="">
            </div>
            <div class="p-info-product-extra" v-show="activeName=='3'">
              <ul class="extra-wrap">
                <li v-for="(item,index) in productAttachList" :key="index">
                  <a href="javascript:void(0) " @click="loadExtra(item)">
                    <span class="extra-item">{{item.fileName}}</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </Modal>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../../core/index'
  import ImgZoom from '../../../components/ImgZoom'

  export default {
    components: {
      ImgZoom
    },
    data: () => ({
      saleDetailVisible: false,
      store: false,
      productInfo: {
        recommends: [
          {
            supplierName: '',
            supplierTelephone: ''
          }
        ]
      },
      imgUrls: [],
      imgId: 0,
      bannerImg: '',
      videoUrl: '',
      hotList: [],
      activeName: '1',
      orderQty: null,
      imgWrap: false,
      content: '',
      productAttachList: [],
      bImg: '',
      tabHeight: '',
      tabSaleHeight: '',
      configs: {
        width: 650,
        height: 450,
        maskWidth: 100,
        maskHeight: 100,
        maskColor: 'red',
        maskOpacity: 0.2
      },
      windowHeight: 0,
      showCart: false,
      dialog: null
    }),
    computed: {
      ...mapState([
        'loading',
        'supplierDetailVisible',
        'supplierProduct'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    created() {
      console.log(this.supplierDetailVisible)
      console.log('弹窗 刷新')
      this.handleBaseDialog({visible: false, type: 'supplierDetailVisible'})
    },
    mounted() {
      this.dialog = this.$refs.dialog
      let self = this
      this.dialog.addEventListener('scroll', () => {
        if (this.dialog.scrollTop > 495 && this.productInfo.restrictionStatus == 3) {
          self.showCart = true
          self.$refs.ipt2.$el.querySelector('input').select()
        } else {
          self.showCart = false
          self.$refs.ipt.$el.querySelector('input').select()
        }
      }, false)
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'saveSupplierProductInfo',
        'saveSupplierProductSeriesInfo',
        'addToSupplierCart',
        'saveSupplierCartNum',
        'addProductSuccess'
      ]),
      toggleStore() {
        this.store = !this.store
      },
      openSale() {
        this.handleBaseDialog({visible: true, type: 'saleDetailVisible'})
      },
      dialogChange(v) {
        console.log(v)
        console.log(this.supplierProduct)
        if (v) {
          this.activeName = '1'
          this.$nextTick(() => {
            this.dialog.scrollTop = 0
          })
          this.windowHeight = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop
          window.scrollTo(0, 0)
          this.getProductDetail()
          // this.getHotList()
          this.getExtra()
          let h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
          this.tabHeight = h - 120
        } else {
          window.scrollTo(0, this.windowHeight)
          this.saveSupplierProductInfo({})
          this.orderQty = null
          this.handleBaseDialog({visible: false, type: 'supplierDetailVisible'})
        }
      },
      itemSelect(v) {
        this.activeName = v
        this.dialog.scrollTop = 500
      },
      qtyFocus(e, id) {
        console.log(this.$refs[id])
        console.log(id)
        setTimeout(() => {
          this.$refs[id].$el.querySelector('input').select()
        }, 10)
      },
      selectImg(v, url) {
        console.log(v)
        this.imgId = v
        this.bannerImg = url
        this.bImg = url.replace('w_350', 'w_800').replace('h_350', 'h_800')
        if (v + 1 > this.imgUrls.length / 2) {
          this.toRightPage()
        } else {
          this.toLeftPage()
        }
      },
      async getHotList() {
        let self = this
        let params = {
          pageIndex: 1,
          pageSize: 6,
          service: '服务商'
        }
        let {data} = await api.getSupplierProductList(params)
        if (data.status == 0) {
          self.hotList = data.data.list
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 左边 上一页
      toLeftPage() {
        this.$nextTick(() => {
          let container = this.$refs.imgList
          console.log(container)
          container.scrollLeft += -3 * 80
        })
      },
      // 右边 下一页
      toRightPage() {
        console.log('to right')
        this.$nextTick(() => {
          let container = this.$refs.imgList
          console.log(container)
          container.scrollLeft += 3 * 80
        })
      },
      // 跳转到店铺
      goStore(row) {
        this.handleBaseDialog({visible: false, type: 'cartDialogVisible'})
        this.handleBaseDialog({visible: false, type: 'orderDialogVisible'})
        this.handleBaseDialog({visible: false, type: 'supplierDetailVisible'})
        this.handleBaseDialog({visible: false, type: 'supplierSettlementDialogVisible'})
        this.handleBaseDialog({visible: false, type: 'supplierOrderDialogVisible'})
        if (this.productInfo.isService == '0') {
          this.$router.push({name: 'franchisestoreproduct',
          query: {serviceType: '0', id: this.productInfo.supplierId, tel: this.productInfo.supplierTelephone, name: this.productInfo.supplierName || this.productInfo.recommends[0].supplierName, areaProduct: this.supplierProduct.areaProduct}})
        } else if (this.productInfo.isService == '1') {
          this.$router.push({name: 'franchisestoreproduct',
          query: {serviceType: '1', id: this.productInfo.supplierId, tel: this.productInfo.supplierTelephone, name: this.productInfo.supplierName || this.productInfo.recommends[0].supplierName, areaProduct: this.supplierProduct.areaProduct}})
        }
      },
      async getProductDetail() {
        let self = this
        let params = {
          productId: self.supplierProduct.productId,
          supplierId: self.supplierProduct.supplierId,
          service: self.supplierProduct.service
        }
        console.log(params)
        self.$Spin.show()
        let {data} = await api.getSupplierProductDetail(params)
        console.log(data)
        if (data.status == 0) {
          self.productInfo = data.data
          // self.productInfo = Object.assign({}, data.data, {areaProduct: self.supplierProduct.areaProduct})
          let qty = self.productInfo
          if (qty.orderQty == 0) {
            self.orderQty = null
          } else {
            self.orderQty = qty.orderQty * 1
          }
          self.imgUrls = data.data.imgUrls
          let img = self.imgUrls[0]
          console.log(self.imgUrls[0])
          console.log(self.bannerImg[0])
          self.bannerImg = img[0]
          self.bImg = self.bannerImg.replace('w_350', 'w_800').replace('h_350', 'h_800')
          self.videoUrl = data.data.videoUrl + '?' + new Date().getTime()
          self.$nextTick(() => {
            this.$refs.ipt.$el.querySelector('input').focus()
            this.$refs.ipt.$el.querySelector('input').select()
          })
        } else {
          self.$Notice.error({
            desc: data.message
          })
          self.handleBaseDialog({visible: false, type: 'supplierDetailVisible'})
        }
        self.$Spin.hide()
      },
      async getExtra() {
        let self = this
        let params = {
          productId: self.supplierProduct.productId
        }
        let {data} = await api.getProductAttachList(params)
        console.log(data)
        if (data.status == 0) {
          self.productAttachList = data.data.list
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 添加到购物车
      addCart() {
        let self = this
        let params = {
          orderQty: self.orderQty,
          supplierId: self.productInfo.supplierId,
          productId: self.productInfo.productId
        }
        this.addToSupplierCart(params).then(res => {
          console.log(res.data)
          let data = res.data
          if (data.status == 0) {
            self.$Notice.success({
              desc: '添加成功'
            })
            // self.getProductDetail()
            self.saveSupplierCartNum(data.data.totalQty)
            // 通知 添加成功
            self.addProductSuccess(self.$route.path + '?' + new Date().getTime())
          } else {
            self.$Modal.error({
              title: '温馨提示',
              content: data.message,
              onOk: () => {
                setTimeout(() => {
                  this.$refs.ipt.$el.querySelector('input').select()
                }, 10)
              }
            })
          }
        })
      },
      // 下载附件
      loadExtra(row) {
        let url = api.getLoadExtra
        console.log(url)
        // return
        window.open(url + '?id=' + row.id + '&type=product')
      },
      toDetail(row) {
        if (row.isService == 1) {
          row.service = '服务商'
        }
        this.saveSupplierProductInfo(row)
        this.saveSupplierProductSeriesInfo(row.productSetId)
        if (row.productSetId == '0') {
          this.getProductDetail()
          this.getHotList()
          this.getExtra()
        } else {
          this.handleBaseDialog({visible: false, type: 'supplierDetailVisible'})
          this.handleBaseDialog({visible: true, type: 'supplierSeriesDetailVisible'})
        }
      }
    }
  }
</script>

<style lang="less">
  @import "prodetail";

  .ivu-input-number-handler-wrap {
    display: none;
  }
  .p-recommend-store-info{
    display: flex;
    justify-content: space-between;
    padding:20px 15px 15px;
    background: url('../../../assets/images/detail/store_bg.png') no-repeat;
    background-size:100% 100%;
    &.servies-bg{
      background: url('../../../assets/images/detail/store_bg_servies.png') no-repeat!important;
    }
    .store-info-left{
       img{
         width:38px;
         height: 38px;
       }
    }
    .store-info-right{
      margin-left: 10px;
      p{
        color: #ffffff;
        overflow: hidden;
        &.store-info-right-name{
          em{
            display: block;
            width:85px;
            float:left;
            font-size: 14px;
            overflow: hidden;
            text-overflow: ellipsis;
            -webkit-box-orient:vertical;
            display: -webkit-box;
            -webkit-line-clamp: 1;
          }
          span{
            float:right;
            font-size: 12;
            padding:1px 8px;
            border-radius: 34px;
            color: #F7B62D;
            background: #ffffff;
          }
        }
        &.store-info-right-tel{
          display: flex;
          justify-content: flex-start;
          align-items: center;
          margin: 5px 0 13px;
          img{
            width: 12px;
            height: 12px;
            display: block;
            margin-right: 5px;
          }
          span{
            color: #ffffff;
          }
        }
      }
      .div-button{
        width:124px;
        height:30px;
        line-height: 30px;
        text-align: center;
        color: #E61E10;
        font-size: 14px;
        border-radius: 4px;
        background: #ffffff;
        cursor: pointer;
        &:hover{
          background: #eeeeee;
        }
      }
    }
  }

</style>
