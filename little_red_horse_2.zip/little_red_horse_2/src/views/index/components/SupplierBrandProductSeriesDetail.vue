<template>
  <Modal
    :value="supplierBrandSeriesDetailVisible"
    title="控区控价系列商品详情"
    :mask-closable="false"
    footer-hide
    width="1100"
    :styles="{top: '20px'}"
    @on-visible-change="dialogChange"
  >
    <div class="product-detail" ref="dialog" :style="{height:tabHeight+'px'}" @mouseover="poptipVisible=false">
      <div class="product-wrap clearfix">
        <div class="p-l-wrap">
          <div class="p-img-wrap">
            <img-zoom width="398" height="398" :src="bannerImg" :bigsrc="bImg" :configs="configs" :videoUrl="videoUrl"
                      class="p-img"></img-zoom>
          </div>
          <div class="p-img-wrap-r" v-show="imgWrap">
            <img :src="bannerImg" alt="" class="p-img2" id="img2">
          </div>
          <div class="p-img-banner">
            <Button class="banner-l-btn" @click="toLeftPage">
              <Icon type="ios-arrow-back" size="18"/>
            </Button>
            <Button class="banner-r-btn" @click="toRightPage">
              <Icon type="ios-arrow-forward" size="18"/>
            </Button>
            <div class="banner-wrap" ref="imgList">
              <template v-for="(item,index) in imgUrls">
                <img :key="index" :src="item[0]" alt="" class="banner-wrap-img"
                     :onerror="defaultPimg()"
                     @mouseenter="selectImg(index,item[0])"
                     :class="[imgId==index?'img-active':'']"
                     @click="selectImg(index,item[0])"/>
              </template>
            </div>
          </div>
        </div>
        <div class="p-r-wrap">
          <div class="p-title">
            <!--<Badge text="厂商直送" class="p-title-badge fl">-->
            <!--</Badge>-->
            <h3>{{productInfo.productName}}</h3>
          </div>
          <div class=tip-word v-if="productInfo.tipWords">
             <img src="@/assets/images/detail/tip.png" alt="">
             <span>{{productInfo.tipWords}}</span>
          </div>
          <div v-if="productInfo.restrictionStatus==3">
            <div class="p-r-price">
              <div class="p-price-wrap" v-if="productInfo.brandRestrictionStatus==3">
                <span class="p-price-name">进价:</span>
                <span class="p-price-p">¥</span>
                <span class="p-price-value">{{productInfo.taxPrice}}</span>
              </div>
              <div class="p-price-wrap" v-if="productInfo.brandRestrictionStatus==3">
                <span class="p-price-name">建议零售价：¥{{productInfo.retailPrice}}</span>
              </div>
              <div class="p-promotion-word" v-if="productInfo.promotionWords"><span>{{productInfo.promotionWords}}</span></div>
              <div class="p-price-wrap" v-else>
                <span class="p-price-value">服务商专供</span>
              </div>
            </div>
            <div class="p-news">
              <span class="p-price-date">{{productInfo.supplierName}}</span>
            </div>
            <!-- 系列商品 -->
            <div class="p-r-select" v-if="productInfo.brandRestrictionStatus=='3'">
               <div class="p-r-select-tip">
                   <p class="p-store">
                      <em class="">{{productSeriesInfo.setOrderPrompt}}</em>
                   </p>
               </div>
               <div class="p-r-select-color" v-if="productSeriesInfo.attrCount==2">
                  <p class="p-r-select-color-l">
                    属性
                    <span></span>
                  </p>
                  <!-- 属性 -->
                  <div class="p-r-select-color-r">
                     <span :class="{'span-active': item.productId==activeTag}" @click="selectAttribute(index, attributeList)"
                      v-for="(item, index) in attributeList" :key="index">{{item.name}}</span>
                  </div>
               </div>
               <div class="p-r-select-attribute">
                 <p class="p-r-select-attribute-l">属性</p>
                  <div class="p-r-select-attribute-r">
                     <!-- 规格 -->
                     <section  v-if="productSeriesInfo.attrCount==2">
                      <div class="p-r-select-attribute-item" :class="{'spec-active': specTag==item.productId}"
                        v-for="(item) in specList[tagIndex]" :key="item.productId" @click="selectSpec(item)">
                        <div class="p-r-select-attribute-item-tip" v-if="specTag==item.productId">
                            <p class="p-store" v-show="item.minOrderQty!=1"> 最小订货量是 <em class="green--text">{{item.minOrderQty}}</em>，</p>
                            <p class="p-store" v-show="item.qtyDecimalPlace==0&&item.fragQty!=1">订货数量必须是<em class="green--text">{{item.fragQty}}</em>的整数倍</p>
                        </div>
                        <div class="p-r-select-attribute-item-l">
                            <img :src="item.imgUrl" :onerror="defaultPimg()" alt="" srcset="">
                            <span>{{item.otherAttrValue}}</span>
                            <em>{{item.taxPrice}}元</em>
                        </div>
                        <div class="p-r-select-attribute-item-r">
                            <p class="p-qty" v-if="userData.showDistQty==='true'">库存：{{item.dcDistQty}}</p>
                            <p v-else>
                              <span v-if="item.dcDistQty*1>0 && item.dcDistQty*1<item.warnDistQty*1"
                                    class="warn--text p-qty">库存紧张</span>
                              <span v-else-if="item.dcDistQty*1<=0" class="red--text p-qty">暂时无货</span>
                              <span v-else class="p-qty">库存充足</span>
                            </p>
                            <form action="javascript:void(0)">
                                <InputNumber
                                  :ref="'0'+item.productId"
                                  :max="999999"
                                  :min="item.minOrderQty*1"
                                  :precision="item.qtyDecimalPlace*1"
                                  @on-focus="(a)=>qtyFocus(a,`0${item.productId}`)"
                                  @on-change="(a)=>qtyChange(a,item)"
                                  v-model="item.orderQty"></InputNumber>
                          </form>
                        </div>
                      </div>
                     </section>
                     <section  v-if="productSeriesInfo.attrCount==1">
                      <div class="p-r-select-attribute-item" :class="{'spec-active': specTag==item.productId}"
                        v-for="(item) in specList" :key="item.productId" @click="selectSpec(item)">
                        <div class="p-r-select-attribute-item-tip" v-if="specTag==item.productId">
                            <p class="p-store" v-show="item.minOrderQty!=1"> 最小订货量是 <em class="green--text">{{item.minOrderQty}}</em>，</p>
                            <p class="p-store" v-show="item.qtyDecimalPlace==0&&item.fragQty!=1">订货数量必须是<em class="green--text">{{item.fragQty}}</em>的整数倍</p>
                        </div>
                        <div class="p-r-select-attribute-item-l">
                            <img :src="item.imgUrl" alt="" srcset="" :onerror="defaultPimg()">
                            <span>{{item.otherAttrValue}}</span>
                            <em>{{item.taxPrice}}元</em>
                        </div>
                        <div class="p-r-select-attribute-item-r">
                            <p class="p-qty" v-if="userData.showDistQty==='true'">库存：{{item.dcDistQty}}</p>
                            <p v-else>
                              <span v-if="item.dcDistQty*1>0 && item.dcDistQty*1<item.warnDistQty*1"
                                    class="warn--text p-qty">库存紧张</span>
                              <span v-else-if="item.dcDistQty*1<=0" class="red--text p-qty">暂时无货</span>
                              <span v-else class="p-qty">库存充足</span>
                            </p>
                            <form action="javascript:void(0)">
                                <InputNumber
                                  :ref="'0'+item.productId"
                                  :max="999999"
                                  :min="item.minOrderQty*1"
                                  :precision="item.qtyDecimalPlace*1"
                                  @on-focus="(a)=>qtyFocus(a,`0${item.productId}`)"
                                  @on-change="(a)=>qtyChange(a,item)"
                                  v-model="item.orderQty"></InputNumber>
                          </form>
                        </div>
                      </div>
                     </section>
                  </div>
               </div>
               <div class="p-select-total">
                  <p>共<em>{{totalInfo.totalOrderQty}}</em>件</p>
                  <p>合计<em>{{`￥${totalInfo.totalPrice}`}}</em></p>
               </div>
            </div>
            <div class="p-r-bottom">
              <div class="p-btn">
                <Button class="addCart" @click="toSign" v-if="productInfo.brandRestrictionStatus=='0'">
                  申请加盟
                </Button>
                <Button class="addCart" style="background-color: #999999" disabled
                        v-if="productInfo.brandRestrictionStatus=='1'">
                  加盟审核中
                </Button>
                <Button class="addCart" style="background-color: #999999" disabled
                        v-if="productInfo.brandRestrictionStatus=='2'">
                  已退回
                </Button>
                <Button class="addCart" @click="addCart(4)" v-if="productInfo.brandRestrictionStatus=='3'">
                  <Icon type="md-cart"/>
                  加入购物车
                </Button>
                <div class="sale-container">
                   <img src="../../../assets/images/headicon/shouho.png" alt="" srcset="">
                   <span @click="openSale()">小红马售后流程</span>
                </div>
              </div>
            </div>
          </div>
          <div v-if="Object.keys(productInfo).length && productInfo.restrictionStatus!=3">
            <div class="p-r-price">
              <div class="p-price-wrap">
                <span class="p-price-value">商品已下架</span>
              </div>
            </div>
          </div>

        </div>
      </div>

      <div class="product-detail-wrap clearfix">
        <div class="p-recommend">
          <div class="p-recommend-store-info" :class="{'servies-bg': productInfo.isService==1}">
             <div class="store-info-left">
               <img src="../../../assets/images/detail/store_icon.png" alt="">
              </div>
             <div class="store-info-right">
                <p class="store-info-right-name">
                  <em>{{productInfo.supplierName}}</em><span v-show="productInfo.isService==1">服务商</span>
                </p>
                <p class="store-info-right-tel">
                  <img src="../../../assets/images/detail/phone_icon.png" alt="" srcset="">
                  <span>客服热线：{{productInfo.supplierTelephone}}</span>
                </p>
                <div class="div-button" @click="goStore()">进店逛逛</div>
             </div>
          </div>
          <h3 class="p-recommend-title">店铺推荐</h3>
          <div class="p-recommend-list">
            <template v-for="(item,index) in productInfo.recommends">
              <Card :key="index" class="p-recommend-p-wrap" @click.native="toDetail(item)">
                <div style="text-align:center">
                  <img :src="item.imgUrl" :onerror="defaultPimg()" class="p-img">
                </div>
                <div>
                  <h4 class="p-name" @click="toDetail(item)" :title="item.productName">{{item.productName}}</h4>
                </div>
                <div>
                  <h3 class="p-price">¥{{item.taxPrice}}</h3>
                </div>
              </Card>
            </template>
          </div>
        </div>
        <div class="p-info">
          <div :class="{'p-info-header-fixed':showCart}">
            <Menu mode="horizontal" :active-name="activeName" class="p-info-menu"
                  @on-select="itemSelect">
              <MenuItem name="1" :class="[activeName=='1'?'menu-item':'']">
                商品介绍
              </MenuItem>
              <MenuItem name="2" :class="[activeName=='2'?'menu-item':'']">
                商品信息
              </MenuItem>
              <!--<MenuItem name="3" :class="[activeName=='3'?'menu-item':'']">-->
              <!--附件-->
              <!--</MenuItem>-->
            </Menu>
            <!-- 吸顶系列商品区 -->
            <div class="p-r-cart" v-show="showCart && productInfo.taxPrice>0">
              <Poptip trigger="click" width="600" placement="bottom-end" v-model="poptipVisible">
                <div class="p-select-total p-select-total-other1" @mouseover.stop="poptipVisible=true">
                    <p>共<em>{{totalInfo.totalOrderQty}}</em>件</p>
                    <p>合计<em>{{`￥${totalInfo.totalPrice}`}}</em></p>
                    <Icon type="ios-arrow-up" class="ios-arrow-up-type"/>
                </div>
                <div slot="content" style="display: flex;" @mouseover.stop="poptipVisible=true">
                    <div class="p-r-select p-r-select-other">
                        <div class="p-r-select-tip">
                            <p class="p-store">
                                <em class="">{{productSeriesInfo.setOrderPrompt}}</em>
                            </p>
                            <!-- <p class="p-store" v-show="productSeriesInfo.attrCount==1">
                                不同的规格可混订，订货数量必须是
                                <em class="">{{productInfo.fragQty}}</em>
                                的整数倍！
                            </p> -->
                        </div>
                        <div class="p-r-select-color" v-if="productSeriesInfo.attrCount==2">
                            <p class="p-r-select-color-l">
                                属性
                                <span></span>
                            </p>
                            <!-- 属性 -->
                            <div class="p-r-select-color-r">
                                <span :class="{'span-active': item.productId==activeTag}" @click="selectAttribute(index, attributeList)"
                                v-for="(item, index) in attributeList" :key="index">{{item.name}}</span>
                            </div>
                        </div>
                        <div class="p-r-select-attribute">
                            <!-- <p class="p-r-select-attribute-l">{{productSeriesInfo.attrCount==2 ? '选择尺码' : '选择规格'}}</p> -->
                            <p class="p-r-select-attribute-l">属性</p>
                            <div class="p-r-select-attribute-r p-r-select-attribute-r-other">
                                <!-- 规格 -->
                              <section v-if="productSeriesInfo.attrCount==2">
                                <div class="p-r-select-attribute-item" :class="{'spec-active': specTag==item.productId}"
                                    v-for="(item) in specList[tagIndex]" :key="item.productId" @click="selectSpec(item)">
                                    <div class="p-r-select-attribute-item-tip" v-if="specTag==item.productId">
                                        <p class="p-store" v-show="item.minOrderQty!=1"> 最小订货量是 <em class="green--text">{{item.minOrderQty}}</em>，</p>
                                        <p class="p-store" v-show="item.qtyDecimalPlace==0&&item.fragQty!=1">订货数量必须是<em class="green--text">{{item.fragQty}}</em>的整数倍</p>
                                    </div>
                                    <div class="p-r-select-attribute-item-l">
                                        <img :src="item.imgUrl" :onerror="defaultPimg()" alt="" srcset="">
                                        <span>{{item.otherAttrValue}}</span>
                                        <em>{{item.taxPrice}}元</em>
                                    </div>
                                    <div class="p-r-select-attribute-item-r">
                                        <p class="p-qty" v-if="userData.showDistQty==='true'">库存：{{item.dcDistQty}}</p>
                                        <p v-else>
                                        <span v-if="item.dcDistQty*1>0 && item.dcDistQty*1<item.warnDistQty*1"
                                                class="warn--text p-qty">库存紧张</span>
                                        <span v-else-if="item.dcDistQty*1<=0" class="red--text p-qty">暂时无货</span>
                                        <span v-else class="p-qty">库存充足</span>
                                        </p>
                                        <form action="javascript:void(0)">
                                            <!-- @click.stop.native="1" -->
                                             <!-- :min="productInfo.minOrderQty*1" -->
                                            <InputNumber
                                            :ref="'1'+item.productId"
                                            :max="999999"
                                            :min="item.minOrderQty*1"
                                            :precision="item.qtyDecimalPlace*1"
                                            @on-focus="(a)=>qtyFocus(a,`1${item.productId}`)"
                                            @on-change="(a)=>qtyChange(a,item)"
                                            v-model="item.orderQty"></InputNumber>
                                    </form>
                                    </div>
                                </div>
                              </section>
                              <section v-if="productSeriesInfo.attrCount==1">
                                <div class="p-r-select-attribute-item" :class="{'spec-active': specTag==item.productId}"
                                    v-for="(item) in specList" :key="item.productId" @click="selectSpec(item)">
                                    <div class="p-r-select-attribute-item-tip" v-if="specTag==item.productId">
                                        <p class="p-store" v-show="item.minOrderQty!=1"> 最小订货量是 <em class="green--text">{{item.minOrderQty}}</em>，</p>
                                        <p class="p-store" v-show="item.qtyDecimalPlace==0&&item.fragQty!=1">订货数量必须是<em class="green--text">{{item.fragQty}}</em>的整数倍</p>
                                    </div>
                                    <div class="p-r-select-attribute-item-l">
                                        <img :src="item.imgUrl" :onerror="defaultPimg()" alt="" srcset="">
                                        <span>{{item.otherAttrValue}}</span>
                                        <em>{{item.taxPrice}}元</em>
                                    </div>
                                    <div class="p-r-select-attribute-item-r">
                                        <p class="p-qty" v-if="userData.showDistQty==='true'">库存：{{item.dcDistQty}}</p>
                                        <p v-else>
                                        <span v-if="item.dcDistQty*1>0 && item.dcDistQty*1<item.warnDistQty*1"
                                                class="warn--text p-qty">库存紧张</span>
                                        <span v-else-if="item.dcDistQty*1<=0" class="red--text p-qty">暂时无货</span>
                                        <span v-else class="p-qty">库存充足</span>
                                        </p>
                                        <form action="javascript:void(0)">
                                             <!-- @click.stop.native="1" -->
                                             <!-- :min="productInfo.minOrderQty*1" -->
                                            <InputNumber
                                            :ref="'1'+item.productId"
                                            :max="999999"
                                            :min="item.minOrderQty*1"
                                            :precision="item.qtyDecimalPlace*1"
                                            @on-focus="(a)=>qtyFocus(a,`1${item.productId}`)"
                                            @on-change="(a)=>qtyChange(a,item)"
                                            v-model="item.orderQty"></InputNumber>
                                    </form>
                                    </div>
                                </div>
                              </section>
                            </div>
                        </div>
                        <div class="p-select-total p-select-total-other">
                            <p>共<em>{{totalInfo.totalOrderQty}}</em>件</p>
                            <p>合计<em>{{`￥${totalInfo.totalPrice}`}}</em></p>
                        </div>
                        <div class="addCart_3 addCart_4 " @click="addCart">
                          <!-- <Icon type="md-cart"/> -->
                          加入购物车
                        </div>
                    </div>
                </div>
              </Poptip>
            </div>
          </div>
          <div class="p-info-wrap">
            <div class="p-info-product-info" v-show="activeName=='2'">
              <Row>
                <Col span="8">
                  <p class="product-item">编号：<span>{{productInfo.productCode}}</span></p>
                  <p class="product-item">销售码：<span>{{productInfo.barCode}}</span></p>
                  <p class="product-item">规格：<span>{{productInfo.spec}}</span></p>
                  <p class="product-item">单位：<span>{{productInfo.unit}}</span></p>
                </Col>
                <Col span="8">
                  <p class="product-item">品类：<span>{{productInfo.productCategoryName}}</span></p>
                  <p class="product-item">品牌：<span>{{productInfo.productBrandName}}</span></p>
                  <p class="product-item">包装：<span>{{productInfo.pack}}</span></p>
                  <p class="product-item">拆零系数：<span>{{productInfo.fragQty}}</span></p>
                </Col>
              </Row>
            </div>
            <div class="p-info-product-introduce" v-show="activeName=='1'">
              <!-- <div v-html="productInfo.baseInfo"></div> -->
              <img style="width: 100%;" :src="productInfo.productDetailImgUrl" alt="" srcset="">
            </div>
            <div class="p-info-product-extra" v-show="activeName=='3'">
              <ul class="extra-wrap">
                <li v-for="(item,index) in productAttachList" :key="index">
                  <a href="javascript:void(0) " @click="loadExtra(item)">
                    <span class="extra-item">{{item.fileName}}</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <Modal
        v-model="signVisible"
        title="温馨提示"
        @on-ok="ok"
        @on-cancel="cancel">
        <p>控区控价的品牌，只有在申请加盟通过后，才可以订货，您确认要申请加盟吗？</p>
      </Modal>

    </div>
  </Modal>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../../core/index'
  import ImgZoom from '../../../components/ImgZoom'

  export default {
    components: {
      ImgZoom
    },
    data: () => ({
      productInfo: {},
      imgUrls: [],
      imgId: 0,
      bannerImg: '',
      videoUrl: '',
      hotList: [],
      activeName: '1',
      orderQty: null,
      imgWrap: false,
      content: '',
      productAttachList: [],
      signVisible: false,
      bImg: '',
      tabHeight: '',
      configs: {
        width: 650,
        height: 450,
        maskWidth: 100,
        maskHeight: 100,
        maskColor: 'red',
        maskOpacity: 0.2
      },
      windowHeight: 0,
      showCart: false,
      poptipVisible: false,
      dialog: null,
      activeTag: '',
      specList: [],
      specTag: '',
      attributeList: [],
      tagIndex: 0,
      totalInfo: {
        totalOrderQty: 0,
        totalPrice: '0.00'
      },
      productSeriesInfo: {},
      selectProductInfo: {}
    }),
    computed: {
      ...mapState([
        'loading',
        'supplierBrandSeriesDetailVisible',
        'supplierBrandDetailVisible',
        'productId',
        'supplierProduct',
        'supplierProductSeriesId'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    created() {
      console.log(this.supplierBrandDetailVisible)
      console.log('弹窗 刷新')
      this.handleBaseDialog({visible: false, type: 'supplierBrandSeriesDetailVisible'})
    },
    mounted() {
      this.dialog = this.$refs.dialog
      let self = this
      this.dialog.addEventListener('scroll', () => {
        // 满足两个条件 ： 在售（没有下架）  已加盟
        if (this.dialog.scrollTop > 500 && this.productInfo.brandRestrictionStatus == 3 && this.productInfo.restrictionStatus == 3) {
          self.showCart = true
          self.$refs.ipt2.$el.querySelector('input').select()
        } else {
          self.showCart = false
          self.$refs.ipt.$el.querySelector('input').select()
        }
      }, false)
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'saveSupplierProductInfo',
        'saveSupplierProductSeriesInfo',
        'addToSupplierSeriesCart',
        'addToSupplierCart',
        'saveSupplierCartNum',
        'addProductSuccess',
        'supplierProductSeriesId'
      ]),
      openSale() {
        this.handleBaseDialog({visible: true, type: 'saleDetailVisible'})
      },
      dialogChange(v) {
        console.log(v)
        if (v) {
          this.activeName = '1'
          this.activeTag = this.supplierProduct.productId
          this.specTag = this.supplierProduct.productId
          this.$nextTick(() => {
            this.dialog.scrollTop = 0
          })
          this.windowHeight = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop
          window.scrollTo(0, 0)
          this.getProductDetail(true)
          this.getProductSeries()
          this.getExtra()
          let h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
          this.tabHeight = h - 120
        } else {
          window.scrollTo(0, this.windowHeight)
          this.saveSupplierProductInfo({})
          this.orderQty = null
          this.handleBaseDialog({visible: false, type: 'supplierBrandSeriesDetailVisible'})
        }
      },
      // 选择属性（有子类）
      selectAttribute(index, list) {
        this.tagIndex = index
        this.activeTag = list[index].productId
        list[index].service = '服务商'
        this.saveSupplierProductInfo(list[index])
        // this.saveSupplierProductSeriesInfo(row.productSetId)
        this.getProductDetail(false)
        this.computedTotal(this.specList[this.tagIndex])
      },
      // 选择属性（无子类）
      selectSpec(item, type) {
        this.specTag = item.productId
        item.service = '服务商'
        this.saveSupplierProductInfo(item)
        this.getProductDetail(false)
        if (this.productSeriesInfo.attrCount == 1) {
          this.computedTotal(this.specList)
        } else {
          this.computedTotal(this.specList[this.tagIndex])
        }
      },
      // 计算价格和合计的数量
      computedTotal(item) {
        this.selectProductInfo = []
        this.totalInfo = {
          totalOrderQty: 0,
          totalPrice: '0.00'
        }
        item.forEach(e => {
          if (e.orderQty > 0) {
            this.selectProductInfo.push(e)
            this.totalInfo.totalPrice = (parseFloat(this.totalInfo.totalPrice) + (parseFloat(e.taxPrice) * parseFloat(e.orderQty))).toFixed(2)
            this.totalInfo.totalOrderQty = parseFloat(this.totalInfo.totalOrderQty) + parseFloat(e.orderQty)
          }
        })
        console.log('计算完成', this.selectProductInfo)
        // this.selectProductInfo = item
      },
      itemSelect(v) {
        this.activeName = v
        this.dialog.scrollTop = 510
      },
      qtyFocus(e, id, type) {
        console.log(this.$refs[id])
        this.$refs[id][0].$el.querySelector('input').select()
      },
      qtyChange(e, item) {
        console.log(item)
        if (item.orderQty === '') {
          item.orderQty = 0
        }
        if (this.productSeriesInfo.attrCount == 1) {
          this.computedTotal(this.specList)
        } else {
          this.computedTotal(this.specList[this.tagIndex])
        }
      },
      // 左边 上一页
      toLeftPage() {
        this.$nextTick(() => {
          let container = this.$refs.imgList
          console.log(container)
          container.scrollLeft += -3 * 80
        })
      },
      // 右边 下一页
      toRightPage() {
        console.log('to right')
        this.$nextTick(() => {
          let container = this.$refs.imgList
          console.log(container)
          container.scrollLeft += 3 * 80
        })
      },
      // 获取商品系列信息
      async getProductSeries() {
        let self = this
        let params = {
          productSetId: self.supplierProductSeriesId,
          supplierId: self.supplierProduct.supplierId,
          service: self.supplierProduct.service
        }
        self.$Spin.show()
        let {data} = await api.getSupplierProductSeriesInfo(params)
        console.log(data)
        if (data.status == '0') {
          self.productSeriesInfo = data.data
          if (data.data.attrCount === 2) {
            self.attributeList = Object.keys(data.data.list)
            self.attributeList.forEach((e, index) => {
              self.attributeList[index] = {
                productId: self.supplierProduct.productId,
                name: e,
                isService: self.supplierProduct.service == '服务商' ? '0' : '',
                supplierId: self.supplierProduct.supplierId
              }
            })
            self.specList = Object.values(data.data.list)
            self.specList.forEach((e, index) => {
                e.forEach(i => {
                if (i.productId == self.supplierProduct.productId) {
                  self.attributeList[index] = {
                    productId: self.supplierProduct.productId,
                    name: self.attributeList[index].name,
                    isService: self.supplierProduct.service == '服务商' ? '0' : '',
                    supplierId: self.supplierProduct.supplierId
                  }
                  // 获取默认下标
                  self.tagIndex = index
                  // 计算
                  self.computedTotal(e)
                } else {
                  self.attributeList[index] = {
                    productId: e[0].productId,
                    name: self.attributeList[index].name,
                    isService: self.supplierProduct.service == '服务商' ? '0' : '',
                    supplierId: self.supplierProduct.supplierId
                  }
                }
                if (i.orderQty == '0') {
                    i.orderQty = ''
                }
                })
            })
          }
          console.log('颜色', self.attributeList)
          if (data.data.attrCount === 1) {
            console.log('单属性')
            self.specList = data.data.list.setProducts
            self.specList.forEach((e, index) => {
              if (e.productId == self.supplierProduct.productId) {
                // 计算
                self.computedTotal(self.specList)
              }
              if (e.orderQty == '0') {
                e.orderQty = ''
              }
            })
          }
          self.$nextTick(() => {
            // self.$refs[self.productId][0].$el.querySelector('input').focus()
            // self.$refs[self.productId][0].$el.querySelector('input').select()
            // self.$refs[self.productId][1].$el.querySelector('input').focus()
            // self.$refs[self.productId][1].$el.querySelector('input').select()
          })
        } else {
          self.$Notice.error({
            desc: data.message
          })
          self.handleBaseDialog({visible: false, type: 'supplierDetailVisible'})
        }
        self.$Spin.hide()
      },
      // 获取详情
      async getProductDetail(flag) {
        console.log(this.supplierProduct)
        let self = this
        let params = {
          productId: self.supplierProduct.productId,
          supplierId: self.supplierProduct.supplierId,
          service: self.supplierProduct.service
        }
        if (flag) {
          self.$Spin.show()
        }
        let {data} = await api.getSupplierProductDetail(params)
        console.log(data)
        if (data.status == '0') {
          self.productInfo = data.data
          self.specTag = data.data.productId
          let qty = self.productInfo
          if (qty.orderQty == 0) {
            self.orderQty = null
          } else {
            self.orderQty = qty.orderQty * 1
          }
          self.imgUrls = data.data.imgUrls
          let img = self.imgUrls[0]
          console.log(self.imgUrls[0])
          console.log(self.bannerImg[0])
          self.bannerImg = img[0]
          self.bImg = self.bannerImg.replace('w_350', 'w_800').replace('h_350', 'h_800')
          self.videoUrl = data.data.videoUrl + '?' + new Date().getTime()
          self.store = data.data.collectionId != '0'
        } else {
          self.$Notice.error({
            desc: data.message
          })
          self.handleBaseDialog({visible: false, type: 'supplierBrandSeriesDetailVisible'})
        }
        self.$Spin.hide()
      },
      async getExtra() {
        let self = this
        let params = {
          productId: self.supplierProduct.productId
        }
        let {data} = await api.getProductAttachList(params)
        console.log(data)
        if (data.status == 0) {
          self.productAttachList = data.data.list
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      ok() {
        this.signVisible = false
        this.handleSign()
      },
      toSign() {
        this.signVisible = true
      },
      cancel() {
        this.signVisible = false
      },
      // 申请加盟
      async handleSign() {
        let self = this
        let params = {
          bizType: 2,
          brandId: self.productInfo.brandId
        }
        let {data} = await api.getSupplierBrandApply(params)
        console.log(data.data)
        if (data.status == 0) {
          self.$Notice.success({
            desc: data.message
          })
          self.productInfo.brandRestrictionStatus = 1
          // 通知 添加成功
          self.addProductSuccess(self.$route.path + '?' + new Date().getTime())
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 添加到购物车
      addCart() {
        let self = this
        let params = []
        self.selectProductInfo.forEach(e => {
          params.push({
            orderQty: e.orderQty,
            productId: e.productId,
            supplierId: e.supplierId
          })
        })
        if (!params.length) {
          self.$Notice.warning({
            desc: '订货数量不能为0！'
          })
          return null
        }
        this.addToSupplierSeriesCart({data: JSON.stringify(params)}).then(res => {
          console.log(res.data)
          let data = res.data
          if (data.status == 0) {
            self.$Notice.success({
              desc: '添加成功'
            })
            self.saveSupplierCartNum(data.data.totalQty)
            // 通知 添加成功
            self.addProductSuccess(self.$route.path + '?' + new Date().getTime())
          } else {
            let msg = data.message.replace(/\n\n/g, '</p></br><p>')
            msg = '<div style="max-height: 500px;overflow: auto"><p>' + msg + '</p></div>'
            self.$Modal.error({
              title: '温馨提示',
              content: msg,
              width: 600,
              onOk: () => {
              }
            })
          }
        })
      },
      // 下载附件
      loadExtra(row) {
        let url = api.getLoadExtra
        console.log(url)
        // return
        window.open(url + '?id=' + row.id + '&type=product')
      },
      // 跳转到店铺
      goStore(row) {
        this.handleBaseDialog({visible: false, type: 'cartDialogVisible'})
        this.handleBaseDialog({visible: false, type: 'orderDialogVisible'})
        this.handleBaseDialog({visible: false, type: 'supplierBrandDetailVisible'})
        this.handleBaseDialog({visible: false, type: 'supplierBrandSeriesDetailVisible'})
        this.handleBaseDialog({visible: false, type: 'supplierOrderDialogVisible'})
        if (this.productInfo.isService == '0') {
          this.$router.push({name: 'franchisestoreproduct',
          query: {serviceType: '0', id: this.productInfo.supplierId, tel: this.productInfo.supplierTelephone, name: this.productInfo.supplierName || this.productInfo.recommends[0].supplierName, areaProduct: this.supplierProduct.areaProduct}})
        } else if (this.productInfo.isService == '1') {
          this.$router.push({name: 'franchisestoreproduct',
          query: {serviceType: '1', id: this.productInfo.supplierId, tel: this.productInfo.supplierTelephone, name: this.productInfo.supplierName || this.productInfo.recommends[0].supplierTelephone, areaProduct: this.supplierProduct.areaProduct}})
        }
      },
      toDetail(row) {
        console.log(row)
        if (row.isService == 1) {
          row.service = '服务商'
        }
        this.saveSupplierProductInfo(row)
        this.saveSupplierProductSeriesInfo(row.productSetId)
        if (row.productSetId == '0') {
          this.handleBaseDialog({visible: false, type: 'supplierBrandSeriesDetailVisible'})
          this.handleBaseDialog({visible: true, type: 'supplierBrandDetailVisible'})
        } else {
          this.getProductDetail(true)
          this.getProductSeries()
          this.getExtra()
          this.handleBaseDialog({visible: true, type: 'supplierBrandSeriesDetailVisible'})
        }
      }
    }
  }
</script>

<style lang="less">
  @import "prodetail";

  .ivu-input-number-handler-wrap {
    display: none;
  }
  .p-select-total-other1{
      display: flex;
      align-items: center;
      font-size: 14px;
      color: #666666;
      display: flex;
      height: 40px;
      line-height: 40px;
      padding:0 10px;
      p{
        margin-right: 10px;
      }
      em{
        color: #E61E10;
      }
      .ios-arrow-up-type{
          transition: all 0.5s;
        &:hover{
          transform: rotate(180deg)
       }
      }
    }
    .p-select-total-other{
      padding: 0 20px!important;
    }
    .p-r-select-attribute-item-tip{
        // width:100%!important;
        position: absolute;
        top:-20px;
        right:0;
        display: flex;
        color:#999999;
        .p-store{
          em{
              color:#FF4C40!important;
          }
        }
    }
</style>
