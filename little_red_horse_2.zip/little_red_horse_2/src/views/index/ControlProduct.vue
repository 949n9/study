<template>
  <div class="control-product">
    <Carousel v-if="bannerList.length>1" autoplay :radius-dot="true" :loop="true">
      <CarouselItem v-for="(item,i) in bannerList" :key="i">
        <img :src="item.url" alt="" class="material-img" @click="handleJump(item)">
      </CarouselItem>
    </Carousel>
    <div class="material-wrap" v-else>
      <img v-if="bannerList.length==1" :src="bannerList[0].url" alt="" @click="handleJump(bannerList[0])"
           class="material-img">
    </div>

    <div class="control-wrap" ref="list">
      <Tabs v-model="tabName" type="card" @on-click="tabSelect">
        <TabPane :label="'全部（'+count4+'）'" name="4"></TabPane>
        <TabPane :label="'已加盟（'+count3+'）'" name="3"></TabPane>
        <TabPane :label="'审核中（'+count1+'）'" name="1"></TabPane>
        <TabPane :label="'已退回（'+count2+'）'" name="2"></TabPane>
        <TabPane :label="'可申请（'+count0+'）'" name="0"></TabPane>
      </Tabs>
      <div v-if="tabName=='0'">
        <div class="brand-header" v-if="supplierBandList.length">
          <img src="../../assets/images/home/le.png" alt="">
          <span class="brand-name">服务商品牌</span>
          <img src="../../assets/images/home/ri.png" alt="">
        </div>
        <template v-for="(item,index) in supplierBandList">
          <Row v-if="supplierBandList.length" :key="index" class="control-row" type="flex" justify="center">
            <Col>
              <ul class="brand-content">
                <li class="brand-item" @click="toDetail(item,2)">
                  <img :src="item.brandBannerUrl"
                       :title="item.brandName"
                       :alt="item.brandName"
                       :onerror="defaultCimg()" class="logo">
                </li>
              </ul>
            </Col>
          </Row>
        </template>
        <div class="brand-header" v-if="bandList.length">
          <img src="../../assets/images/home/le.png" alt="">
          <span class="brand-name">小红马商城品牌</span>
          <img src="../../assets/images/home/ri.png" alt="">
        </div>
        <template v-for="(item,index) in bandList">
          <Row v-if="bandList.length" :key="index" class="control-row" type="flex" justify="center">
            <Col>
              <ul class="brand-content">
                <li class="brand-item" @click="toDetail(item,1)">
                  <img :src="item.brandBannerUrl" :alt="item.brandName" :onerror="defaultCimg()" class="logo">
                </li>
              </ul>
            </Col>
          </Row>
        </template>
        <Row v-if="bandList.length==0&&supplierBandList.length==0">
          <Col span="24">
            <div class="search-result">
              <img src="../../assets/images/empty/search.png" alt="" class="search-img">
              <span class="search-info">抱歉，没有找到相关商品内容！</span>
            </div>
          </Col>
        </Row>
      </div>
      <Table :columns="columns" :data="tableData" height="500" border v-else-if="tabName=='1'">
        <template slot-scope="{ row }" slot="action">
          <Button type="text" size="small" class="del-btn" @click.native="search(row)">查看</Button>
        </template>
      </Table>
      <Table :columns="columns2" :data="tableData" height="500" border v-else-if="tabName=='3'">
        <template slot-scope="{ row }" slot="action">
          <Button type="text" size="small" class="del-btn" @click.native="search(row)">查看</Button>
        </template>
      </Table>
      <Table :columns="columns3" :data="tableData" height="500" border v-else-if="tabName=='2'">
        <template slot-scope="{ row }" slot="action">
          <Button type="text" size="small" class="del-btn" @click.native="search(row)">查看</Button>
        </template>
      </Table>
      <div class="control-all" v-else-if="tabName=='4'">
          <div class="control-all-item" v-for="(item, index) in brandAllList" :key="index">
             <div class="top-brand-dot">
               <img v-if="item.approveStatus==3" src="@/assets/images/coupon/control_2.png" alt="" srcset="">
               <img v-if="item.approveStatus==1" src="@/assets/images/coupon/control_1.png" alt="" srcset="">
               <img v-if="item.approveStatus==2" src="@/assets/images/coupon/control_3.png" alt="" srcset="">
             </div>
             <!-- <div class="control-all-item-top">
                <div class="top-brand-img"><img :src="item.brandLogoUrl" alt="" srcset=""></div>
                <p>{{item.brandName}}</p>
             </div> -->
             <div class="control-all-item-buttom" @click="searchAll(item)">
                 <!-- <div class="product-item">
                     <div class="product-item-img"><img src="" alt="" srcset=""></div>
                     <p class="product-item-name">惠氏金装1段</p>
                 </div>
                 <div class="product-item">
                     <div class="product-item-img"><img src="" alt="" srcset=""></div>
                     <p class="product-item-name">惠氏金装1段</p>
                 </div>
                 <div class="product-item">
                     <div class="product-item-img"><img src="" alt="" srcset=""></div>
                     <p class="product-item-name">惠氏金装1段</p>
                 </div> -->
                 <img :src="item.brandBannerUrl" :onerror="defaultCimg()" alt="" srcset="">
             </div>             
          </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'
  import * as opt from './components/options'

  export default {
    name: 'ControlProduct',
    components: {},
    data: () => ({
      tabName: '4',
      bannerList: [],
      bandList: [],
      brandAllList: [],
      count0: 0,
      count1: 0,
      count2: 0,
      count3: 0,
      count4: 0,      
      supplierBandList: [],
      columns: opt.controlColumns,
      columns2: opt.controlColumns2,
      columns3: opt.controlColumns3,
      tableData: []
    }),
    computed: {
      ...mapState([
        'loading'
      ]),
      ...mapGetters([])
    },
    created() {
      this.initData()
      this.getBanner()
    },
    methods: {
      ...mapActions([]),
      initData() {
        this.getBrandAll()
        this.getBrand2(1)
        this.getBrand2(2)
        this.getBrand2(3)
        this.getBrand()        
      },
      async getBanner() {
        let self = this
        let params = {
          displayPosition: 10
        }
        let {data} = await api.getBannerList(params)
        console.log(data)
        if (data.status == '0') {
          let arr = data.data.aterials
          self.bannerList = arr
        } else {
        }
      },
      // 处理跳转 1：相应的路由地址 2. 广告页面
      handleJump(item) {
        // this.handleADJump(item)
        this.$router.push({name: 'controlareaproduct'})
      },
      async getBrand() {
        let self = this
        let params = {pageSize: 9999}
        let {data} = await api.getSupplierBrand(params)
        console.log(data.data.supplierBrandInfo)

        if (data.status == 0) {
          self.bandList = data.data.brandInfo.list.data
          self.supplierBandList = data.data.supplierBrandInfo.list.data
          self.count0 = 1 * self.bandList.length + 1 * self.supplierBandList.length
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      async getBrand2(status) {
        let self = this
        let params = {
          status: status,
          pageSize: 9999
        }
        let {data} = await api.getSupplierBrandOther(params)
        console.log(data)
        if (data.status == 0) {
          self.tableData = data.data.list
          if (status == '1') self.count1 = data.data.dataCount
          if (status == '2') self.count2 = data.data.dataCount
          if (status == '3') self.count3 = data.data.dataCount
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      async getBrandAll(status) {
        let self = this
        let params = {
          status: status,
          pageSize: 9999
        }
        let {data} = await api.getSupplierBrandAll(params)
        console.log(data)
        if (data.status == 0) {
          self.brandAllList = data.data.list
          self.count4 = data.data.list.length
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      // 切换tab选择时候
      tabSelect(name) {
        if (name == '4') {
          this.getBrandAll()
        } else if (name == '0') {
          this.getBrand()
        } else {
          this.getBrand2(name)
        }
      },
      // 查看
      search(row) {
        console.log(row)
        let id = row.brandId
        this.$router.push({path: '/index/supplierbranddetail', query: {id: id, bizType: row.bizType}})
      },
      searchAll(row) {
        console.log(row)
        let id = row.brandId
        let bizType = row.supplierId === '0' ? '1' : '2'
        this.$router.push({path: '/index/supplierbranddetail', query: {id: id, bizType: bizType}})
      },
      toDetail(row, bizType) {
        console.log(row)
        let id = row.brandId
        this.$router.push({path: '/index/supplierbranddetail', query: {id: id, bizType: bizType}})
      }
    }
  }
</script>

<style lang="less">

  .control-product {
    background-color: #F5F5F5;

    .control-wrap {
      margin: 20px auto;
      width: 1200px;
      background-color: #ffffff;
      padding: 20px 10px;

      .brand-header {
        text-align: center;
        display: flex;
        justify-content: center;
        align-items: center;

        .brand-name {
          font-size: 20px;
          padding: 0 15px;
        }
      }
    }

    .control-row {
      padding: 10px 0;

      .brand-content {
        margin-top: 10px;
        display: flex;
        padding: 10px;

        .brand-item {
          cursor: pointer;

          .logo {
          }
        }
      }
    }

    .del-btn:hover {
      background-color: #ebf7ff;
    }
    .control-all{
       background: #ffffff;
       width: 100%;
       .control-all-item{
          padding: 10px 0;
          margin: 0 auto 10px;
          position: relative;
          background: #E2E8FF;
          padding: 0 200px;
          overflow: hidden;
          height: auto;
          .control-all-item-top{
             display: flex;
             margin-top: 20px;
             .top-brand-img{
                width: 130px;
                height: 70px;
                background: #fefefe;
                border-radius: 5px;
                overflow: hidden;
                img{
                  width: 100%;
                  height: 100%;
                }
             }
             p{
               color: #000;
               font-size: 16px;
               padding:0 0 0 10px;
             }
          }
          .control-all-item-buttom{
            height: auto;
            margin: 20px auto 20px;
            background: #ffffff;
            padding:12px 15px;
            display: flex;
            flex-wrap: wrap;
            border-radius: 5px;
            cursor: pointer;
            .product-item{
              margin:5px;
              background: #F7F7F7;
              width:calc(100% / 3 - 10px);
              border-radius: 5px;
              overflow: hidden;
              .product-item-img{
                 width:100%;
                 height: 80%;
              }
              .product-item-name{
                 display: flex;
                 align-items: center;
                 justify-content: center;
                 height: 20%;
                 color: #ffffff;
                 text-align: center;
                 background: #FA4741;
                 font-size: 18px;
                 padding:0 15px;
              }
            }
            img{
                margin: 0 auto;
                height: 450px;
            }
          }
          .top-brand-dot{
            position: absolute;
            top:0;
            right:0px;
            // background: #ffffff;
            width: 132px;
            height: 132px;
          }
       }
    }
  }
</style>
