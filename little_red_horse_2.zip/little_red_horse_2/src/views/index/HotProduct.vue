<template>
  <div class="recent-product">
    <Carousel v-if="bannerList.length>1" autoplay :radius-dot="true" :loop="true">
      <CarouselItem v-for="(item,i) in bannerList" :key="i">
        <img :src="item.url" alt="" class="material-img" @click="handleJump(item)">
      </CarouselItem>
    </Carousel>
    <div class="material-wrap" v-else>
      <img v-if="bannerList.length==1" :src="bannerList[0].url" alt="" @click="handleJump(bannerList[0])"
           class="material-img">
    </div>

    <div>
      <selector-header @selectChange="handleSelectChange"></selector-header>
    </div>
    <div>
      <sort-type @display="handleDisplay" @sort="handleSort"></sort-type>
    </div>

    <div class="recent-wrap" ref="list">
      <Row v-if="hotProductData.list&&hotProductData.list.length">
        <template v-for="(item,index) in hotProductData.list">
          <Col span="4" :key="item.id" class="grid-wrap" v-show="displyType=='grid'">
            <Card :key="index" class="p-wrap grid-wrap-hot" style="height: 342px" @click.native="toDetail(item)">
              <div class="p-wrap-grid" @click="toDetail(item)">
                <img :src="item.imgUrl" :alt="item.productName" :onerror="defaultPimg()" class="p-wrap-grid-img">
              </div>
              <h4 class="p-wrap-name" @click="toDetail(item)" :title="item.productName">
                <img src="@/assets/images/detail/icon_shangcheng.png" alt="" srcset="" v-if="item.serviceType==2">
                <img src="@/assets/images/detail/icon_service.png" alt="" srcset="" v-if="item.serviceType==1">
                <img src="@/assets/images/detail/icon_shangjia.png" alt="" srcset="" v-if="item.serviceType==0">
                {{item.productName}}
              </h4>
              <p class="p-wrap-areaProduct-flag" v-if="item.areaProduct==1">控区控价</p>
              <p v-if="item.areaProduct==0" style="height:18px;margin:5px 0;"></p>
              <!-- <Badge :text="'物流费减免：'+item.deliveryFeeReduceRate+'%'" class-name="p-wrap-badge" v-if="item.areaProduct==0">
              </Badge> -->
              <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                库存：{{item.dcDistQty}}
              </p>
              <p class="p-wrap-time" v-else>
                <span v-if="item.dcDistQty>0&&item.dcDistQty<item.warnDistQty" class="warn--text">库存紧张</span>
                <span v-else-if="item.dcDistQty<=0" class="red--text">暂时无货</span>
                <span v-else>库存充足</span>
              </p>
                <div v-if="item.areaProduct==0">
                    <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice!=item.minPeriodPrice">
                        <span style="font-size:12px;">￥</span>{{item.minPeriodPrice}} -
                        <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                      </p>
                      <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice==item.minPeriodPrice">
                        <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                      </p>
                      <p class="p-wrap-price" v-if="item.productType!=2">
                        <span style="font-size:12px;">￥</span>{{item.taxPrice}}
                      </p>
                </div>
                <div v-if="item.areaProduct==1" style="margin:10px 0;color:#E61E10;">
                    <span class="p-wrap-hide" v-if="item.approveStatus==0">加盟看价格</span>
                    <span class="p-wrap-hide" v-if="item.approveStatus==1">审核中</span>
                    <span class="p-wrap-hide" v-if="item.approveStatus==2">已退回</span>                  
                </div>
                <div class="clearfix" v-if="item.areaProduct==0">
                  <Button type="primary" long v-if="item.taxPrice*1>0" @click="toDetail(item)">订货
                    <em v-show="item.orderQty>0">({{item.orderQty}})</em>
                  </Button>
                </div>
                <div class="p-wrap-areaProduct" v-if="item.areaProduct==1">
                    <Button type="primary" class="button-primary" v-if="item.approveStatus==0">申请加盟</Button>
                    <Button class="disable-btn button-primary" v-if="item.approveStatus==1">审核中</Button>
                    <Button class="disable-btn button-primary" v-if="item.approveStatus==2">已退回</Button>
                </div>
            </Card>
          </Col>

          <Col span="24" :key="index" class="list-wrap" v-show="displyType=='list'">
            <Card :key="index" class="p-wrap" @click.native="toDetail(item)">
              <div class="list-wrap-h">
                <div @click="toDetail(item)">
                  <img :src="item.imgUrl" :onerror="defaultPimg()" class="p-wrap-list-img">
                </div>

                <div class="list-wrap-product">
                  <h4 class="p-wrap-name" @click="toDetail(item)" :title="item.productName">
                    <img src="@/assets/images/detail/icon_shangcheng.png" alt="" srcset="" v-if="item.serviceType==2">
                    <img src="@/assets/images/detail/icon_service.png" alt="" srcset="" v-if="item.serviceType==1">
                    <img src="@/assets/images/detail/icon_shangjia.png" alt="" srcset="" v-if="item.serviceType==0">
                    {{item.productName}}
                  </h4>
                  <p class="p-wrap-areaProduct-flag" v-if="item.areaProduct==1">控区控价</p>
                  <p class="p-wrap-time" v-if="item.areaProduct==0" style="height:18px;margin:5px 0;"></p>
                  <!-- <Badge :text="'物流费减免：'+item.deliveryFeeReduceRate+'%'" class-name="p-wrap-badge" v-if="item.areaProduct==0">
                  </Badge> -->
                  <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                    库存：{{item.dcDistQty}}
                  </p>
                  <p class="p-wrap-time" v-else>
                    <span v-if="item.dcDistQty>0&&item.dcDistQty<item.warnDistQty" class="warn--text">库存紧张</span>
                    <span v-else-if="item.dcDistQty<=0" class="red--text">暂时无货</span>
                    <span v-else>库存充足</span>
                  </p>
                  <div class="p-wrap-line" v-if="item.areaProduct==0">
                      <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice!=item.minPeriodPrice">
                        <span style="font-size:12px;">￥</span>{{item.minPeriodPrice}} -
                        <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                      </p>
                      <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice==item.minPeriodPrice">
                        <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                      </p>
                      <p class="p-wrap-price" v-if="item.productType!=2">
                        <span style="font-size:12px;">￥</span>{{item.taxPrice}}
                      </p>
                  </div>
                  <div v-if="item.areaProduct==1" style="margin:10px 0;color:#E61E10;">
                      <span class="p-wrap-hide" v-if="item.approveStatus==0">加盟看价格</span>
                      <span class="p-wrap-hide" v-if="item.approveStatus==1">审核中</span>
                      <span class="p-wrap-hide" v-if="item.approveStatus==2">已退回</span>
                  </div>
                  <div class="p-wrap-line" @click="toDetail(item)" v-if="item.areaProduct==0">
                    <Button type="primary" v-if="item.taxPrice*1>0" class="order-btn">订货
                      <em v-show="item.orderQty>0">({{item.orderQty}})</em>
                    </Button>
                  </div>
                  <div class="p-wrap-areaProduct-left" v-if="item.areaProduct==1" style="margin-top: 10px;">
                    <Button type="primary" v-if="item.approveStatus==0">申请加盟</Button>
                    <Button class="disable-btn" v-if="item.approveStatus==1">审核中</Button>
                    <Button class="disable-btn" v-if="item.approveStatus==2">已退回</Button>
                  </div>
                </div>
              </div>
            </Card>
          </Col>
        </template>
      </Row>

      <Row v-else>
        <Col span="24">
          <div class="search-result">
            <img src="../../assets/images/empty/search.png" alt="" class="search-img">
            <span class="search-info">抱歉，没有找到相关商品内容！</span>
          </div>
        </Col>
      </Row>

      <product-page :pageInfo="hotProductData" @pageChange="handlePageChange"
                    @pageSizeChange="handlePageSizeChange">
      </product-page>

    </div>
  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'
  import SelectorHeader from '../../common/Selector-Header'
  import SortType from '../../common/Sort-Type'
  import ProductPage from '../../common/Product-Page'

  export default {
    name: 'HotProduct',
    components: {
      SortType,
      SelectorHeader,
      ProductPage
    },
    data: () => ({
      code: '',
      bannerList: [],
      newPorudctList: [],
      orderCondition: '',
      orderConditionType: 'desc',
      productCategoryCode: '',
      productBrandId: '',
      productPropertyId: '',
      store: false,
      displyType: 'grid',

      pageIndex: 1,
      pageSize: 50
    }),
    computed: {
      ...mapState([
        'addSuccess',
        'loading'
      ]),
      ...mapGetters([
        'hotProductData',
        'userData'
      ])
    },
    created() {
      this.saveSearchInfo({})
      this.saveSelectInfo({})
      this.initData()
      this.getBanner()
    },
    watch: {
      'addSuccess': 'handleAddSuccess'
    },
    methods: {
      ...mapActions([
        'getHotData',
        'saveProductInfo',
        'saveProductSeriesInfo',
        'saveProductDateInfo',
        'saveSupplierProductSeriesInfo',
        'saveSupplierProductInfo',
        'handleBaseDialog',
        'saveSearchInfo',
        'saveSelectInfo'
      ]),
      handleAddSuccess(v) {
        console.log(v)
        let path = v.split('?')[0]
        if (path == this.$route.path) {
          this.initData()
        }
      },
      initData() {
        this.getHotData({
          pageIndex: this.pageIndex,
          pageSize: this.pageSize,
          orderCondition: this.orderCondition,
          orderConditionType: this.orderConditionType,
          productCategoryCode: this.productCategoryCode,
          productBrandId: this.productBrandId,
          productPropertyId: this.productPropertyId
        })
      },
      async getBanner() {
        let self = this
        let params = {
          displayPosition: 11
        }
        let {data} = await api.getBannerList(params)
        console.log(data)
        if (data.status == '0') {
          let arr = data.data.aterials
          self.bannerList = arr
        } else {
        }
      },
      // 处理跳转 1：相应的路由地址 2. 广告页面
      handleJump(item) {
        this.handleADJump(item)
      },
      handleSelectChange(v) {
        this.pageIndex = 1
        this.productCategoryCode = v.productCategoryCode
        this.productBrandId = v.productBrandId
        this.productPropertyId = v.productPropertyId
        this.initData()
      },
      handlePageChange(v) {
        window.scrollTo(0, 500)
        this.pageIndex = v.pageIndex
        this.initData()
      },
      handlePageSizeChange(v) {
        window.scrollTo(0, 500)
        this.pageSize = v.pageSize
        this.initData()
      },
      handleDisplay(v) {
        this.displyType = v
      },
      handleSort(v) {
        this.pageIndex = 1
        this.orderCondition = v.orderCondition
        this.orderConditionType = v.orderConditionType
        this.initData()
      },
      toDetail(row) {
        console.log(row)
        this.toProductDetail(row)
      }
    }
  }
</script>

<style lang="less">

  .recent-product {
    background-color: #F5F5F5;
    overflow-x: hidden;

    .recent-wrap {
      margin: 20px auto;
      width: 1200px;
      background-color: #ffffff;
      padding: 20px 10px;

      .ivu-card-body:hover {
        border: 1px solid red;
        border-radius: 4px;
      }
    }
    // .p-wrap-hide{
    //   margin:5px 0;
    //   color:#E61E10;
    //   display:flex;
    //   align-items: center;
    //   justify-content: space-between;
    // }
  }
</style>
