<template>
  <div class="recent-product fw-product">
    <Carousel v-if="bannerList.length>1" autoplay :radius-dot="true" :loop="true">
      <CarouselItem v-for="(item,i) in bannerList" :key="i">
        <img :src="item.url" alt="" class="material-img" @click="handleJump(item)">
      </CarouselItem>
    </Carousel>
    <div class="material-wrap" v-else>
      <img v-if="bannerList.length==1" :src="bannerList[0].url" alt="" @click="handleJump(bannerList[0])"
           class="material-img">
    </div>

    <div>
      <selector-header @selectChange="handleSelectChange"></selector-header>
    </div>
    <div>
      <sort-type @display="handleDisplay" @sort="handleSort"></sort-type>
    </div>

    <div class="recent-wrap" ref="list">
      <Row v-if="fwProductData.list&&fwProductData.list.length">
        <template v-for="(item,index) in fwProductData.list">
          <Col span="4" :key="item.id" class="grid-wrap" v-show="displyType=='grid'">
            <Card :key="index" class="p-wrap grid-wrap-fw" @click.native="toDetail(item)">
              <div class="p-wrap-grid" @click="toDetail(item)">
                <img :src="item.imgUrl" :alt="item.productName" :onerror="defaultPimg()" class="p-wrap-grid-img">
              </div>
              <h4 class="p-wrap-name" @click="toDetail(item)" :title="item.productName">{{item.productName}}</h4>
              <p class="p-wrap-time">上架时间：{{item.firstImpTime|cutTime}}</p>
              <div class="p-wrap-from-servies">
                  <img src="../../assets/images/detail/icon_fuwushang.png" alt="" srcset="">
                  <span @click.stop="goStore(item)">{{item.supplierName}}</span>
              </div>
              <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                库存：{{item.dcDistQty}}
              </p>
              <p class="p-wrap-time" v-else>
                <span v-if="item.dcDistQty>0&&item.dcDistQty<item.warnDistQty" class="warn--text">库存紧张</span>
                <span v-else-if="item.dcDistQty<=0" class="red--text">暂时无货</span>
                <span v-else>库存充足</span>
              </p>
              <div class="p-wrap-line">
                <div>
                  <span class="p-wrap-time red--text">¥</span>
                  <span class="p-wrap-price">{{item.taxPrice}}</span>
                </div>
                <Button type="primary" v-if="item.taxPrice*1>0" class="order-btn" @click="toDetail(item)">订货
                  <em v-show="item.orderQty>0">({{item.orderQty}})</em>
                </Button>
              </div>
            </Card>
          </Col>

          <Col span="24" :key="index" class="list-wrap" v-show="displyType=='list'" style="height:240px;">
            <Card :key="index" class="p-wrap" @click.native="toDetail(item)">
              <div class="list-wrap-h">
                <div @click="toDetail(item)">
                  <img :src="item.imgUrl" :onerror="defaultPimg()" class="p-wrap-list-img">
                </div>

                <div class="list-wrap-product">
                  <h4 class="p-wrap-name" @click="toDetail(item)" :title="item.productName">{{item.productName}}</h4>
                  <p class="p-wrap-time">上架时间：{{item.firstImpTime|cutTime}}</p>
                  <div class="p-wrap-from-servies">
                      <img src="../../assets/images/detail/icon_fuwushang.png" alt="" srcset="">
                      <span @click.stop="goStore(item)">{{item.supplierName}}</span>
                  </div>
                  <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                    库存：{{item.dcDistQty}}
                  </p>
                  <p class="p-wrap-time" v-else>
                    <span v-if="item.dcDistQty>0&&item.dcDistQty<item.warnDistQty" class="warn--text">库存紧张</span>
                    <span v-else-if="item.dcDistQty<=0" class="red--text">暂时无货</span>
                    <span v-else>库存充足</span>
                  </p>
                  <div class="p-wrap-line">
                    <div>
                      <span class="p-wrap-time red--text">¥</span>
                      <span class="p-wrap-price">{{item.taxPrice}}</span>
                    </div>
                  </div>
                  <div class="p-wrap-line">
                    <Button type="primary" v-if="item.taxPrice*1>0" class="order-btn" @click="toDetail(item)">订货
                      <em v-show="item.orderQty>0">({{item.orderQty}})</em>
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </Col>
        </template>
      </Row>

      <Row v-else>
        <Col span="24">
          <div class="search-result">
            <img src="../../assets/images/empty/search.png" alt="" class="search-img">
            <span class="search-info">抱歉，没有找到相关商品内容！</span>
          </div>
        </Col>
      </Row>

      <product-page :pageInfo="fwProductData" @pageChange="handlePageChange"
                    @pageSizeChange="handlePageSizeChange">
      </product-page>

    </div>
  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'
  import SelectorHeader from '../../common/Selector-Header'
  import SortType from '../../common/Sort-Type'
  import ProductPage from '../../common/Product-Page'

  export default {
    name: 'FwProduct',
    components: {
      SortType,
      SelectorHeader,
      ProductPage
    },
    data: () => ({
      code: '',
      bannerList: [],
      newPorudctList: [],
      orderCondition: '',
      orderConditionType: 'desc',
      productCategoryCode: '',
      productBrandId: '',
      productPropertyId: '',
      store: false,
      displyType: 'grid',

      pageIndex: 1,
      pageSize: 50
    }),
    computed: {
      ...mapState([
        'searchInfo',
        'addSuccess',
        'loading'
      ]),
      ...mapGetters([
        'fwProductData',
        'userData'
      ])
    },
    watch: {
      'searchInfo': 'handleSearch',
      'addSuccess': 'handleAddSuccess'
    },
    created() {
      if (Object.keys(this.searchInfo).length && this.searchInfo.type == 'own') {
        this.saveSearchInfo({})
      }
      console.log(this.searchInfo)

      this.saveSelectInfo({})
      this.initData()
      this.getBanner()
    },
    methods: {
      ...mapActions([
        'getFwData',
        'saveSupplierProductInfo',
        'saveSupplierProductSeriesInfo',
        'handleBaseDialog',
        'saveSearchInfo',
        'saveSelectInfo'
      ]),
      handleAddSuccess(v) {
        console.log(v)
        let path = v.split('?')[0]
        if (path == this.$route.path) {
          this.initData()
        }
      },
      handleSearch(v) {
        console.log(v)
        if (Object.keys(this.searchInfo).length && this.searchInfo.type == 'fw') {
          this.initData()
        }
      },
      initData() {
        this.getFwData({
          pageIndex: this.pageIndex,
          pageSize: this.pageSize,
          productCondition: this.searchInfo.id,
          orderCondition: this.orderCondition,
          orderConditionType: this.orderConditionType,
          productCategoryCode: this.productCategoryCode,
          productBrandId: this.productBrandId,
          productPropertyId: this.productPropertyId,
          service: '服务商'
        })
      },
      async getBanner() {
        let self = this
        let params = {
          displayPosition: 9
        }
        let {data} = await api.getBannerList(params)
        console.log(data)
        if (data.status == '0') {
          let arr = data.data.aterials
          self.bannerList = arr
        } else {
        }
      },
      // 处理跳转 1：相应的路由地址 2. 广告页面
      handleJump(item) {
        this.handleADJump(item)
      },
      handleSelectChange(v) {
        this.pageIndex = 1
        this.productCategoryCode = v.productCategoryCode
        this.productBrandId = v.productBrandId
        this.productPropertyId = v.productPropertyId
        this.initData()
      },
      handlePageChange(v) {
        window.scrollTo(0, 500)
        // let path = this.$route.path
        // if (v.route == path) {
        this.pageIndex = v.pageIndex
        this.initData()
        // }
      },
      handlePageSizeChange(v) {
        window.scrollTo(0, 500)
        let path = this.$route.path
        if (v.route == path) {
          this.pageSize = v.pageSize
          this.initData()
        }
      },
      handleDisplay(v) {
        this.displyType = v
      },
      handleSort(v) {
        this.pageIndex = 1
        this.orderCondition = v.orderCondition
        this.orderConditionType = v.orderConditionType
        this.initData()
      },
      goStore(row) {
        this.$router.push({name: 'franchisestoreproduct',
        query: {serviceType: '1', id: row.supplierId, tel: row.supplierTelephone, name: row.supplierName}})
      },
      toDetail(row) {
        row.service = '服务商'
        this.saveSupplierProductInfo(row)
        this.saveSupplierProductSeriesInfo(row.productSetId)
        if (row.productSetId == '0') {
          this.handleBaseDialog({visible: true, type: 'supplierDetailVisible'})
        } else {
          this.handleBaseDialog({visible: true, type: 'supplierSeriesDetailVisible'})
        }
      }
    }
  }
</script>

<style lang="less">

  .recent-product {
    background-color: #F5F5F5;
    overflow-x: hidden;

    .recent-wrap {
      margin: 20px auto;
      width: 1200px;
      background-color: #ffffff;
      padding: 20px 10px;

      .ivu-card-body:hover {
        border: 1px solid red;
        border-radius: 4px;
      }
    }
  }
  .grid-wrap-fw{
    height: 344px!important;
    .ivu-card-body{
      height: 100%;
    }
  }
</style>
