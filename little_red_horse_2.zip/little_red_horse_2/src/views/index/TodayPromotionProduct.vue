<template>
  <div class="recent-product">

    <Carousel v-if="bannerList.length>1" autoplay :radius-dot="true" :loop="true">
      <CarouselItem v-for="(item,i) in bannerList" :key="i">
        <img :src="item.url" alt="" class="recent-img" @click="handleJump(item)">
      </CarouselItem>
    </Carousel>
    <div class="material-wrap">
      <img v-if="bannerList.length==1" :src="bannerList[0].url" alt="" @click="handleJump(bannerList[0])"
           class="material-img">
    </div>

    <div class="recent-wrap" ref="list">
      <Row>
        <Col>
          <div class="flashSale_wrap">
            <div class="flashSale_wrap" v-if="status==2">
              <span class="buy_time">距离本场结束：</span>
              <div class="buy_wrap" v-if="downTime.d">
                <span class="buy_text">{{downTime.d}} </span>
              </div>
              <span class="buy_day" v-if="downTime.d">天</span>
              <div class="buy_wrap">
                <span class="buy_text">{{downTime.h}}</span>
              </div>
              <span class="buy_m">:</span>
              <div class="buy_wrap">
                <span class="buy_text">{{downTime.m}}</span>
              </div>
              <span class="buy_m">:</span>
              <div class="buy_wrap">
                <span class="buy_text">{{downTime.s}}</span>
              </div>
            </div>

            <div class="flashSale_wrap" v-if="status=='0'">
              <span class="before_sale" style="background-color: #19be6b">{{showTime}} 开抢</span>
            </div>
            <div class="flashSale_wrap" v-if="status=='3'">
              <span class="before_sale" style="background-color: #999999">活动已结束</span>
            </div>

          </div>
        </Col>
      </Row>
      <Row v-if="productList.length">
        <template v-for="(item,index) in productList">
          <Col span="4" :key="item.id" class="grid-wrap">
            <Card :key="index" class="p-wrap grid-wrap-fw" @click.native="toDetail(item)" style="height:322px;">
              <div class="p-wrap-grid" @click="toDetail(item)">
                <img :src="item.imgUrl" :alt="item.productName" :onerror="defaultPimg()" class="p-wrap-grid-img">
              </div>
              <h4 class="p-wrap-name" @click="toDetail(item)" :title="item.productName">{{item.productName}}</h4>
              <!-- <Badge :text="'物流费减免：'+item.deliveryFeeReduceRate+'%'" class-name="p-wrap-badge">
              </Badge> -->
              <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                库存：{{item.dcDistQty}}
              </p>
              <p class="p-wrap-time" v-else>
                <span v-if="item.dcDistQty>0&&item.dcDistQty<item.warnDistQty" class="warn--text">库存紧张</span>
                <span v-else-if="item.dcDistQty<=0" class="red--text">暂时无货</span>
                <span v-else>库存充足</span>
              </p>
              <div class="p-wrap-line">
                <div>
                  <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice!=item.minPeriodPrice">
                    <span style="font-size:12px;">￥</span>{{item.minPeriodPrice}} -
                    <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                  </p>
                  <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice==item.minPeriodPrice">
                      <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                  </p>
                  <p class="p-wrap-price" v-if="item.productType!=2">
                      <span style="font-size:12px;">￥</span>{{item.taxPrice}}
                  </p>
                </div>
              </div>
              <div class="clearfix">
                  <Button type="success" long @click="toDetail(item)" v-if="status=='0'">即将开始
                  </Button>
                  <Button type="primary" long @click="toDetail(item)" v-else>订货
                    <em v-show="item.orderQty>0">({{item.orderQty}})</em>
                  </Button>
              </div>
            </Card>
          </Col>
        </template>
      </Row>

      <Row v-if="productList.length==0 && !loading">
        <Col span="24">
          <div class="search-result">
            <!--<img src="../../assets/images/empty/search.png" alt="" class="search-img">-->
            <!--<span class="search-info">抱歉，没有找到相关商品内容！</span>-->
          </div>
        </Col>
      </Row>

    </div>
  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'

  export default {
    name: 'TodayPromotionProduct',
    components: {
    },
    data: () => ({
      bannerList: [],
      productList: [],
      flashSaleId: '',
      pageIndex: 1,
      pageSize: 50,
      currentTime: '',
      startTime: '',
      endTime: '',
      showTime: '',
      downTime: {
        d: null,
        h: '00',
        m: '00',
        s: '00'
      },
      beforeInterval: null,
      interval: null,
      status: null
    }),
    computed: {
      ...mapState([
        'addSuccess',
        'loading'
      ]),
      ...mapGetters([
        'fwProductData',
        'userData'
      ])
    },
    watch: {
      'addSuccess': 'handleAddSuccess'
    },
    beforeDestroy() {
      clearInterval(this.interval)
    },
    created() {
      this.flashSaleId = this.$route.query.id
      this.saveSearchInfo({})
      this.saveSelectInfo({})
      this.initData()
      this.getBanner()
    },
    methods: {
      ...mapActions([
        'getFwData',
        'saveProductInfo',
        'saveProductSeriesInfo',
        'saveProductDateInfo',
        'handleBaseDialog',
        'saveSearchInfo',
        'saveSelectInfo'
      ]),
      handleAddSuccess(v) {
        console.log(v)
        let path = v.split('?')[0]
        if (path == this.$route.path) {
          this.initData()
        }
      },
      initData() {
        this.getData()
        this.getTime()
      },
      // 获取当前时间
      async getTime() {
        let self = this
        let {data} = await api.getCurrentTime()
        console.log(data)
        if (data.status == 0) {
          console.log(data)
          self.currentTime = data.data.currentTime
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      handleTime() {
        let self = this
        let a = this.$moment(this.startTime)
        let b = this.$moment(this.currentTime)
        console.log(a.diff(b, 'days'))

        let beforeTime = this.$moment(this.startTime).diff(this.$moment())
        let time = this.$moment(this.endTime).diff(this.$moment())
        console.log(time)

        // 未开始
        if (this.status == '0') {
          if (a.diff(b, 'days') >= 1) {
            this.showTime = this.startTime
          } else {
            this.showTime = this.startTime.substring(10)
          }
          self.beforeInterval = setInterval(function () {
            beforeTime -= 1000
            if (beforeTime < 0) {
              clearInterval(self.beforeInterval) // 判断是否到期,到期后自动删除定时器
              self.status = '2'
            }
          }, 1000)
        }

        self.interval = setInterval(function () {
          let t = null
          let d = null
          let h = null
          let m = null
          let s = null
          // js默认时间戳为毫秒,需要转化成秒
          t = time / 1000
          d = Math.floor(t / (24 * 3600))
          h = Math.floor((t - 24 * 3600 * d) / 3600)
          m = Math.floor((t - 24 * 3600 * d - h * 3600) / 60)
          s = Math.floor((t - 24 * 3600 * d - h * 3600 - m * 60))
          // 这里可以做一个格式化的处理,甚至做毫秒级的页面渲染,基于DOM操作,太多个倒计时一起会导致页面性能下降
          let result = d + '天' + h + '小时' + m + '分钟' + s + '秒'
          console.log(result)

          if (h < 10) {
            h = '0' + h
          }
          if (s < 10) {
            s = '0' + s
          }
          if (m < 10) {
            m = '0' + m
          }

          self.downTime = {
            s: s,
            d: d,
            h: h,
            m: m
          }

          time -= 1000
          if (time < 0) {
            clearInterval(self.interval) // 判断是否到期,到期后自动删除定时器
            self.interval = null
            self.status = '3'
          }
        }, 1000)
      },

      // 获取商品列表
      async getData() {
        let self = this
        let params = {
          pageIndex: this.pageIndex,
          pageSize: '99999999',
          flashSaleId: self.flashSaleId
        }
        let {data} = await api.getFlashSaleProduct(params)
        console.log(data)
        if (data.status == '0') {
          self.productList = data.data.flashSaleProduct
          self.startTime = data.data.startTime
          self.endTime = data.data.endTime
          self.status = data.data.status
          self.handleTime()
        } else {
        }
      },
      async getBanner() {
        let self = this
        let params = {
          displayPosition: 3
        }
        let {data} = await api.getBannerList(params)
        console.log(data)
        if (data.status == '0') {
          let arr = data.data.aterials
          self.bannerList = arr
        } else {
        }
      },
      // 处理跳转 1：相应的路由地址 2. 广告页面
      handleJump(item) {
        this.handleADJump(item)
      },
      toDetail(row) {
        this.toProductDetail(row)
      }
    }
  }
</script>

<style lang="less">

  .recent-product {
    background-color: #F5F5F5;
    overflow-x: hidden;

    .recent-wrap {
      margin: 20px auto;
      width: 1200px;
      background-color: #ffffff;
      padding: 20px 10px;

      .ivu-card-body:hover {
        border: 1px solid red;
        border-radius: 4px;
      }

      .flashSale_wrap {
        display: flex;
        height: 40px;
        line-height: 40px;

        .before_sale {
          display: inline-block;
          margin-left: 30px;
          margin-top: 10px;
          height: 30px;
          line-height: 30px;
          background-color: #E61E10;
          border-radius: 10px;
          padding: 0 10px;
          color: #ffffff;
          font-size: 16px;
          font-weight: 600;
        }

        .buy_img {
          height: 40px;
          width: 172px;
        }

        .buy_time {
          margin-left: 20px;
          margin-top: 5px;
          font-size: 22px;
          font-weight: 600;
          color: #4A4A4A;
        }

        .buy_day {
          display: inline-block;
          width: 30px;
          height: 40px;
          text-align: center;
          line-height: 40px;
          font-weight: bold;
          font-size: 16px;
        }

        .buy_wrap {
          position: relative;
          width: 40px;
          height: 40px;
          text-align: center;
          background-color: #2f3430;
          border-radius: 5px;

          .buy_text {
            position: relative;
            display: inline-block;
            line-height: 40px;
            width: 40px;
            font-weight: bold;
            font-size: 20px;
            color: #ffffff;
          }
        }

        .buy_m {
          display: inline-block;
          line-height: 40px;
          font-size: 20px;
          font-weight: 700;
          margin: 0 3px;
        }
      }
    }
  }
</style>
