<template>
  <div class="recent-product">
    <!-- <Carousel v-if="bannerList.length>1" autoplay :radius-dot="true" :loop="true">
      <CarouselItem v-for="(item,i) in bannerList" :key="i">
        <img :src="item.url" alt="" class="material-img" @click="handleJump(item)">
      </CarouselItem>
    </Carousel>
    <div class="material-wrap" v-else>
      <img v-if="bannerList.length==1" :src="bannerList[0].url" alt="" @click="handleJump(bannerList[0])"
           class="material-img">
    </div> -->
    <div class="ranchise-store-info" :class="{'ranchise-store-info-servies': serviceType=='1'}">
      <div class="ranchise-store-info-con" :class="{'ranchise-store-info-con-servies': serviceType=='1'}">
          <div class="ranchise-store-info-left">
              <img src="../../assets/images/detail/ranchise_store_icon.png" alt="">
          </div>
          <div class="ranchise-store-info-right">
              <p>
                  <span>{{supplierName}}</span>
                  <em v-show="serviceType=='1'">服务商</em>
              </p>
              <p>
                  <img src="../../assets/images/detail/ranchise_tore_phone_icon.png" alt="">
                  <span>客服热线：{{supplierTel}}</span>
              </p>
       </div>
      </div>
    </div>
    <div>
      <selector-header @selectChange="handleSelectChange"></selector-header>
    </div>
    <div>
      <sort-type @display="handleDisplay" @sort="handleSort"></sort-type>
    </div>

    <div class="recent-wrap" ref="list">
      <Row v-if="serviceType==0?(supplierProductData.list&&supplierProductData.list.length):(fwProductData.list&&fwProductData.list.length)">
        <template v-for="(item,index) in serviceType==0?supplierProductData.list:fwProductData.list">
          <Col span="4" :key="item.id" class="grid-wrap" v-show="displyType=='grid'">
            <Card :key="index" class="p-wrap grid-wrap-franchise" @click.native="toDetail(item)">
              <div class="p-wrap-grid" @click="toDetail(item)">
                <img :src="item.imgUrl" :alt="item.productName" :onerror="defaultPimg()" class="p-wrap-grid-img">
              </div>
              <h4 class="p-wrap-name" @click="toDetail(item)" :title="item.productName">{{item.productName}}</h4>
              <p class="p-wrap-time">上架时间：{{item.firstImpTime|cutTime}}</p>
              <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                库存：{{item.dcDistQty}}
              </p>
              <p class="p-wrap-time" v-else>
                <span v-if="item.dcDistQty>0&&item.dcDistQty<item.warnDistQty" class="warn--text">库存紧张</span>
                <span v-else-if="item.dcDistQty<=0" class="red--text">暂时无货</span>
                <span v-else>库存充足</span>
              </p>
              <div class="p-wrap-line">
                <div>
                  <span class="p-wrap-time red--text">¥</span>
                  <span class="p-wrap-price">{{item.taxPrice}}</span>
                </div>
                <Button type="primary" v-if="item.taxPrice*1>0" class="order-btn" @click="toDetail(item)">订货
                  <em v-show="item.orderQty>0">({{item.orderQty}})</em>
                </Button>
              </div>
            </Card>
          </Col>

          <Col span="24" :key="index" class="list-wrap" v-show="displyType=='list'">
            <Card :key="index" class="p-wrap" @click.native="toDetail(item)">
              <div class="list-wrap-h">
                <div @click="toDetail(item)">
                  <img :src="item.imgUrl" :onerror="defaultPimg()" class="p-wrap-list-img">
                </div>

                <div class="list-wrap-product">
                  <h4 class="p-wrap-name" @click="toDetail(item)" :title="item.productName">{{item.productName}}</h4>
                  <p class="p-wrap-time">上架时间：{{item.firstImpTime|cutTime}}</p>
                  <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                    库存：{{item.dcDistQty}}
                  </p>
                  <p class="p-wrap-time" v-else>
                    <span v-if="item.dcDistQty>0&&item.dcDistQty<item.warnDistQty" class="warn--text">库存紧张</span>
                    <span v-else-if="item.dcDistQty<=0" class="red--text">暂时无货</span>
                    <span v-else>库存充足</span>
                  </p>
                  <div class="p-wrap-line">
                    <div>
                      <span class="p-wrap-time red--text">¥</span>
                      <span class="p-wrap-price">{{item.taxPrice}}</span>
                    </div>
                  </div>
                  <div class="p-wrap-line">
                    <Button type="primary" v-if="item.taxPrice*1>0" class="order-btn" @click="toDetail(item)">订货
                      <em v-show="item.orderQty>0">({{item.orderQty}})</em>
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </Col>
        </template>
      </Row>

      <Row v-else>
        <Col span="24">
          <div class="search-result">
            <img src="../../assets/images/empty/search.png" alt="" class="search-img">
            <span class="search-info">抱歉，没有找到相关商品内容！</span>
          </div>
        </Col>
      </Row>
      <product-page :pageInfo="serviceType==0?supplierProductData:fwProductData" @pageChange="handlePageChange"
                    @pageSizeChange="handlePageSizeChange">
      </product-page>

    </div>
  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'
  import SelectorHeader from '../../common/Selector-Header'
  import SortType from '../../common/Sort-Type'
  import ProductPage from '../../common/Product-Page'

  export default {
    name: 'FwProduct',
    components: {
      SortType,
      SelectorHeader,
      ProductPage
    },
    data: () => ({
      code: '',
      bannerList: [],
      newPorudctList: [],
      orderCondition: '',
      orderConditionType: 'desc',
      productCategoryCode: '',
      productBrandId: '',
      productPropertyId: '',
      store: false,
      displyType: 'grid',

      pageIndex: 1,
      pageSize: 50
    }),
    computed: {
      ...mapState([
        'searchInfo',
        'addSuccess',
        'loading'
      ]),
      ...mapGetters([
        'fwProductData',
        'supplierProductData',
        'userData'
      ]),
      query () {
        return this.$route.query
      },
      serviceType () {
        return this.query.serviceType
      },
      supplierId () {
        return this.query.id
      },
      supplierName () {
        return this.query.name
      },
      supplierTel () {
        return this.query.tel
      },
      areaProduct () {
        return this.query.areaProduct
      }
    },
    watch: {
      'searchInfo': 'handleSearch',
      'addSuccess': 'handleAddSuccess'
    },
    created() {
      if (Object.keys(this.searchInfo).length && this.searchInfo.type == 'own') {
        this.saveSearchInfo({})
      }
      this.handleBaseDialog({visible: false, type: 'supplierDetailVisible'})
      console.log(this.searchInfo)
      this.saveSelectInfo({})
      this.saveSearchInfo({})
      this.initData()
      this.getBanner()
    },
    methods: {
      ...mapActions([
        'getFwData',
        'getSupplierProductData',
        'saveSupplierProductInfo',
        'saveSupplierProductSeriesInfo',
        'handleBaseDialog',
        'saveSearchInfo',
        'saveSelectInfo'
      ]),
      handleAddSuccess(v) {
        console.log(v)
        let path = v.split('?')[0]
        if (path == this.$route.path) {
          this.initData()
        }
      },
      handleSearch(v) {
        console.log(v)
        if (Object.keys(this.searchInfo).length && this.searchInfo.type == 'fw') {
          this.initData()
        }
      },
      initData() {
        if (this.serviceType == '0') {
          this.getSupplierProductData({
            pageIndex: this.pageIndex,
            pageSize: this.pageSize,
            productCondition: this.searchInfo.id,
            orderCondition: this.orderCondition,
            orderConditionType: this.orderConditionType,
            productCategoryCode: this.productCategoryCode,
            productBrandId: this.productBrandId,
            productPropertyId: this.productPropertyId,
            supplierId: this.supplierId
          })
        }
        if (this.serviceType == '1') {
          this.getFwData({
            pageIndex: this.pageIndex,
            pageSize: this.pageSize,
            productCondition: this.searchInfo.id,
            orderCondition: this.orderCondition,
            orderConditionType: this.orderConditionType,
            productCategoryCode: this.productCategoryCode,
            productBrandId: this.productBrandId,
            productPropertyId: this.productPropertyId,
            service: '服务商',
            supplierId: this.supplierId
          })
        }
      },
      async getBanner() {
        let self = this
        let params = {
          displayPosition: 9
        }
        let {data} = await api.getBannerList(params)
        console.log(data)
        if (data.status == '0') {
          let arr = data.data.aterials
          self.bannerList = arr
        } else {
        }
      },
      // 处理跳转 1：相应的路由地址 2. 广告页面
      handleJump(item) {
        this.handleADJump(item)
      },
      handleSelectChange(v) {
        this.pageIndex = 1
        this.productCategoryCode = v.productCategoryCode
        this.productBrandId = v.productBrandId
        this.productPropertyId = v.productPropertyId
        this.initData()
      },
      handlePageChange(v) {
        window.scrollTo(0, 500)
        // let path = this.$route.path
        // if (v.route == path) {
        this.pageIndex = v.pageIndex
        this.initData()
        // }
      },
      handlePageSizeChange(v) {
        window.scrollTo(0, 500)
        let path = this.$route.path
        if (v.route == path) {
          this.pageSize = v.pageSize
          this.initData()
        }
      },
      handleDisplay(v) {
        this.displyType = v
      },
      handleSort(v) {
        this.pageIndex = 1
        this.orderCondition = v.orderCondition
        this.orderConditionType = v.orderConditionType
        this.initData()
      },
      toDetail(row) {
        if (this.serviceType == '1') {
          row.service = '服务商'
        }
        this.saveSupplierProductInfo(Object.assign({}, row, {areaProduct: this.areaProduct}))
        this.saveSupplierProductSeriesInfo(row.productSetId)
        if (row.productSetId == '0' && this.areaProduct == '0') {
          this.handleBaseDialog({visible: true, type: 'supplierDetailVisible'})
        }
        if (row.productSetId == '0' && this.areaProduct == '1') {
          this.handleBaseDialog({visible: true, type: 'supplierBrandDetailVisible'})
        }
        if (row.productSetId !== '0' && this.areaProduct == '0') {
          this.handleBaseDialog({visible: true, type: 'supplierSeriesDetailVisible'})
        }
        if (row.productSetId !== '0' && this.areaProduct == '1') {
          this.handleBaseDialog({visible: true, type: 'supplierBrandSeriesDetailVisible'})
        }
        // if (row.productSetId == '0') {
        //   this.handleBaseDialog({visible: true, type: 'supplierDetailVisible'})
        // } else {
        //   this.handleBaseDialog({visible: true, type: 'supplierSeriesDetailVisible'})
        // }
      }
    }
  }
</script>

<style lang="less">

  .recent-product {
    background-color: #F5F5F5;
    overflow-x: hidden;

    .recent-wrap {
      margin: 20px auto;
      width: 1200px;
      background-color: #ffffff;
      padding: 20px 10px;

      .ivu-card-body:hover {
        border: 1px solid red;
        border-radius: 4px;
      }
    }
  }
  .ranchise-store-info{
     height:130px;
     background: #FA4A47;
     &.ranchise-store-info-servies{
       background: #F76F1F;
     }
     .ranchise-store-info-con{
       display: flex;
       background: url('../../assets/images/detail/ranchise_store_bg.png');
       background-size: 100% 100%;
       height:100%;
       width:1200px;
       margin: 0 auto;
       padding:30px 50px 20px;
       &.ranchise-store-info-con-servies{
         background: url('../../assets/images/detail/ranchise_store_servies_bg.png');
       }
       .ranchise-store-info-left{
         display: flex;
         align-items: center;
         margin-right: 30px;
         img{
           display: block;
           width:80px;
           height:80px;
         }
       }
       .ranchise-store-info-right{
         display: flex;
         flex-direction: column;
         justify-content: space-between;
         p{
          color: #ffffff;
          display: flex;
          align-items: center;
          &:first-child{
            margin-top: 5px;
            span{
              font-size: 26px;
            }
            em{
              color: #F7B62D;
              background: #ffffff;
              border-radius: 20px;
              padding:2px 10px;
              margin: 0 8px;
            }
          }
          &:last-child{
            margin-bottom: 6px;
            padding: 0 10px;
            border:1px solid #ffffff;
            border-radius: 30px;
            width: 230px;
            img{
              width: 19px;
              height: 19px;
              margin-right: 10px;
            }
            span{
              font-size: 16px;
            }
          }
        }
       }
     }
  }
</style>
