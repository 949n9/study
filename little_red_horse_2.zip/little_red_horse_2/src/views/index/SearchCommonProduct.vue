<template>
  <div class="recent-product">

    <div class="recent-wrap" ref="list">
      <Row v-if="categoryProductData.list&&categoryProductData.list.length">
        <template v-for="(item,index) in categoryProductData.list">
          <Col span="4" :key="item.id" class="grid-wrap">
            <Card :key="index" class="p-wrap grid-wrap-recent">
              <!--<div class="p-wrap-unstore" @click="unStore">-->
              <!--<span style="">取消收藏</span>-->
              <!--</div>-->
              <div class="p-wrap-grid" @click="toDetail(item)">
                <img :src="item.imgUrl" :alt="item.productName" :onerror="defaultPimg()" class="p-wrap-grid-img">
              </div>
              <h4 class="p-wrap-name" @click="toDetail(item)" :title="item.productName">{{item.productName}}</h4>
              <Badge :text="'物流费减免：'+item.deliveryFeeReduceRate+'%'" class-name="p-wrap-badge">
              </Badge>
              <p class="p-wrap-time">上架时间：{{item.firstImpTime|cutTime}}</p>
              <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                库存：{{item.dcDistQty}}
              </p>
              <p class="p-wrap-time" v-else>
                <span v-if="item.dcDistQty>0&&item.dcDistQty<item.warnDistQty" class="warn--text">库存紧张</span>
                <span v-else-if="item.dcDistQty<=0" class="red--text">暂时无货</span>
                <span v-else>库存充足</span>
              </p>
              <div class="p-wrap-line">
                <div>
                  <span class="p-wrap-time red--text">¥</span>
                  <span class="p-wrap-price">{{item.taxPrice}}</span>
                </div>
                <Button type="primary" v-if="item.taxPrice*1>0" class="order-btn" @click="toDetail(item)">订货
                  <em v-show="item.orderQty>0">({{item.orderQty}})</em>
                </Button>
              </div>
            </Card>
          </Col>
        </template>
      </Row>

      <Row v-else>
        <Col span="24">
          <div class="search-result">
            <img src="../../assets/images/empty/search.png" alt="" class="search-img">
            <span class="search-info">抱歉，没有找到相关商品内容！</span>
          </div>
        </Col>
      </Row>

      <product-page :pageInfo="categoryProductData" @pageChange="handlePageChange"
                    @pageSizeChange="handlePageSizeChange">
      </product-page>

    </div>
  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  // import api from '../../core/index'
  import ProductPage from '../../common/Product-Page'

  // 搜索出来的商品
  export default {
    name: 'SearchCommonProduct',
    components: {
      ProductPage
    },
    data: () => ({
      orderCondition: '',
      orderConditionType: 'desc',
      productCategoryCode: '',
      productBrandId: '',
      productPropertyId: '',

      pageIndex: 1,
      pageSize: 50
    }),
    computed: {
      ...mapState([
        'searchInfo',
        'addSuccess',
        'loading'
      ]),
      ...mapGetters([
        'categoryProductData',
        'userData'
      ])
    },
    watch: {
      'searchInfo': 'handleSearch',
      'addSuccess': 'handleAddSuccess'
    },
    created() {
      this.initData()
    },
    methods: {
      ...mapActions([
        'getCategoryProductData',
        'saveProductInfo',
        'saveProductSeriesInfo',
        'handleBaseDialog'
      ]),
      handleAddSuccess(v) {
        console.log(v)
        let path = v.split('?')[0]
        if (path == this.$route.path) {
          this.initData()
        }
      },
      handleSearch(v) {
        console.log(v)
        if (Object.keys(this.searchInfo).length && this.searchInfo.type == 'own') {
          this.initData()
        }
      },
      initData() {
        console.log(this.selectInfo)
        console.log(this.searchInfo)
        this.getCategoryProductData({
          pageIndex: this.pageIndex,
          pageSize: this.pageSize,
          productCondition: this.searchInfo.id,
          orderCondition: this.orderCondition,
          orderConditionType: this.orderConditionType,
          productCategoryCode: this.productCategoryCode,
          productBrandId: this.productBrandId,
          productPropertyId: this.productPropertyId
        })
      },
      handlePageChange(v) {
        window.scrollTo(0, 500)
        this.pageIndex = v.pageIndex
        this.initData()
      },
      handlePageSizeChange(v) {
        window.scrollTo(0, 500)
        this.pageSize = v.pageSize
        this.initData()
      },
      toDetail(row) {
        console.log(row)
        this.saveProductInfo(row.productId)
        this.saveProductSeriesInfo(row.productSetId)
        if (row.productSetId == '0') {
          this.handleBaseDialog({visible: true, type: 'productDetailVisible'})
        } else {
          this.handleBaseDialog({visible: true, type: 'productSeriesDetailVisible'})
        }
      }
    }
  }
</script>

<style lang="less">

  .recent-product {
    background-color: #F5F5F5;
    overflow-x: hidden;

    .recent-wrap {
      margin: 20px auto;
      width: 1200px;
      background-color: #ffffff;
      padding: 20px 10px;

      .ivu-card-body:hover {
        border: 1px solid red;
        border-radius: 4px;
      }
    }

    .recent-img {
      height: 200px;
      width: 100%;
      min-width: 1250px;
    }
  }
</style>
