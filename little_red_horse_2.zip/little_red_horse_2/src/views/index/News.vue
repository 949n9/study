<template>
  <div class="news">
    <div class="news-wrap">
      <div class="wrap-l">
        <Carousel v-if="bannerList.length>1" autoplay :radius-dot="true" :loop="true">
          <CarouselItem v-for="(item,i) in bannerList" :key="i">
            <img :src="item.url" alt="" class="news-material-img" @click="handleJump(item)">
          </CarouselItem>
        </Carousel>
        <div class="news-material-wrap" v-else>
          <img v-if="bannerList.length==1" :src="bannerList[0].url" alt="" @click="handleJump(bannerList[0])"
               class="news-material-img">
        </div>
        <div class="news-list">
          <Card :key="index" v-for="(item,index) in newsList" @click.native="toDetail(item)">
            <div class="news-list-wrap">
              <div @click="toDetail(item)" class="list-img-wrap">
                <img :src="item.imageUrl" :onerror="defaultPimg()" class="list-img">
              </div>

              <div class="list-content">
                <p class="list-content-title" @click="toDetail(item)" title="">
                  {{item.title}}</p>

                <p class="list-content-des">
                  {{item.description}}
                </p>

                <div class="list-content-tip">
                  <div class="fl">
                    <span class="tags" v-for="(i,j) in item.tags" :key="j">{{i}}</span>
                  </div>
                  <div class="fr">
                    <Icon type="ios-eye-outline" size="18" color="#797979"/>
                    {{item.readCount}}人浏览
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>

      </div>
      <div class="wrap-r">
        <div class="r-header">
          <img src="../../assets/images/icon/paihangicon.png" alt="">
          <img src="../../assets/images/icon/liulanpaihang.png" class="img" alt="">
        </div>
        <ul class="r-content">
          <li class="r-content-item" v-for="(item,index) in hotList" :key="index" @click="toDetail(item)">
            <p class="r-content-item-title">{{item.title}}</p>
            <p class="r-content-item-des">{{item.description}}</p>
            <div class="r-content-item-other">
              <Icon type="ios-eye-outline" size="18" color="#797979"/>
              {{item.readCount}}浏览
            </div>
          </li>

        </ul>
      </div>
    </div>
  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'

  export default {
    name: 'HotProduct',
    components: {},
    data: () => ({
      pageIndex: 1,
      pageSize: 10,
      newsList: [],
      hotList: [],
      bannerList: []
    }),
    computed: {
      ...mapState([
        'loading'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    created() {
      this.saveSearchInfo({})
      this.saveSelectInfo({})
      this.initData()
    },
    watch: {},
    methods: {
      ...mapActions([
        'saveSearchInfo',
        'saveSelectInfo'
      ]),
      initData() {
        this.getHotList()
        this.getBanner()
        this.getNewsList()
      },
      async getNewsList() {
        let self = this
        let params = {
          pageIndex: self.pageIndex,
          pageSize: self.pageSize
        }
        let {data} = await api.getArticleList(params)
        if (data.status == '0') {
          self.newsList = data.data.list
          self.newsList.forEach(item => {
            item.tags = item.tags.split(' ')
          })
        } else {

        }
      },
      // 浏览排行
      async getHotList() {
        let self = this
        let params = {
          pageIndex: 1,
          pageSize: 5,
          orderCondition: 'readCount',
          orderConditionType: 'desc'
        }
        let {data} = await api.getArticleList(params)
        if (data.status == '0') {
          self.hotList = data.data.list
        } else {

        }
      },
      async getBanner() {
        let self = this
        let params = {
          displayPosition: 11
        }
        let {data} = await api.getBannerList(params)
        console.log(data)
        if (data.status == '0') {
          let arr = data.data.aterials
          // self.bannerList = arr
          self.bannerList = [
            {
              url: require('../../assets/images/news-banner.png')
            }
          ]
        } else {
        }
      },
      handlePageChange(v) {
        window.scrollTo(0, 500)
        this.pageIndex = v.pageIndex
        this.getNewsList()
      },
      handlePageSizeChange(v) {
        window.scrollTo(0, 500)
        let path = this.$route.path
        if (v.route == path) {
          this.pageSize = v.pageSize
          this.getNewsList()
        }
      },
      toDetail(item) {
        let id = item.id
        this.$router.push({
          path: `/index/newsdetail/${id}`
        })
      }
    }
  }
</script>

<style lang="less">

  .news {
    width: 100%;
    background-color: #F5F5F5;
    overflow-x: hidden;

    .news-wrap {
      width: 1200px;
      margin: 0 auto;
      position: relative;

      .wrap-l {
        width: 795px;

        .news-material-wrap {
          width: 100%;
          display: flex;
          justify-content: center;
        }

        .news-material-img {
          height: auto;
          width: 795px;
          cursor: pointer;
        }

        .news-list {
          .ivu-card-body {
            padding: 0;
          }
        }

        .news-list-wrap {
          padding: 20px;
          display: flex;
          cursor: pointer;

          .list-img-wrap {
            width: 230px;
            height: 150px;

            .list-img {
              display: inline-block;
              height: 100%;
              width: 100%;
            }
          }

          .list-content {
            margin-left: 20px;
            width: 470px;
            position: relative;

            &-title {
              font-size: 18px;
              font-weight: 600;
              color: #333;
              overflow: hidden;
              white-space: nowrap;
              text-overflow: ellipsis;
            }

            &-des {
              font-size: 14px;
              color: #666;
              margin-top: 20px;
              overflow: hidden;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-line-clamp: 2;
              line-clamp: 2;
              -webkit-box-orient: vertical;
            }

            &-tip {
              position: absolute;
              bottom: 0;
              left: 0;
              width: 470px;
              margin-top: 24px;
              display: flex;
              justify-content: space-between;

              .tags {
                margin-right: 8px;
              }

              .tags:hover {
                color: #E61E10;
              }
            }
          }
        }
      }

      .wrap-r {
        position: absolute;
        right: 0;
        top: 0;
        width: 390px;
        background-color: #ffffff;
        padding: 12px 13px;

        .r-header {
          height: 30px;
          display: flex;
          align-items: center;

          .img {
            margin-left: 12px;
          }
        }

        .r-content {
          .r-content-item {
            cursor: pointer;
            border-bottom: 1px solid #eeeeee;
            padding: 10px 20px;

            &-title {
              font-size: 14px;
              color: #333;
              font-weight: 600;
              overflow: hidden;
              white-space: nowrap;
              text-overflow: ellipsis;
            }

            &-des {
              font-size: 14px;
              margin-top: 8px;
              color: #999;
              overflow: hidden;
              white-space: nowrap;
              text-overflow: ellipsis;
            }

            &-other {
              margin-top: 18px;
              color: #666666;
            }
          }
        }
      }
    }
  }
</style>
