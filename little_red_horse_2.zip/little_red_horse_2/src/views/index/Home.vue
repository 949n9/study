<template>
  <div class="home">
    <div :key="index" v-for="(item,index) in materialsList">
      <template v-if="item.templateId==17">
        <m-carousel :defaultData="item.content" :leftHeight="`450px`"></m-carousel>
      </template>

      <template v-if="item.templateId==19">
        <m-capsule :defaultData="item.content"></m-capsule>
      </template>

      <template v-if="item.templateId==5">
        <m-today-purchase :defaultData="item.content" :flashSale="item.flashSale"></m-today-purchase>
      </template>

      <template v-if="item.templateId==21">
        <m-theme-activity :defaultData="item.content"></m-theme-activity>
      </template>

      <template v-if="item.templateId==18">
        <m-carousel2 :defaultData="item.content"></m-carousel2>
      </template>

      <template v-if="item.templateId==13">
        <m-brand :defaultData="item.content"></m-brand>
      </template>

      <template v-if="item.templateId==14">
        <m-promotion-product :defaultData="item.content" :defaultProduct="item.promotionProduct"></m-promotion-product>
      </template>

      <template v-if="item.templateId==16">
        <m-hot-product :defaultData="item.content" :defaultProduct="item.hotPorudct"></m-hot-product>
      </template>

      <template v-if="item.templateId==15">
        <m-fw-product :defaultData="item.content" :defaultProduct="item.subCustomerSupplierProduct"></m-fw-product>
      </template>
    </div>

    <!--快讯-->
    <div class="home-wrap" style="padding: 0" v-if="newsList.length">
      <div class="brand-header">
        <div>
          <span class="brand-title">快讯</span>
          <em class="brand-em"></em>
          <span class="brand-des">这里你将了解更多</span>
        </div>
        <Button type="text" to="/index/news">更多>></Button>
      </div>
      <ul class="news-list">
        <li v-for="(item,index) in newsList" :key="index" class="news-item">
          <img @click="handleNewsClick(item)" :src="item.imageUrl" alt=""
               class="news-img">
          <div class="news-content">
            <p class="news-content-title">{{item.title}}</p>
            <p class="news-content-des">{{item.description}}</p>
            <div class="news-content-des">
              <Icon type="ios-eye-outline" size="18" color="#ffffff"/>
              {{item.readCount}}人浏览
            </div>
          </div>
        </li>
      </ul>
    </div>

  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'
  import MCarousel from '../../components/MCarousel'
  import MCapsule from '../../components/MCapsule'
  import MTodayPurchase from '../../components/MTodayPurchase'
  import MBrand from '../../components/MBrand'
  import MCarousel2 from '../../components/MCarousel2'
  import MThemeActivity from '../../components/MThemeActivity'
  import MPromotionProduct from '../../components/MPromotionProduct'
  import MHotProduct from '../../components/MHotProduct'
  import MFwProduct from '../../components/MFwProduct'

  export default {
    name: 'Home',
    components: {
      MCarousel,
      MCapsule,
      MTodayPurchase,
      MThemeActivity,
      MBrand,
      MCarousel2,
      MPromotionProduct,
      MHotProduct,
      MFwProduct
    },
    data() {
      return {
        materialsList: [],
        newsList: []
      }
    },
    computed: {
      ...mapState([
        'CustomerListVisible',
        'addSuccess'
      ]),
      ...mapGetters([
        'userData'
      ])
    },
    created() {
      this.saveSearchInfo({})
      this.saveSelectInfo({})
      this.getProduct()
    },
    beforeDestroy() {
      clearInterval(this.interval)
      clearInterval(this.beforeInterval)
      window.removeEventListener('scroll', this.handleScroll)
    },
    mounted() {
      this.$nextTick(function () {
        window.addEventListener('scroll', this.handleScroll)
      })
    },
    watch: {
      'addSuccess': 'handleAddSuccess'
    },
    methods: {
      ...mapActions([
        'handleBaseDialog',
        'saveSearchInfo',
        'saveSelectInfo',
        'hideLeftMenu'
      ]),
      handleScroll() {
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
        if (scrollTop > 250) {
          this.hideLeftMenu(true)
        } else {
          this.hideLeftMenu(false)
        }
      },
      handleAddSuccess(v) {
        console.log(v)
        let path = v.split('?')[0]
        if (path == this.$route.path) {
          this.getProduct()
        }
      },
      async getProduct() {
        let self = this
        let params = {}
        let {data} = await api.getProductList(params)
        console.log(data)
        if (data.status == '0') {
          self.materialsList = data.data.materials || []
        }
      },
      // 新闻点击查看
      handleNewsClick(item) {
        let id = item.id
        this.$router.push({
          path: `/index/newsdetail/${id}`
        })
      }
    }
  }
</script>

<style lang="less">

  .home {
    background-color: #f5f5f5;

    .home-wrap {
      margin: 20px auto;
      width: 1200px;
      background-color: #ffffff;
      padding: 20px 10px;

      .brand-header {
        height: 60px;
        line-height: 60px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 30px;

        .brand-title {
          font-size: 22px;
          font-weight: 600;
        }

        .brand-em {
          display: inline-block;
          width: 1px;
          height: 14px;
          background-color: #E61E10;
          margin: 0 10px;
        }

        .brand-des {
          font-size: 14px;
          color: #999999;
        }
      }

      .brand-list {
        display: flex;
        flex-wrap: wrap;
        padding: 12px 12px 0 12px;

        .brand-item {
          margin-right: 9px;
          margin-bottom: 5px;
        }

        .brand-item:nth-child(9n) {
          margin-right: 0px;
        }
      }

      .news-list {
        display: flex;
        flex-wrap: wrap;
        padding: 5px 24px 0 24px;

        .news-item {
          width: 377px;
          height: 248px;
          margin-right: 9px;
          margin-bottom: 5px;
          position: relative;
        }

        .news-item:last-child {
          margin-right: 0px;
          position: relative;
        }

        .news-img {
          width: 377px;
          height: 248px;
          cursor: pointer;
        }

        .news-content {
          position: absolute;
          bottom: 10px;
          left: 16px;
          width: 343px;
          cursor: pointer;

          &-title {
            font-size: 14px;
            color: #fff;
            font-weight: 600;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }

          &-des {
            font-size: 12px;
            color: #fff;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }

          &-des:hover, &-title:hover {
            color: #E61E10;
          }

        }
      }

      .carousel-brand-img {
        width: 100%;
        height: 180px;
        cursor: pointer;
      }

      .brand-img {
        width: 122px;
        height: 72px;
        border: 1px solid #DDDDDD;
        cursor: pointer;
      }

      .brand-img:hover {
        border: 1px solid #E61E10;
      }

      .ivu-card-body:hover {
        border: 1px solid red;
        border-radius: 4px;
      }

      .activity-wrap-cus {
        height: 698px;
        background-color: #f4f4f4;
        margin: 10px;

        .img {
          height: 100%;
          width: 100%;
          cursor: pointer;
        }
      }

      .activity-wrap-pro {
        height: 704px;
        background-color: #f4f4f4;
        margin: 10px;

        .img {
          height: 100%;
          width: 100%;
          cursor: pointer;
        }
      }
    }

    .theme-wrap {
      margin: 0px auto;
      width: 1200px;

      .theme-ul {
        margin-top: 20px;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
        align-items: center;
        overflow: hidden;

        li {
          float: left;
          margin-right: 8px;
          &.right-item{
            margin-right: 0px;
          }
        }

        .theme-img {
          height: auto;
          width: 100%;
          cursor: pointer;
        }
      }
    }

    .flashSale_wrap {
      display: flex;
      height: 40px;
      line-height: 40px;

      .before_sale {
        display: inline-block;
        margin-left: 30px;
        margin-top: 8px;
        height: 30px;
        line-height: 30px;
        background-color: #E61E10;
        border-radius: 10px;
        padding: 0 10px;
        color: #ffffff;
        font-size: 16px;
        font-weight: 600;
      }

      .buy_img {
        height: 40px;
        width: 172px;
      }

      .buy_time {
        margin-left: 20px;
        font-size: 22px;
        font-weight: 600;
        color: #4A4A4A;
      }

      .buy_day {
        display: inline-block;
        width: 30px;
        height: 40px;
        text-align: center;
        line-height: 40px;
        font-weight: bold;
        font-size: 16px;
        color: #fff;
      }

      .buy_wrap {
        position: relative;
        width: 40px;
        height: 40px;
        text-align: center;
        background-color: #2f3430;
        border-radius: 5px;

        .buy_text {
          position: relative;
          display: inline-block;
          line-height: 40px;
          width: 40px;
          font-weight: bold;
          font-size: 20px;
          color: #ffffff;
        }
      }

      .buy_m {
        display: inline-block;
        line-height: 40px;
        font-size: 20px;
        font-weight: 700;
        margin: 0 3px;
        color: #fff;
      }
    }

    .today-bg {
      /*background-image: url("../../assets/images/home/biqiang_bg@2x.png");*/
      background: #fff;
    }

    .carousel-img {
      height: auto;
      width: 100%;
      display: block;
      cursor: pointer;
    }

    .col-wrap {
      width: 235px;
      padding: 10px;
    }

    .p-title {
      display: inline-block;
      padding-left: 20px;
      height: 30px;
      line-height: 30px;
      font-size: 20px;
      font-weight: 500;
      white-space: nowrap;
    }

    .p-more {
      display: inline-block;
      height: 30px;
      line-height: 30px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
    }

    .home-active {
      height: 180px;
      background-color: #ffbb52;
      text-align: center;
      cursor: pointer;

      &-img {
        height: 100%;
        width: 100%;
      }
    }
  }
</style>
