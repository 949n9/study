<template>
  <div class="brand-product">
    <div v-if="materialInfo.detailUrl" class="material-wrap">
      <img :src="materialInfo.detailUrl" alt="" class="material-img">
    </div>

    <div class="recent-wrap" style="padding: 0">
      <ul v-if="secKillProduct.length" class="brand-sec-product">
        <li v-for="(item,index) in secKillProduct" :key="index" class="brand-sec-item" @click="toDetail(item)">
          <div @click="toDetail(item)" class="item-img-wrap">
            <img :src="item.imgUrl" class="item-img">
          </div>

          <div class="item-product">
            <h4 class="item-product-name" @click="toDetail(item)" :title="item.productName">{{item.productName}}</h4>
            <div class="item-product-tags">
              <span class="tags" v-for="(i,j) in item.tag.split('，')" :key="j">{{i}}</span>
            </div>
            <!-- <Badge :text="'物流费减免：'+item.deliveryFeeReduceRate+'%'" class-name="item-product-badge" v-if="item.areaProduct==0">
            </Badge> -->
            <p class="p-wrap-areaProduct-flag" v-if="item.areaProduct==1">控区控价</p>
            <p class="item-product-time" v-if="userData.showDistQty==='true'">
              库存：{{item.dcDistQty}}
            </p>
            <p class="item-product-time" v-else>
              <span v-if="item.dcDistQty*1>0&&item.dcDistQty*1<item.warnDistQty*1" class="warn--text">库存紧张</span>
              <span v-else-if="item.dcDistQty*1<=0" class="red--text">暂时无货</span>
              <span v-else>库存充足</span>
            </p>

            <div class="item-product-line" v-if="item.areaProduct==0">
              <div>
                <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice!=item.minPeriodPrice">
                    <span style="font-size:12px;">￥</span>{{item.minPeriodPrice}} -
                    <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                </p>
                <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice==item.minPeriodPrice">
                    <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                </p>
                <p class="p-wrap-price" v-if="item.productType!=2">
                    <span style="font-size:12px;">￥</span>{{item.taxPrice}}
                </p>
              </div>
              <Button type="primary" v-if="item.taxPrice*1>0" class="btn" @click="toDetail(item)">订货
                <em v-show="item.orderQty*1>0">({{item.orderQty}})</em>
              </Button>
            </div>
            <div class="p-wrap-areaProduct" v-if="item.areaProduct==1">
                  <Button type="primary" class="second-primary" v-if="item.approveStatus==0">申请加盟</Button>
                  <Button class="second-disable-btn" v-if="item.approveStatus==1">审核中</Button>
                  <Button class="second-disable-btn" v-if="item.approveStatus==2">已退回</Button>
            </div>
          </div>

        </li>
      </ul>
    </div>

    <div class="recent-wrap" v-if="hotProduct.length" style="padding: 0">
      <div class="brand-hot-header">
        <img src="../../assets/images/home/hotseal.png" alt="" class="brand-hot-img">
        <span class="brand-hot-des">{{time}}s后换一批</span>
      </div>
      <ul class="brand-hot-product">
        <li v-for="(item,index) in hotProduct" :key="index" class="brand-hot-item" @click="toDetail(item)">
          <div>
            <img :src="item.imgUrl" alt="" class="product-hot-img">
            <p class="product-hot-tag">{{tagsList[index]}}</p>
            <p class="product-hot-price" v-if="item.areaProduct==0">¥{{item.taxPrice}}</p>
          </div>
        </li>
      </ul>
    </div>

    <div v-for="(i,index) in brandProduct" :key="index">
      <div class="brand-tag" v-show="brandProduct.length>1">
        <img src="../../assets/images/home/zuo@2x.png" alt="" class="brand-tag-img">
        <span class="brand-tag-text">{{i.name}}</span>
        <img src="../../assets/images/home/you@2x.png" alt="" class="brand-tag-img">
      </div>
      <div class="recent-wrap" ref="list">
        <Row v-if="i.data && i.data.length">
          <template v-for="(item,index) in i.data">
            <Col span="4" class="grid-wrap" :key="index" style="height:385px;" @click.native="toDetail(item)">
              <Card :key="index" class="p-wrap" style="height: 100%" @click="toDetail(item)">
                <div class="p-wrap-grid" @click="toDetail(item)">
                  <img :src="item.imgUrl" :alt="item.productName" :onerror="defaultPimg()" class="p-wrap-grid-img">
                </div>
                <h4 class="p-wrap-name" @click="toDetail(item)" :title="item.productName">{{item.productName}}</h4>
                <div>
                    <!-- <Badge  v-if="item.areaProduct==0" :text="'物流费减免：'+item.deliveryFeeReduceRate+'%'" class-name="p-wrap-badge">
                    </Badge> -->
                    <div class="p-wrap-from-servies" v-if="item.serviceType=='0'||item.serviceType=='1'">
                        <img src="../../assets/images/detail/icon_fuwushang.png" alt="" srcset="" v-if="item.serviceType=='1'">
                        <span @click.stop="goStore(item)">{{item.supplierName}}</span>
                    </div>
                    <div class="p-wrap-from" v-if="item.serviceType=='2'">
                        <img src="../../assets/images/detail/icon_shangchen.png" alt="" srcset="">
                        <span>{{'小红马商城'}}</span>
                    </div>
                </div>
                <p class="p-wrap-areaProduct-flag" v-if="item.areaProduct==1">控区控价</p>
                <p class="p-wrap-time" v-if="item.areaProduct==0" style="height:18px;margin:5px 0;"></p>
                <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                  库存：{{item.dcDistQty}}
                </p>
                <p class="p-wrap-time" v-else>
                  <span v-if="item.dcDistQty*1>0&&item.dcDistQty*1<item.warnDistQty*1" class="warn--text">库存紧张</span>
                  <span v-else-if="item.dcDistQty*1<=0" class="red--text">暂时无货</span>
                  <span v-else>库存充足</span>
                </p>
                <div v-if="item.areaProduct==0">
                  <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice!=item.minPeriodPrice">
                    <span style="font-size:12px;">￥</span>{{item.minPeriodPrice}} -
                    <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                  </p>
                  <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice==item.minPeriodPrice">
                      <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                  </p>
                  <p class="p-wrap-price" v-if="item.productType!=2">
                      <span style="font-size:12px;">￥</span>{{item.taxPrice}}
                </p>
                </div>
                <div class="clearfix" v-if="item.areaProduct==0">
                  <Button type="primary" long v-if="item.taxPrice*1>0" @click="toDetail(item)">订货
                    <em v-show="item.orderQty*1>0">({{item.orderQty}})</em>
                  </Button>
                </div>
                <div class="p-wrap-areaProduct" v-if="item.areaProduct==1">
                  <Button type="primary" class="button-primary" v-if="item.approveStatus==0">申请加盟</Button>
                  <Button class="disable-btn button-primary" v-if="item.approveStatus==1">审核中</Button>
                  <Button class="disable-btn button-primary" v-if="item.approveStatus==2">已退回</Button>
                </div>
              </Card>
            </Col>
          </template>
        </Row>
      </div>
    </div>

    <Row v-if="brandProduct.length==0 && secKillProduct.length==0 && hotProduct.length==0 && !loading"
         style="background-color: #ffffff">
      <Col span="24">
        <div class="search-result">
          <img src="../../assets/images/empty/search.png" alt="" class="search-img">
          <span class="search-info">抱歉，没有找到相关商品内容！</span>
        </div>
      </Col>
    </Row>

  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'
  import utils from '../../utils'

  export default {
    name: 'BrandPromotionProduct',
    components: {},
    data: () => ({
      materialInfo: {},
      id: '',
      brandProduct: [],
      allProduct: [],
      secKillProduct: [],
      hotProduct: [],
      tagsList: [],
      time: 10,
      interval: null
    }),
    computed: {
      ...mapState([
        'addSuccess',
        'loading'
      ]),
      ...mapGetters([
        'promotionProductData',
        'userData'
      ])
    },
    created() {
      this.id = this.$route.query.id
      this.saveSearchInfo({})
      this.saveSelectInfo({})
      this.initData()
    },
    beforeDestroy() {
      clearInterval(this.interval)
    },
    watch: {
      'addSuccess': 'handleAddSuccess'
    },
    methods: {
      ...mapActions([
        'getPromotionData',
        'handleBaseDialog',
        'saveProductInfo',
        'saveProductSeriesInfo',
        'saveProductDateInfo',
        'saveSupplierProductInfo',
        'saveSupplierProductSeriesInfo',
        'saveSearchInfo',
        'saveSelectInfo'
      ]),
      handleAddSuccess(v) {
        console.log(v)
        let path = v.split('?')[0]
        if (path == this.$route.path) {
          this.getData()
        }
      },
      initData() {
        this.getData()
      },
      async getData() {
        let self = this
        let params = {
          materialId: self.id
        }
        let {data} = await api.getMaterialProduct(params)
        console.log(data)
        if (data.status == '0') {
          self.materialInfo = data.data.materialInfo || {}
          self.brandProduct = data.data.categoryProductInfo || []

          let hotTags = []
          let allArr = []
          let secArr = []

          if (self.brandProduct.length) {
            // 获取所有商品 热销商品
            self.brandProduct.forEach(item => {
              if (item.data.length) {
                item.data.forEach(i => {
                  if (i.featured == 0) {
                    secArr.push(i)
                  }
                  allArr.push(i)
                })
              }
            })
            self.allProduct = allArr
            self.secKillProduct = secArr

            // 获取所有的热销榜标签
            hotTags = self.materialInfo.hotTags
            let arr = []
            if (hotTags.length && self.brandProduct.length) {
              for (let i = 0; i < 4 - hotTags.length; i++) {
                arr.push(hotTags[Math.min(hotTags.length - 1, i)])
              }
              console.log(arr)
              self.tagsList = hotTags.concat(arr)
              self.hotProduct = utils.randomArr(self.allProduct, 4)
              self.handleHotProduct()
            } else {
              self.hotProduct = []
            }
          }
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      },
      handleHotProduct() {
        this.interval = setInterval(() => {
          this.time--
          if (this.time == 0) {
            this.hotProduct = utils.randomArr(this.allProduct, 4)
            this.time = 10
          }
          console.log(this.time)
        }, 1000)
      },
      // 进店
      goStore(row) {
        if (row.serviceType == '0') {
          this.$router.replace({name: 'franchisestoreproduct',
          query: {serviceType: '0', id: row.supplierId, tel: row.telephone, name: row.supplierName, areaProduct: row.areaProduct}})
        } else if (row.serviceType == '1') {
          this.$router.replace({name: 'franchisestoreproduct',
          query: {serviceType: '1', id: row.supplierId, tel: row.telephone, name: row.supplierName, areaProduct: row.areaProduct}})
        }
      },
      toDetail(row) {
        this.toProductDetail(row)
      }
    }
  }
</script>

<style lang="less">
  .ivu-card-body{
    height:100%;
  }
  .brand-product {
    background-color: #FF776E;
    overflow-x: hidden;

    .brand-sec-product {
      background-color: #FF776E;
      display: flex;
      flex-wrap: wrap;
      width: 1200px;

      .brand-sec-item:nth-child(2n+1) {
        margin-right: 10px;
      }

      .brand-sec-item {
        background-color: #ffffff;
        width: 595px;
        display: flex;
        margin-bottom: 10px;
        padding: 20px;
        cursor: pointer;

        .item-img-wrap {
          width: 177px;
          height: 183px;
          border: 1px solid #CCCCCC;
          border-radius: 5px;
          cursor: pointer;
          text-align: center;
        }

        .item-img {
          width: 130px;
          height: 145px;
          margin-top: 19px;
          display: inline-block;
        }

        .item-product {
          margin-left: 20px;
          width: 370px;
          position: relative;

          &-name {
            cursor: pointer;
            height: 48px;
            font-size: 16px;
            font-weight: 600;
            color: #333333;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            line-clamp: 2;
            -webkit-box-orient: vertical;
          }

          &-name:hover {
            color: #E61E10;
          }

          &-tags {
            height: 40px;
            line-height: 40px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;

            .tags {
              color: #F1C449;
              font-size: 16px;
              margin-right: 10px;
            }
          }

          &-badge {
            border: 1px solid red;
            color: red;
            background-color: #fff2fb !important;
          }

          &-line {
            position: absolute;
            left: 0;
            bottom: 0;
            width: 370px;
            display: flex;
            justify-content: space-between;
            padding: 3px 0;
          }

          &-time {
            padding-top: 5px;
            font-size: 14px;
            color: #999999;
            overflow: hidden;
            white-space: nowrap;
          }

          &-price {
            color: red;
            line-height: 35px;
            font-size: 30px;
            font-weight: 600;
          }

          .btn {
            width: 141px;
            height: 40px;
            border-radius: 20px;
            font-size: 20px;
            padding: 0;
          }
        }
      }
    }

    .brand-hot-header {
      height: 70px;
      border-bottom: 1px solid #CCCCCC;

      .brand-hot-img {
        display: inline-block;
        margin-top: 21px;
        margin-left: 28px;
      }

      .brand-hot-des {
        display: inline-block;
        font-size: 20px;
        margin-left: 15px;
        color: #999999;
      }
    }

    .brand-hot-product {
      display: flex;
      padding: 30px 0;

      .brand-hot-item {
        text-align: center;
        margin: 0 20px;
        width: 300px;
        cursor: pointer;

        .product-hot-img {
          width: 131px;
          height: 146px;
        }

        .product-hot-tag {
          font-size: 26px;
          color: #333333;
          font-weight: 600;
        }

        .product-hot-price {
          font-size: 26px;
          color: #E61E10;
          font-weight: 600;
        }
      }
    }

    .brand-tag {
      height: 70px;
      line-height: 70px;
      text-align: center;

      &-img {
        width: 207px;
      }

      &-text {
        font-size: 34px;
        color: #ffffff;
        display: inline-block;
        margin: 0 20px;
      }
    }

    .recent-wrap {
      margin: 10px auto;
      width: 1200px;
      background-color: #ffffff;
      padding: 20px 10px;

      .ivu-card-body:hover {
        border: 1px solid red;
        border-radius: 4px;
      }
    }

    .recent-img {
      height: 280px;
      width: 100%;
      min-width: 1250px;
      cursor: pointer;
    }
  }
</style>
