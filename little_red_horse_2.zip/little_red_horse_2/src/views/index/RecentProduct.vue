<template>
  <div class="recent-product">
    <Carousel v-if="bannerList.length>1" autoplay :radius-dot="true" :loop="true">
      <CarouselItem v-for="(item,i) in bannerList" :key="i">
        <img :src="item.url" alt="" class="material-img" @click="handleJump(item)">
      </CarouselItem>
    </Carousel>
    <div class="material-wrap" v-else>
      <img v-if="bannerList.length==1" :src="bannerList[0].url" alt="" @click="handleJump(bannerList[0])"
           class="material-img">
    </div>

    <div>
      <selector-header @selectChange="handleSelectChange"></selector-header>
    </div>
    <div>
      <sort-type @display="handleDisplay" @sort="handleSort"></sort-type>
    </div>

    <div class="recent-wrap" ref="list">
      <Row v-if="categoryProductData.list && categoryProductData.list.length">
        <template v-for="(item,index) in categoryProductData.list">
          <Col span="4" :key="item.id" class="grid-wrap" v-show="displyType=='grid'">
            <Card :key="index" class="p-wrap grid-wrap-recent"  @click.native="toDetail(item)">
              <div class="p-wrap-grid" @click="toDetail(item)">
                <img :src="item.imgUrl" :alt="item.productName" :onerror="defaultPimg()" class="p-wrap-grid-img">
              </div>
              <h4 class="p-wrap-name" @click="toDetail(item)" :title="item.productName">{{item.productName}}</h4>
              <!-- <Badge :text="'物流费减免：'+item.deliveryFeeReduceRate+'%'" class-name="p-wrap-badge">
              </Badge> -->
              <p class="p-wrap-time">上架时间：{{item.firstImpTime|cutTime}}</p>
              <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                库存：{{item.dcDistQty}}
              </p>
              <p class="p-wrap-time" v-else>
                <span v-if="item.dcDistQty*1>0 && item.dcDistQty*1<item.warnDistQty*1" class="warn--text">库存紧张</span>
                <span v-else-if="item.dcDistQty*1<=0" class="red--text">暂时无货</span>
                <span v-else>库存充足</span>
              </p>
              <div>
                <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice!=item.minPeriodPrice">
                    <span style="font-size:12px;">￥</span>{{item.minPeriodPrice}} -
                    <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                </p>
                <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice==item.minPeriodPrice">
                    <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                </p>
                <p class="p-wrap-price" v-if="item.productType!=2">
                    <span style="font-size:12px;">￥</span>{{item.taxPrice}}
                </p>
              </div>
              <div class="clearfix">
                  <Button type="primary" long v-if="item.taxPrice*1>0" @click="toDetail(item)">订货
                    <em v-show="item.orderQty>0">({{item.orderQty}})</em>
                  </Button>
              </div>
            </Card>
          </Col>

          <Col span="24" :key="index" class="list-wrap" v-show="displyType=='list'">
            <Card :key="index" class="p-wrap" @click.native="toDetail(item)">
              <div class="list-wrap-h">
                <div @click="toDetail(item)">
                  <img :src="item.imgUrl" :onerror="defaultPimg()" class="p-wrap-list-img">
                </div>

                <div class="list-wrap-product">
                  <h4 class="p-wrap-name" @click="toDetail(item)" :title="item.productName">{{item.productName}}</h4>
                  <!-- <Badge :text="'物流费减免：'+item.deliveryFeeReduceRate+'%'" class-name="p-wrap-badge">
                  </Badge> -->
                  <p class="p-wrap-time">上架时间：{{item.firstImpTime|cutTime}}</p>
                  <p class="p-wrap-time" v-if="userData.showDistQty==='true'">
                    库存：{{item.dcDistQty}}
                  </p>
                  <p class="p-wrap-time" v-else>
                    <span v-if="item.dcDistQty*1>0 && item.dcDistQty*1<item.warnDistQty*1"
                          class="warn--text">库存紧张</span>
                    <span v-else-if="item.dcDistQty*1<=0" class="red--text">暂时无货</span>
                    <span v-else>库存充足</span>
                  </p>
                  <div class="p-wrap-line">
                    <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice!=item.minPeriodPrice">
                        <span style="font-size:12px;">￥</span>{{item.minPeriodPrice}} -
                        <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                    </p>
                    <p class="p-wrap-price" v-if="item.productType==2&&item.maxPeriodPrice==item.minPeriodPrice">
                        <span style="font-size:12px;">￥</span>{{item.maxPeriodPrice}}
                    </p>
                    <p class="p-wrap-price" v-if="item.productType!=2">
                        <span style="font-size:12px;">￥</span>{{item.taxPrice}}
                    </p>
                  </div>
                  <div class="p-wrap-line">
                    <Button type="primary" v-if="item.taxPrice*1>0" class="order-btn" @click="toDetail(item)">订货
                      <em v-show="item.orderQty*1>0">({{item.orderQty}})</em>
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </Col>
        </template>
      </Row>

      <Row v-else>
        <Col span="24">
          <div class="search-result">
            <img src="../../assets/images/empty/search.png" alt="" class="search-img">
            <span class="search-info">抱歉，没有找到相关商品内容！</span>
          </div>
        </Col>
      </Row>

      <product-page :pageInfo="categoryProductData" @pageChange="handlePageChange"
                    @pageSizeChange="handlePageSizeChange">
      </product-page>

    </div>
  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../../core/index'
  import SelectorHeader from '../../common/Selector-Header'
  import SortType from '../../common/Sort-Type'
  import ProductPage from '../../common/Product-Page'

  export default {
    name: 'RecentProduct',
    components: {
      SortType,
      SelectorHeader,
      ProductPage
    },
    data: () => ({
      code: '',
      bannerList: [],
      newPorudctList: [],
      orderCondition: 'firstImpTime',
      orderConditionType: 'desc',
      productCategoryCode: '',
      productBrandId: '',
      productPropertyId: '',
      store: false,
      displyType: 'grid',

      pageIndex: 1,
      pageSize: 50
    }),
    computed: {
      ...mapState([
        'addSuccess',
        'loading'
      ]),
      ...mapGetters([
        'categoryProductData',
        'userData'
      ])
    },
    created() {
      this.saveSearchInfo({})
      this.saveSelectInfo({})
      this.initData()
      this.getBanner()
    },
    watch: {
      'addSuccess': 'handleAddSuccess'
    },
    methods: {
      ...mapActions([
        'getCategoryProductData',
        'handleBaseDialog',
        'saveProductInfo',
        'saveProductSeriesInfo',
        'saveProductDateInfo',
        'saveSearchInfo',
        'saveSelectInfo'
      ]),
      handleAddSuccess(v) {
        console.log(v)
        let path = v.split('?')[0]
        if (path == this.$route.path) {
          this.initData()
        }
      },
      initData() {
        this.getCategoryProductData({
          pageIndex: this.pageIndex,
          pageSize: this.pageSize,
          orderCondition: this.orderCondition,
          orderConditionType: this.orderConditionType,
          productCategoryCode: this.productCategoryCode,
          productBrandId: this.productBrandId,
          productPropertyId: this.productPropertyId
        })
      },
      async getBanner() {
        let self = this
        let params = {
          displayPosition: 15
        }
        let {data} = await api.getBannerList(params)
        console.log(data)
        if (data.status == '0') {
          let arr = data.data.aterials
          self.bannerList = arr
        }
      },
      // 处理跳转 1：相应的路由地址 2. 广告页面
      handleJump(item) {
        this.handleADJump(item)
      },
      handleSelectChange(v) {
        this.pageIndex = 1
        this.productCategoryCode = v.productCategoryCode
        this.productBrandId = v.productBrandId
        this.productPropertyId = v.productPropertyId
        this.initData()
      },
      handlePageChange(v) {
        window.scrollTo(0, 500)
        this.pageIndex = v.pageIndex
        this.initData()
      },
      handlePageSizeChange(v) {
        window.scrollTo(0, 500)
        this.pageSize = v.pageSize
        this.initData()
      },
      handleDisplay(v) {
        this.displyType = v
      },
      handleSort(v) {
        this.pageIndex = 1
        this.orderCondition = v.orderCondition
        this.orderConditionType = v.orderConditionType
        this.initData()
      },

      toDetail(row) {
        console.log(row)
        this.saveProductInfo(row.productId)
        this.saveProductSeriesInfo(row.productSetId)
        this.saveProductDateInfo('null')
        if (row.productType == '0') {
          this.handleBaseDialog({visible: true, type: 'productDetailVisible'})
        }
        if (row.productType == '1') {
          this.handleBaseDialog({visible: true, type: 'productSeriesDetailVisible'})
        }
        if (row.productType == '2') {
          this.handleBaseDialog({visible: true, type: 'productDateDetailVisible'})
        }
      }
    }
  }
</script>

<style lang="less">

  .recent-product {
    background-color: #F5F5F5;
    overflow-x: hidden;

    .recent-wrap {
      margin: 20px auto;
      width: 1200px;
      background-color: #ffffff;
      padding: 20px 10px;

      .ivu-card-body:hover {
        border: 1px solid red;
        border-radius: 4px;
      }
    }
  }
</style>
