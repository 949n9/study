<template>
  <div class="mine-menu">
    <Row>
      <Col>
        <Button type="error" class="menu-title-first"
                to="/mine/personalcenter" icon="md-person">
          个人中心1
        </Button>
      </Col>
    </Row>
    <Row>
      <Col>
        <Menu :active-name="activeName" width="180px" class="menu-wrap">
          <MenuItem name="/mine/recharge" to="/mine/recharge">
            充值1
          </MenuItem>
          <MenuItem name="/mine/rechargelist" to="/mine/rechargelist">
            充值记录2
          </MenuItem>
          <MenuItem name="/mine/account" to="/mine/account">
            资金账户3
          </MenuItem>
          <MenuItem name="/mine/coupon" to="/mine/coupon">
            优惠券4
          </MenuItem>
          <MenuItem name="/index/storeproduct" to="/index/storeproduct">
            收藏商品5
          </MenuItem>
          <MenuItem name="/mine/subcustomerinfo" to="/mine/subcustomerinfo">
            本店信息
          </MenuItem>
          <MenuItem name="/mine/receiveaddress" to="/mine/receiveaddress">
            收货地址
          </MenuItem>
          <MenuItem v-if="userData.admin==1" name="/mine/unitmanage" to="/mine/unitmanage">
            本单位人员管理
          </MenuItem>
          <MenuItem name="/mine/editloginpwd" to="/mine/editloginpwd">
            修改登录密码
          </MenuItem>
          <!--<MenuItem name="/mine/editpaypwd" to="/mine/editpaypwd">-->
          <!--修改支付密码-->
          <!--</MenuItem>-->
          <MenuItem name="/mine/commonproblem" to="/mine/commonproblem">
            常见问题
          </MenuItem>
          <MenuItem name="/mine/contactservice" to="/mine/contactservice">
            联系客服
          </MenuItem>
        </Menu>
      </Col>
    </Row>
  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'

  export default {
    data: () => ({
      activeName: ''
    }),
    created() {
      // this.initData()
    },
    watch: {
      '$route': {
        handler: 'routeChange',
        immediate: true
      }
    },
    computed: {
      ...mapState([]),
      ...mapGetters([
        'userData'
      ])
    },
    methods: {
      ...mapActions([]),
      initData() {
        this.routeChange()
      },
      routeChange() {
        this.activeName = this.$route.path
        if (this.$route.path == '/mine/deliveryaddress') {
          this.activeName = '/mine/orderunit'
        }
      }
    }
  }
</script>

<style lang="less">
  .mine-menu {
    background-color: #f5f5f5;
    position: relative;

    .ivu-menu-horizontal {
      height: 40px;
      line-height: 40px;
      font-weight: 700;
    }

    .menu-wrap {
      background-color: #ffffff;
      text-align: center;
      border-radius: 2px;
    }

    .menu-title-first {
      height: 40px;
      width: 180px;
      padding-top: 10px;
      background-color: #E61E10;
      color: white;
      border-radius: 0;
      text-align: center;
      z-index: 88;
    }

    .ivu-menu-vertical .ivu-menu-item {
      padding: 8px 24px;
    }

    .menu-list-wrap {
      position: absolute;
      z-index: 888;
      height: 418px;
      left: 0px;
      background-color: #ffffff;

      .ivu-menu-item {
        border-bottom: 1px dotted #CCC;
      }
    }

    .menu-list-content {
      position: absolute;
      z-index: 889;
      left: 164px;
      width: 780px;
      height: 418px;
      border: 1px solid #e7e7e7;
      background-color: #ffffff;

      .menu-content {
        padding: 10px 20px;
        height: 100%;
        overflow-y: auto;
        background-color: #fcfcfc;

        .content-l {
          width: 120px;
          height: 40px;
          line-height: 40px;
          position: relative;
          float: left;

          &-title {
            display: inline-block;
            width: 100px;
            font-size: 14px;
            font-weight: 600;
            color: #333333;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            text-align: justify;
            text-align-last: justify;
          }

          &-arror {
            position: absolute;
            top: 10px;
          }
        }

        .content-r {
          float: right;
          width: 600px;
          padding: 10px 0;

          &-title {
            display: inline-block;
            padding: 0 10px 0 0;
            font-size: 14px;
            color: #666666;
            cursor: pointer;
          }

          &-title:hover {
            color: #E61E10;
          }
        }
      }
    }
  }
</style>
