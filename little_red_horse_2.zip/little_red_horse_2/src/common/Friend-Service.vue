<template>
  <div class="frind-service">
    <div class="m-wrap">
      <Row type="flex" justify="space-around" style="margin-left: 20px">
        <template v-for="(item,index) in items">
          <Col span="4" :key="index">
            <div class="item-wrap" :key="index">
              <img :src="item.iconClass" class="item-wrap-img">
              <div class="item-info">
                <p class="item-info-title">{{item.title}}</p>
                <p style="color: grey">{{item.subtitle}}</p>
              </div>
            </div>
          </Col>
        </template>
      </Row>
    </div>
  </div>
</template>

<script>
  export default {
    data: () => ({
      items: [
        {iconClass: require('../assets/images/icon/zhengpin.png'), title: '正品保证', subtitle: '品牌商家授权'},
        {iconClass: require('../assets/images/icon/wuliu.png'), title: '极速物流', subtitle: '多种物流渠道'},
        {iconClass: require('../assets/images/icon/fukuan.png'), title: '方便付款', subtitle: '多种付款方式'},
        {iconClass: require('../assets/images/icon/kaixiang.png'), title: '开箱验', subtitle: '当场开箱验货'},
        {iconClass: require('../assets/images/icon/tiexinfuwu.png'), title: '贴心服务', subtitle: '4000-6868-17'}
      ]
    })
  }
</script>

<style lang="less">

  .frind-service {
    height: 112px;
    padding: 40px 0;
    background-color: #ffffff;
    .item-wrap {
      display: flex;
      justify-content: center;
      .item-wrap-img {
        width: 45px;
        height: 40px;
      }
    }
    .item-info {
      margin-left: 10px;
      &-title{
        font-size: 15px;
        font-weight: 500;
      }
    }
  }
</style>
