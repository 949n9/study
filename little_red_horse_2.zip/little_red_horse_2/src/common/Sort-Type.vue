<template>
  <div class="sort-wrap m-wrap">
    <Row>
      <Col span="2">
        <span class="recent-sort-item">排序： </span>
      </Col>
      <Col span="16">
        <ButtonGroup>
          <Button v-show="$route.path!='/index/recentproduct'" :type="orderCondition==''?'primary':'default'"
                  @click="sortClick('')">综合排序
            <Icon type="md-arrow-round-down"/>
          </Button>
          <Button v-show="$route.path=='/index/recentproduct'"
                  :type="orderCondition=='firstImpTime'?'primary':'default'" @click="sortClick('firstImpTime')">时间排序
            <Icon type="md-arrow-round-down"/>
          </Button>
          <Button :type="orderCondition=='distQty'?'primary':'default'" @click="sortClick('distQty')">库存
            <Icon v-if="distQtyDesc" type="md-arrow-round-up"/>
            <Icon v-else-if="!distQtyDesc" type="md-arrow-round-down"/>
          </Button>
          <Button :type="orderCondition=='taxPrice'?'primary':'default'" @click="sortClick('taxPrice')">价格
            <Icon v-if="taxPriceDesc" type="md-arrow-round-up"/>
            <Icon v-else-if="!taxPriceDesc" type="md-arrow-round-down"/>
          </Button>
          <Button :type="orderCondition=='deliveryFeeReduceRate'?'primary':'default'" @click="sortClick('deliveryFeeReduceRate')"
           v-show="['promotionproduct', 'recentproduct', 'hotproduct', 'searchunifiedproduct', 'resultproduct'].includes($route.name)">物流费减免比例
            <Icon v-if="deliveryFeeReduceRateDesc" type="md-arrow-round-up"/>
            <Icon v-else-if="!deliveryFeeReduceRateDesc" type="md-arrow-round-down"/>
          </Button>
          <Button :type="orderCondition=='date'?'primary':'default'" v-show="$route.path=='/index/supplierproduct'"
                  @click="sortClick('date')">时间
            <Icon v-if="dateDesc" type="md-arrow-round-up"/>
            <Icon v-else-if="!dateDesc" type="md-arrow-round-down"/>
          </Button>
        </ButtonGroup>
      </Col>
      <Col span="4">
        &nbsp;
        <DatePicker type="daterange" v-show="$route.path=='/index/supplierproduct'" v-model="date"
                    @on-change="dateChange" placement="bottom-end" placeholder=""
                    style="width: 180px"></DatePicker>
      </Col>
      <Col span="2">
        <ButtonGroup v-show="!displyShow">
          <Button :type="displyType=='grid'?'primary':'default'" @click="displyClick('grid')">
            <Icon type="ios-grid"/>
          </Button>
          <Button :type="displyType=='list'?'primary':'default'" @click="displyClick('list')">
            <Icon type="md-list"/>
          </Button>
        </ButtonGroup>
      </Col>
    </Row>
  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'

  export default {
    components: {},
    props: ['displyShow'],
    data: () => ({
      orderCondition: '',
      distQtyDesc: false,
      taxPriceDesc: false,
      dateDesc: false,
      deliveryFeeReduceRateDesc: false,
      orderConditionType: 'desc',

      date: [],
      displyType: 'grid'
    }),
    computed: {
      ...mapState([]),
      ...mapGetters([])
    },
    created() {
      if (this.$route.path == '/index/recentproduct') {
        this.orderCondition = 'firstImpTime'
      }
    },
    methods: {
      ...mapActions([]),
      displyClick(v) {
        this.displyType = v
        this.$emit('display', v)
      },
      dateChange(v) {
        console.log(v)
        this.$emit('dateChange', v)
      },
      sortClick(v) {
        console.log(this.orderCondition)
        if (v == 'distQty' && v == this.orderCondition) {
          this.distQtyDesc = !this.distQtyDesc
        }
        if (v == 'taxPrice' && v == this.orderCondition) {
          this.taxPriceDesc = !this.taxPriceDesc
        }
        if (v == 'date' && v == this.orderCondition) {
          this.dateDesc = !this.dateDesc
        }
        if (v == 'deliveryFeeReduceRate' && v == this.orderCondition) {
          this.deliveryFeeReduceRateDesc = !this.deliveryFeeReduceRateDesc
        }
        this.orderCondition = v

        if (v == 'distQty') {
          this.orderConditionType = this.distQtyDesc ? 'asc' : 'desc'
        }
        if (v == 'taxPrice') {
          this.orderConditionType = this.taxPriceDesc ? 'asc' : 'desc'
        }
        if (v == 'date') {
          this.orderConditionType = this.dateDesc ? 'asc' : 'desc'
        }
        if (v == 'deliveryFeeReduceRate') {
          this.orderConditionType = this.deliveryFeeReduceRateDesc ? 'asc' : 'desc'
        }
        console.log(this.orderConditionType)
        let obj = {
          orderCondition: this.orderCondition,
          orderConditionType: this.orderConditionType
        }
        this.$emit('sort', obj)
      }
    }
  }
</script>

<style lang="less">

  .sort-wrap {
    height: 60px;
    line-height: 60px;
    border: 1px solid #cccccc;
    background-color: #ffffff;
    .recent-sort-item {
      margin-left: 25px;
      font-size: 14px;
    }
  }
</style>
