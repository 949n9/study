<template>
  <div class="selector-header">
    <Row class="m-wrap" style="margin-bottom: -20px;height: 40px">
      <Col span="24">
        <span class="search-text"
              v-show="productCategoryName||productBrandName||productPropertyName||supplierName">全部结果 ></span>
        <Tag closable color="default" style="border: 1px solid #E61E10" v-show="productCategoryName"
             @on-close="tagClose('category')">品类：{{ productCategoryName }}
        </Tag>
        <Tag closable color="default" style="border: 1px solid #E61E10" v-show="productBrandName"
             @on-close="tagClose('brand')">品牌：{{ productBrandName }}
        </Tag>
        <Tag closable color="default" style="border: 1px solid #E61E10" v-show="productPropertyName"
             @on-close="tagClose('property')">商品属性：{{ productPropertyName }}
        </Tag>
        <Tag closable color="default" style="border: 1px solid #E61E10" v-show="supplierName"
             @on-close="tagClose('supplier')">供货单位：{{ supplierName }}
        </Tag>
      </Col>
    </Row>

    <Row class="recent-wrap search-header">
      <Col class="search-wrap" span="24" v-show="categoryListData.length">
        <div class="search-l">
          <span class="search-l-title">一级品类：</span>
        </div>
        <div class="search-m">
          <ul class="search-m-normal-wrap">
            <li v-for="(item,index) in categoryListData" :key="index" class="search-m-normal-item"
                @mouseleave="btnOut"
            >
              <Button type="text" @mouseenter.native="categoryHover(item.id)"
                      :class="{'btn-select':selectId==item.id}"
                      @click="categoryClick(item)"
              >
                {{item.name}}
                <Icon type="ios-arrow-down"/>
              </Button>
            </li>
          </ul>
        </div>

        <div v-show="categoryWrap" class="second-wrap" @mouseenter="btnOver"
             @mouseleave="btnOut">
          <ul class="second-wrap-ul">
            <li v-for="(item,index) in secondCategory" :key="index" class="second-wrap-li">
              <Button type="text"
                      :class="{'red--text':productCategoryCode==item.code}"
                      @click="categoryClick(item)"> {{item.name}}
              </Button>
            </li>
          </ul>
        </div>

      </Col>
      <Col class="search-wrap" span="24" v-if="brandList.length">
        <div class="search-l">
          <span class="search-l-title">品牌：</span>
        </div>
        <div class="search-m">
          <div class="band-normal">
            <ul class="search-m-normal-wrap">
              <li class="search-m-normal-item">
                <Button class="band-tag" type="text" size="small" @mouseenter.native="selectTag('all')"
                        :class="{'btn-hover':tagHover=='all'}">所有品牌
                </Button>
              </li>
              <li v-for="(item,index) in bandTagList" :key="index" class="search-m-normal-item">
                <Button @mouseenter.native="selectTag(item)" :class="{'btn-hover':tagHover==item}"
                        class="band-tag"
                        type="text" size="small">{{item}}
                </Button>
              </li>
            </ul>
            <ul class="search-m-normal-wrap"
                :class="[bandToggle?'band-wrap-close':'band-wrap-open']"
                v-if="tagHover=='all'">
              <li v-for="(item,index) in brandList" :key="index" class="search-m-normal-item">
                <div class="img-wrap">
                  <img :src="item.icon" alt="" class="img"
                       :title="item.name"
                       :onerror="defaultBimg()"
                       :class="{'img-select':productBrandId==item.id}"
                       @click="brandClick(item)">
                </div>

                <!--<Button class="band-title"-->
                <!--:class="{'btn-select':productBrandId==item.id}"-->
                <!--@click="brandClick(item)"> {{}}-->
                <!--</Button>-->
              </li>
            </ul>
            <ul class="search-m-normal-wrap"
                :class="[bandToggle?'band-wrap-close':'band-wrap-open']"
                v-else>
              <li v-for="(item,index) in pinYinBrand" :key="index" class="search-m-normal-item">
                <div class="img-wrap">
                  <img :src="item.icon" alt="" class="img"
                       :title="item.name"
                       :onerror="defaultBimg()"
                       :class="{'img-select':productBrandId==item.id}"
                       @click="brandClick(item)">
                </div>

                <!--<Button class="band-title"-->
                <!--:class="{'btn-select':productBrandId==item.id}"-->
                <!--@click="brandClick(item)"> {{item.name}}-->
                <!--</Button>-->
              </li>
            </ul>
          </div>
        </div>
        <div class="search-r" v-show="brandList.length>17">
          <Button size="small" @click="toggleBand">{{bandToggle?'更多':'收起'}}
            <Icon type="ios-arrow-down" v-if="bandToggle"/>
            <Icon type="ios-arrow-up" v-else/>
          </Button>
        </div>
      </Col>
      <Col class="search-wrap" span="24" v-if="$route.name=='supplierproduct'&&supplierData.length">
        <div class="search-l">
          <span class="search-l-title">供货单位：</span>
        </div>
        <div class="search-m">
          <ul class="search-m-normal-wrap">
            <li v-for="(item,index) in supplierData" :key="index" class="search-m-normal-item">
              <div>
                <Button type="text"
                        :class="{'btn-select':supplierId==item.id}"
                        @click="supplierClick(item)"> {{item.name}}
                </Button>
              </div>

            </li>
          </ul>
        </div>
        <div class="search-r" v-show="supplierAllData.length>20">
          <Button size="small" @click="togglesupplier">{{supplierToggle?'更多':'收起'}}
            <Icon type="ios-arrow-down" v-if="supplierToggle"/>
            <Icon type="ios-arrow-up" v-else/>
          </Button>
        </div>
      </Col>
      <Col class="search-wrap" span="24">
        <div class="search-l">
          <span class="search-l-title">商品属性：</span>
        </div>
        <div class="search-m">
          <ul class="search-m-normal-wrap">
            <li v-for="(item,index) in propertyData" :key="index" class="search-m-normal-item">
              <div>
                <Button type="text"
                        :class="{'btn-select':productPropertyId==item.id}"
                        @click="propertyClick(item)"> {{item.name}}
                </Button>
              </div>

            </li>
          </ul>
        </div>
      </Col>
    </Row>
  </div>
</template>
<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../core/index'

  export default {
    data: () => ({
      bandTagList: [],
      bandToggle: true,
      supplierToggle: true,
      secondCategory: [],
      secondAllCategory: [],
      parentIdArr: [],

      productCategoryCode: '',
      productCategoryName: '',
      productBrandId: '',
      productBrandName: '',
      productPropertyId: '',
      productPropertyName: '',
      supplierId: '',
      supplierName: '',

      tagHover: 'all',
      parentId: '',
      selectId: '',

      categoryListData: [],
      brandListData: [],
      supplierData: [],
      supplierAllData: [],
      pinYinBrand: {},
      brandList: [],
      categoryWrap: false
    }),
    computed: {
      ...mapState([
        'selectInfo'
      ]),
      ...mapGetters([
        'propertyData'
      ])
    },
    created() {
      this.initData()
    },
    watch: {
      'selectInfo': 'selectInfoChange'
    },
    methods: {
      ...mapActions([
        'getPropertyData',
        'saveSelectInfo'
      ]),
      // 筛选的条件改变时候
      selectInfoChange(v) {
        console.log(v)
        // this.selectId = -1

        if (v.brandId) {
          this.productBrandId = v.brandId
          this.productBrandName = v.brandName
          this.productCategoryCode = ''
          this.productCategoryName = ''
          this.productPropertyName = ''
          this.productPropertyId = ''
          this.supplierId = ''
          this.supplierName = ''
          let obj = {
            productBrandId: v.brandId
          }
          this.handleGetData()
          this.$emit('selectChange', obj)
        }
        if (v.id) {
          if (v.parentId == '0') {
            this.selectId = v.id
          } else {
            this.selectId = v.parentId
          }
          this.productCategoryCode = v.code
          this.productCategoryName = v.name
          this.productBrandId = ''
          this.productBrandName = ''
          this.productPropertyName = ''
          this.productPropertyId = ''
          this.supplierId = ''
          this.supplierName = ''
          let obj = {
            productCategoryCode: v.code
          }
          this.handleGetData()
          this.$emit('selectChange', obj)
        }
      },
      initData() {
        // 假如首次创建的时候 存在选择的品牌或者品类
        if (Object.keys(this.selectInfo).length) {
          this.selectInfoChange(this.selectInfo)
        }
        this.handleGetData()

        // 获取商品属性
        this.getPropertyData({})
        this.getSubList()
      },
      // 获取进货渠道
      async getSubList() {
        let self = this
        let {data} = await api.getCustomerSupplierList({
          pageIndex: 1,
          pageSize: 9999
        })
        if (data.status == 0) {
          self.supplierAllData = data.data.list
          self.supplierData = data.data.list.slice(0, 20)
        }
      },
      // 分类品牌接口 =========
      async handleGetData() {
        let self = this
        let params = {
          categoryCode: self.productCategoryCode,
          brandId: self.productBrandId,
          type: self.changeType()
        }
        let {data} = await api.getCategory(params)
        if (data.status == '0') {
          self.categoryListData = data.data.category
          self.brandListData = data.data.brand

          let brandTag = self.brandListData.pinYinBrand
          console.log(Object.keys(brandTag))
          self.bandTagList = Object.keys(brandTag)
          self.tagHover = 'all'
          self.brandList = self.brandListData.brand
        }
        console.log(data)
      },
      // 区分配置 进行品类和品牌的筛选
      changeType() {
        let type = ''
        let path = this.$route.path
        switch (path) {
          case '/index/fwproduct':
            type = 'service'
            break
          case '/index/supplierproduct':
            type = 'supplier'
            break
          case '/index/promotionproduct':
            type = 'promotion'
            break
          case '/index/recentproduct':
          case '/index/resultproduct':
            type = 'proprietary'
            break
          case '/index/hotproduct':
            type = 'hotSale'
            break
        }
        return type
      },
      // 商品品类选择
      categoryClick(v) {
        console.log(v)
        this.saveSelectInfo({})
        if (v.parentId == '0') {
          this.selectId = v.id
        } else {
          this.selectId = v.parentId
        }

        this.productCategoryCode = v.code
        this.productCategoryName = v.name
        let obj = {
          productCategoryCode: this.productCategoryCode,
          productBrandId: this.productBrandId,
          productPropertyId: this.productPropertyId,
          supplierId: this.supplierId
        }
        // 假如已经选择了 品牌id  那么不在查询handleGetData  直接进行商品查询
        if (this.productCategoryCode == '' || this.productBrandId == '') {
          this.handleGetData()
        }
        this.$emit('selectChange', obj)
      },
      // 商品品牌选择
      brandClick(v) {
        this.saveSelectInfo({})
        this.productBrandId = v.id
        this.productBrandName = v.name
        let obj = {
          productCategoryCode: this.productCategoryCode,
          productBrandId: this.productBrandId,
          productPropertyId: this.productPropertyId,
          supplierId: this.supplierId
        }
        // 假如已经选择了 品类id  那么不在查询handleGetData  直接进行商品查询
        if (this.productBrandId == '' || this.productCategoryCode == '') {
          this.handleGetData()
        }

        this.$emit('selectChange', obj)
      },
      // 商品属性选择
      propertyClick(v) {
        this.productPropertyId = v.id
        this.productPropertyName = v.name
        let obj = {
          productCategoryCode: this.productCategoryCode,
          productBrandId: this.productBrandId,
          productPropertyId: this.productPropertyId,
          supplierId: this.supplierId
        }
        this.$emit('selectChange', obj)
      },
      // 供货单位选择
      supplierClick(v) {
        this.supplierId = v.id
        this.supplierName = v.name
        let obj = {
          productCategoryCode: this.productCategoryCode,
          productBrandId: this.productBrandId,
          productPropertyId: this.productPropertyId,
          supplierId: this.supplierId
        }
        this.$emit('selectChange', obj)
      },
      // 品牌hover时候
      selectTag(v) {
        console.log(v)
        this.tagHover = v
        let arr = this.brandListData.brand
        let obj = this.brandListData.pinYinBrand
        let pinyinArr = obj[v]
        if (v == 'all') {
          if (this.bandToggle) {
            this.brandList = arr.slice(0, 18)
          } else {
            this.brandList = arr
          }
        } else {
          if (this.bandToggle) {
            this.pinYinBrand = pinyinArr.slice(0, 18)
          } else {
            this.pinYinBrand = pinyinArr
          }
        }
      },
      // 清空筛选条件
      tagClose(v) {
        console.log(v)
        this.saveSelectInfo({})
        let obj = {id: '', name: '', code: ''}
        if (v == 'category') {
          this.productCategoryCode = ''
          this.categoryClick(obj)
        } else if (v == 'brand') {
          this.productBrandId = ''
          this.brandClick(obj)
        } else if (v == 'property') {
          this.propertyClick(obj)
        } else if (v == 'supplier') {
          this.supplierClick(obj)
        }
      },
      // 品类hover时候
      categoryHover(v) {
        this.categoryWrap = true
        this.parentId = v
        if (this.parentIdArr.includes(v)) {
          let arr = this.secondAllCategory.filter(item => item.id == v)
          this.secondCategory = arr[0].secondCategory
        } else {
          this.getSecondList(v)
          this.parentIdArr.push(v)
        }
      },
      btnOut() {
        this.categoryWrap = false
      },
      btnOver() {
        this.categoryWrap = true
      },
      // 获取二级分类
      async getSecondList(v) {
        let self = this
        let params = {
          parentId: v
        }
        let {data} = await api.getCategoryList(params)
        console.log(data)
        self.secondCategory = data.data
        let obj = {id: v, secondCategory: self.secondCategory}
        self.secondAllCategory.push(obj)
      },
      // 切换品牌
      toggleBand() {
        console.log(this.bandToggle)
        this.bandToggle = !this.bandToggle

        let arr = this.brandListData.brand
        let obj = this.brandListData.pinYinBrand
        let pinyinArr = obj[this.tagHover]
        if (this.bandToggle) {
          this.brandList = arr.slice(0, 18)
          this.pinYinBrand = pinyinArr.slice(0, 18)
        } else {
          this.brandList = arr
          this.pinYinBrand = pinyinArr
        }
      },
      togglesupplier() {
        this.supplierToggle = !this.supplierToggle
        if (!this.supplierToggle) {
          this.supplierData = this.supplierAllData
        } else {
          this.supplierData = this.supplierAllData.slice(0, 20)
        }
      }
    }
  }
</script>

<style lang="less">

  .selector-header {
    background-color: #F5F5F5;

    .search-text {
      display: inline-block;
      height: 30px;
      line-height: 30px;
      padding: 0 15px;
    }

    .recent-wrap {
      margin: 20px auto;
      width: 1200px;
      background-color: #ffffff;
      padding: 20px 10px;

      .ivu-card-body:hover {
        border: 1px solid red;
        border-radius: 4px;
      }
    }

    .recent-img {
      height: 200px;
      width: 100%;
    }

    .search-header {
      border: 1px solid #cccccc;

      .search-wrap {
        position: relative;
        background-color: #f5f5f5;
        border-bottom: 1px solid #cccccc;

        .search-l {
          float: left;
          height: 100%;
          width: 100px;
          padding-left: 10px;
          background-color: #f5f5f5;

          &-title {
            color: #000;
            line-height: 34px;
            font-size: 14px;
            font-weight: 500;
          }
        }

        .search-m {
          margin-left: 110px;
          padding-right: 50px;
          background-color: #ffffff;

          .band-normal {
            padding: 10px;
          }

          .search-m-normal-wrap {
            overflow: hidden;
            padding: 3px;
            width: 100%;
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-start;
            align-content: flex-start;

            .search-m-normal-item {
              position: relative;

              .btn-hover {
                border: 1px solid #E61E10;
              }

              .band-tag:hover {
                border: 1px solid #E61E10;
              }

              .img-wrap {
                width: 100px;
                height: 60px;
                margin: 2px;
                border: 1px solid #f4f4f4;
              }

              .img {
                display: block;
                width: 98px;
                height: 58px;
                cursor: pointer;
              }
            }
          }

          .band-title {
            height: 38px;
            width: 100px;
            border-radius: 0;
          }

          .band-wrap {
            height: 80px;
          }

          .band-wrap-close {
            height: 133px;
          }

          .band-wrap-open {
            height: 195px;
            overflow: auto;
          }
        }

        .search-r {
          position: absolute;
          width: 50px;
          right: 10px;
          top: 10px;
        }

        .second-wrap {
          display: block;
          position: absolute;
          left: 120px;
          top: 35px;
          width: 980px;
          background: #fcfcfc;
          border-radius: 8px;
          border: 1px solid #cccccc;
          padding: 3px 5px 10px 5px;
          z-index: 10086;

          .second-wrap-ul {
            display: flex;
            flex-wrap: wrap;
          }
        }

        .category-m {
          margin-left: 110px;
          padding-right: 80px;
          background-color: #ffffff;

          .category-m-normal {
            padding: 10px;

            .category-m-normal-wrap {
              overflow: hidden;
              zoom: 1;

              .category-m-normal-item {
                float: left;

                .band-title {
                  border: 0;
                }
              }
            }

            .search-m-normal-open {
              height: 180px;
              overflow: auto;
            }
          }
        }
      }
    }

    .btn-select {
      background-color: #E61E10;
      color: #ffffff;
    }

    .img-select {
      border: 1px solid #E61E10;
    }
  }
</style>
