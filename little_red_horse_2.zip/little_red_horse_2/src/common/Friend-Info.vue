<template>
  <div class="frind-info">
    <div class="m-wrap">
      <Row  type="flex" justify="space-around">
        <Col span="4">
          <ul>
            <li>
              <a href="javascript:void(0)"> <span>新手上路</span><br></a>
            </li>
            <li>
              <a href="javascript:void(0)"> <span>购物流程</span><br></a>
            </li>
            <li>
              <a href="javascript:void(0)"> <span>订单查询</span><br></a>
            </li>
            <li>
              <a href="javascript:void(0)"> <span>常见问题</span><br></a>
            </li>
          </ul>
        </Col>
        <Col span="4">
          <ul>
            <li>
              <a href="javascript:void(0)"> <span>支付方式</span><br></a>
            </li>
            <li>
              <a href="javascript:void(0)"> <span>手机支付</span><br></a>
            </li>
            <li>
              <a href="javascript:void(0)"> <span>电脑支付</span><br></a>
            </li>
            <li>
              <a href="javascript:void(0)"> <span>网银转账</span><br></a>
            </li>
          </ul>
        </Col>
        <Col span="4">
          <ul>
            <li>
              <a href="javascript:void(0)"> <span>配送服务</span><br></a>
            </li>
            <li>
              <a href="javascript:void(0)"> <span>配送范围及收费标准</span><br></a>
            </li>
            <li>
              <a href="javascript:void(0)"> <span>订单进度查询</span><br></a>
            </li>
            <li>
              <a href="javascript:void(0)"> <span>验货与签收</span><br></a>
            </li>
          </ul>
        </Col>
        <Col span="4">
          <ul>
            <li>
              <a href="javascript:void(0)"> <span>售后服务</span><br></a>
            </li>
            <li>
              <a href="javascript:void(0)"> <span>退换货政策</span><br></a>
            </li>
            <li>
              <a href="javascript:void(0)"> <span>退换货流程</span><br></a>
            </li>
            <li>
              <a href="javascript:void(0)"> <span>退款说明</span><br></a>
            </li>
          </ul>
        </Col>
        <Col span="4">
          <ul>
            <li>
              <a href="javascript:void(0)"> <span>商家合作</span><br></a>
            </li>
            <li>
              <a href="javascript:void(0)"> <span>商家入驻</span><br></a>
            </li>
            <li>
              <a href="javascript:void(0)"> <span>商家规则</span><br></a>
            </li>
            <li>
              <a href="javascript:void(0)"> <span>入驻流程</span><br></a>
            </li>
          </ul>
        </Col>
      </Row>
    </div>

  </div>
</template>

<script>
  export default {
    data: () => ({
    }),
    methods: {}
  }
</script>

<style lang="less">

  .frind-info {
    background-color: #ffffff;
    text-align: center;
    padding: 40px 0;
    ul{
      li{
        padding: 5px;
      }
      li:first-child{
        font-size: 20px;
      }
    }
    span {
      white-space: nowrap;
    }
    a {
      color: grey;
    }
    a:hover {
      color: red;
    }
  }
</style>
