<template>
  <div class="header-search">
    <div class="m-wrap">
      <Row type="flex" justify="space-between">
        <Col span="4">
          <div class="m-logo">
            <img
              class="m-logo-img"
              src="../assets/images/logohome.png"
              @click="toHome"
            />
            <div class="m-logo-desc">
              <span>· 中国母婴全品类直供平台 ·</span>
            </div>
          </div>
        </Col>
        <Col span="16">
          <!-- <Row class="m-search">
            <Col>
              <Button
                :type="own?'error':'text'"
                class="search-btn"
                :class="own?'':'red--text'"
                @click="own=true"
              >小红马商城
              </Button>
              <Button
                :type="own?'text':'error'"
                class="search-btn"
                :class="own?'red--text':''"
                @click="own=false"> 服务商商品
              </Button>
            </Col>
          </Row> -->

          <div class="m-search-ipt">
            <form action="javascript:void(0)">
                <Input type="text" v-model.trim="productCondition" class="ipt" search size="large" enter-button
                      @on-search="search"
                      @on-change="showSearchFlag=true"
                      @on-focus="showSearchFlag=true"
                      :maxlength="50"
                      placeholder="商品名称/商品编码/商品条码"/>
            </form>
            <Button type="error" size="large" class="cart-btn" @click="handleJump">
              <Badge :count="getCartNum" class-name="m-badge">
                <Icon type="md-cart" size="22"/>&nbsp;&nbsp;
              </Badge>
              <span>&nbsp;&nbsp;&nbsp;&nbsp;购物车</span>
            </Button>
            <div class="m-search-record" v-if="searchRecord.length&&showSearchFlag" @mouseleave.self="handleMouseout()">
               <div class="m-search-record-con">
                  <div class="m-search-record-item" v-for="(item, index) in searchRecord" :key="index"
                   @click="handleSearch(item)">
                      <p>{{item}}</p>
                      <p>
                        <span>搜索历史</span>
                        <em @click.stop="deleteItem(item, index)">删除</em>
                      </p>
                  </div>
               </div>
               <section><span @click="deteleAll()" :class="{'auto': searchRecord.length>=10}">删除全部</span></section>
            </div>
          </div>
        </Col>

        <Col span="2">
          <Card class="code-wrap" v-show="userData.qrCodeUrl&&showRqcode">
            <div class="close-btn">
              <Icon custom="close-icon" type="ios-close" size="18" @click="closeRqCode()"/>
            </div>
            <p class="code-wrap-text red--text">小红马</p>
            <div>
              <img
                class="code-wrap-img"
                :src="userData.qrCodeUrl"
              >
            </div>
          </Card>
        </Col>
      </Row>
    </div>

  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'

  export default {
    components: {},

    data: () => ({
      own: true,
      productCondition: '',
      showSearchFlag: false,
      showRqcode: true
    }),
    created() {
      this.saveSearchInfo({})
    },
    computed: {
      ...mapState([
        'loading',
        'searchInfo',
        'searchRecord'
      ]),
      ...mapGetters([
        'getCartNum',
        'userData'
      ])
    },
    watch: {
      'searchInfo': 'searchInfoChange',
      '$route': {
        handler: 'routeChange',
        immediate: true
      }
    },
    methods: {
      ...mapActions([
        'saveSearchInfo',
        'saveSearchRecord',
        'getProductUnifiedSearchData',
        'saveSelectInfo',
        'handleBaseDialog'
      ]),
      routeChange() {
        let path = this.$route.path
        if (path == '/index/fwproduct' || path == '/index/searchsupplierproduct') {
          this.own = false
        } else {
          this.own = true
        }
        this.showSearchFlag = false
        this.showRqcode = true
      },
      searchInfoChange(v) {
        console.log(v)
        if (Object.keys(v).length == 0) {
          this.productCondition = ''
        }
      },
      search() {
        // 清空选择的品牌的条件
        this.saveSelectInfo({})
        this.handleSearchRecord()
        this.handleSearch(this.productCondition)
      },
      deteleAll() {
        this.saveSearchRecord([])
      },
      deleteItem(item, index) {
        this.searchRecord.splice(index, 1)
        this.saveSearchRecord(this.searchRecord)
      },
      handleSearch(condition) {
        this.productCondition = condition
        this.saveSearchInfo({type: 'unified', id: condition})
        this.$router.push({path: '/index/searchunifiedproduct'})
        // if (this.own) {
        //   this.saveSearchInfo({type: 'own', id: this.productCondition})
        //   this.$router.push({path: '/index/searchcommonproduct'})
        // } else {
        //   this.saveSearchInfo({type: 'fw', id: this.productCondition})
        //   this.$router.push({path: '/index/searchsupplierproduct'})
        // }
      },
      closeRqCode() {
        this.showRqcode = false
      },
      handleSearchRecord() {
        let searchRecord = this.searchRecord
        if (!searchRecord.includes(this.productCondition) && this.productCondition) {
          searchRecord.push(this.productCondition)
        }
        this.saveSearchRecord(searchRecord)
      },
      handleMouseout() {
        setTimeout(e => {
          this.showSearchFlag = false
        }, 600)
      },
      toHome() {
        this.$router.push('/index/home')
      },
      // 处理购物车跳转
      handleJump() {
        this.handleBaseDialog({visible: true, type: 'cartDialogVisible'})
      }

    }
  }
</script>

<style lang="less">
  .header-search {
    background-color: #ffffff;
    padding: 20px 0;

    .m-logo {
      text-align: center;

      .m-logo-img {
        height: 64px;
        width: 81px;
        cursor: pointer;
      }

      .m-logo-desc {
        height: 22px;
        line-height: 22px;
        border-radius: 11px;
        background-color: #E61E10;
        text-align: center;

        span {
          color: white;
          font-size: 12px;
        }
      }
    }

    .m-search {
      margin-left: 5px;
      width: 100%;

    }

    .m-search-ipt {
      display: flex;
      justify-content: space-between;
      position: relative;
      margin-top: 45px;
      .ipt {
        width: 650px;

        i {
          font-size: 26px;
        }
      }
    }
    .m-search-record{
      position: absolute;
      top:38px;
      left:0;
      background: #ffffff;
      width: 583px;
      z-index:1000;
      border:1px solid #dddddd;
      border-top:0px;
      border-radius: 0 0 8px 8px;
      .m-search-record-con{
        max-height:350px;
        overflow: auto;
        margin-bottom: 38px;
        // position: relative;
      }
      .m-search-record-item{
        display: flex;
        justify-content: space-between;
        padding: 10px 15px;
        font-size: 12px;
        cursor: pointer;
        &:hover{
          background: #FFE6E5;
          span{
            display: none;
          }
          em{
            display: block;
          }
        }
        span{
          color:#999999;
        }
        em{
          display: none;
        }
        p{
          &:first-child{
            color:#4A90E2;
          }
        }
      }
      section{
        cursor: pointer;
        margin:0 15px;
        padding: 10px 0;
        width:calc(100% - 30px);
        display: flex;
        justify-content: flex-end;
        color: #333;
        border-top:1px solid #dddddd;
        position: absolute;
        bottom:0;
        background: #ffffff;
        span{
          &.auto{
             margin-right: 15px;
          }
        }
      }
    }
    .search-btn {
      border-top-left-radius: 8px;
      border-top-right-radius: 8px;
      border-bottom-left-radius: 0;
      border-bottom-right-radius: 0;
      font-weight: 600;
      padding: 3px 10px;
      margin-right: 5px;
    }

    .cart-btn {
      border-radius: 5px;

      .m-badge {
        background: #ffffff !important;
        color: #E61E10;
        border: 1px solid #E61E10;
      }
    }

    .search-tip {
      display: flex;

      a {
        color: #333;
      }

      a:hover {
        color: #E61E10;
      }
    }

    .ivu-card-body {
      padding: 5px 10px;
    }
    .code-wrap {
      width: 100px;
      text-align: center;
      position: relative;
      &:hover{
        .close-icon{
            text-align: center;
            line-height: 18px;
            box-shadow: 1px 1px 6px #dddddd;
            transition: all 0.8s;
        }
      }
      .close-btn{
        position: absolute;
        width: 18px;
        height: 18px;
        top:0;
        left: -19px;
        border:1px solid #DDDDDD;
        border-radius: 2px;
        cursor: pointer;
        display: flex;
        justify-content: center;
        align-items: center;
        .close-icon{
           text-align: center;
           line-height: 18px;
        }
      }
      &-text {
        text-align: center;
        font-size: 14px;
      }

      &-img {
        width: 80px;
        height: 80px;
      }
    }
  }
</style>
