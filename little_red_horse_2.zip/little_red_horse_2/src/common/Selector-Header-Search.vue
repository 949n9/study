<template>
  <div class="selector-header-search">
    <Row class="m-wrap">
      <Col span="24">
        <span class="search-text"
              v-show="productCategoryName||productBrandName||serviceTypeName">全部结果 ></span>
        <Tag closable color="default" style="border: 1px solid #E61E10" v-show="productCategoryName"
             @on-close="tagClose('category')">类别：{{ productCategoryName }}
        </Tag>
        <Tag closable color="default" style="border: 1px solid #E61E10" v-show="productBrandName"
             @on-close="tagClose('brand')">品牌：{{ productBrandName }}
        </Tag>
        <Tag closable color="default" style="border: 1px solid #E61E10" v-show="serviceTypeName"
             @on-close="tagClose('serviceType')">商家类型：{{ serviceTypeName }}
        </Tag>
      </Col>
    </Row>

    <Row class="recent-wrap search-header">
      <Col class="search-wrap" span="24" v-show="categoryListData.length">
        <div class="search-l">
          <span class="search-l-title">类别：</span>
        </div>
        <div class="search-m">
          <ul class="search-m-normal-wrap">
            <li v-for="item in categoryListData" :key="item.code" class="search-m-normal-item search-m-normal-category-item">
              <Button type="text"
                      :class="{'btn-select':item.checked}"
                      @click="categoryClick(item)">
                {{item.name}}
                <!-- <Icon type="ios-arrow-down"/> -->
              </Button>
            </li>
          </ul>
        </div>
      </Col>
      <Col class="search-wrap" span="24" v-if="brandList.length">
        <div class="search-l">
          <span class="search-l-title">品牌：</span>
        </div>
        <div class="search-m">
          <div class="band-normal">
            <ul class="search-m-normal-wrap"
                :class="[bandToggle?'band-wrap-close':'band-wrap-open']">
              <li v-for="item in brandList" :key="item.id" class="search-m-normal-item">
                <div class="img-wrap">
                  <img :src="item.imgUrl" alt="" class="img"
                       :title="item.name"
                       :onerror="defaultBimg()"
                       :class="{'img-select':item.checked}"
                       @click="brandClick(item)">
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div class="search-r" v-show="brandList.length>17">
          <Button size="small" @click="toggleBand">{{bandToggle?'更多':'收起'}}
            <Icon type="ios-arrow-down" v-if="bandToggle"/>
            <Icon type="ios-arrow-up" v-else/>
          </Button>
        </div>
      </Col>
      <Col class="search-wrap" span="24">
        <div class="search-l">
          <span class="search-l-title">商家类型：</span>
        </div>
        <div class="search-m">
          <ul class="search-m-normal-wrap">
            <li v-for="item in businessTypeData" :key="item.value" class="search-m-normal-item">
              <div>
                <Button type="text"
                        :class="{'btn-select':item.checked}"
                        @click="businessTypeClick(item)"> {{item.name}}
                </Button>
              </div>

            </li>
          </ul>
        </div>
      </Col>
    </Row>
  </div>
</template>
<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  // import api from '../core/index'

  export default {
    props: {
    },
    data: () => ({
      bandToggle: true,
      reloadFlag: true,
      productCategoryCode: '',
      productCategoryName: '',
      productBrandId: '',
      productBrandName: '',
      serviceType: '',
      serviceTypeName: '',

      condition: '',
      oldCondition: '',

      categoryListData: [],
      brandListData: [],
      pinYinBrand: {},
      brandList: [],
      businessTypeData: [
        {
          value: '0',
          name: '平台商家',
          checked: false
        },
        {
          value: '1',
          name: '服务商',
          checked: false
        },
         {
          value: '2',
          name: '小红马商城',
          checked: false
        }
      ]
    }),
    computed: {
      ...mapState([
        'searchInfo'
      ]),
      ...mapGetters([
        'searchProductData',
        'userData'
      ])
    },
    created() {
      this.initData()
      console.log(this.data)
    },
    watch: {
      'searchProductData': 'searchProductDataChange',
      'searchInfo': 'searchInfoChange'
    },
    methods: {
      ...mapActions([
      ]),
      initData() {
        this.categoryListData = this.searchProductData.categories
        this.brandListData = this.searchProductData.brands
        this.brandList = this.brandListData.slice(0, 18)
      },
      searchProductDataChange() {
        if (this.reloadFlag) {
          console.log('条件改变了')
          this.categoryListData = this.searchProductData.categories
          this.brandList = this.searchProductData.brands.slice(0, 18)
        }
      },
      searchInfoChange(val, oldval) {
        this.reloadFlag = true
        this.$emit('selectChange', {
          productCategoryCode: '',
          productBrandId: '',
          serviceType: ''
        })
      },
      // 商品品类选择
      categoryClick(v) {
        console.log(v)
        this.reloadFlag = false
        v.checked = !v.checked
        let checkedArr = this.categoryListData.filter(e => {
          return e.checked
        }).map(i => {
          return i.code
        })
        let checkedArrName = this.categoryListData.filter(e => {
          return e.checked
        }).map(i => {
          return i.name
        })
        this.productCategoryCode = checkedArr.join()
        this.productCategoryName = checkedArrName.join()
        console.log('品类选择', this.productCategoryCode, this.productCategoryName)
        this.$emit('selectChange', {
          productCategoryCode: this.productCategoryCode,
          productBrandId: this.productBrandId,
          serviceType: this.serviceType
        })
      },
      // 商品品牌选择
      brandClick(v) {
        this.reloadFlag = false
        v.checked = !v.checked
        let checkedArr = this.brandList.filter(e => {
          return e.checked
        }).map(i => {
          return i.id
        })
        let checkedArrName = this.brandList.filter(e => {
          return e.checked
        }).map(i => {
          return i.name
        })
        this.productBrandId = checkedArr.join()
        this.productBrandName = checkedArrName.join()
        console.log('品牌选择', this.productBrandId, this.productBrandName)
        this.$emit('selectChange', {
          productCategoryCode: this.productCategoryCode,
          productBrandId: this.productBrandId,
          serviceType: this.serviceType
        })
      },
      // 商家类型选择
      businessTypeClick(v) {
        this.reloadFlag = false
        v.checked = !v.checked
        let checkedArr = this.businessTypeData.filter(e => {
          return e.checked
        }).map(i => {
          return i.value
        })
        let checkedArrName = this.businessTypeData.filter(e => {
          return e.checked
        }).map(i => {
          return i.name
        })
        this.serviceType = checkedArr.join()
        this.serviceTypeName = checkedArrName.join()
        console.log('商家选择', this.serviceType, this.serviceTypeName)
        this.$emit('selectChange', {
          productCategoryCode: this.productCategoryCode,
          productBrandId: this.productBrandId,
          serviceType: this.serviceType
        })
      },
      // 清空筛选条件
      tagClose(v) {
        // this.saveSelectInfo({})
        if (v == 'category') {
          this.categoryListData.forEach(e => {
            e.checked = false
          })
          this.categoryClick(this.categoryListData)
        } else if (v == 'brand') {
           this.brandList.forEach(e => {
            e.checked = false
          })
          this.brandClick(this.brandList)
        } else if (v == 'serviceType') {
          this.businessTypeData.forEach(e => {
            e.checked = false
          })
          this.businessTypeClick(this.businessTypeData)
        }
      },
      // 切换品牌
      toggleBand() {
        console.log(this.bandToggle)
        this.bandToggle = !this.bandToggle
        let arr = this.brandListData
        if (this.bandToggle) {
          this.brandList = arr.slice(0, 18)
        } else {
          this.brandList = arr
        }
      }
    }
  }
</script>

<style lang="less">

  .selector-header-search {
    background-color: #F5F5F5;

    .search-text {
      display: inline-block;
      height: 30px;
      line-height: 30px;
      padding: 0 15px;
    }

    .recent-wrap {
      margin: 20px auto;
      width: 1200px;
      background-color: #ffffff;
      padding: 20px 10px;

      .ivu-card-body:hover {
        border: 1px solid red;
        border-radius: 4px;
      }
    }

    .recent-img {
      height: 200px;
      width: 100%;
    }

    .search-header {
      border: 1px solid #cccccc;

      .search-wrap {
        position: relative;
        background-color: #f5f5f5;
        border-bottom: 1px solid #cccccc;

        .search-l {
          float: left;
          height: 100%;
          width: 100px;
          padding-left: 10px;
          background-color: #f5f5f5;

          &-title {
            color: #000;
            line-height: 34px;
            font-size: 14px;
            font-weight: 500;
          }
        }

        .search-m {
          margin-left: 110px;
          padding-right: 50px;
          background-color: #ffffff;

          .band-normal {
            padding: 10px;
          }

          .search-m-normal-wrap {
            overflow: hidden;
            padding: 3px;
            width: 100%;
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-start;
            align-content: flex-start;

            .search-m-normal-item {
              position: relative;
              margin-right: 10px;
              .btn-hover {
                border: 1px solid #E61E10;
              }

              .band-tag:hover {
                border: 1px solid #E61E10;
              }

              .img-wrap {
                width: 100px;
                height: 60px;
                margin: 2px;
                border: 1px solid #f4f4f4;
              }

              .img {
                display: block;
                width: 98px;
                height: 58px;
                cursor: pointer;
              }
            }
            .search-m-normal-category-item{
              margin-bottom: 10px;
            }
          }

          .band-title {
            height: 38px;
            width: 100px;
            border-radius: 0;
          }

          .band-wrap {
            height: 80px;
          }

          .band-wrap-close {
            height: 133px;
          }

          .band-wrap-open {
            height: 195px;
            overflow: auto;
          }
        }

        .search-r {
          position: absolute;
          width: 50px;
          right: 10px;
          top: 10px;
        }

        .second-wrap {
          display: block;
          position: absolute;
          left: 120px;
          top: 35px;
          width: 980px;
          background: #fcfcfc;
          border-radius: 8px;
          border: 1px solid #cccccc;
          padding: 3px 5px 10px 5px;
          z-index: 10086;

          .second-wrap-ul {
            display: flex;
            flex-wrap: wrap;
          }
        }

        .category-m {
          margin-left: 110px;
          padding-right: 80px;
          background-color: #ffffff;

          .category-m-normal {
            padding: 10px;

            .category-m-normal-wrap {
              overflow: hidden;
              zoom: 1;

              .category-m-normal-item {
                float: left;

                .band-title {
                  border: 0;
                }
              }
            }

            .search-m-normal-open {
              height: 180px;
              overflow: auto;
            }
          }
        }
      }
    }

    .btn-select {
      background-color: #E61E10;
      color: #ffffff;
    }

    .img-select {
      border: 1px solid #E61E10;
    }
  }
</style>
