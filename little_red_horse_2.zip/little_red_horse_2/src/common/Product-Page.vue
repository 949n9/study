<template>
  <Row type="flex" justify="end" v-show="pageInfo.totalPage>1">
    <Col>
      <Page :total="pageInfo.dataCount"
            :page-size="pageInfo.pageSize"
            :current="pageInfo.pageIndex"
            :page-size-opts="pageOpts"
            @on-change="pageChange"
            @on-page-size-change="pageSizeChange"
            show-elevator show-total show-sizer/>
    </Col>
  </Row>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'

  export default {
    components: {},
    props: ['pageInfo'],
    data: () => ({
      pageOpts: [50, 100, 200]
    }),
    computed: {
      ...mapState([]),
      ...mapGetters([])
    },
    created() {
    },
    methods: {
      ...mapActions([]),
      pageChange(v) {
        let path = this.$route.path
        let obj = {
          pageIndex: v,
          route: path
        }
        this.$emit('pageChange', obj)
      },
      pageSizeChange(v) {
        console.log(v)
        let path = this.$route.path
        let obj = {
          pageSize: v,
          route: path
        }
        this.$emit('pageSizeChange', obj)
      }
    }
  }
</script>

<style lang="less">

  .sort-wrap {
    height: 60px;
    line-height: 60px;
    border: 1px solid #cccccc;
    background-color: #ffffff;
    .recent-sort-item {
      margin-left: 25px;
      font-size: 14px;
    }
  }
</style>
