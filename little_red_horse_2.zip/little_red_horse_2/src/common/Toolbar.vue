<template>
  <div class="toolbar">
    <ul>
      <li @mouseover="toolbarHover('mine')" @mouseout="toolbarHover('')" @click="handleTab('mine')">
        <a href="javascript:void(0)" style="position: relative">
          <div v-show="tag=='mine'"
               class="tab-hide">
            <span class="tab-hide-text">个人中心</span>
          </div>
          <div class="tab-item">
            <Icon type="ios-contact" color="white" size="20"/>
          </div>
        </a>
      </li>

      <li @mouseover="toolbarHover('cart')" @mouseout="toolbarHover('')" @click="handleTab('cart')">
        <a href="javascript:void(0)" style="position: relative">
          <div v-show="tag=='cart'"
               class="tab-hide">
            <span class="tab-hide-text">购物车</span>
          </div>
          <div class="tab-item">
            <Badge :count="getCartNum" class-name="m-badge">
              <Icon type="md-cart" color="white" size="20"/>
            </Badge>
          </div>
        </a>
      </li>
      <li @mouseover="toolbarHover('top')" @mouseout="toolbarHover('')" @click="handleTab('top')">
        <a href="javascript:void(0)" style="position: relative">
          <div v-show="tag=='top'"
               class="tab-hide">
            <span class="tab-hide-text">顶部</span>
          </div>
          <div class="tab-item">
            <Icon type="md-arrow-round-up" color="white" size="20"/>
          </div>
        </a>
      </li>
      <li @mouseover="toolbarHover('phone')" @mouseout="toolbarHover('')" @click="handleTab('phone')">
        <a href="javascript:void(0)" style="position: relative">
          <div v-show="tag=='phone'"
               class="tab-hide">
            <span class="tab-hide-text">4000686817</span>
          </div>
          <div class="tab-item">
            <Icon type="md-call" color="white" size="20"/>
          </div>
        </a>
      </li>
      <li @mouseover="toolbarHover('contact')" @mouseout="toolbarHover('')" @click="handleTab('contact')">
        <a href="javascript:void(0)" style="position: relative">
          <div v-show="tag=='contact'"
               class="tab-hide">
            <span class="tab-hide-text">在线客服</span>
          </div>
          <div class="tab-item">
            <Icon type="ios-chatboxes-outline" style="font-weight: 700;" color="#ffffff" size="20"/>
          </div>
        </a>
      </li>
    </ul>
  </div>
</template>
<script>

  import {mapState, mapGetters, mapActions} from 'vuex'

  export default {
    name: 'Index',
    components: {},
    data: () => ({
      tag: '',
      easemobim: {}
    }),
    computed: {
      ...mapState([
        'loading'
      ]),
      ...mapGetters([
        'getCartNum',
        'userData'
      ])
    },
    created() {
      this.easemobim = window.easemobim || {}
      this.easemobim.config = {
        hide: true,
        autoConnect: true
      }
    },
    methods: {
      ...mapActions([
        'handleBaseDialog'
      ]),
      // 点击tab
      handleTab(v) {
        console.log(v)
        if (v == 'top') {
          window.scrollTo(0, 0)
        }
        if (v == 'mine') {
          this.$router.push({path: '/mine/personalcenter'})
        }
        if (v == 'cart') {
          // 处理购物车跳转
          this.handleBaseDialog({visible: true, type: 'cartDialogVisible'})
        }
        if (v == 'contact') {
          console.log(this.userData)
          // 为了实现在退出时候，隐藏客服弹窗，在登录后清除掉样式
          let pany = document.querySelector('.easemobim-chat-panel')
          if (pany) {
            pany.style.display = 'block'
          }
          this.easemobim.bind({
            configId: 'c16fad54-5784-4a5d-b929-b4a53c5b86ff',
            // agentName: '1439281489@qq.com',
            visitor: {
              trueName: this.userData.imName,
              qq: '',
              phone: this.userData.imMobilePhone,
              companyName: this.userData.imCompany,
              userNickname: this.userData.imNickName,
              description: '',
              email: this.userData.imEmail
            }
          })
        }
      },
      // 处理tab item 切换
      toolbarHover(v) {
        this.tag = v
      }
    }
  }
</script>

<style lang="less">
  .toolbar {
    position: fixed;
    right: 10px;
    bottom: 100px;
    z-index: 22;

    .tab-hide {
      position: absolute;
      background-color: #7A7A7A;
      border-left: 1px solid #dddddd;
      border-top: 1px solid #dddddd;
      border-bottom: 1px solid #dddddd;
      width: 100px;
      left: -100px;
      top: 0;
      height: 39px;
      text-align: center;
    }

    .tab-hide-text {
      height: 39px;
      line-height: 39px;
      font-size: 14px;
      color: #ffffff;
      font-weight: 600;
    }

    .tab-hide-phone {
      font-size: 12px;
      color: #ffffff;
      font-weight: 600;
    }

    .tab-item {
      width: 39px;
      height: 39px;
      background-color: #7A7A7A;
      text-align: center;
      line-height: 39px;
      margin-top: 2px;
    }

    .tab-item:hover {
      border-right: 1px solid #dddddd;
      border-top: 1px solid #dddddd;
      border-bottom: 1px solid #dddddd;
    }
  }
</style>
