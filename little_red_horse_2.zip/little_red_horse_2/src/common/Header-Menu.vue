<template>
  <div class="header-menu">
    <div class="m-wrap">
      <Row>
        <Col span="4">
          <Button type="error" class="menu-title-first"
                  @mouseover.native="handleOver"
                  @mouseout.native="handleOut">
            <Icon type="ios-list"  size="20"/>
            全部分类
          </Button>
        </Col>
        <Col span="20">
          <Menu mode="horizontal" :active-name="activeName"
                style="display: flex; background-color: #ffffff;">
            <MenuItem name="/index/home" to="/index/home" class="menu-item">
              首页
            </MenuItem>
            <MenuItem name="/index/promotionproduct" to="/index/promotionproduct" class="menu-item">
              爆品促销
            </MenuItem>
            <MenuItem name="/index/recentproduct" to="/index/recentproduct" class="menu-item">
              新品查询
            </MenuItem>
            <MenuItem name="/index/hotproduct" to="/index/hotproduct" class="menu-item">
              热卖推荐
            </MenuItem>
            <MenuItem name="/index/controlproduct" to="/index/controlproduct" class="menu-item">
              控区控价
            </MenuItem>
            <MenuItem name="/index/fwproduct" to="/index/fwproduct" class="menu-item">
              服务商商品
            </MenuItem>
            <MenuItem name="/index/supplierproduct" to="/index/supplierproduct" class="menu-item">
              厂商直送
            </MenuItem>
            <MenuItem name="mIndex" class="menu-item">
              <span @click="toJump">网站首页</span>
            </MenuItem>
          </Menu>
        </Col>
      </Row>

      <Row class="menu-list-wrap" v-show="showMenu">
        <Col span="2">
          <Menu width="180px" style="background-color: #ffffff;" @on-select="selectMenu" :active-name="activeTypeName">
            <MenuItem v-for="(item,index) in categoryData" :name="item.id" :key="index"
                      style="color:#333333"
                      @mouseenter.native="menuHover(item)"
                      @mouseout.native="menuOut">
              {{item.name}}
              <!--<Icon type="ios-arrow-forward" class="fr" size="16"/>-->
            </MenuItem>
          </Menu>
        </Col>
        <Col span="18" v-show="showMenuWrap">
          <div class="menu-list-content" @mouseover="selectStyle"
               @mouseout="outStyle">
            <div class="menu-content">
              <ul class="menu-content-l">
                <li v-for="(item,index) in secondCategory" :key="index">
                  <div style="display: flex;" class="clearfix">
                    <div class="content-l">
                      <span class="content-l-title" @click="itemSelect(item)">{{item.name}}</span>
                      <Icon type="ios-arrow-forward" class="content-l-arror" size="18"/>
                      <!--<span>|</span>-->
                    </div>
                    <div class="content-r">
                        <span v-for="(i,index) in item.children" :key=index class="content-r-title"
                              @click="itemSelect(i)">{{i.name}}
                          <!--<em :key=index class="content-r-line" v-show="index<item.children.length-1">|</em>-->
                        </span>
                    </div>
                  </div>
                </li>
              </ul>
              <div class="menu-content-r">
                <img v-for="(item,index) in brandList" :key=index class="band-text" @click="itemSelect(item)"
                     :title="item.brandName"
                     :onerror="defaultBimg()"
                     :src="item.logo" alt="">
                <!--<span v-for="(item,index) in brandList" :key=index class="band-text" @click="itemSelect(item)">{{item.brandName}}</span>-->
              </div>
            </div>
          </div>
        </Col>
      </Row>
    </div>

  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../core/index'
  import * as options from '../utils/options'

  export default {
    data: () => ({
      activeName: '/index/home',
      activeTypeName: '',
      isHover: false,
      showMenu: false,
      showMenuWrap: false,
      path: '',
      secondCategory: [],
      secondAllCategory: [],
      brandList: [],
      brandAllList: [],
      parentIdArr: []
    }),
    created() {
      // this.initData()
      this.getData()
    },
    watch: {
      '$route': {
        handler: 'routeChange',
        immediate: true
      },
      'hideMenu': 'hideMenuChange'
    },
    computed: {
      ...mapState([
        'categoryInfo',
        'hideMenu'
      ]),
      ...mapGetters([
        'categoryData'
      ])
    },
    methods: {
      ...mapActions([
        'getCategoryData',
        'saveCategoryInfo',
        'saveSelectInfo',
        'saveSearchInfo'
      ]),
      // 处理 首页 左侧菜单是显示与隐藏
      hideMenuChange(v) {
        console.log(v)
        if (this.isHover) {
        } else {
          this.showMenu = !v
        }
      },
      initData() {
        this.path = this.$route.path
        this.activeName = this.$route.path
        this.activeTypeName = this.$route.path
        if (this.$route.path == '/index/supplierbranddetail') {
          this.activeName = '/index/controlproduct'
        }
        this.handleMenu()
      },
      // 获取全部分类
      getData() {
        this.getCategoryData({parentId: ''})
      },
      // 一级分类
      menuHover(row) {
        this.showMenuWrap = true
        this.showMenu = true
        this.isHover = true
        if (this.parentIdArr.includes(row.id)) {
          let categoryArr = this.secondAllCategory.filter(item => item.id == row.id)
          if (categoryArr.length) {
            this.secondCategory = categoryArr[0].secondCategory || []
          }
          let brandArr = this.brandAllList.filter(item => item.id == row.id)
          if (brandArr.length) {
            this.brandList = brandArr[0].brandList || []
          }
        } else {
          this.getSecondList(row.id)
          this.getBrandList(row)
          this.parentIdArr.push(row.id)
        }
      },
      menuOut() {
        this.showMenuWrap = false
        this.showMenu = false
        this.isHover = false
        this.handleMenu()
      },
      // 选择一级菜单时候
      selectMenu(id) {
        console.log(id)
        let arr = this.categoryData.filter(item => item.id == id)
        console.log(arr)
        this.showMenu = false
        this.itemSelect(arr[0])
      },
      // 点击分类或者点击 品牌时候跳转 (假如已经在结果页面中 那么就让滚动回顶部)
      itemSelect(v) {
        console.log(v)
        this.saveSelectInfo(v)
        this.saveSearchInfo({})
        this.showMenuWrap = false
        this.$router.push({path: '/index/resultproduct'})
        window.scrollTo(0, 0)
      },
      // 获取二级分类
      async getSecondList(v) {
        let self = this
        let params = {
          parentId: v
        }
        let {data} = await api.getProduct2Category(params)
        console.log(data)
        self.secondCategory = data.data
        let obj = {id: v, secondCategory: self.secondCategory}
        self.secondAllCategory.push(obj)
      },
      // 获取对应的品牌
      async getBrandList(row) {
        let self = this
        let params = {
          code: row.code
        }
        let {data} = await api.getCategoryBandList(params)
        console.log(data)
        let arr = data.data.brandsByParentId
        if (arr.length > 14) {
          self.brandList = arr.slice(0, 14)
        } else {
          self.brandList = arr
        }
        let obj = {id: row.id, brandList: self.brandList}
        self.brandAllList.push(obj)
      },
      routeChange() {
        this.initData()
      },
      handleMenu() {
        if (this.path == '/index/home') {
          if (this.hideMenu) {
            this.showMenu = false
          } else {
            this.showMenu = true
          }
        } else {
          this.showMenu = false
        }
      },
      selectStyle() {
        this.showMenuWrap = true
        this.showMenu = true
      },
      outStyle() {
        this.showMenuWrap = false
        this.initData()
      },
      handleOver() {
        this.showMenu = true
      },
      handleOut() {
        console.log(222)
        this.showMenu = false
        this.initData()
      },
      toJump() {
        let url = options.BaseUrl
        window.open(url)
      }
    }
  }
</script>

<style lang="less">

  .header-menu {
    background-color: #ffffff;
    position: relative;

    .menu-item {
      font-size: 16px;
    }

    .ivu-menu-horizontal {
      height: 40px;
      line-height: 40px;
      font-weight: 700;
    }

    .ivu-menu-light.ivu-menu-horizontal .ivu-menu-item-active, .ivu-menu-light.ivu-menu-horizontal .ivu-menu-submenu-active, .ivu-menu-light.ivu-menu-horizontal .ivu-menu-item:hover, .ivu-menu-light.ivu-menu-horizontal .ivu-menu-submenu:hover:hover {
      border-bottom: none;
    }

    .menu-title-first {
      height: 40px;
      width: 180px;
      padding-top: 10px;
      background-color: #E61E10;
      color: white;
      border-radius: 0;
      text-align: center;
      z-index: 88;
    }

    .ivu-menu-vertical .ivu-menu-item {
      padding: 8px 24px;
    }

    .menu-list-wrap {
      position: absolute;
      z-index: 888;
      max-height: 418px;
      left: 0px;
      background-color: #ffffff;

      .ivu-menu-item {
        border-bottom: 1px dotted #CCC;
      }
    }

    .menu-list-content {
      position: absolute;
      z-index: 99999;
      left: 164px;
      width: 1021px;
      min-height: 418px;
      border: 1px solid #e7e7e7;
      background-color: #ffffff;

      .menu-content {
        padding: 10px 20px;
        overflow-y: auto;
        background-color: #fcfcfc;
        display: flex;
        justify-content: space-between;

        .menu-content-l {
          min-height: 396px;

          .content-l {
            width: 110px;
            height: 40px;
            line-height: 40px;
            position: relative;

            &-title {
              display: inline-block;
              width: 85px;
              font-size: 14px;
              font-weight: 600;
              color: #333333;
              overflow: hidden;
              white-space: nowrap;
              text-overflow: ellipsis;
              text-align: center;
              cursor: pointer;
            }

            &-title:hover {
              color: #E61E10;
            }

            &-arror {
              position: absolute;
              top: 10px;
            }
          }

          .content-r {
            width: 666px;
            padding: 10px 0;

            &-title {
              display: inline-block;
              padding: 0 20px 0 0;
              font-size: 14px;
              color: #666666;
              cursor: pointer;
            }

            &-line {
              margin-right: 10px;
            }

            &-title:hover {
              color: #E61E10;
            }
          }
        }

        .menu-content-r {
          display: flex;
          flex-wrap: wrap;
          height: 100%;
          width: 200px;

          .band-text {
            cursor: pointer;
            margin-bottom: 5px;
            margin-right: 2px;
            text-align: center;
            width: 95px;
            line-height: 50px;
            height: 50px;
            border: 1px solid #f4f4f4;
            display: inline-block;
            background-color: #ffffff;
          }
        }

      }
    }
  }
</style>
