<template>
  <div class="header-tab">
    <div class="m-wrap"
    >
      <Menu mode="horizontal" class="tab-menu" @on-select="itemSelect">
        <MenuItem name="0" to="/index/home">
          首页
        </MenuItem>
        <Submenu name="1">
          <template slot="title">
           <span @click="openDialog">
              我的订单
            </span>
          </template>
          <MenuItem name="commonOrder">商城订单</MenuItem>
          <MenuItem name="supplierOrder">厂商直送订单</MenuItem>
        </Submenu>
        <Submenu name="2">
          <template slot="title">
            <span @click="jump('/mine/personalcenter')">
              个人中心
            </span>
          </template>
          <MenuItem name="/mine/recharge" to="/mine/recharge">充值</MenuItem>
          <MenuItem name="/mine/rechargelist" to="/mine/rechargelist">充值记录</MenuItem>
          <MenuItem name="/mine/account" to="/mine/account">资金账户</MenuItem>
          <MenuItem name="/mine/coupon" to="/mine/coupon">优惠券</MenuItem>
          <MenuItem name="/index/storeproduct" to="/index/storeproduct">收藏商品</MenuItem>
          <MenuItem name="/mine/subcustomerinfo" to="/mine/subcustomerinfo">本店信息</MenuItem>
          <MenuItem name="/mine/receiveaddress" to="/mine/receiveaddress">收货地址</MenuItem>
          <MenuItem v-if="userData.admin==1" name="/mine/unitmanage" to="/mine/unitmanage">本单位人员管理</MenuItem>
          <MenuItem name="/mine/editloginpwd" to="/mine/editloginpwd">修改登录密码</MenuItem>
          <!--<MenuItem name="/mine/editpaypwd" to="/mine/editpaypwd">修改支付密码</MenuItem>-->
          <MenuItem name="/mine/commonproblem" to="/mine/commonproblem">常见问题</MenuItem>
          <MenuItem name="/mine/contactservice" to="/mine/contactservice">联系客服</MenuItem>
        </Submenu>

        <div class="spacer"></div>

        <template v-if="tableData.length==1">
          <MenuItem name="4">
            <img src="../assets/images/headicon/house.png" class="menu-item-icon" alt="">&nbsp;&nbsp;
            <span @click="jump('/mine/personalcenter')">
           {{userData.subCustomerName}}
           </span>
          </MenuItem>
        </template>
        <template v-else>
          <Submenu name="4">
            <template slot="title">
              <img src="../assets/images/headicon/house.png" class="menu-item-icon" alt="">&nbsp;&nbsp;
              <span @click="jump('/mine/personalcenter')">
            {{userData.subCustomerName}}
            </span>
            </template>
            <MenuItem v-for="item in tableData" :name="'id'+item.id" :key="item.id">{{item.name}}</MenuItem>
          </Submenu>
        </template>

        <MenuItem name="5">
          <img src="../assets/images/headicon/user.png" class="menu-item-icon" alt="">&nbsp;&nbsp;{{userData.imName}}
        </MenuItem>

        <MenuItem name="6">
          <img src="../assets/images/headicon/tuichu.png" class="menu-item-icon" alt="">&nbsp;&nbsp;退出
        </MenuItem>
      </Menu>
    </div>
  </div>
</template>

<script>
  import {mapState, mapGetters, mapActions} from 'vuex'
  import api from '../core/index'
  import * as types from '@/store/mutation_types'

  export default {
    name: '',
    inject: ['reload'],
    data() {
      return {
        tableData: []
      }
    },
    computed: {
      ...mapState([]),
      ...mapGetters([
        'userData'
      ])
    },
    created() {
      this.getList()
    },
    methods: {
      ...mapActions([
        'selectSub',
        'saveCommonCartNum',
        'saveSupplierCartNum',
        'handleBaseDialog',
        'saveOrderStatus'
      ]),
      async getList() {
        let self = this
        let params = {
          searchCondition: ''
        }
        let {data} = await api.getSubCustomerList(params)
        console.log(data)
        if (data.status == 0) {
          self.tableData = data.data.list
        }
      },
      // 选中相应的菜单时候
      itemSelect(name) {
        console.log(name)
        if (name == '6') {
          this.loginOut()
        } else if (name == 'commonOrder') {
          this.saveOrderStatus({type: 'commonOrder', status: '-1', name: '1'})
          this.handleBaseDialog({visible: true, type: 'orderDialogVisible'})
        } else if (name == 'supplierOrder') {
          this.saveOrderStatus({type: 'supplierOrder', status: '-1', name: '1'})
          this.handleBaseDialog({visible: true, type: 'orderDialogVisible'})
        } else {
          this.selectItem(name)
        }
      },
      // 选择订货单位 判断当前的订货单位id是不是等于 需要切换的订货单位id
      selectItem(id) {
        console.log(id)
        let self = this
        if (id.indexOf('id') > -1) {
          console.log(id.replace('id', ''))
          id = id.replace('id', '')
          if (this.userData.subCustomerId != id) {
            // 选择部门
            self.selectSub({subCustomerId: id}).then(res => {
              let data = res.data
              if (data.status == 0) {
                this.$store.commit(types.USER_INFO, Object.assign({}, data.data, this.userData))
                let query = {
                  supplierId: this.userData.supplierId,
                  userId: this.userData.userId,
                  subcustomerId: this.userData.subCustomerId,
                  intoTypeId: 2,
                  recordType: 1,
                  deviceType: 'pc',
                  sysVersion: window.navigator.appVersion,
                  programType: 3
                }
                api.getGetActionTime(query).then(res => {
                })
                console.log(data.data.totalQty)
                self.saveCommonCartNum(data.data.totalQty)
                self.saveSupplierCartNum(data.data.supplierTotalQty)
                self.$router.replace({name: 'home'})
                self.reload()
              }
            })
          }
        }
      },
      jump(path) {
        this.$router.replace({path: path})
      },
      // 打开订单弹窗
      openDialog() {
        this.saveOrderStatus({type: 'commonOrder', status: '-1', name: '1'})
        this.handleBaseDialog({visible: true, type: 'orderDialogVisible'})
      },
      async loginOut() {
        let self = this
        let query = {
          supplierId: this.userData.supplierId,
          userId: this.userData.userId,
          subcustomerId: this.userData.subCustomerId,
          intoTypeId: 2,
          recordType: 1,
          deviceId: '',
          deviceType: 'pc',
          manufacturer: '',
          model: '',
          sysVersion: '',
          programType: 3
        }
        await api.getGetActionTime(query).then(res => {
        })
        let {data} = await api.LogOut()
        console.log(data)
        if (data.status == 0) {
          localStorage.removeItem('vuex')
          self.$router.replace({path: `/login?v=${new Date().getTime()}`})
          location.replace(location.href)
        } else {
          self.$Notice.error({
            desc: data.message
          })
        }
      }
    }
  }
</script>

<style lang="less">
  .header-tab {
    background-color: #eeeeee;

    .ivu-menu-horizontal {
      height: 40px;
      line-height: 40px;
      font-weight: 700;
    }

    .ivu-menu-item {
      max-width: 220px;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }

    .ivu-menu-light.ivu-menu-horizontal .ivu-menu-item-active, .ivu-menu-light.ivu-menu-horizontal .ivu-menu-submenu-active, .ivu-menu-light.ivu-menu-horizontal .ivu-menu-item:hover, .ivu-menu-light.ivu-menu-horizontal .ivu-menu-submenu:hover:hover {
      border-bottom: none;
    }

    .tab-menu {
      display: flex;
      z-index: 999;
      background-color: #eeeeee;

      .menu-item-icon {
        position: absolute;
        display: inline-block;
        top: 8px;
        left: 0;
        height: 20px;
        width: 20px;
      }
    }
  }
</style>
